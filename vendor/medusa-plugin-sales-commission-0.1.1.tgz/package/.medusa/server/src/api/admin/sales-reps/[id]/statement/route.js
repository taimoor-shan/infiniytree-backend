"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const export_1 = require("../../../../../lib/export");
const report_1 = require("../../../../../lib/report");
const period_activity_1 = require("../../../../../utils/period-activity");
const helpers_1 = require("../../../sales-commission/helpers");
/** A rep's month: commission lines, reversals, adjustments, payouts, totals. */
async function GET(req, res) {
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { period, timezone } = (0, helpers_1.requestedPeriod)(req);
    const { data: [salesRep], } = await query.graph({
        entity: "sales_rep",
        fields: ["id", "name", "email"],
        filters: { id: req.params.id },
    });
    if (!salesRep) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, `Sales rep ${req.params.id} was not found`);
    }
    const activity = await (0, period_activity_1.loadPeriodActivity)(req.scope, {
        period,
        salesRepId: salesRep.id,
    });
    const lines = (0, report_1.statementLines)({ period, ...activity });
    const totals = (0, report_1.summarize)(lines);
    if ((0, helpers_1.wantsCsv)(req)) {
        return (0, helpers_1.sendCsv)(res, `commission-statement-${(0, helpers_1.slug)(salesRep.name)}-${period}.csv`, (0, export_1.statementCsv)({ lines, totals, timezone }));
    }
    res.json({ period, sales_rep: salesRep, lines, totals });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLXJlcHMvW2lkXS9zdGF0ZW1lbnQvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFtQkEsa0JBcUNDO0FBcERELHFEQUdrQztBQUNsQyxzREFBd0Q7QUFDeEQsc0RBQXFFO0FBQ3JFLDBFQUF5RTtBQUN6RSwrREFLMEM7QUFFMUMsZ0ZBQWdGO0FBQ3pFLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQStCLEVBQy9CLEdBQW1CO0lBRW5CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFBO0lBQ2hFLE1BQU0sRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLEdBQUcsSUFBQSx5QkFBZSxFQUFDLEdBQUcsQ0FBQyxDQUFBO0lBRWpELE1BQU0sRUFDSixJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsR0FDakIsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDcEIsTUFBTSxFQUFFLFdBQVc7UUFDbkIsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLENBQUM7UUFDL0IsT0FBTyxFQUFFLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFO0tBQy9CLENBQUMsQ0FBQTtJQUNGLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNkLE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQzNCLGFBQWEsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLGdCQUFnQixDQUMzQyxDQUFBO0lBQ0gsQ0FBQztJQUVELE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBQSxvQ0FBa0IsRUFBQyxHQUFHLENBQUMsS0FBSyxFQUFFO1FBQ25ELE1BQU07UUFDTixVQUFVLEVBQUUsUUFBUSxDQUFDLEVBQUU7S0FDeEIsQ0FBQyxDQUFBO0lBQ0YsTUFBTSxLQUFLLEdBQUcsSUFBQSx1QkFBYyxFQUFDLEVBQUUsTUFBTSxFQUFFLEdBQUcsUUFBUSxFQUFFLENBQUMsQ0FBQTtJQUNyRCxNQUFNLE1BQU0sR0FBRyxJQUFBLGtCQUFTLEVBQUMsS0FBSyxDQUFDLENBQUE7SUFFL0IsSUFBSSxJQUFBLGtCQUFRLEVBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztRQUNsQixPQUFPLElBQUEsaUJBQU8sRUFDWixHQUFHLEVBQ0gsd0JBQXdCLElBQUEsY0FBSSxFQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxNQUFNLE1BQU0sRUFDM0QsSUFBQSxxQkFBWSxFQUFDLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUMxQyxDQUFBO0lBQ0gsQ0FBQztJQUVELEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQTtBQUMxRCxDQUFDIn0=