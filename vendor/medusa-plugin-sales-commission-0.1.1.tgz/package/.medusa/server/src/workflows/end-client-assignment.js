"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.endClientAssignmentWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const end_open_client_assignment_1 = require("./steps/end-open-client-assignment");
const resolve_effective_from_1 = require("./steps/resolve-effective-from");
exports.endClientAssignmentWorkflow = (0, workflows_sdk_1.createWorkflow)("end-client-assignment", function (input) {
    const endedAt = (0, resolve_effective_from_1.resolveEffectiveFromStep)();
    const assignment = (0, end_open_client_assignment_1.endOpenClientAssignmentStep)((0, workflows_sdk_1.transform)({ input, endedAt }, ({ input, endedAt }) => ({
        customer_id: input.customer_id,
        ended_at: endedAt,
        ended_by: input.actor_id ?? null,
        required: true,
    })));
    return new workflows_sdk_1.WorkflowResponse(assignment);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW5kLWNsaWVudC1hc3NpZ25tZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9lbmQtY2xpZW50LWFzc2lnbm1lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscUVBSTBDO0FBQzFDLG1GQUFnRjtBQUNoRiwyRUFBeUU7QUFPNUQsUUFBQSwyQkFBMkIsR0FBRyxJQUFBLDhCQUFjLEVBQ3ZELHVCQUF1QixFQUN2QixVQUFVLEtBQXVDO0lBQy9DLE1BQU0sT0FBTyxHQUFHLElBQUEsaURBQXdCLEdBQUUsQ0FBQTtJQUUxQyxNQUFNLFVBQVUsR0FBRyxJQUFBLHdEQUEyQixFQUM1QyxJQUFBLHlCQUFTLEVBQUMsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNyRCxXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVc7UUFDOUIsUUFBUSxFQUFFLE9BQU87UUFDakIsUUFBUSxFQUFFLEtBQUssQ0FBQyxRQUFRLElBQUksSUFBSTtRQUNoQyxRQUFRLEVBQUUsSUFBSTtLQUNmLENBQUMsQ0FBQyxDQUNKLENBQUE7SUFFRCxPQUFPLElBQUksZ0NBQWdCLENBQUMsVUFBVSxDQUFDLENBQUE7QUFDekMsQ0FBQyxDQUNGLENBQUEifQ==