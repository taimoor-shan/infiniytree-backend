"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assertPayoutCurrency = exports.assertMoney = void 0;
const utils_1 = require("@medusajs/framework/utils");
const money_1 = require("../lib/money");
const invalid = (message) => new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, message);
/** Amounts a rep is paid or adjusted by are in a real currency, to its smallest unit. */
const assertMoney = (amount, currencyCode, label) => {
    if (!(0, money_1.isCurrencyCode)(currencyCode)) {
        throw invalid(`${currencyCode} is not a currency code (use EUR or HUF)`);
    }
    if (!(0, money_1.hasValidPrecision)(amount, currencyCode)) {
        throw invalid(`${label} in ${currencyCode.toUpperCase()} can have at most ${(0, money_1.currencyDecimals)(currencyCode)} decimals`);
    }
};
exports.assertMoney = assertMoney;
/** A rep with a payout currency is paid and adjusted in that currency only. */
const assertPayoutCurrency = (rep, currencyCode) => {
    const own = rep.payout_currency_code?.toLowerCase();
    if (own && own !== currencyCode.toLowerCase()) {
        throw invalid(`${rep.name} is paid in ${own.toUpperCase()}. Use ${own.toUpperCase()} instead of ${currencyCode.toUpperCase()}`);
    }
};
exports.assertPayoutCurrency = assertPayoutCurrency;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGF5b3V0LXJ1bGVzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3V0aWxzL3BheW91dC1ydWxlcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxREFBdUQ7QUFDdkQsd0NBSXFCO0FBRXJCLE1BQU0sT0FBTyxHQUFHLENBQUMsT0FBZSxFQUFFLEVBQUUsQ0FDbEMsSUFBSSxtQkFBVyxDQUFDLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQTtBQUUxRCx5RkFBeUY7QUFDbEYsTUFBTSxXQUFXLEdBQUcsQ0FDekIsTUFBYyxFQUNkLFlBQW9CLEVBQ3BCLEtBQWEsRUFDYixFQUFFO0lBQ0YsSUFBSSxDQUFDLElBQUEsc0JBQWMsRUFBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1FBQ2xDLE1BQU0sT0FBTyxDQUFDLEdBQUcsWUFBWSwwQ0FBMEMsQ0FBQyxDQUFBO0lBQzFFLENBQUM7SUFDRCxJQUFJLENBQUMsSUFBQSx5QkFBaUIsRUFBQyxNQUFNLEVBQUUsWUFBWSxDQUFDLEVBQUUsQ0FBQztRQUM3QyxNQUFNLE9BQU8sQ0FDWCxHQUFHLEtBQUssT0FBTyxZQUFZLENBQUMsV0FBVyxFQUFFLHFCQUFxQixJQUFBLHdCQUFnQixFQUFDLFlBQVksQ0FBQyxXQUFXLENBQ3hHLENBQUE7SUFDSCxDQUFDO0FBQ0gsQ0FBQyxDQUFBO0FBYlksUUFBQSxXQUFXLGVBYXZCO0FBRUQsK0VBQStFO0FBQ3hFLE1BQU0sb0JBQW9CLEdBQUcsQ0FDbEMsR0FBMkQsRUFDM0QsWUFBb0IsRUFDcEIsRUFBRTtJQUNGLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxXQUFXLEVBQUUsQ0FBQTtJQUNuRCxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUssWUFBWSxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQUM7UUFDOUMsTUFBTSxPQUFPLENBQ1gsR0FBRyxHQUFHLENBQUMsSUFBSSxlQUFlLEdBQUcsQ0FBQyxXQUFXLEVBQUUsU0FBUyxHQUFHLENBQUMsV0FBVyxFQUFFLGVBQWUsWUFBWSxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQ2pILENBQUE7SUFDSCxDQUFDO0FBQ0gsQ0FBQyxDQUFBO0FBVlksUUFBQSxvQkFBb0Isd0JBVWhDIn0=