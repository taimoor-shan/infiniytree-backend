"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.grantPortalAccessWorkflow = void 0;
const core_flows_1 = require("@medusajs/medusa/core-flows");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const ensure_portal_auth_identity_1 = require("./steps/ensure-portal-auth-identity");
const set_sales_rep_auth_identity_1 = require("./steps/set-sales-rep-auth-identity");
const validate_portal_access_target_1 = require("./steps/validate-portal-access-target");
/**
 * Gives a rep a sales portal login using Medusa's own auth: a login for their
 * email, linked to them as the `sales_rep` actor. Signing in, forgot-password
 * and password reset are Medusa's `/auth/sales_rep/emailpass` routes; the rep
 * sets a first password with forgot-password. Granting again after a revoke
 * reuses the same login, so the rep keeps their password.
 */
exports.grantPortalAccessWorkflow = (0, workflows_sdk_1.createWorkflow)("grant-portal-access", function (input) {
    const salesRep = (0, validate_portal_access_target_1.validatePortalAccessTargetStep)(input);
    const identity = (0, ensure_portal_auth_identity_1.ensurePortalAuthIdentityStep)((0, workflows_sdk_1.transform)({ salesRep }, ({ salesRep }) => ({
        email: salesRep.email,
        sales_rep_id: salesRep.id,
    })));
    // A login kept from an earlier grant is already linked, and Medusa's step
    // refuses to set a key that exists
    (0, workflows_sdk_1.when)({ identity }, ({ identity }) => !identity.already_linked).then(() => {
        (0, core_flows_1.setAuthAppMetadataStep)((0, workflows_sdk_1.transform)({ identity, salesRep }, ({ identity, salesRep }) => ({
            authIdentityId: identity.auth_identity_id,
            actorType: "sales_rep",
            value: salesRep.id,
        })));
    });
    (0, set_sales_rep_auth_identity_1.setSalesRepAuthIdentityStep)((0, workflows_sdk_1.transform)({ identity, salesRep }, ({ identity, salesRep }) => ({
        sales_rep_id: salesRep.id,
        auth_identity_id: identity.auth_identity_id,
    })));
    return new workflows_sdk_1.WorkflowResponse((0, workflows_sdk_1.transform)({ salesRep }, ({ salesRep }) => ({
        id: salesRep.id,
        email: salesRep.email,
    })));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhbnQtcG9ydGFsLWFjY2Vzcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3MvZ3JhbnQtcG9ydGFsLWFjY2Vzcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSw0REFBb0U7QUFDcEUscUVBSzBDO0FBQzFDLHFGQUFrRjtBQUNsRixxRkFBaUY7QUFDakYseUZBQXNGO0FBSXRGOzs7Ozs7R0FNRztBQUNVLFFBQUEseUJBQXlCLEdBQUcsSUFBQSw4QkFBYyxFQUNyRCxxQkFBcUIsRUFDckIsVUFBVSxLQUFxQztJQUM3QyxNQUFNLFFBQVEsR0FBRyxJQUFBLDhEQUE4QixFQUFDLEtBQUssQ0FBQyxDQUFBO0lBRXRELE1BQU0sUUFBUSxHQUFHLElBQUEsMERBQTRCLEVBQzNDLElBQUEseUJBQVMsRUFBQyxFQUFFLFFBQVEsRUFBRSxFQUFFLENBQUMsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUN6QyxLQUFLLEVBQUUsUUFBUSxDQUFDLEtBQUs7UUFDckIsWUFBWSxFQUFFLFFBQVEsQ0FBQyxFQUFFO0tBQzFCLENBQUMsQ0FBQyxDQUNKLENBQUE7SUFFRCwwRUFBMEU7SUFDMUUsbUNBQW1DO0lBQ25DLElBQUEsb0JBQUksRUFBQyxFQUFFLFFBQVEsRUFBRSxFQUFFLENBQUMsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtRQUN2RSxJQUFBLG1DQUFzQixFQUNwQixJQUFBLHlCQUFTLEVBQUMsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUM3RCxjQUFjLEVBQUUsUUFBUSxDQUFDLGdCQUFnQjtZQUN6QyxTQUFTLEVBQUUsV0FBVztZQUN0QixLQUFLLEVBQUUsUUFBUSxDQUFDLEVBQUU7U0FDbkIsQ0FBQyxDQUFDLENBQ0osQ0FBQTtJQUNILENBQUMsQ0FBQyxDQUFBO0lBRUYsSUFBQSx5REFBMkIsRUFDekIsSUFBQSx5QkFBUyxFQUFDLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxFQUFFLENBQUMsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDN0QsWUFBWSxFQUFFLFFBQVEsQ0FBQyxFQUFFO1FBQ3pCLGdCQUFnQixFQUFFLFFBQVEsQ0FBQyxnQkFBZ0I7S0FDNUMsQ0FBQyxDQUFDLENBQ0osQ0FBQTtJQUVELE9BQU8sSUFBSSxnQ0FBZ0IsQ0FDekIsSUFBQSx5QkFBUyxFQUFDLEVBQUUsUUFBUSxFQUFFLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ3pDLEVBQUUsRUFBRSxRQUFRLENBQUMsRUFBRTtRQUNmLEtBQUssRUFBRSxRQUFRLENBQUMsS0FBSztLQUN0QixDQUFDLENBQUMsQ0FDSixDQUFBO0FBQ0gsQ0FBQyxDQUNGLENBQUEifQ==