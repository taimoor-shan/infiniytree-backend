"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
/**
 * An exchange rate for one day: how many units of the quote currency one unit
 * of the base currency buys. Commission earned in one currency is converted
 * to a rep's payout currency at the rate of the day it was earned, and the
 * rate used is stored on the entry, so these rows can change without
 * touching anything already earned.
 */
const FxRate = utils_1.model
    .define("fx_rate", {
    id: utils_1.model.id({ prefix: "scfx" }).primaryKey(),
    base_currency_code: utils_1.model.text(),
    quote_currency_code: utils_1.model.text(),
    rate_date: utils_1.model.text(),
    rate: utils_1.model.bigNumber(),
    source: utils_1.model.text(),
    created_by: utils_1.model.text().nullable(),
})
    .indexes([
    {
        on: ["base_currency_code", "quote_currency_code", "rate_date"],
        unique: true,
        where: "deleted_at IS NULL",
    },
]);
exports.default = FxRate;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZngtcmF0ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL3NhbGVzLWNvbW1pc3Npb24vbW9kZWxzL2Z4LXJhdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBaUQ7QUFFakQ7Ozs7OztHQU1HO0FBQ0gsTUFBTSxNQUFNLEdBQUcsYUFBSztLQUNqQixNQUFNLENBQUMsU0FBUyxFQUFFO0lBQ2pCLEVBQUUsRUFBRSxhQUFLLENBQUMsRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsVUFBVSxFQUFFO0lBQzdDLGtCQUFrQixFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDaEMsbUJBQW1CLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUNqQyxTQUFTLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUN2QixJQUFJLEVBQUUsYUFBSyxDQUFDLFNBQVMsRUFBRTtJQUN2QixNQUFNLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUNwQixVQUFVLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtDQUNwQyxDQUFDO0tBQ0QsT0FBTyxDQUFDO0lBQ1A7UUFDRSxFQUFFLEVBQUUsQ0FBQyxvQkFBb0IsRUFBRSxxQkFBcUIsRUFBRSxXQUFXLENBQUM7UUFDOUQsTUFBTSxFQUFFLElBQUk7UUFDWixLQUFLLEVBQUUsb0JBQW9CO0tBQzVCO0NBQ0YsQ0FBQyxDQUFBO0FBRUosa0JBQWUsTUFBTSxDQUFBIn0=