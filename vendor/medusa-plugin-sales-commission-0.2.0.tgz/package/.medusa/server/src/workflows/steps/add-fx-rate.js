"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addFxRateStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const fx_1 = require("../../lib/fx");
const sales_commission_1 = require("../../modules/sales-commission");
/** A rate entered by hand, for a day the ECB file is missing or unusable. */
exports.addFxRateStep = (0, workflows_sdk_1.createStep)("add-fx-rate", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    if (!(input.rate > 0)) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, "A rate must be above zero");
    }
    const [existing] = await service.listFxRates({
        base_currency_code: fx_1.FX_BASE,
        quote_currency_code: fx_1.FX_QUOTE,
        rate_date: input.rate_date,
    }, { take: 1, select: ["id"] });
    if (existing) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, `A rate for ${input.rate_date} already exists. Entries already earned keep the rate they were earned at`);
    }
    const created = await service.createFxRates({
        base_currency_code: fx_1.FX_BASE,
        quote_currency_code: fx_1.FX_QUOTE,
        rate_date: input.rate_date,
        rate: input.rate,
        source: "manual",
        created_by: input.created_by ?? null,
    });
    return new workflows_sdk_1.StepResponse(created, created.id);
}, async (id, { container }) => {
    if (!id) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.deleteFxRates(id);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWRkLWZ4LXJhdGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL3N0ZXBzL2FkZC1meC1yYXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFEQUF1RDtBQUN2RCxxRUFBNEU7QUFDNUUscUNBQWdEO0FBQ2hELHFFQUF3RTtBQVd4RSw2RUFBNkU7QUFDaEUsUUFBQSxhQUFhLEdBQUcsSUFBQSwwQkFBVSxFQUNyQyxhQUFhLEVBQ2IsS0FBSyxFQUFFLEtBQXlCLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQ2pELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUN0QixNQUFNLElBQUksbUJBQVcsQ0FBQyxtQkFBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsMkJBQTJCLENBQUMsQ0FBQTtJQUNwRixDQUFDO0lBQ0QsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLFdBQVcsQ0FDMUM7UUFDRSxrQkFBa0IsRUFBRSxZQUFPO1FBQzNCLG1CQUFtQixFQUFFLGFBQVE7UUFDN0IsU0FBUyxFQUFFLEtBQUssQ0FBQyxTQUFTO0tBQzNCLEVBQ0QsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQzVCLENBQUE7SUFDRCxJQUFJLFFBQVEsRUFBRSxDQUFDO1FBQ2IsTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFDOUIsY0FBYyxLQUFLLENBQUMsU0FBUywyRUFBMkUsQ0FDekcsQ0FBQTtJQUNILENBQUM7SUFFRCxNQUFNLE9BQU8sR0FBRyxNQUFNLE9BQU8sQ0FBQyxhQUFhLENBQUM7UUFDMUMsa0JBQWtCLEVBQUUsWUFBTztRQUMzQixtQkFBbUIsRUFBRSxhQUFRO1FBQzdCLFNBQVMsRUFBRSxLQUFLLENBQUMsU0FBUztRQUMxQixJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUk7UUFDaEIsTUFBTSxFQUFFLFFBQVE7UUFDaEIsVUFBVSxFQUFFLEtBQUssQ0FBQyxVQUFVLElBQUksSUFBSTtLQUNyQyxDQUFDLENBQUE7SUFFRixPQUFPLElBQUksNEJBQVksQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQzlDLENBQUMsRUFDRCxLQUFLLEVBQUUsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUMxQixJQUFJLENBQUMsRUFBRSxFQUFFLENBQUM7UUFDUixPQUFNO0lBQ1IsQ0FBQztJQUNELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sT0FBTyxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQTtBQUNqQyxDQUFDLENBQ0YsQ0FBQSJ9