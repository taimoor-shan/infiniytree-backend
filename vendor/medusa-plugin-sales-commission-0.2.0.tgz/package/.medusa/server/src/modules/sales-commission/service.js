"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const client_assignment_1 = __importDefault(require("./models/client-assignment"));
const commission_adjustment_1 = __importDefault(require("./models/commission-adjustment"));
const commission_entry_1 = __importDefault(require("./models/commission-entry"));
const commission_payout_1 = __importDefault(require("./models/commission-payout"));
const fx_rate_1 = __importDefault(require("./models/fx-rate"));
const period_approval_1 = __importDefault(require("./models/period-approval"));
const rep_invite_1 = __importDefault(require("./models/rep-invite"));
const rep_referral_1 = __importDefault(require("./models/rep-referral"));
const sales_rep_1 = __importDefault(require("./models/sales-rep"));
const sales_rep_contract_1 = __importDefault(require("./models/sales-rep-contract"));
class SalesCommissionModuleService extends (0, utils_1.MedusaService)({
    SalesRep: sales_rep_1.default,
    SalesRepContract: sales_rep_contract_1.default,
    ClientAssignment: client_assignment_1.default,
    RepReferral: rep_referral_1.default,
    CommissionEntry: commission_entry_1.default,
    CommissionAdjustment: commission_adjustment_1.default,
    CommissionPayout: commission_payout_1.default,
    PeriodApproval: period_approval_1.default,
    FxRate: fx_rate_1.default,
    RepInvite: rep_invite_1.default,
}) {
    constructor(container, options) {
        super(...arguments);
        this.options_ = {
            ...options,
            timezone: options?.timezone ?? "Europe/Budapest",
        };
    }
    getOptions() {
        return this.options_;
    }
}
exports.default = SalesCommissionModuleService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL3NhbGVzLWNvbW1pc3Npb24vc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLHFEQUF5RDtBQUN6RCxtRkFBeUQ7QUFDekQsMkZBQWlFO0FBQ2pFLGlGQUF1RDtBQUN2RCxtRkFBeUQ7QUFDekQsK0RBQXFDO0FBQ3JDLCtFQUFxRDtBQUNyRCxxRUFBMkM7QUFDM0MseUVBQStDO0FBQy9DLG1FQUF5QztBQUN6QyxxRkFBMEQ7QUF1QjFELE1BQU0sNEJBQTZCLFNBQVEsSUFBQSxxQkFBYSxFQUFDO0lBQ3ZELFFBQVEsRUFBUixtQkFBUTtJQUNSLGdCQUFnQixFQUFoQiw0QkFBZ0I7SUFDaEIsZ0JBQWdCLEVBQWhCLDJCQUFnQjtJQUNoQixXQUFXLEVBQVgsc0JBQVc7SUFDWCxlQUFlLEVBQWYsMEJBQWU7SUFDZixvQkFBb0IsRUFBcEIsK0JBQW9CO0lBQ3BCLGdCQUFnQixFQUFoQiwyQkFBZ0I7SUFDaEIsY0FBYyxFQUFkLHlCQUFjO0lBQ2QsTUFBTSxFQUFOLGlCQUFNO0lBQ04sU0FBUyxFQUFULG9CQUFTO0NBQ1YsQ0FBQztJQUdBLFlBQVksU0FBa0MsRUFBRSxPQUFnQztRQUM5RSxLQUFLLENBQUMsR0FBRyxTQUFTLENBQUMsQ0FBQTtRQUNuQixJQUFJLENBQUMsUUFBUSxHQUFHO1lBQ2QsR0FBRyxPQUFPO1lBQ1YsUUFBUSxFQUFFLE9BQU8sRUFBRSxRQUFRLElBQUksaUJBQWlCO1NBQ2pELENBQUE7SUFDSCxDQUFDO0lBRUQsVUFBVTtRQUNSLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQTtJQUN0QixDQUFDO0NBQ0Y7QUFFRCxrQkFBZSw0QkFBNEIsQ0FBQSJ9