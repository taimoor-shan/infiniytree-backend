"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const sales_commission_1 = require("../../../../../modules/sales-commission");
const applications_1 = require("../../../../../utils/applications");
const invites_1 = require("../../../../../utils/invites");
/**
 * One application with the recruiter, the terms the approval form starts
 * with, and anything that would stop an approval, so it is shown up front.
 */
async function GET(req, res) {
    const service = req.scope.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const invite = await service.retrieveRepInvite(req.params.id);
    // A recruiter who was deleted since leaves the record of an old application
    const [recruiter] = await service.listSalesReps({ id: invite.recruiter_sales_rep_id }, { take: 1 });
    const settings = (0, invites_1.recruitingSettings)(service);
    res.json({
        application: (0, applications_1.adminApplicationView)(invite, recruiter),
        recruiter: recruiter
            ? {
                id: recruiter.id,
                name: recruiter.name,
                email: recruiter.email,
                is_active: recruiter.is_active,
            }
            : null,
        defaults: {
            level2_rate: settings.level2_default_rate,
            level2_months: settings.level2_default_months,
        },
        blockers: await (0, applications_1.approvalBlockers)(req.scope, invite, recruiter),
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLWNvbW1pc3Npb24vYXBwbGljYXRpb25zL1tpZF0vcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFnQkEsa0JBZ0NDO0FBNUNELDhFQUFpRjtBQUVqRixvRUFHMEM7QUFDMUMsMERBQWlFO0FBRWpFOzs7R0FHRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQStCLEVBQy9CLEdBQW1CO0lBRW5CLE1BQU0sT0FBTyxHQUFpQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFFRCxNQUFNLE1BQU0sR0FBRyxNQUFNLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBQzdELDRFQUE0RTtJQUM1RSxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsTUFBTSxPQUFPLENBQUMsYUFBYSxDQUM3QyxFQUFFLEVBQUUsRUFBRSxNQUFNLENBQUMsc0JBQXNCLEVBQUUsRUFDckMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQ1osQ0FBQTtJQUNELE1BQU0sUUFBUSxHQUFHLElBQUEsNEJBQWtCLEVBQUMsT0FBTyxDQUFDLENBQUE7SUFFNUMsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNQLFdBQVcsRUFBRSxJQUFBLG1DQUFvQixFQUFDLE1BQU0sRUFBRSxTQUFTLENBQUM7UUFDcEQsU0FBUyxFQUFFLFNBQVM7WUFDbEIsQ0FBQyxDQUFDO2dCQUNFLEVBQUUsRUFBRSxTQUFTLENBQUMsRUFBRTtnQkFDaEIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxJQUFJO2dCQUNwQixLQUFLLEVBQUUsU0FBUyxDQUFDLEtBQUs7Z0JBQ3RCLFNBQVMsRUFBRSxTQUFTLENBQUMsU0FBUzthQUMvQjtZQUNILENBQUMsQ0FBQyxJQUFJO1FBQ1IsUUFBUSxFQUFFO1lBQ1IsV0FBVyxFQUFFLFFBQVEsQ0FBQyxtQkFBbUI7WUFDekMsYUFBYSxFQUFFLFFBQVEsQ0FBQyxxQkFBcUI7U0FDOUM7UUFDRCxRQUFRLEVBQUUsTUFBTSxJQUFBLCtCQUFnQixFQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLFNBQVMsQ0FBQztLQUMvRCxDQUFDLENBQUE7QUFDSixDQUFDIn0=