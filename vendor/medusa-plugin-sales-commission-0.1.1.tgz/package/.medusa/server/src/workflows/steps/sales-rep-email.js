"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assertEmailAvailable = exports.normalizeEmail = void 0;
const utils_1 = require("@medusajs/framework/utils");
const normalizeEmail = (email) => email.trim().toLowerCase();
exports.normalizeEmail = normalizeEmail;
/** Throws if another (non-deleted) rep already uses `email`. */
const assertEmailAvailable = async (service, email, exceptSalesRepId) => {
    const [existing] = await service.listSalesReps({ email }, { take: 1, select: ["id"] });
    if (existing && existing.id !== exceptSalesRepId) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, `A sales rep with email ${email} already exists`);
    }
};
exports.assertEmailAvailable = assertEmailAvailable;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2FsZXMtcmVwLWVtYWlsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9zYWxlcy1yZXAtZW1haWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQXVEO0FBR2hELE1BQU0sY0FBYyxHQUFHLENBQUMsS0FBYSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUE7QUFBOUQsUUFBQSxjQUFjLGtCQUFnRDtBQUUzRSxnRUFBZ0U7QUFDekQsTUFBTSxvQkFBb0IsR0FBRyxLQUFLLEVBQ3ZDLE9BQXFDLEVBQ3JDLEtBQWEsRUFDYixnQkFBeUIsRUFDekIsRUFBRTtJQUNGLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxhQUFhLENBQzVDLEVBQUUsS0FBSyxFQUFFLEVBQ1QsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQzVCLENBQUE7SUFFRCxJQUFJLFFBQVEsSUFBSSxRQUFRLENBQUMsRUFBRSxLQUFLLGdCQUFnQixFQUFFLENBQUM7UUFDakQsTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFDOUIsMEJBQTBCLEtBQUssaUJBQWlCLENBQ2pELENBQUE7SUFDSCxDQUFDO0FBQ0gsQ0FBQyxDQUFBO0FBaEJZLFFBQUEsb0JBQW9CLHdCQWdCaEMifQ==