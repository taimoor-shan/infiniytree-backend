"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createSalesRepWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const create_sales_rep_1 = require("./steps/create-sales-rep");
exports.createSalesRepWorkflow = (0, workflows_sdk_1.createWorkflow)("create-sales-rep", function (input) {
    const salesRep = (0, create_sales_rep_1.createSalesRepStep)(input);
    return new workflows_sdk_1.WorkflowResponse(salesRep);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLXNhbGVzLXJlcC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3MvY3JlYXRlLXNhbGVzLXJlcC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxRUFHMEM7QUFDMUMsK0RBR2lDO0FBRXBCLFFBQUEsc0JBQXNCLEdBQUcsSUFBQSw4QkFBYyxFQUNsRCxrQkFBa0IsRUFDbEIsVUFBVSxLQUE4QjtJQUN0QyxNQUFNLFFBQVEsR0FBRyxJQUFBLHFDQUFrQixFQUFDLEtBQUssQ0FBQyxDQUFBO0lBRTFDLE9BQU8sSUFBSSxnQ0FBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQTtBQUN2QyxDQUFDLENBQ0YsQ0FBQSJ9