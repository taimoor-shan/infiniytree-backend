"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteCommissionPayoutStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const sales_commission_1 = require("../../modules/sales-commission");
/** Soft-deletes a payout recorded by mistake; the row stays in the database. */
exports.deleteCommissionPayoutStep = (0, workflows_sdk_1.createStep)("delete-commission-payout", async ({ id }, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.retrieveCommissionPayout(id);
    await service.softDeleteCommissionPayouts(id);
    return new workflows_sdk_1.StepResponse(id, id);
}, async (payoutId, { container }) => {
    if (!payoutId) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.restoreCommissionPayouts(payoutId);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVsZXRlLWNvbW1pc3Npb24tcGF5b3V0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9kZWxldGUtY29tbWlzc2lvbi1wYXlvdXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscUVBQTRFO0FBQzVFLHFFQUF3RTtBQUd4RSxnRkFBZ0Y7QUFDbkUsUUFBQSwwQkFBMEIsR0FBRyxJQUFBLDBCQUFVLEVBQ2xELDBCQUEwQixFQUMxQixLQUFLLEVBQUUsRUFBRSxFQUFFLEVBQWtCLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQzlDLE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sT0FBTyxDQUFDLHdCQUF3QixDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBQzFDLE1BQU0sT0FBTyxDQUFDLDJCQUEyQixDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBRTdDLE9BQU8sSUFBSSw0QkFBWSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQTtBQUNqQyxDQUFDLEVBQ0QsS0FBSyxFQUFFLFFBQVEsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDaEMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2QsT0FBTTtJQUNSLENBQUM7SUFDRCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLE9BQU8sQ0FBQyx3QkFBd0IsQ0FBQyxRQUFRLENBQUMsQ0FBQTtBQUNsRCxDQUFDLENBQ0YsQ0FBQSJ9