"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.submitRepApplicationWorkflow = void 0;
const core_flows_1 = require("@medusajs/medusa/core-flows");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const events_1 = require("../events");
const submit_rep_application_1 = require("./steps/submit-rep-application");
/**
 * A candidate applies through their invite link. The owner is told there is
 * an application to review; the rest waits for the owner.
 */
exports.submitRepApplicationWorkflow = (0, workflows_sdk_1.createWorkflow)("submit-rep-application", function (input) {
    const submitted = (0, submit_rep_application_1.submitRepApplicationStep)(input);
    (0, core_flows_1.emitEventStep)({
        eventName: events_1.SalesCommissionEvents.APPLICATION_RECEIVED,
        data: (0, workflows_sdk_1.transform)({ submitted }, ({ submitted }) => ({
            invite_id: submitted.invite.id,
            applicant_name: submitted.invite.applicant_name,
            email: submitted.invite.email,
            phone: submitted.invite.applicant_phone ?? null,
            company: submitted.invite.applicant_company ?? null,
            requested_currency_code: submitted.invite.requested_currency_code ?? null,
            recruiter_name: submitted.recruiter_name,
            locale: submitted.invite.locale ?? null,
        })),
    });
    return new workflows_sdk_1.WorkflowResponse((0, workflows_sdk_1.transform)({ submitted }, ({ submitted }) => ({
        id: submitted.invite.id,
        status: submitted.invite.status,
    })));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3VibWl0LXJlcC1hcHBsaWNhdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3Mvc3VibWl0LXJlcC1hcHBsaWNhdGlvbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSw0REFBMkQ7QUFDM0QscUVBSTBDO0FBQzFDLHNDQUFpRDtBQUNqRCwyRUFHdUM7QUFFdkM7OztHQUdHO0FBQ1UsUUFBQSw0QkFBNEIsR0FBRyxJQUFBLDhCQUFjLEVBQ3hELHdCQUF3QixFQUN4QixVQUFVLEtBQW9DO0lBQzVDLE1BQU0sU0FBUyxHQUFHLElBQUEsaURBQXdCLEVBQUMsS0FBSyxDQUFDLENBQUE7SUFFakQsSUFBQSwwQkFBYSxFQUFDO1FBQ1osU0FBUyxFQUFFLDhCQUFxQixDQUFDLG9CQUFvQjtRQUNyRCxJQUFJLEVBQUUsSUFBQSx5QkFBUyxFQUFDLEVBQUUsU0FBUyxFQUFFLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQ2pELFNBQVMsRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDOUIsY0FBYyxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsY0FBZTtZQUNoRCxLQUFLLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxLQUFLO1lBQzdCLEtBQUssRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLGVBQWUsSUFBSSxJQUFJO1lBQy9DLE9BQU8sRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLGlCQUFpQixJQUFJLElBQUk7WUFDbkQsdUJBQXVCLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyx1QkFBdUIsSUFBSSxJQUFJO1lBQ3pFLGNBQWMsRUFBRSxTQUFTLENBQUMsY0FBYztZQUN4QyxNQUFNLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxNQUFNLElBQUksSUFBSTtTQUN4QyxDQUFDLENBQUM7S0FDSixDQUFDLENBQUE7SUFFRixPQUFPLElBQUksZ0NBQWdCLENBQ3pCLElBQUEseUJBQVMsRUFBQyxFQUFFLFNBQVMsRUFBRSxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUMzQyxFQUFFLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBQ3ZCLE1BQU0sRUFBRSxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU07S0FDaEMsQ0FBQyxDQUFDLENBQ0osQ0FBQTtBQUNILENBQUMsQ0FDRixDQUFBIn0=