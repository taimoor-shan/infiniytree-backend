"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesCommissionEvents = void 0;
/**
 * Events emitted as people join the sales team. The shop's own subscribers
 * turn them into emails; each carries everything its email needs, and the
 * ones with a `token` carry a secret link token, so they must not be logged.
 */
exports.SalesCommissionEvents = {
    /** An invite was sent, or sent again: email the candidate their link */
    INVITE_SENT: "sales-commission.invite.sent",
    /** A candidate applied: tell the owner there is something to review */
    APPLICATION_RECEIVED: "sales-commission.application.received",
    /** The owner approved: welcome the new rep and tell the recruiter */
    APPLICATION_APPROVED: "sales-commission.application.approved",
    /** The owner declined: tell the candidate and the recruiter */
    APPLICATION_DECLINED: "sales-commission.application.declined",
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXZlbnRzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL2V2ZW50cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQTs7OztHQUlHO0FBQ1UsUUFBQSxxQkFBcUIsR0FBRztJQUNuQyx3RUFBd0U7SUFDeEUsV0FBVyxFQUFFLDhCQUE4QjtJQUMzQyx1RUFBdUU7SUFDdkUsb0JBQW9CLEVBQUUsdUNBQXVDO0lBQzdELHFFQUFxRTtJQUNyRSxvQkFBb0IsRUFBRSx1Q0FBdUM7SUFDN0QsK0RBQStEO0lBQy9ELG9CQUFvQixFQUFFLHVDQUF1QztDQUNyRCxDQUFBIn0=