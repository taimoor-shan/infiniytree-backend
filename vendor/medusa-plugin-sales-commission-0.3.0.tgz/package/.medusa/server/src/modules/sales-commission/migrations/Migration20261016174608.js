"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migration20261016174608 = void 0;
const migrations_1 = require("@medusajs/framework/mikro-orm/migrations");
class Migration20261016174608 extends migrations_1.Migration {
    async up() {
        this.addSql(`alter table if exists "sales_rep" drop constraint if exists "sales_rep_client_link_code_unique";`);
        this.addSql(`alter table if exists "link_claim" drop constraint if exists "link_claim_customer_id_unique";`);
        this.addSql(`create table if not exists "link_claim" ("id" text not null, "customer_id" text not null, "code" text not null, "sales_rep_id" text null, "outcome" text check ("outcome" in ('credited', 'unknown_code', 'rep_inactive', 'no_rate', 'own_account', 'existing_client')) not null, "assignment_id" text null, "client_name" text not null, "client_email" text not null, "created_at" timestamptz not null default now(), "updated_at" timestamptz not null default now(), "deleted_at" timestamptz null, constraint "link_claim_pkey" primary key ("id"));`);
        this.addSql(`CREATE INDEX IF NOT EXISTS "IDX_link_claim_deleted_at" ON "link_claim" ("deleted_at") WHERE deleted_at IS NULL;`);
        this.addSql(`CREATE UNIQUE INDEX IF NOT EXISTS "IDX_link_claim_customer_id_unique" ON "link_claim" ("customer_id") WHERE deleted_at IS NULL;`);
        this.addSql(`CREATE INDEX IF NOT EXISTS "IDX_link_claim_sales_rep_id" ON "link_claim" ("sales_rep_id") WHERE deleted_at IS NULL;`);
        this.addSql(`alter table if exists "sales_rep" add column if not exists "client_link_code" text null, add column if not exists "default_client_rate" numeric null, add column if not exists "locale" text null, add column if not exists "raw_default_client_rate" jsonb null;`);
        this.addSql(`CREATE UNIQUE INDEX IF NOT EXISTS "IDX_sales_rep_client_link_code_unique" ON "sales_rep" ("client_link_code") WHERE client_link_code IS NOT NULL AND deleted_at IS NULL;`);
        this.addSql(`alter table if exists "client_assignment" add column if not exists "source" text check ("source" in ('admin', 'link')) not null default 'admin', add column if not exists "link_code" text null;`);
    }
    async down() {
        this.addSql(`drop table if exists "link_claim" cascade;`);
        this.addSql(`drop index if exists "IDX_sales_rep_client_link_code_unique";`);
        this.addSql(`alter table if exists "sales_rep" drop column if exists "client_link_code", drop column if exists "default_client_rate", drop column if exists "locale", drop column if exists "raw_default_client_rate";`);
        this.addSql(`alter table if exists "client_assignment" drop column if exists "source", drop column if exists "link_code";`);
    }
}
exports.Migration20261016174608 = Migration20261016174608;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWlncmF0aW9uMjAyNjEwMTYxNzQ2MDguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9zYWxlcy1jb21taXNzaW9uL21pZ3JhdGlvbnMvTWlncmF0aW9uMjAyNjEwMTYxNzQ2MDgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEseUVBQXFFO0FBRXJFLE1BQWEsdUJBQXdCLFNBQVEsc0JBQVM7SUFFM0MsS0FBSyxDQUFDLEVBQUU7UUFDZixJQUFJLENBQUMsTUFBTSxDQUFDLGtHQUFrRyxDQUFDLENBQUM7UUFDaEgsSUFBSSxDQUFDLE1BQU0sQ0FBQywrRkFBK0YsQ0FBQyxDQUFDO1FBQzdHLElBQUksQ0FBQyxNQUFNLENBQUMsNGhCQUE0aEIsQ0FBQyxDQUFDO1FBQzFpQixJQUFJLENBQUMsTUFBTSxDQUFDLGlIQUFpSCxDQUFDLENBQUM7UUFDL0gsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpSUFBaUksQ0FBQyxDQUFDO1FBQy9JLElBQUksQ0FBQyxNQUFNLENBQUMscUhBQXFILENBQUMsQ0FBQztRQUVuSSxJQUFJLENBQUMsTUFBTSxDQUFDLG1RQUFtUSxDQUFDLENBQUM7UUFDalIsSUFBSSxDQUFDLE1BQU0sQ0FBQywwS0FBMEssQ0FBQyxDQUFDO1FBRXhMLElBQUksQ0FBQyxNQUFNLENBQUMsa01BQWtNLENBQUMsQ0FBQztJQUNsTixDQUFDO0lBRVEsS0FBSyxDQUFDLElBQUk7UUFDakIsSUFBSSxDQUFDLE1BQU0sQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFDO1FBRTFELElBQUksQ0FBQyxNQUFNLENBQUMsK0RBQStELENBQUMsQ0FBQztRQUM3RSxJQUFJLENBQUMsTUFBTSxDQUFDLDJNQUEyTSxDQUFDLENBQUM7UUFFek4sSUFBSSxDQUFDLE1BQU0sQ0FBQyw4R0FBOEcsQ0FBQyxDQUFDO0lBQzlILENBQUM7Q0FFRjtBQXpCRCwwREF5QkMifQ==