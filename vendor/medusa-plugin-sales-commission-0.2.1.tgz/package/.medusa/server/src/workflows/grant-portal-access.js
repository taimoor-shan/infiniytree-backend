"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.grantPortalAccessWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const ensure_portal_auth_identity_1 = require("./steps/ensure-portal-auth-identity");
const link_portal_auth_identity_1 = require("./steps/link-portal-auth-identity");
const set_sales_rep_auth_identity_1 = require("./steps/set-sales-rep-auth-identity");
const validate_portal_access_target_1 = require("./steps/validate-portal-access-target");
/**
 * Gives a rep a sales portal login using Medusa's own auth: a login for their
 * email, linked to them as the `sales_rep` actor. Signing in, forgot-password
 * and password reset are Medusa's `/auth/sales_rep/emailpass` routes; the rep
 * sets a first password with forgot-password. Granting again after a revoke
 * reuses the same login, so the rep keeps their password.
 */
exports.grantPortalAccessWorkflow = (0, workflows_sdk_1.createWorkflow)("grant-portal-access", function (input) {
    const salesRep = (0, validate_portal_access_target_1.validatePortalAccessTargetStep)(input);
    const identity = (0, ensure_portal_auth_identity_1.ensurePortalAuthIdentityStep)((0, workflows_sdk_1.transform)({ salesRep }, ({ salesRep }) => ({
        email: salesRep.email,
        sales_rep_id: salesRep.id,
    })));
    // A login kept from an earlier grant is already linked to this rep
    (0, workflows_sdk_1.when)({ identity }, ({ identity }) => !identity.already_linked).then(() => {
        (0, link_portal_auth_identity_1.linkPortalAuthIdentityStep)((0, workflows_sdk_1.transform)({ identity, salesRep }, ({ identity, salesRep }) => ({
            auth_identity_id: identity.auth_identity_id,
            sales_rep_id: salesRep.id,
        })));
    });
    (0, set_sales_rep_auth_identity_1.setSalesRepAuthIdentityStep)((0, workflows_sdk_1.transform)({ identity, salesRep }, ({ identity, salesRep }) => ({
        sales_rep_id: salesRep.id,
        auth_identity_id: identity.auth_identity_id,
    })));
    return new workflows_sdk_1.WorkflowResponse((0, workflows_sdk_1.transform)({ salesRep }, ({ salesRep }) => ({
        id: salesRep.id,
        email: salesRep.email,
    })));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhbnQtcG9ydGFsLWFjY2Vzcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3MvZ3JhbnQtcG9ydGFsLWFjY2Vzcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxRUFLMEM7QUFDMUMscUZBQWtGO0FBQ2xGLGlGQUE4RTtBQUM5RSxxRkFBaUY7QUFDakYseUZBQXNGO0FBSXRGOzs7Ozs7R0FNRztBQUNVLFFBQUEseUJBQXlCLEdBQUcsSUFBQSw4QkFBYyxFQUNyRCxxQkFBcUIsRUFDckIsVUFBVSxLQUFxQztJQUM3QyxNQUFNLFFBQVEsR0FBRyxJQUFBLDhEQUE4QixFQUFDLEtBQUssQ0FBQyxDQUFBO0lBRXRELE1BQU0sUUFBUSxHQUFHLElBQUEsMERBQTRCLEVBQzNDLElBQUEseUJBQVMsRUFBQyxFQUFFLFFBQVEsRUFBRSxFQUFFLENBQUMsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUN6QyxLQUFLLEVBQUUsUUFBUSxDQUFDLEtBQUs7UUFDckIsWUFBWSxFQUFFLFFBQVEsQ0FBQyxFQUFFO0tBQzFCLENBQUMsQ0FBQyxDQUNKLENBQUE7SUFFRCxtRUFBbUU7SUFDbkUsSUFBQSxvQkFBSSxFQUFDLEVBQUUsUUFBUSxFQUFFLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1FBQ3ZFLElBQUEsc0RBQTBCLEVBQ3hCLElBQUEseUJBQVMsRUFBQyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQzdELGdCQUFnQixFQUFFLFFBQVEsQ0FBQyxnQkFBZ0I7WUFDM0MsWUFBWSxFQUFFLFFBQVEsQ0FBQyxFQUFFO1NBQzFCLENBQUMsQ0FBQyxDQUNKLENBQUE7SUFDSCxDQUFDLENBQUMsQ0FBQTtJQUVGLElBQUEseURBQTJCLEVBQ3pCLElBQUEseUJBQVMsRUFBQyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQzdELFlBQVksRUFBRSxRQUFRLENBQUMsRUFBRTtRQUN6QixnQkFBZ0IsRUFBRSxRQUFRLENBQUMsZ0JBQWdCO0tBQzVDLENBQUMsQ0FBQyxDQUNKLENBQUE7SUFFRCxPQUFPLElBQUksZ0NBQWdCLENBQ3pCLElBQUEseUJBQVMsRUFBQyxFQUFFLFFBQVEsRUFBRSxFQUFFLENBQUMsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUN6QyxFQUFFLEVBQUUsUUFBUSxDQUFDLEVBQUU7UUFDZixLQUFLLEVBQUUsUUFBUSxDQUFDLEtBQUs7S0FDdEIsQ0FBQyxDQUFDLENBQ0osQ0FBQTtBQUNILENBQUMsQ0FDRixDQUFBIn0=