"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendRepInviteAgainStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const invite_1 = require("../../lib/invite");
const recruiting_errors_1 = require("../../lib/recruiting-errors");
const sales_commission_1 = require("../../modules/sales-commission");
const invites_1 = require("../../utils/invites");
const invalid = (message, code) => new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, message, code);
/**
 * Gives an invite nobody has answered a new link and a new expiry. The old
 * link stops working, so a link that was forwarded or mistyped can be
 * replaced. Only the rep who invited can do this, and not within a minute of
 * the last send.
 */
exports.sendRepInviteAgainStep = (0, workflows_sdk_1.createStep)("send-rep-invite-again", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const settings = (0, invites_1.recruitingSettings)(service);
    const now = new Date();
    const [invite] = await service.listRepInvites({ id: input.invite_id, recruiter_sales_rep_id: input.recruiter_sales_rep_id }, { take: 1 });
    if (!invite) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, "Invitation not found");
    }
    if (invite.status !== "invited") {
        throw invalid("Only an invitation that hasn't been answered can be sent again", recruiting_errors_1.RECRUITING_ERRORS.INVITE_NOT_PENDING);
    }
    if (invite.last_sent_at &&
        now.getTime() - new Date(invite.last_sent_at).getTime() < invites_1.RESEND_COOLDOWN_MS) {
        throw invalid("Wait a minute before sending the invitation again", recruiting_errors_1.RECRUITING_ERRORS.INVITE_COOLDOWN);
    }
    const recruiter = await service.retrieveSalesRep(input.recruiter_sales_rep_id);
    const [existingRep] = await service.listSalesReps({ email: invite.email }, { take: 1, select: ["id"] });
    if (existingRep) {
        throw invalid(`${invite.email} is already a sales rep`, recruiting_errors_1.RECRUITING_ERRORS.INVITE_ALREADY_REP);
    }
    const { token, hash } = (0, invite_1.newInviteToken)();
    const updated = await service.updateRepInvites({
        id: invite.id,
        token_hash: hash,
        expires_at: (0, invite_1.inviteExpiry)(now, settings.invite_days),
        last_sent_at: now,
        locale: (0, invites_1.normalizeLocale)(input.locale) ?? invite.locale,
    });
    return new workflows_sdk_1.StepResponse({ invite: updated, token, recruiter_name: recruiter.name }, {
        id: invite.id,
        token_hash: invite.token_hash,
        expires_at: invite.expires_at,
        last_sent_at: invite.last_sent_at,
        locale: invite.locale,
    });
}, async (prior, { container }) => {
    if (!prior) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.updateRepInvites(prior);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VuZC1yZXAtaW52aXRlLWFnYWluLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9zZW5kLXJlcC1pbnZpdGUtYWdhaW4udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQXVEO0FBQ3ZELHFFQUE0RTtBQUM1RSw2Q0FBK0Q7QUFDL0QsbUVBQTZGO0FBQzdGLHFFQUF3RTtBQUV4RSxpREFJNEI7QUFRNUIsTUFBTSxPQUFPLEdBQUcsQ0FBQyxPQUFlLEVBQUUsSUFBeUIsRUFBRSxFQUFFLENBQzdELElBQUksbUJBQVcsQ0FBQyxtQkFBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFBO0FBRWhFOzs7OztHQUtHO0FBQ1UsUUFBQSxzQkFBc0IsR0FBRyxJQUFBLDBCQUFVLEVBQzlDLHVCQUF1QixFQUN2QixLQUFLLEVBQUUsS0FBa0MsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDMUQsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxRQUFRLEdBQUcsSUFBQSw0QkFBa0IsRUFBQyxPQUFPLENBQUMsQ0FBQTtJQUM1QyxNQUFNLEdBQUcsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFBO0lBRXRCLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxjQUFjLENBQzNDLEVBQUUsRUFBRSxFQUFFLEtBQUssQ0FBQyxTQUFTLEVBQUUsc0JBQXNCLEVBQUUsS0FBSyxDQUFDLHNCQUFzQixFQUFFLEVBQzdFLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUNaLENBQUE7SUFDRCxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDWixNQUFNLElBQUksbUJBQVcsQ0FBQyxtQkFBVyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsc0JBQXNCLENBQUMsQ0FBQTtJQUM1RSxDQUFDO0lBQ0QsSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQ2hDLE1BQU0sT0FBTyxDQUNYLGdFQUFnRSxFQUNoRSxxQ0FBSyxDQUFDLGtCQUFrQixDQUN6QixDQUFBO0lBQ0gsQ0FBQztJQUNELElBQ0UsTUFBTSxDQUFDLFlBQVk7UUFDbkIsR0FBRyxDQUFDLE9BQU8sRUFBRSxHQUFHLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxPQUFPLEVBQUUsR0FBRyw0QkFBa0IsRUFDNUUsQ0FBQztRQUNELE1BQU0sT0FBTyxDQUFDLG1EQUFtRCxFQUFFLHFDQUFLLENBQUMsZUFBZSxDQUFDLENBQUE7SUFDM0YsQ0FBQztJQUVELE1BQU0sU0FBUyxHQUFHLE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxDQUFBO0lBQzlFLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxhQUFhLENBQy9DLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLLEVBQUUsRUFDdkIsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQzVCLENBQUE7SUFDRCxJQUFJLFdBQVcsRUFBRSxDQUFDO1FBQ2hCLE1BQU0sT0FBTyxDQUFDLEdBQUcsTUFBTSxDQUFDLEtBQUsseUJBQXlCLEVBQUUscUNBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFBO0lBQ25GLENBQUM7SUFFRCxNQUFNLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLElBQUEsdUJBQWMsR0FBRSxDQUFBO0lBQ3hDLE1BQU0sT0FBTyxHQUFHLE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUFDO1FBQzdDLEVBQUUsRUFBRSxNQUFNLENBQUMsRUFBRTtRQUNiLFVBQVUsRUFBRSxJQUFJO1FBQ2hCLFVBQVUsRUFBRSxJQUFBLHFCQUFZLEVBQUMsR0FBRyxFQUFFLFFBQVEsQ0FBQyxXQUFXLENBQUM7UUFDbkQsWUFBWSxFQUFFLEdBQUc7UUFDakIsTUFBTSxFQUFFLElBQUEseUJBQWUsRUFBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksTUFBTSxDQUFDLE1BQU07S0FDdkQsQ0FBQyxDQUFBO0lBRUYsT0FBTyxJQUFJLDRCQUFZLENBQ3JCLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFFLFNBQVMsQ0FBQyxJQUFJLEVBQUUsRUFDMUQ7UUFDRSxFQUFFLEVBQUUsTUFBTSxDQUFDLEVBQUU7UUFDYixVQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVU7UUFDN0IsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO1FBQzdCLFlBQVksRUFBRSxNQUFNLENBQUMsWUFBWTtRQUNqQyxNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07S0FDdEIsQ0FDRixDQUFBO0FBQ0gsQ0FBQyxFQUNELEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQzdCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNYLE9BQU07SUFDUixDQUFDO0lBQ0QsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDdkMsQ0FBQyxDQUNGLENBQUEifQ==