"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
/**
 * A rep's invitation of someone to join, and what comes of it. The invite
 * link carries a random token; only its hash is stored. An invite is not a
 * rep: nothing is paid and nobody gets access until the owner approves it.
 */
const RepInvite = utils_1.model
    .define("rep_invite", {
    id: utils_1.model.id({ prefix: "srinv" }).primaryKey(),
    recruiter_sales_rep_id: utils_1.model.text(),
    email: utils_1.model.text(),
    name: utils_1.model.text(),
    note: utils_1.model.text().nullable(),
    token_hash: utils_1.model.text(),
    status: utils_1.model
        .enum(["invited", "applied", "approved", "declined", "canceled"])
        .default("invited"),
    expires_at: utils_1.model.dateTime(),
    /** The language of the emails about this invite: the recruiter's portal language */
    locale: utils_1.model.text().nullable(),
    /** When the link was last emailed; sending it again has to wait a minute */
    last_sent_at: utils_1.model.dateTime().nullable(),
    applicant_name: utils_1.model.text().nullable(),
    applicant_phone: utils_1.model.text().nullable(),
    applicant_company: utils_1.model.text().nullable(),
    requested_currency_code: utils_1.model.text().nullable(),
    terms_accepted_at: utils_1.model.dateTime().nullable(),
    applied_at: utils_1.model.dateTime().nullable(),
    decided_by: utils_1.model.text().nullable(),
    decided_at: utils_1.model.dateTime().nullable(),
    decision_reason: utils_1.model.text().nullable(),
    /** The rep created when the owner approved the application */
    sales_rep_id: utils_1.model.text().nullable(),
})
    .indexes([
    { on: ["token_hash"], unique: true, where: "deleted_at IS NULL" },
    {
        on: ["email"],
        unique: true,
        where: "status IN ('invited', 'applied') AND deleted_at IS NULL",
    },
    { on: ["recruiter_sales_rep_id"] },
]);
exports.default = RepInvite;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVwLWludml0ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL3NhbGVzLWNvbW1pc3Npb24vbW9kZWxzL3JlcC1pbnZpdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBaUQ7QUFFakQ7Ozs7R0FJRztBQUNILE1BQU0sU0FBUyxHQUFHLGFBQUs7S0FDcEIsTUFBTSxDQUFDLFlBQVksRUFBRTtJQUNwQixFQUFFLEVBQUUsYUFBSyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDLFVBQVUsRUFBRTtJQUM5QyxzQkFBc0IsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBQ3BDLEtBQUssRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBQ25CLElBQUksRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBQ2xCLElBQUksRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQzdCLFVBQVUsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBQ3hCLE1BQU0sRUFBRSxhQUFLO1NBQ1YsSUFBSSxDQUFDLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxVQUFVLEVBQUUsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1NBQ2hFLE9BQU8sQ0FBQyxTQUFTLENBQUM7SUFDckIsVUFBVSxFQUFFLGFBQUssQ0FBQyxRQUFRLEVBQUU7SUFDNUIsb0ZBQW9GO0lBQ3BGLE1BQU0sRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQy9CLDRFQUE0RTtJQUM1RSxZQUFZLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUN6QyxjQUFjLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUN2QyxlQUFlLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUN4QyxpQkFBaUIsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQzFDLHVCQUF1QixFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDaEQsaUJBQWlCLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUM5QyxVQUFVLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUN2QyxVQUFVLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNuQyxVQUFVLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUN2QyxlQUFlLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUN4Qyw4REFBOEQ7SUFDOUQsWUFBWSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7Q0FDdEMsQ0FBQztLQUNELE9BQU8sQ0FBQztJQUNQLEVBQUUsRUFBRSxFQUFFLENBQUMsWUFBWSxDQUFDLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsb0JBQW9CLEVBQUU7SUFDakU7UUFDRSxFQUFFLEVBQUUsQ0FBQyxPQUFPLENBQUM7UUFDYixNQUFNLEVBQUUsSUFBSTtRQUNaLEtBQUssRUFBRSx5REFBeUQ7S0FDakU7SUFDRCxFQUFFLEVBQUUsRUFBRSxDQUFDLHdCQUF3QixDQUFDLEVBQUU7Q0FDbkMsQ0FBQyxDQUFBO0FBRUosa0JBQWUsU0FBUyxDQUFBIn0=