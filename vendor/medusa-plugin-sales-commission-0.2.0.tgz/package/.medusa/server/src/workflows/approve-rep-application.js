"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.approveRepApplicationWorkflow = void 0;
const core_flows_1 = require("@medusajs/medusa/core-flows");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const events_1 = require("../events");
const grant_portal_access_1 = require("./grant-portal-access");
const create_rep_referral_1 = require("./steps/create-rep-referral");
const create_sales_rep_contract_1 = require("./steps/create-sales-rep-contract");
const create_sales_rep_1 = require("./steps/create-sales-rep");
const create_welcome_token_1 = require("./steps/create-welcome-token");
const mark_application_decided_1 = require("./steps/mark-application-decided");
const resolve_effective_from_1 = require("./steps/resolve-effective-from");
const resolve_level2_expiry_1 = require("./steps/resolve-level2-expiry");
const validate_rep_application_1 = require("./steps/validate-rep-application");
const validate_rep_referral_1 = require("./steps/validate-rep-referral");
/**
 * The owner approves an application, and the whole onboarding happens at
 * once: the rep is created, the recruiter is linked as their referrer from
 * today on the agreed Level 2 terms, the rep gets a portal login, and the
 * welcome email carries a link to set a first password. If any step fails,
 * all of it is undone and the application stays waiting.
 */
exports.approveRepApplicationWorkflow = (0, workflows_sdk_1.createWorkflow)("approve-rep-application", function (input) {
    const application = (0, validate_rep_application_1.validateRepApplicationStep)((0, workflows_sdk_1.transform)({ input }, ({ input }) => ({
        invite_id: input.invite_id,
        for_approval: true,
    })));
    const salesRep = (0, create_sales_rep_1.createSalesRepStep)((0, workflows_sdk_1.transform)({ application, input }, ({ application, input }) => {
        const { invite, recruiter } = application;
        const company = invite.applicant_company
            ? `Company or tax number: ${invite.applicant_company}\n`
            : "";
        return {
            name: invite.applicant_name ?? invite.name,
            email: invite.email,
            phone: invite.applicant_phone,
            notes: `${company}Recruited by ${recruiter.name} through an invitation.`,
            payout_currency_code: input.payout_currency_code ?? null,
        };
    }));
    (0, validate_rep_referral_1.validateRepReferralStep)((0, workflows_sdk_1.transform)({ application, salesRep, input }, ({ application, salesRep, input }) => ({
        referred_sales_rep_id: salesRep.id,
        referrer_sales_rep_id: application.recruiter.id,
        level2_rate: input.level2_rate,
    })));
    const from = (0, resolve_effective_from_1.resolveEffectiveFromStep)();
    const until = (0, resolve_level2_expiry_1.resolveLevel2ExpiryStep)((0, workflows_sdk_1.transform)({ input }, ({ input }) => ({ months: input.level2_months ?? null })));
    (0, create_rep_referral_1.createRepReferralStep)((0, workflows_sdk_1.transform)({ application, salesRep, input, from, until }, ({ application, salesRep, input, from, until }) => ({
        referrer_sales_rep_id: application.recruiter.id,
        referred_sales_rep_id: salesRep.id,
        level2_rate: input.level2_rate,
        starts_at: from,
        expires_at: until,
        created_by: input.actor_id ?? null,
    })));
    grant_portal_access_1.grantPortalAccessWorkflow.runAsStep({
        input: (0, workflows_sdk_1.transform)({ salesRep }, ({ salesRep }) => ({
            sales_rep_id: salesRep.id,
        })),
    });
    (0, workflows_sdk_1.when)({ input }, ({ input }) => !!input.contract).then(() => {
        (0, create_sales_rep_contract_1.createSalesRepContractStep)((0, workflows_sdk_1.transform)({ input, salesRep }, ({ input, salesRep }) => ({
            ...input.contract,
            sales_rep_id: salesRep.id,
            uploaded_by: input.actor_id ?? null,
        })));
    });
    (0, mark_application_decided_1.markApplicationDecidedStep)((0, workflows_sdk_1.transform)({ input, salesRep }, ({ input, salesRep }) => ({
        invite_id: input.invite_id,
        decision: "approved",
        decided_by: input.actor_id ?? null,
        sales_rep_id: salesRep.id,
    })));
    const welcome = (0, create_welcome_token_1.createWelcomeTokenStep)((0, workflows_sdk_1.transform)({ salesRep }, ({ salesRep }) => ({ email: salesRep.email })));
    (0, core_flows_1.emitEventStep)({
        eventName: events_1.SalesCommissionEvents.APPLICATION_APPROVED,
        data: (0, workflows_sdk_1.transform)({ application, salesRep, welcome, input, until }, ({ application, salesRep, welcome, input, until }) => ({
            invite_id: application.invite.id,
            sales_rep_id: salesRep.id,
            name: salesRep.name,
            email: salesRep.email,
            token: welcome.token,
            recruiter: {
                name: application.recruiter.name,
                email: application.recruiter.email,
            },
            level2_rate: input.level2_rate,
            level2_until: until ? new Date(until).toISOString() : null,
            locale: application.invite.locale ?? null,
        })),
    });
    return new workflows_sdk_1.WorkflowResponse((0, workflows_sdk_1.transform)({ salesRep, application }, ({ salesRep, application }) => ({
        sales_rep: salesRep,
        recruiter_id: application.recruiter.id,
    })));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwcm92ZS1yZXAtYXBwbGljYXRpb24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL2FwcHJvdmUtcmVwLWFwcGxpY2F0aW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLDREQUEyRDtBQUMzRCxxRUFLMEM7QUFDMUMsc0NBQWlEO0FBQ2pELCtEQUFpRTtBQUNqRSxxRUFBbUU7QUFDbkUsaUZBQThFO0FBQzlFLCtEQUE2RDtBQUM3RCx1RUFBcUU7QUFDckUsK0VBQTZFO0FBQzdFLDJFQUF5RTtBQUN6RSx5RUFBdUU7QUFDdkUsK0VBQTZFO0FBQzdFLHlFQUF1RTtBQWtCdkU7Ozs7OztHQU1HO0FBQ1UsUUFBQSw2QkFBNkIsR0FBRyxJQUFBLDhCQUFjLEVBQ3pELHlCQUF5QixFQUN6QixVQUFVLEtBQXlDO0lBQ2pELE1BQU0sV0FBVyxHQUFHLElBQUEscURBQTBCLEVBQzVDLElBQUEseUJBQVMsRUFBQyxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNuQyxTQUFTLEVBQUUsS0FBSyxDQUFDLFNBQVM7UUFDMUIsWUFBWSxFQUFFLElBQUk7S0FDbkIsQ0FBQyxDQUFDLENBQ0osQ0FBQTtJQUVELE1BQU0sUUFBUSxHQUFHLElBQUEscUNBQWtCLEVBQ2pDLElBQUEseUJBQVMsRUFBQyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUU7UUFDM0QsTUFBTSxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsR0FBRyxXQUFXLENBQUE7UUFDekMsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLGlCQUFpQjtZQUN0QyxDQUFDLENBQUMsMEJBQTBCLE1BQU0sQ0FBQyxpQkFBaUIsSUFBSTtZQUN4RCxDQUFDLENBQUMsRUFBRSxDQUFBO1FBRU4sT0FBTztZQUNMLElBQUksRUFBRSxNQUFNLENBQUMsY0FBYyxJQUFJLE1BQU0sQ0FBQyxJQUFJO1lBQzFDLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSztZQUNuQixLQUFLLEVBQUUsTUFBTSxDQUFDLGVBQWU7WUFDN0IsS0FBSyxFQUFFLEdBQUcsT0FBTyxnQkFBZ0IsU0FBUyxDQUFDLElBQUkseUJBQXlCO1lBQ3hFLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxvQkFBb0IsSUFBSSxJQUFJO1NBQ3pELENBQUE7SUFDSCxDQUFDLENBQUMsQ0FDSCxDQUFBO0lBRUQsSUFBQSwrQ0FBdUIsRUFDckIsSUFBQSx5QkFBUyxFQUFDLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNqRixxQkFBcUIsRUFBRSxRQUFRLENBQUMsRUFBRTtRQUNsQyxxQkFBcUIsRUFBRSxXQUFXLENBQUMsU0FBUyxDQUFDLEVBQUU7UUFDL0MsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXO0tBQy9CLENBQUMsQ0FBQyxDQUNKLENBQUE7SUFDRCxNQUFNLElBQUksR0FBRyxJQUFBLGlEQUF3QixHQUFFLENBQUE7SUFDdkMsTUFBTSxLQUFLLEdBQUcsSUFBQSwrQ0FBdUIsRUFDbkMsSUFBQSx5QkFBUyxFQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxFQUFFLEtBQUssQ0FBQyxhQUFhLElBQUksSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUMvRSxDQUFBO0lBQ0QsSUFBQSwyQ0FBcUIsRUFDbkIsSUFBQSx5QkFBUyxFQUNQLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUM3QyxDQUFDLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ2xELHFCQUFxQixFQUFFLFdBQVcsQ0FBQyxTQUFTLENBQUMsRUFBRTtRQUMvQyxxQkFBcUIsRUFBRSxRQUFRLENBQUMsRUFBRTtRQUNsQyxXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVc7UUFDOUIsU0FBUyxFQUFFLElBQUk7UUFDZixVQUFVLEVBQUUsS0FBSztRQUNqQixVQUFVLEVBQUUsS0FBSyxDQUFDLFFBQVEsSUFBSSxJQUFJO0tBQ25DLENBQUMsQ0FDSCxDQUNGLENBQUE7SUFFRCwrQ0FBeUIsQ0FBQyxTQUFTLENBQUM7UUFDbEMsS0FBSyxFQUFFLElBQUEseUJBQVMsRUFBQyxFQUFFLFFBQVEsRUFBRSxFQUFFLENBQUMsRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUNoRCxZQUFZLEVBQUUsUUFBUSxDQUFDLEVBQUU7U0FDMUIsQ0FBQyxDQUFDO0tBQ0osQ0FBQyxDQUFBO0lBRUYsSUFBQSxvQkFBSSxFQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7UUFDekQsSUFBQSxzREFBMEIsRUFDeEIsSUFBQSx5QkFBUyxFQUFDLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDdkQsR0FBRyxLQUFLLENBQUMsUUFBUztZQUNsQixZQUFZLEVBQUUsUUFBUSxDQUFDLEVBQUU7WUFDekIsV0FBVyxFQUFFLEtBQUssQ0FBQyxRQUFRLElBQUksSUFBSTtTQUNwQyxDQUFDLENBQUMsQ0FDSixDQUFBO0lBQ0gsQ0FBQyxDQUFDLENBQUE7SUFFRixJQUFBLHFEQUEwQixFQUN4QixJQUFBLHlCQUFTLEVBQUMsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUN2RCxTQUFTLEVBQUUsS0FBSyxDQUFDLFNBQVM7UUFDMUIsUUFBUSxFQUFFLFVBQW1CO1FBQzdCLFVBQVUsRUFBRSxLQUFLLENBQUMsUUFBUSxJQUFJLElBQUk7UUFDbEMsWUFBWSxFQUFFLFFBQVEsQ0FBQyxFQUFFO0tBQzFCLENBQUMsQ0FBQyxDQUNKLENBQUE7SUFFRCxNQUFNLE9BQU8sR0FBRyxJQUFBLDZDQUFzQixFQUNwQyxJQUFBLHlCQUFTLEVBQUMsRUFBRSxRQUFRLEVBQUUsRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxLQUFLLEVBQUUsUUFBUSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FDdkUsQ0FBQTtJQUVELElBQUEsMEJBQWEsRUFBQztRQUNaLFNBQVMsRUFBRSw4QkFBcUIsQ0FBQyxvQkFBb0I7UUFDckQsSUFBSSxFQUFFLElBQUEseUJBQVMsRUFDYixFQUFFLFdBQVcsRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsRUFDaEQsQ0FBQyxFQUFFLFdBQVcsRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUNyRCxTQUFTLEVBQUUsV0FBVyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ2hDLFlBQVksRUFBRSxRQUFRLENBQUMsRUFBRTtZQUN6QixJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUk7WUFDbkIsS0FBSyxFQUFFLFFBQVEsQ0FBQyxLQUFLO1lBQ3JCLEtBQUssRUFBRSxPQUFPLENBQUMsS0FBSztZQUNwQixTQUFTLEVBQUU7Z0JBQ1QsSUFBSSxFQUFFLFdBQVcsQ0FBQyxTQUFTLENBQUMsSUFBSTtnQkFDaEMsS0FBSyxFQUFFLFdBQVcsQ0FBQyxTQUFTLENBQUMsS0FBSzthQUNuQztZQUNELFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVztZQUM5QixZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSTtZQUMxRCxNQUFNLEVBQUUsV0FBVyxDQUFDLE1BQU0sQ0FBQyxNQUFNLElBQUksSUFBSTtTQUMxQyxDQUFDLENBQ0g7S0FDRixDQUFDLENBQUE7SUFFRixPQUFPLElBQUksZ0NBQWdCLENBQ3pCLElBQUEseUJBQVMsRUFBQyxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ25FLFNBQVMsRUFBRSxRQUFRO1FBQ25CLFlBQVksRUFBRSxXQUFXLENBQUMsU0FBUyxDQUFDLEVBQUU7S0FDdkMsQ0FBQyxDQUFDLENBQ0osQ0FBQTtBQUNILENBQUMsQ0FDRixDQUFBIn0=