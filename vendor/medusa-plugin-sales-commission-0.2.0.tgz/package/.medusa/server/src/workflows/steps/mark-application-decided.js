"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.markApplicationDecidedStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const sales_commission_1 = require("../../modules/sales-commission");
/** Records the owner's decision. Fails if someone else decided first. */
exports.markApplicationDecidedStep = (0, workflows_sdk_1.createStep)("mark-application-decided", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const invite = await service.retrieveRepInvite(input.invite_id);
    if (invite.status !== "applied") {
        throw new utils_1.MedusaError(
        // Not CONFLICT: Medusa answers that with a canned retry message and drops ours
        utils_1.MedusaError.Types.INVALID_DATA, `This application was already ${invite.status}`);
    }
    const updated = await service.updateRepInvites({
        id: invite.id,
        status: input.decision,
        decided_by: input.decided_by ?? null,
        decided_at: new Date(),
        decision_reason: input.reason?.trim() || null,
        sales_rep_id: input.sales_rep_id ?? null,
    });
    return new workflows_sdk_1.StepResponse(updated, invite.id);
}, async (inviteId, { container }) => {
    if (!inviteId) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.updateRepInvites({
        id: inviteId,
        status: "applied",
        decided_by: null,
        decided_at: null,
        decision_reason: null,
        sales_rep_id: null,
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFyay1hcHBsaWNhdGlvbi1kZWNpZGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9tYXJrLWFwcGxpY2F0aW9uLWRlY2lkZWQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQXVEO0FBQ3ZELHFFQUE0RTtBQUM1RSxxRUFBd0U7QUFZeEUseUVBQXlFO0FBQzVELFFBQUEsMEJBQTBCLEdBQUcsSUFBQSwwQkFBVSxFQUNsRCwwQkFBMEIsRUFDMUIsS0FBSyxFQUFFLEtBQXNDLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQzlELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUVELE1BQU0sTUFBTSxHQUFHLE1BQU0sT0FBTyxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQTtJQUMvRCxJQUFJLE1BQU0sQ0FBQyxNQUFNLEtBQUssU0FBUyxFQUFFLENBQUM7UUFDaEMsTUFBTSxJQUFJLG1CQUFXO1FBQ25CLCtFQUErRTtRQUMvRSxtQkFBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQzlCLGdDQUFnQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQ2hELENBQUE7SUFDSCxDQUFDO0lBRUQsTUFBTSxPQUFPLEdBQUcsTUFBTSxPQUFPLENBQUMsZ0JBQWdCLENBQUM7UUFDN0MsRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1FBQ2IsTUFBTSxFQUFFLEtBQUssQ0FBQyxRQUFRO1FBQ3RCLFVBQVUsRUFBRSxLQUFLLENBQUMsVUFBVSxJQUFJLElBQUk7UUFDcEMsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFO1FBQ3RCLGVBQWUsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxJQUFJLElBQUk7UUFDN0MsWUFBWSxFQUFFLEtBQUssQ0FBQyxZQUFZLElBQUksSUFBSTtLQUN6QyxDQUFDLENBQUE7SUFFRixPQUFPLElBQUksNEJBQVksQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQzdDLENBQUMsRUFDRCxLQUFLLEVBQUUsUUFBUSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUNoQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDZCxPQUFNO0lBQ1IsQ0FBQztJQUNELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUFDO1FBQzdCLEVBQUUsRUFBRSxRQUFRO1FBQ1osTUFBTSxFQUFFLFNBQVM7UUFDakIsVUFBVSxFQUFFLElBQUk7UUFDaEIsVUFBVSxFQUFFLElBQUk7UUFDaEIsZUFBZSxFQUFFLElBQUk7UUFDckIsWUFBWSxFQUFFLElBQUk7S0FDbkIsQ0FBQyxDQUFBO0FBQ0osQ0FBQyxDQUNGLENBQUEifQ==