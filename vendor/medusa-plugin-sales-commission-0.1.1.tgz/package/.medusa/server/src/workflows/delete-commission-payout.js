"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteCommissionPayoutWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const delete_commission_payout_1 = require("./steps/delete-commission-payout");
exports.deleteCommissionPayoutWorkflow = (0, workflows_sdk_1.createWorkflow)("delete-commission-payout", function (input) {
    const id = (0, delete_commission_payout_1.deleteCommissionPayoutStep)(input);
    return new workflows_sdk_1.WorkflowResponse(id);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVsZXRlLWNvbW1pc3Npb24tcGF5b3V0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9kZWxldGUtY29tbWlzc2lvbi1wYXlvdXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscUVBRzBDO0FBQzFDLCtFQUE2RTtBQUVoRSxRQUFBLDhCQUE4QixHQUFHLElBQUEsOEJBQWMsRUFDMUQsMEJBQTBCLEVBQzFCLFVBQVUsS0FBcUI7SUFDN0IsTUFBTSxFQUFFLEdBQUcsSUFBQSxxREFBMEIsRUFBQyxLQUFLLENBQUMsQ0FBQTtJQUU1QyxPQUFPLElBQUksZ0NBQWdCLENBQUMsRUFBRSxDQUFDLENBQUE7QUFDakMsQ0FBQyxDQUNGLENBQUEifQ==