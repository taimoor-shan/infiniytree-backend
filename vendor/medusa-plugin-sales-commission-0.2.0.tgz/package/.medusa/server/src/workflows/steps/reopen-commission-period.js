"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reopenCommissionPeriodStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const sales_commission_1 = require("../../modules/sales-commission");
/**
 * Undoes the latest approval. Only the latest can be undone, and only while no
 * payout has been recorded since: a payout made on the strength of an
 * approval would otherwise look like an advance.
 */
exports.reopenCommissionPeriodStep = (0, workflows_sdk_1.createStep)("reopen-commission-period", async (_, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const [latest] = await service.listPeriodApprovals({}, { order: { period: "DESC" }, take: 1 });
    if (!latest) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, "No month is approved");
    }
    const [later] = await service.listCommissionPayouts({ created_at: { $gte: latest.approved_at } }, { take: 1, select: ["id"] });
    if (later) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, `Payouts were recorded after ${latest.period} was approved. Remove them first, then reopen the month`);
    }
    await service.softDeletePeriodApprovals(latest.id);
    return new workflows_sdk_1.StepResponse(latest, latest.id);
}, async (id, { container }) => {
    if (!id) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.restorePeriodApprovals(id);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVvcGVuLWNvbW1pc3Npb24tcGVyaW9kLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9yZW9wZW4tY29tbWlzc2lvbi1wZXJpb2QudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQXVEO0FBQ3ZELHFFQUE0RTtBQUM1RSxxRUFBd0U7QUFHeEU7Ozs7R0FJRztBQUNVLFFBQUEsMEJBQTBCLEdBQUcsSUFBQSwwQkFBVSxFQUNsRCwwQkFBMEIsRUFDMUIsS0FBSyxFQUFFLENBQU8sRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDL0IsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLG1CQUFtQixDQUNoRCxFQUFFLEVBQ0YsRUFBRSxLQUFLLEVBQUUsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUN2QyxDQUFBO0lBQ0QsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ1osTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFDM0Isc0JBQXNCLENBQ3ZCLENBQUE7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLHFCQUFxQixDQUNqRCxFQUFFLFVBQVUsRUFBRSxFQUFFLElBQUksRUFBRSxNQUFNLENBQUMsV0FBVyxFQUFFLEVBQUUsRUFDNUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQzVCLENBQUE7SUFDRCxJQUFJLEtBQUssRUFBRSxDQUFDO1FBQ1YsTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFDOUIsK0JBQStCLE1BQU0sQ0FBQyxNQUFNLHlEQUF5RCxDQUN0RyxDQUFBO0lBQ0gsQ0FBQztJQUVELE1BQU0sT0FBTyxDQUFDLHlCQUF5QixDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUVsRCxPQUFPLElBQUksNEJBQVksQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQzVDLENBQUMsRUFDRCxLQUFLLEVBQUUsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUMxQixJQUFJLENBQUMsRUFBRSxFQUFFLENBQUM7UUFDUixPQUFNO0lBQ1IsQ0FBQztJQUNELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sT0FBTyxDQUFDLHNCQUFzQixDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQzFDLENBQUMsQ0FDRixDQUFBIn0=