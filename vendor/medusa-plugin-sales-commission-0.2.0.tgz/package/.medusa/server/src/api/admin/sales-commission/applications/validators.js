"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminDeclineApplication = exports.AdminApproveApplication = exports.AdminListApplications = void 0;
const zod_1 = require("@medusajs/framework/zod");
/** The currencies a rep can be paid in */
const payoutCurrency = zod_1.z
    .string()
    .transform((code) => code.toLowerCase())
    .pipe(zod_1.z.enum(["eur", "huf"]));
exports.AdminListApplications = zod_1.z.object({
    /** What to list; "applied" is what is waiting for the owner */
    status: zod_1.z
        .enum(["applied", "approved", "declined", "invited", "canceled", "all"])
        .default("applied"),
    limit: zod_1.z.coerce.number().int().min(1).max(100).default(50),
    offset: zod_1.z.coerce.number().int().min(0).default(0),
});
exports.AdminApproveApplication = zod_1.z.object({
    /** Percent of the recruit's clients' net sales the recruiter earns */
    level2_rate: zod_1.z.number().min(0).max(100),
    /** Months Level 2 lasts from today; null or left out means until the owner ends it */
    level2_months: zod_1.z.number().int().min(1).max(120).nullish(),
    payout_currency_code: payoutCurrency.nullish(),
    contract: zod_1.z
        .object({
        file_name: zod_1.z.string().trim().min(1).max(255),
        mime_type: zod_1.z.string(),
        content_base64: zod_1.z.string(),
    })
        .nullish(),
});
exports.AdminDeclineApplication = zod_1.z.object({
    /** Stays with the owner: the candidate and the recruiter aren't told it */
    reason: zod_1.z.string().trim().min(1).max(500),
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdG9ycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcGkvYWRtaW4vc2FsZXMtY29tbWlzc2lvbi9hcHBsaWNhdGlvbnMvdmFsaWRhdG9ycy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxpREFBMkM7QUFFM0MsMENBQTBDO0FBQzFDLE1BQU0sY0FBYyxHQUFHLE9BQUM7S0FDckIsTUFBTSxFQUFFO0tBQ1IsU0FBUyxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7S0FDdkMsSUFBSSxDQUFDLE9BQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFBO0FBRWxCLFFBQUEscUJBQXFCLEdBQUcsT0FBQyxDQUFDLE1BQU0sQ0FBQztJQUM1QywrREFBK0Q7SUFDL0QsTUFBTSxFQUFFLE9BQUM7U0FDTixJQUFJLENBQUMsQ0FBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO1NBQ3ZFLE9BQU8sQ0FBQyxTQUFTLENBQUM7SUFDckIsS0FBSyxFQUFFLE9BQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO0lBQzFELE1BQU0sRUFBRSxPQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0NBQ2xELENBQUMsQ0FBQTtBQUdXLFFBQUEsdUJBQXVCLEdBQUcsT0FBQyxDQUFDLE1BQU0sQ0FBQztJQUM5QyxzRUFBc0U7SUFDdEUsV0FBVyxFQUFFLE9BQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN2QyxzRkFBc0Y7SUFDdEYsYUFBYSxFQUFFLE9BQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRTtJQUN6RCxvQkFBb0IsRUFBRSxjQUFjLENBQUMsT0FBTyxFQUFFO0lBQzlDLFFBQVEsRUFBRSxPQUFDO1NBQ1IsTUFBTSxDQUFDO1FBQ04sU0FBUyxFQUFFLE9BQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztRQUM1QyxTQUFTLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRTtRQUNyQixjQUFjLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRTtLQUMzQixDQUFDO1NBQ0QsT0FBTyxFQUFFO0NBQ2IsQ0FBQyxDQUFBO0FBR1csUUFBQSx1QkFBdUIsR0FBRyxPQUFDLENBQUMsTUFBTSxDQUFDO0lBQzlDLDJFQUEyRTtJQUMzRSxNQUFNLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0NBQzFDLENBQUMsQ0FBQSJ9