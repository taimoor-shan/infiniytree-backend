"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assignClientWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const create_client_assignment_1 = require("./steps/create-client-assignment");
const end_open_client_assignment_1 = require("./steps/end-open-client-assignment");
const resolve_effective_from_1 = require("./steps/resolve-effective-from");
const validate_client_assignment_1 = require("./steps/validate-client-assignment");
/**
 * Assigns a customer to a rep, moves them to another rep, or changes their
 * rate, from the start of today (Budapest). The open assignment ends at the
 * same instant the new one starts, so every order falls in exactly one
 * assignment.
 */
exports.assignClientWorkflow = (0, workflows_sdk_1.createWorkflow)("assign-client", function (input) {
    (0, validate_client_assignment_1.validateClientAssignmentStep)(input);
    const now = (0, resolve_effective_from_1.resolveEffectiveFromStep)();
    (0, end_open_client_assignment_1.endOpenClientAssignmentStep)((0, workflows_sdk_1.transform)({ input, now }, ({ input, now }) => ({
        customer_id: input.customer_id,
        ended_at: now,
        ended_by: input.actor_id ?? null,
    })));
    const assignment = (0, create_client_assignment_1.createClientAssignmentStep)((0, workflows_sdk_1.transform)({ input, now }, ({ input, now }) => ({
        customer_id: input.customer_id,
        sales_rep_id: input.sales_rep_id,
        commission_rate: input.commission_rate,
        starts_at: now,
        created_by: input.actor_id ?? null,
    })));
    return new workflows_sdk_1.WorkflowResponse(assignment);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXNzaWduLWNsaWVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3MvYXNzaWduLWNsaWVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxRUFJMEM7QUFDMUMsK0VBQTZFO0FBQzdFLG1GQUFnRjtBQUNoRiwyRUFBeUU7QUFDekUsbUZBQWlGO0FBU2pGOzs7OztHQUtHO0FBQ1UsUUFBQSxvQkFBb0IsR0FBRyxJQUFBLDhCQUFjLEVBQ2hELGVBQWUsRUFDZixVQUFVLEtBQWdDO0lBQ3hDLElBQUEseURBQTRCLEVBQUMsS0FBSyxDQUFDLENBQUE7SUFFbkMsTUFBTSxHQUFHLEdBQUcsSUFBQSxpREFBd0IsR0FBRSxDQUFBO0lBRXRDLElBQUEsd0RBQTJCLEVBQ3pCLElBQUEseUJBQVMsRUFBQyxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQzdDLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVztRQUM5QixRQUFRLEVBQUUsR0FBRztRQUNiLFFBQVEsRUFBRSxLQUFLLENBQUMsUUFBUSxJQUFJLElBQUk7S0FDakMsQ0FBQyxDQUFDLENBQ0osQ0FBQTtJQUVELE1BQU0sVUFBVSxHQUFHLElBQUEscURBQTBCLEVBQzNDLElBQUEseUJBQVMsRUFBQyxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQzdDLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVztRQUM5QixZQUFZLEVBQUUsS0FBSyxDQUFDLFlBQVk7UUFDaEMsZUFBZSxFQUFFLEtBQUssQ0FBQyxlQUFlO1FBQ3RDLFNBQVMsRUFBRSxHQUFHO1FBQ2QsVUFBVSxFQUFFLEtBQUssQ0FBQyxRQUFRLElBQUksSUFBSTtLQUNuQyxDQUFDLENBQUMsQ0FDSixDQUFBO0lBRUQsT0FBTyxJQUFJLGdDQUFnQixDQUFDLFVBQVUsQ0FBQyxDQUFBO0FBQ3pDLENBQUMsQ0FDRixDQUFBIn0=