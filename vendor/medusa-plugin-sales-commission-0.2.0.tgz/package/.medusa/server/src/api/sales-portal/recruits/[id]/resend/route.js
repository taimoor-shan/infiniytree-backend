"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const send_rep_invite_again_1 = require("../../../../../workflows/send-rep-invite-again");
const recruits_1 = require("../../../../../utils/recruits");
const middlewares_1 = require("../../../middlewares");
/** Emails the invitation again with a new link and a new expiry; the old link stops working. */
async function POST(req, res) {
    const recruiter = (0, middlewares_1.portalRep)(req);
    const { result } = await (0, send_rep_invite_again_1.sendRepInviteAgainWorkflow)(req.scope).run({
        input: {
            invite_id: req.params.id,
            recruiter_sales_rep_id: recruiter.id,
            locale: req.validatedBody?.locale,
        },
    });
    const { recruits, limits } = await (0, recruits_1.loadPortalRecruits)(req.scope, recruiter.id);
    res.json({
        recruit: recruits.find((recruit) => recruit.id === result.id),
        limits,
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLXBvcnRhbC9yZWNydWl0cy9baWRdL3Jlc2VuZC9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQU9BLG9CQW9CQztBQTFCRCwwRkFBMkY7QUFDM0YsNERBQWtFO0FBQ2xFLHNEQUFnRDtBQUdoRCxnR0FBZ0c7QUFDekYsS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBMEMsRUFDMUMsR0FBbUI7SUFFbkIsTUFBTSxTQUFTLEdBQUcsSUFBQSx1QkFBUyxFQUFDLEdBQUcsQ0FBQyxDQUFBO0lBRWhDLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLElBQUEsa0RBQTBCLEVBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUNqRSxLQUFLLEVBQUU7WUFDTCxTQUFTLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ3hCLHNCQUFzQixFQUFFLFNBQVMsQ0FBQyxFQUFFO1lBQ3BDLE1BQU0sRUFBRSxHQUFHLENBQUMsYUFBYSxFQUFFLE1BQU07U0FDbEM7S0FDRixDQUFDLENBQUE7SUFFRixNQUFNLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sSUFBQSw2QkFBa0IsRUFBQyxHQUFHLENBQUMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUU5RSxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ1AsT0FBTyxFQUFFLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLE9BQU8sQ0FBQyxFQUFFLEtBQUssTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUM3RCxNQUFNO0tBQ1AsQ0FBQyxDQUFBO0FBQ0osQ0FBQyJ9