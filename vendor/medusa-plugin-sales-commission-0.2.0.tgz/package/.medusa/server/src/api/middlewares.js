"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = require("@medusajs/framework/http");
const validators_1 = require("./admin/customers/validators");
const validators_2 = require("./admin/sales-commission/validators");
const query_config_1 = require("./admin/sales-reps/query-config");
const validators_3 = require("./admin/sales-commission/applications/validators");
const validators_4 = require("./sales-invites/validators");
const middlewares_1 = require("./sales-portal/middlewares");
const validators_5 = require("./sales-portal/validators");
const validators_6 = require("./admin/sales-reps/validators");
exports.default = (0, http_1.defineMiddlewares)({
    routes: [
        {
            matcher: "/admin/sales-reps",
            method: "GET",
            middlewares: [
                (0, http_1.validateAndTransformQuery)(validators_6.AdminGetSalesRepsParams, query_config_1.listSalesRepsQueryConfig),
            ],
        },
        {
            matcher: "/admin/sales-reps",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_6.AdminCreateSalesRep)],
        },
        {
            matcher: "/admin/sales-reps/:id",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_6.AdminUpdateSalesRep)],
        },
        {
            matcher: "/admin/sales-reps/:id/contracts",
            method: "POST",
            // base64 of a 10 MB contract is ~13.4 MB
            bodyParser: { sizeLimit: "15mb" },
            middlewares: [(0, http_1.validateAndTransformBody)(validators_6.AdminUploadSalesRepContract)],
        },
        {
            matcher: "/admin/sales-reps/:id/referral",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_6.AdminSetRepReferral)],
        },
        {
            matcher: "/admin/sales-reps/:id/adjustments",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_2.AdminCreateCommissionAdjustment)],
        },
        {
            matcher: "/admin/sales-reps/:id/payouts",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_2.AdminCreateCommissionPayout)],
        },
        {
            matcher: "/admin/sales-reps/:id/statement",
            method: "GET",
            middlewares: [(0, http_1.validateAndTransformQuery)(validators_2.AdminCommissionPeriodParams, {})],
        },
        {
            matcher: "/admin/sales-commission/report",
            method: "GET",
            middlewares: [(0, http_1.validateAndTransformQuery)(validators_2.AdminCommissionPeriodParams, {})],
        },
        {
            matcher: "/admin/sales-commission/periods",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_2.AdminApproveCommissionPeriods)],
        },
        {
            matcher: "/admin/sales-commission/fx-rates",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_2.AdminAddFxRate)],
        },
        {
            matcher: "/admin/sales-commission/payment-run",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_2.AdminRecordPaymentRun)],
        },
        {
            matcher: "/admin/sales-commission/applications",
            method: "GET",
            middlewares: [(0, http_1.validateAndTransformQuery)(validators_3.AdminListApplications, {})],
        },
        {
            matcher: "/admin/sales-commission/applications/:id/approve",
            method: "POST",
            // base64 of a 10 MB contract is ~13.4 MB
            bodyParser: { sizeLimit: "15mb" },
            middlewares: [(0, http_1.validateAndTransformBody)(validators_3.AdminApproveApplication)],
        },
        {
            matcher: "/admin/sales-commission/applications/:id/decline",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_3.AdminDeclineApplication)],
        },
        {
            matcher: "/admin/customers/:id/sales-rep-assignment",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_1.AdminAssignClient)],
        },
        // The candidate's invite page: no sign-in, the personal link is the
        // credential. Kept outside /sales-portal, which needs a signed-in rep.
        {
            matcher: "/sales-invites/:token/apply",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_4.ApplyToInvite)],
        },
        // Sales portal: everything under /sales-portal needs a signed-in rep who
        // currently has access. Listed first so a route added later is protected
        // by default.
        {
            matcher: "/sales-portal*",
            middlewares: [
                (0, http_1.authenticate)("sales_rep", ["session", "bearer"]),
                middlewares_1.ensureActiveSalesRep,
            ],
        },
        {
            matcher: "/sales-portal/recruits",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_5.PortalInviteRecruit)],
        },
        {
            matcher: "/sales-portal/recruits/:id/resend",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_5.PortalResendInvite)],
        },
        ...["/sales-portal/summary", "/sales-portal/statement", "/sales-portal/clients"].map((matcher) => ({
            matcher,
            method: "GET",
            middlewares: [(0, http_1.validateAndTransformQuery)(validators_5.PortalPeriodParams, {})],
        })),
        ...["/sales-portal/clients/:customer_id/orders", "/sales-portal/statements"].map((matcher) => ({
            matcher,
            method: "GET",
            middlewares: [(0, http_1.validateAndTransformQuery)(validators_5.PortalPageParams, {})],
        })),
    ],
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWlkZGxld2FyZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvYXBpL21pZGRsZXdhcmVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsbURBS2lDO0FBQ2pDLDZEQUFnRTtBQUNoRSxvRUFPNEM7QUFDNUMsa0VBQTBFO0FBQzFFLGlGQUl5RDtBQUN6RCwyREFBMEQ7QUFDMUQsNERBQWlFO0FBQ2pFLDBEQUtrQztBQUNsQyw4REFNc0M7QUFFdEMsa0JBQWUsSUFBQSx3QkFBaUIsRUFBQztJQUMvQixNQUFNLEVBQUU7UUFDTjtZQUNFLE9BQU8sRUFBRSxtQkFBbUI7WUFDNUIsTUFBTSxFQUFFLEtBQUs7WUFDYixXQUFXLEVBQUU7Z0JBQ1gsSUFBQSxnQ0FBeUIsRUFDdkIsb0NBQXVCLEVBQ3ZCLHVDQUF3QixDQUN6QjthQUNGO1NBQ0Y7UUFDRDtZQUNFLE9BQU8sRUFBRSxtQkFBbUI7WUFDNUIsTUFBTSxFQUFFLE1BQU07WUFDZCxXQUFXLEVBQUUsQ0FBQyxJQUFBLCtCQUF3QixFQUFDLGdDQUFtQixDQUFDLENBQUM7U0FDN0Q7UUFDRDtZQUNFLE9BQU8sRUFBRSx1QkFBdUI7WUFDaEMsTUFBTSxFQUFFLE1BQU07WUFDZCxXQUFXLEVBQUUsQ0FBQyxJQUFBLCtCQUF3QixFQUFDLGdDQUFtQixDQUFDLENBQUM7U0FDN0Q7UUFDRDtZQUNFLE9BQU8sRUFBRSxpQ0FBaUM7WUFDMUMsTUFBTSxFQUFFLE1BQU07WUFDZCx5Q0FBeUM7WUFDekMsVUFBVSxFQUFFLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRTtZQUNqQyxXQUFXLEVBQUUsQ0FBQyxJQUFBLCtCQUF3QixFQUFDLHdDQUEyQixDQUFDLENBQUM7U0FDckU7UUFDRDtZQUNFLE9BQU8sRUFBRSxnQ0FBZ0M7WUFDekMsTUFBTSxFQUFFLE1BQU07WUFDZCxXQUFXLEVBQUUsQ0FBQyxJQUFBLCtCQUF3QixFQUFDLGdDQUFtQixDQUFDLENBQUM7U0FDN0Q7UUFDRDtZQUNFLE9BQU8sRUFBRSxtQ0FBbUM7WUFDNUMsTUFBTSxFQUFFLE1BQU07WUFDZCxXQUFXLEVBQUUsQ0FBQyxJQUFBLCtCQUF3QixFQUFDLDRDQUErQixDQUFDLENBQUM7U0FDekU7UUFDRDtZQUNFLE9BQU8sRUFBRSwrQkFBK0I7WUFDeEMsTUFBTSxFQUFFLE1BQU07WUFDZCxXQUFXLEVBQUUsQ0FBQyxJQUFBLCtCQUF3QixFQUFDLHdDQUEyQixDQUFDLENBQUM7U0FDckU7UUFDRDtZQUNFLE9BQU8sRUFBRSxpQ0FBaUM7WUFDMUMsTUFBTSxFQUFFLEtBQUs7WUFDYixXQUFXLEVBQUUsQ0FBQyxJQUFBLGdDQUF5QixFQUFDLHdDQUEyQixFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQzFFO1FBQ0Q7WUFDRSxPQUFPLEVBQUUsZ0NBQWdDO1lBQ3pDLE1BQU0sRUFBRSxLQUFLO1lBQ2IsV0FBVyxFQUFFLENBQUMsSUFBQSxnQ0FBeUIsRUFBQyx3Q0FBMkIsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUMxRTtRQUNEO1lBQ0UsT0FBTyxFQUFFLGlDQUFpQztZQUMxQyxNQUFNLEVBQUUsTUFBTTtZQUNkLFdBQVcsRUFBRSxDQUFDLElBQUEsK0JBQXdCLEVBQUMsMENBQTZCLENBQUMsQ0FBQztTQUN2RTtRQUNEO1lBQ0UsT0FBTyxFQUFFLGtDQUFrQztZQUMzQyxNQUFNLEVBQUUsTUFBTTtZQUNkLFdBQVcsRUFBRSxDQUFDLElBQUEsK0JBQXdCLEVBQUMsMkJBQWMsQ0FBQyxDQUFDO1NBQ3hEO1FBQ0Q7WUFDRSxPQUFPLEVBQUUscUNBQXFDO1lBQzlDLE1BQU0sRUFBRSxNQUFNO1lBQ2QsV0FBVyxFQUFFLENBQUMsSUFBQSwrQkFBd0IsRUFBQyxrQ0FBcUIsQ0FBQyxDQUFDO1NBQy9EO1FBQ0Q7WUFDRSxPQUFPLEVBQUUsc0NBQXNDO1lBQy9DLE1BQU0sRUFBRSxLQUFLO1lBQ2IsV0FBVyxFQUFFLENBQUMsSUFBQSxnQ0FBeUIsRUFBQyxrQ0FBcUIsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUNwRTtRQUNEO1lBQ0UsT0FBTyxFQUFFLGtEQUFrRDtZQUMzRCxNQUFNLEVBQUUsTUFBTTtZQUNkLHlDQUF5QztZQUN6QyxVQUFVLEVBQUUsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFO1lBQ2pDLFdBQVcsRUFBRSxDQUFDLElBQUEsK0JBQXdCLEVBQUMsb0NBQXVCLENBQUMsQ0FBQztTQUNqRTtRQUNEO1lBQ0UsT0FBTyxFQUFFLGtEQUFrRDtZQUMzRCxNQUFNLEVBQUUsTUFBTTtZQUNkLFdBQVcsRUFBRSxDQUFDLElBQUEsK0JBQXdCLEVBQUMsb0NBQXVCLENBQUMsQ0FBQztTQUNqRTtRQUNEO1lBQ0UsT0FBTyxFQUFFLDJDQUEyQztZQUNwRCxNQUFNLEVBQUUsTUFBTTtZQUNkLFdBQVcsRUFBRSxDQUFDLElBQUEsK0JBQXdCLEVBQUMsOEJBQWlCLENBQUMsQ0FBQztTQUMzRDtRQUVELG9FQUFvRTtRQUNwRSx1RUFBdUU7UUFDdkU7WUFDRSxPQUFPLEVBQUUsNkJBQTZCO1lBQ3RDLE1BQU0sRUFBRSxNQUFNO1lBQ2QsV0FBVyxFQUFFLENBQUMsSUFBQSwrQkFBd0IsRUFBQywwQkFBYSxDQUFDLENBQUM7U0FDdkQ7UUFFRCx5RUFBeUU7UUFDekUseUVBQXlFO1FBQ3pFLGNBQWM7UUFDZDtZQUNFLE9BQU8sRUFBRSxnQkFBZ0I7WUFDekIsV0FBVyxFQUFFO2dCQUNYLElBQUEsbUJBQVksRUFBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTLEVBQUUsUUFBUSxDQUFDLENBQUM7Z0JBQ2hELGtDQUFvQjthQUNyQjtTQUNGO1FBQ0Q7WUFDRSxPQUFPLEVBQUUsd0JBQXdCO1lBQ2pDLE1BQU0sRUFBRSxNQUFNO1lBQ2QsV0FBVyxFQUFFLENBQUMsSUFBQSwrQkFBd0IsRUFBQyxnQ0FBbUIsQ0FBQyxDQUFDO1NBQzdEO1FBQ0Q7WUFDRSxPQUFPLEVBQUUsbUNBQW1DO1lBQzVDLE1BQU0sRUFBRSxNQUFNO1lBQ2QsV0FBVyxFQUFFLENBQUMsSUFBQSwrQkFBd0IsRUFBQywrQkFBa0IsQ0FBQyxDQUFDO1NBQzVEO1FBQ0QsR0FBRyxDQUFDLHVCQUF1QixFQUFFLHlCQUF5QixFQUFFLHVCQUF1QixDQUFDLENBQUMsR0FBRyxDQUNsRixDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQztZQUNaLE9BQU87WUFDUCxNQUFNLEVBQUUsS0FBYztZQUN0QixXQUFXLEVBQUUsQ0FBQyxJQUFBLGdDQUF5QixFQUFDLCtCQUFrQixFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQ2pFLENBQUMsQ0FDSDtRQUNELEdBQUcsQ0FBQywyQ0FBMkMsRUFBRSwwQkFBMEIsQ0FBQyxDQUFDLEdBQUcsQ0FDOUUsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDWixPQUFPO1lBQ1AsTUFBTSxFQUFFLEtBQWM7WUFDdEIsV0FBVyxFQUFFLENBQUMsSUFBQSxnQ0FBeUIsRUFBQyw2QkFBZ0IsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUMvRCxDQUFDLENBQ0g7S0FDRjtDQUNGLENBQUMsQ0FBQSJ9