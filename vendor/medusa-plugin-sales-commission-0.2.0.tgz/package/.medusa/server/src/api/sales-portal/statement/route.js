"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const portal_view_1 = require("../../../lib/portal-view");
const report_1 = require("../../../lib/report");
const statement_1 = require("../../../lib/statement");
const period_activity_1 = require("../../../utils/period-activity");
const pending_1 = require("../../../utils/pending");
const helpers_1 = require("../../admin/sales-commission/helpers");
const helpers_2 = require("../helpers");
const middlewares_1 = require("../middlewares");
/**
 * The month as a rep sees it: their orders by client, Level 2 per referred
 * rep, adjustments and payouts, each line with the balance after it, and the
 * totals with what was owed at the start and the end of the month. `pending`
 * lists what the rep's unpaid orders would earn if paid now.
 */
async function GET(req, res) {
    const { period } = (0, helpers_1.requestedPeriod)(req);
    const [history, approvedThrough, pending] = await Promise.all([
        (0, period_activity_1.loadRepHistory)(req.scope, (0, middlewares_1.portalRep)(req).id),
        (0, period_activity_1.loadApprovedThrough)(req.scope),
        (0, pending_1.loadPendingLines)(req.scope, { salesRepId: (0, middlewares_1.portalRep)(req).id }),
    ]);
    const statement = (0, statement_1.buildStatement)({
        lines: (0, report_1.allLines)(history),
        period,
        approvedThrough,
    });
    const names = await (0, helpers_2.referredRepNames)(req.scope, [
        ...statement.lines,
        ...pending,
    ]);
    res.json({
        period,
        approved: statement.approved,
        lines: (0, portal_view_1.portalStatementLines)(statement.lines, names),
        totals: statement.totals,
        // Orders not paid yet, whatever month is shown: they earn nothing until paid
        pending: (0, portal_view_1.portalPendingLines)(pending, names),
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLXBvcnRhbC9zdGF0ZW1lbnQvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFtQkEsa0JBMEJDO0FBNUNELDBEQUFtRjtBQUNuRixnREFBOEM7QUFDOUMsc0RBQXVEO0FBQ3ZELG9FQUd1QztBQUN2QyxvREFBeUQ7QUFDekQsa0VBQXNFO0FBQ3RFLHdDQUE2QztBQUM3QyxnREFBMEM7QUFFMUM7Ozs7O0dBS0c7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxFQUFFLE1BQU0sRUFBRSxHQUFHLElBQUEseUJBQWUsRUFBQyxHQUFHLENBQUMsQ0FBQTtJQUN2QyxNQUFNLENBQUMsT0FBTyxFQUFFLGVBQWUsRUFBRSxPQUFPLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7UUFDNUQsSUFBQSxnQ0FBYyxFQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsSUFBQSx1QkFBUyxFQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUM1QyxJQUFBLHFDQUFtQixFQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7UUFDOUIsSUFBQSwwQkFBZ0IsRUFBQyxHQUFHLENBQUMsS0FBSyxFQUFFLEVBQUUsVUFBVSxFQUFFLElBQUEsdUJBQVMsRUFBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztLQUMvRCxDQUFDLENBQUE7SUFDRixNQUFNLFNBQVMsR0FBRyxJQUFBLDBCQUFjLEVBQUM7UUFDL0IsS0FBSyxFQUFFLElBQUEsaUJBQVEsRUFBQyxPQUFPLENBQUM7UUFDeEIsTUFBTTtRQUNOLGVBQWU7S0FDaEIsQ0FBQyxDQUFBO0lBRUYsTUFBTSxLQUFLLEdBQUcsTUFBTSxJQUFBLDBCQUFnQixFQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUU7UUFDOUMsR0FBRyxTQUFTLENBQUMsS0FBSztRQUNsQixHQUFHLE9BQU87S0FDWCxDQUFDLENBQUE7SUFFRixHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ1AsTUFBTTtRQUNOLFFBQVEsRUFBRSxTQUFTLENBQUMsUUFBUTtRQUM1QixLQUFLLEVBQUUsSUFBQSxrQ0FBb0IsRUFBQyxTQUFTLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQztRQUNuRCxNQUFNLEVBQUUsU0FBUyxDQUFDLE1BQU07UUFDeEIsNkVBQTZFO1FBQzdFLE9BQU8sRUFBRSxJQUFBLGdDQUFrQixFQUFDLE9BQU8sRUFBRSxLQUFLLENBQUM7S0FDNUMsQ0FBQyxDQUFBO0FBQ0osQ0FBQyJ9