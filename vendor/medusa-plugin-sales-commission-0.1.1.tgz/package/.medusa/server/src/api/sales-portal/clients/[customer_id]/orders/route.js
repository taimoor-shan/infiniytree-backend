"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const sales_commission_1 = require("../../../../../modules/sales-commission");
const helpers_1 = require("../../../helpers");
const middlewares_1 = require("../../../middlewares");
/**
 * A client's paid orders: number, date, net value, currency and the rep's
 * commission. Answers 404 for a customer who isn't (or wasn't) the rep's
 * client, exactly as for one that doesn't exist.
 */
async function GET(req, res) {
    const rep = (0, middlewares_1.portalRep)(req);
    const customerId = req.params.customer_id;
    const { limit, offset } = req.validatedQuery;
    const service = req.scope.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const [assignment] = await service.listClientAssignments({ sales_rep_id: rep.id, customer_id: customerId }, { take: 1, select: ["id"] });
    const [earned] = assignment
        ? []
        : await service.listCommissionEntries({ sales_rep_id: rep.id, customer_id: customerId, type: "direct" }, { take: 1, select: ["id"] });
    if (!assignment && !earned) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, "Client not found");
    }
    const [{ data: entries, metadata }, { data: customers }] = await Promise.all([
        query.graph({
            entity: "commission_entry",
            fields: [
                "order_display_id",
                "earned_at",
                "base_amount",
                "currency_code",
                "rate",
                "amount",
                "voided_at",
            ],
            filters: { sales_rep_id: rep.id, customer_id: customerId, type: "direct" },
            pagination: { skip: offset, take: limit, order: { earned_at: "DESC" } },
        }),
        query.graph({
            entity: "customer",
            fields: ["company_name", "first_name", "last_name"],
            filters: { id: customerId },
        }),
    ]);
    res.json({
        client_name: (0, helpers_1.clientDisplayName)(customers[0]),
        orders: entries.map((entry) => ({
            order_number: entry.order_display_id,
            paid_at: entry.earned_at,
            net_value: (0, helpers_1.toNumber)(entry.base_amount),
            currency_code: entry.currency_code,
            rate: (0, helpers_1.toNumber)(entry.rate),
            commission: (0, helpers_1.toNumber)(entry.amount),
            status: entry.voided_at ? "reversed" : "paid",
        })),
        count: metadata?.count ?? entries.length,
        offset,
        limit,
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLXBvcnRhbC9jbGllbnRzL1tjdXN0b21lcl9pZF0vb3JkZXJzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBZ0JBLGtCQTREQztBQTNFRCxxREFHa0M7QUFDbEMsOEVBQWlGO0FBRWpGLDhDQUE4RDtBQUM5RCxzREFBZ0Q7QUFHaEQ7Ozs7R0FJRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUMvRCxNQUFNLEdBQUcsR0FBRyxJQUFBLHVCQUFTLEVBQUMsR0FBRyxDQUFDLENBQUE7SUFDMUIsTUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUE7SUFDekMsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsY0FBc0MsQ0FBQTtJQUNwRSxNQUFNLE9BQU8sR0FBaUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUE7SUFFaEUsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLHFCQUFxQixDQUN0RCxFQUFFLFlBQVksRUFBRSxHQUFHLENBQUMsRUFBRSxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUUsRUFDakQsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQzVCLENBQUE7SUFDRCxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsVUFBVTtRQUN6QixDQUFDLENBQUMsRUFBRTtRQUNKLENBQUMsQ0FBQyxNQUFNLE9BQU8sQ0FBQyxxQkFBcUIsQ0FDakMsRUFBRSxZQUFZLEVBQUUsR0FBRyxDQUFDLEVBQUUsRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsRUFDakUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQzVCLENBQUE7SUFDTCxJQUFJLENBQUMsVUFBVSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDM0IsTUFBTSxJQUFJLG1CQUFXLENBQUMsbUJBQVcsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLGtCQUFrQixDQUFDLENBQUE7SUFDeEUsQ0FBQztJQUVELE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7UUFDM0UsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUNWLE1BQU0sRUFBRSxrQkFBa0I7WUFDMUIsTUFBTSxFQUFFO2dCQUNOLGtCQUFrQjtnQkFDbEIsV0FBVztnQkFDWCxhQUFhO2dCQUNiLGVBQWU7Z0JBQ2YsTUFBTTtnQkFDTixRQUFRO2dCQUNSLFdBQVc7YUFDWjtZQUNELE9BQU8sRUFBRSxFQUFFLFlBQVksRUFBRSxHQUFHLENBQUMsRUFBRSxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRTtZQUMxRSxVQUFVLEVBQUUsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxFQUFFO1NBQ3hFLENBQUM7UUFDRixLQUFLLENBQUMsS0FBSyxDQUFDO1lBQ1YsTUFBTSxFQUFFLFVBQVU7WUFDbEIsTUFBTSxFQUFFLENBQUMsY0FBYyxFQUFFLFlBQVksRUFBRSxXQUFXLENBQUM7WUFDbkQsT0FBTyxFQUFFLEVBQUUsRUFBRSxFQUFFLFVBQVUsRUFBRTtTQUM1QixDQUFDO0tBQ0gsQ0FBQyxDQUFBO0lBRUYsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNQLFdBQVcsRUFBRSxJQUFBLDJCQUFpQixFQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM1QyxNQUFNLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztZQUM5QixZQUFZLEVBQUUsS0FBSyxDQUFDLGdCQUFnQjtZQUNwQyxPQUFPLEVBQUUsS0FBSyxDQUFDLFNBQVM7WUFDeEIsU0FBUyxFQUFFLElBQUEsa0JBQVEsRUFBQyxLQUFLLENBQUMsV0FBVyxDQUFDO1lBQ3RDLGFBQWEsRUFBRSxLQUFLLENBQUMsYUFBYTtZQUNsQyxJQUFJLEVBQUUsSUFBQSxrQkFBUSxFQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7WUFDMUIsVUFBVSxFQUFFLElBQUEsa0JBQVEsRUFBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1lBQ2xDLE1BQU0sRUFBRSxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLE1BQU07U0FDOUMsQ0FBQyxDQUFDO1FBQ0gsS0FBSyxFQUFFLFFBQVEsRUFBRSxLQUFLLElBQUksT0FBTyxDQUFDLE1BQU07UUFDeEMsTUFBTTtRQUNOLEtBQUs7S0FDTixDQUFDLENBQUE7QUFDSixDQUFDIn0=