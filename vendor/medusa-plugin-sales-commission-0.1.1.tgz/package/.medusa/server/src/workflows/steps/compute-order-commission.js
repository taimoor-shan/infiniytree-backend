"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.computeOrderCommissionStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const commission_1 = require("../../lib/commission");
const sales_commission_1 = require("../../modules/sales-commission");
/** Company name, else the person's name, else the email. */
const clientName = (order) => order.customer?.company_name?.trim() ||
    [order.customer?.first_name, order.customer?.last_name]
        .filter(Boolean)
        .join(" ")
        .trim() ||
    order.customer?.email ||
    order.email ||
    "";
/**
 * The entries a paid order should earn, or none when it is already recorded,
 * canceled, not fully captured, or its customer had no rep when it was placed.
 */
exports.computeOrderCommissionStep = (0, workflows_sdk_1.createStep)("compute-order-commission", async ({ order_id }, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const none = () => new workflows_sdk_1.StepResponse([]);
    const recorded = await service.listCommissionEntries({ order_id }, { take: 1, select: ["id"] });
    if (recorded.length) {
        return none();
    }
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { data: [order], } = await query.graph({
        entity: "order",
        fields: [
            "id",
            "display_id",
            "created_at",
            "canceled_at",
            "status",
            "email",
            "currency_code",
            "customer_id",
            "item_total",
            "item_tax_total",
            "customer.email",
            "customer.company_name",
            "customer.first_name",
            "customer.last_name",
            "payment_collections.payments.id",
            "payment_collections.payments.captured_at",
            "payment_collections.payments.canceled_at",
        ],
        filters: { id: order_id },
    });
    if (!order?.customer_id ||
        order.canceled_at ||
        order.status === "canceled") {
        return none();
    }
    const payments = (order.payment_collections ?? [])
        .flatMap((collection) => collection?.payments ?? [])
        .filter((payment) => !!payment && !payment.canceled_at);
    if (!payments.length || payments.some((payment) => !payment.captured_at)) {
        return none();
    }
    const lastPayment = payments.reduce((latest, payment) => new Date(payment.captured_at) > new Date(latest.captured_at)
        ? payment
        : latest);
    const assignments = await service.listClientAssignments({
        customer_id: order.customer_id,
    });
    const repIds = [...new Set(assignments.map((a) => a.sales_rep_id))];
    const referrals = repIds.length
        ? await service.listRepReferrals({ referred_sales_rep_id: repIds })
        : [];
    return new workflows_sdk_1.StepResponse((0, commission_1.computeCommissionEntries)({
        order: {
            id: order.id,
            display_id: order.display_id,
            created_at: order.created_at,
            currency_code: order.currency_code,
            customer_id: order.customer_id,
            client_name: clientName(order),
            item_total: order.item_total,
            item_tax_total: order.item_tax_total,
        },
        assignments,
        referrals,
        earnedAt: new Date(lastPayment.captured_at),
        timezone: service.getOptions().timezone,
        paymentId: lastPayment.id,
    }));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tcHV0ZS1vcmRlci1jb21taXNzaW9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9jb21wdXRlLW9yZGVyLWNvbW1pc3Npb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQXFFO0FBQ3JFLHFFQUE0RTtBQUM1RSxxREFHNkI7QUFDN0IscUVBQXdFO0FBU3hFLDREQUE0RDtBQUM1RCxNQUFNLFVBQVUsR0FBRyxDQUFDLEtBQVUsRUFBVSxFQUFFLENBQ3hDLEtBQUssQ0FBQyxRQUFRLEVBQUUsWUFBWSxFQUFFLElBQUksRUFBRTtJQUNwQyxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsVUFBVSxFQUFFLEtBQUssQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDO1NBQ3BELE1BQU0sQ0FBQyxPQUFPLENBQUM7U0FDZixJQUFJLENBQUMsR0FBRyxDQUFDO1NBQ1QsSUFBSSxFQUFFO0lBQ1QsS0FBSyxDQUFDLFFBQVEsRUFBRSxLQUFLO0lBQ3JCLEtBQUssQ0FBQyxLQUFLO0lBQ1gsRUFBRSxDQUFBO0FBRUo7OztHQUdHO0FBQ1UsUUFBQSwwQkFBMEIsR0FBRyxJQUFBLDBCQUFVLEVBQ2xELDBCQUEwQixFQUMxQixLQUFLLEVBQUUsRUFBRSxRQUFRLEVBQXdCLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQzFELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLElBQUksNEJBQVksQ0FBeUIsRUFBRSxDQUFDLENBQUE7SUFFL0QsTUFBTSxRQUFRLEdBQUcsTUFBTSxPQUFPLENBQUMscUJBQXFCLENBQ2xELEVBQUUsUUFBUSxFQUFFLEVBQ1osRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQzVCLENBQUE7SUFDRCxJQUFJLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNwQixPQUFPLElBQUksRUFBRSxDQUFBO0lBQ2YsQ0FBQztJQUVELE1BQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUE7SUFDaEUsTUFBTSxFQUNKLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUNkLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQ3BCLE1BQU0sRUFBRSxPQUFPO1FBQ2YsTUFBTSxFQUFFO1lBQ04sSUFBSTtZQUNKLFlBQVk7WUFDWixZQUFZO1lBQ1osYUFBYTtZQUNiLFFBQVE7WUFDUixPQUFPO1lBQ1AsZUFBZTtZQUNmLGFBQWE7WUFDYixZQUFZO1lBQ1osZ0JBQWdCO1lBQ2hCLGdCQUFnQjtZQUNoQix1QkFBdUI7WUFDdkIscUJBQXFCO1lBQ3JCLG9CQUFvQjtZQUNwQixpQ0FBaUM7WUFDakMsMENBQTBDO1lBQzFDLDBDQUEwQztTQUMzQztRQUNELE9BQU8sRUFBRSxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUU7S0FDMUIsQ0FBQyxDQUFBO0lBQ0YsSUFDRSxDQUFDLEtBQUssRUFBRSxXQUFXO1FBQ25CLEtBQUssQ0FBQyxXQUFXO1FBQ2pCLEtBQUssQ0FBQyxNQUFNLEtBQUssVUFBVSxFQUMzQixDQUFDO1FBQ0QsT0FBTyxJQUFJLEVBQUUsQ0FBQTtJQUNmLENBQUM7SUFFRCxNQUFNLFFBQVEsR0FBRyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsSUFBSSxFQUFFLENBQUM7U0FDL0MsT0FBTyxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQyxVQUFVLEVBQUUsUUFBUSxJQUFJLEVBQUUsQ0FBQztTQUNuRCxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQXlCLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFBO0lBQ2hGLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7UUFDekUsT0FBTyxJQUFJLEVBQUUsQ0FBQTtJQUNmLENBQUM7SUFDRCxNQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxFQUFFLENBQ3RELElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFZLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBWSxDQUFDO1FBQzVELENBQUMsQ0FBQyxPQUFPO1FBQ1QsQ0FBQyxDQUFDLE1BQU0sQ0FDWCxDQUFBO0lBRUQsTUFBTSxXQUFXLEdBQUcsTUFBTSxPQUFPLENBQUMscUJBQXFCLENBQUM7UUFDdEQsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXO0tBQy9CLENBQUMsQ0FBQTtJQUNGLE1BQU0sTUFBTSxHQUFHLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQ25FLE1BQU0sU0FBUyxHQUFHLE1BQU0sQ0FBQyxNQUFNO1FBQzdCLENBQUMsQ0FBQyxNQUFNLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sRUFBRSxDQUFDO1FBQ25FLENBQUMsQ0FBQyxFQUFFLENBQUE7SUFFTixPQUFPLElBQUksNEJBQVksQ0FDckIsSUFBQSxxQ0FBd0IsRUFBQztRQUN2QixLQUFLLEVBQUU7WUFDTCxFQUFFLEVBQUUsS0FBSyxDQUFDLEVBQUU7WUFDWixVQUFVLEVBQUUsS0FBSyxDQUFDLFVBQVc7WUFDN0IsVUFBVSxFQUFFLEtBQUssQ0FBQyxVQUFXO1lBQzdCLGFBQWEsRUFBRSxLQUFLLENBQUMsYUFBYTtZQUNsQyxXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVc7WUFDOUIsV0FBVyxFQUFFLFVBQVUsQ0FBQyxLQUFLLENBQUM7WUFDOUIsVUFBVSxFQUFFLEtBQUssQ0FBQyxVQUFvQjtZQUN0QyxjQUFjLEVBQUUsS0FBSyxDQUFDLGNBQXdCO1NBQy9DO1FBQ0QsV0FBVztRQUNYLFNBQVM7UUFDVCxRQUFRLEVBQUUsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVksQ0FBQztRQUM1QyxRQUFRLEVBQUUsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFDLFFBQVE7UUFDdkMsU0FBUyxFQUFFLFdBQVcsQ0FBQyxFQUFFO0tBQzFCLENBQUMsQ0FDSCxDQUFBO0FBQ0gsQ0FBQyxDQUNGLENBQUEifQ==