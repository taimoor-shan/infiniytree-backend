"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createSalesRepContractStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const path_1 = __importDefault(require("path"));
const sales_commission_1 = require("../../modules/sales-commission");
const ALLOWED_TYPES = ["application/pdf", "image/jpeg", "image/png"];
const MAX_BYTES = 10 * 1024 * 1024;
const invalid = (message) => new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, message);
exports.createSalesRepContractStep = (0, workflows_sdk_1.createStep)("create-sales-rep-contract", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.retrieveSalesRep(input.sales_rep_id);
    if (!ALLOWED_TYPES.includes(input.mime_type)) {
        throw invalid("Contracts must be PDF, JPEG or PNG files");
    }
    // Buffer.from skips invalid characters, so a lossless round trip proves
    // the content is canonical base64 (a regex overflows on 10 MB inputs)
    const bytes = Buffer.from(input.content_base64, "base64");
    if (bytes.toString("base64") !== input.content_base64) {
        throw invalid("Contract content is not valid base64");
    }
    const size = bytes.length;
    if (size === 0) {
        throw invalid("Contract file is empty");
    }
    if (size > MAX_BYTES) {
        throw invalid("Contract files can be at most 10 MB");
    }
    const contract = await service.createSalesRepContracts({
        sales_rep_id: input.sales_rep_id,
        // Keep only a plain file name: it ends up in a download header
        file_name: path_1.default.basename(input.file_name).replace(/[\x00-\x1f"\\]/g, "_"),
        mime_type: input.mime_type,
        size_bytes: size,
        content_base64: input.content_base64,
        uploaded_by: input.uploaded_by ?? null,
    });
    const { content_base64: _content, ...metadata } = contract;
    return new workflows_sdk_1.StepResponse(metadata, contract.id);
}, async (contractId, { container }) => {
    if (!contractId) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.deleteSalesRepContracts(contractId);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLXNhbGVzLXJlcC1jb250cmFjdC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3Mvc3RlcHMvY3JlYXRlLXNhbGVzLXJlcC1jb250cmFjdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxxREFBdUQ7QUFDdkQscUVBQTRFO0FBQzVFLGdEQUF1QjtBQUN2QixxRUFBd0U7QUFHeEUsTUFBTSxhQUFhLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxZQUFZLEVBQUUsV0FBVyxDQUFDLENBQUE7QUFDcEUsTUFBTSxTQUFTLEdBQUcsRUFBRSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUE7QUFVbEMsTUFBTSxPQUFPLEdBQUcsQ0FBQyxPQUFlLEVBQUUsRUFBRSxDQUNsQyxJQUFJLG1CQUFXLENBQUMsbUJBQVcsQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxDQUFBO0FBRTdDLFFBQUEsMEJBQTBCLEdBQUcsSUFBQSwwQkFBVSxFQUNsRCwyQkFBMkIsRUFDM0IsS0FBSyxFQUFFLEtBQXNDLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQzlELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQTtJQUVsRCxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztRQUM3QyxNQUFNLE9BQU8sQ0FBQywwQ0FBMEMsQ0FBQyxDQUFBO0lBQzNELENBQUM7SUFDRCx3RUFBd0U7SUFDeEUsc0VBQXNFO0lBQ3RFLE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFBRSxRQUFRLENBQUMsQ0FBQTtJQUN6RCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEtBQUssS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3RELE1BQU0sT0FBTyxDQUFDLHNDQUFzQyxDQUFDLENBQUE7SUFDdkQsQ0FBQztJQUNELE1BQU0sSUFBSSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUE7SUFDekIsSUFBSSxJQUFJLEtBQUssQ0FBQyxFQUFFLENBQUM7UUFDZixNQUFNLE9BQU8sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFBO0lBQ3pDLENBQUM7SUFDRCxJQUFJLElBQUksR0FBRyxTQUFTLEVBQUUsQ0FBQztRQUNyQixNQUFNLE9BQU8sQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFBO0lBQ3RELENBQUM7SUFFRCxNQUFNLFFBQVEsR0FBRyxNQUFNLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQztRQUNyRCxZQUFZLEVBQUUsS0FBSyxDQUFDLFlBQVk7UUFDaEMsK0RBQStEO1FBQy9ELFNBQVMsRUFBRSxjQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsR0FBRyxDQUFDO1FBQ3pFLFNBQVMsRUFBRSxLQUFLLENBQUMsU0FBUztRQUMxQixVQUFVLEVBQUUsSUFBSTtRQUNoQixjQUFjLEVBQUUsS0FBSyxDQUFDLGNBQWM7UUFDcEMsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXLElBQUksSUFBSTtLQUN2QyxDQUFDLENBQUE7SUFDRixNQUFNLEVBQUUsY0FBYyxFQUFFLFFBQVEsRUFBRSxHQUFHLFFBQVEsRUFBRSxHQUFHLFFBQVEsQ0FBQTtJQUUxRCxPQUFPLElBQUksNEJBQVksQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQ2hELENBQUMsRUFDRCxLQUFLLEVBQUUsVUFBVSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUNsQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDaEIsT0FBTTtJQUNSLENBQUM7SUFDRCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxVQUFVLENBQUMsQ0FBQTtBQUNuRCxDQUFDLENBQ0YsQ0FBQSJ9