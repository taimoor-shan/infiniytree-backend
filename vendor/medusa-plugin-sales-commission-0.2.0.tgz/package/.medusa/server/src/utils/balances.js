"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.payableFor = exports.historyBalances = exports.balancesByRep = exports.loadEveryLine = exports.loadRepBalances = void 0;
const balance_1 = require("../lib/balance");
const report_1 = require("../lib/report");
const period_activity_1 = require("./period-activity");
/** A rep's lines across every month, and what they are owed per currency. */
const loadRepBalances = async (container, salesRepId, { year }) => {
    const [history, approvedThrough] = await Promise.all([
        (0, period_activity_1.loadRepHistory)(container, salesRepId),
        (0, period_activity_1.loadApprovedThrough)(container),
    ]);
    const lines = (0, report_1.allLines)(history);
    return {
        approved_through: approvedThrough,
        lines,
        balances: (0, balance_1.currencyBalances)({ lines, approvedThrough }),
        paid_this_year: (0, balance_1.paidInYear)(lines, year),
    };
};
exports.loadRepBalances = loadRepBalances;
/** Every rep's lines at once, for the payment run and the rep list. */
const loadEveryLine = async (container) => {
    const [history, approvedThrough] = await Promise.all([
        (0, period_activity_1.loadAllHistory)(container),
        (0, period_activity_1.loadApprovedThrough)(container),
    ]);
    return { approved_through: approvedThrough, lines: (0, report_1.allLines)(history) };
};
exports.loadEveryLine = loadEveryLine;
/** What each rep is owed per currency; reps with no activity are left out. */
const balancesByRep = (lines, approvedThrough) => {
    const byRep = new Map();
    for (const line of lines) {
        byRep.set(line.sales_rep_id, [...(byRep.get(line.sales_rep_id) ?? []), line]);
    }
    return Object.fromEntries([...byRep.entries()].map(([repId, repLines]) => [
        repId,
        (0, balance_1.currencyBalances)({ lines: repLines, approvedThrough }),
    ]));
};
exports.balancesByRep = balancesByRep;
const historyBalances = (history, approvedThrough) => (0, balance_1.currencyBalances)({ lines: (0, report_1.allLines)(history), approvedThrough });
exports.historyBalances = historyBalances;
/** What one rep can be paid now in one currency, from lines already loaded. */
const payableFor = ({ lines, salesRepId, currencyCode, approvedThrough, }) => (0, balance_1.currencyBalances)({
    lines: lines.filter((line) => line.sales_rep_id === salesRepId && line.currency_code === currencyCode),
    approvedThrough,
})[0]?.payable ?? 0;
exports.payableFor = payableFor;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFsYW5jZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvdXRpbHMvYmFsYW5jZXMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQ0EsNENBQThFO0FBQzlFLDBDQUF1RDtBQUN2RCx1REFLMEI7QUFTMUIsNkVBQTZFO0FBQ3RFLE1BQU0sZUFBZSxHQUFHLEtBQUssRUFDbEMsU0FBMEIsRUFDMUIsVUFBa0IsRUFDbEIsRUFBRSxJQUFJLEVBQW9CLEVBQ0osRUFBRTtJQUN4QixNQUFNLENBQUMsT0FBTyxFQUFFLGVBQWUsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUNuRCxJQUFBLGdDQUFjLEVBQUMsU0FBUyxFQUFFLFVBQVUsQ0FBQztRQUNyQyxJQUFBLHFDQUFtQixFQUFDLFNBQVMsQ0FBQztLQUMvQixDQUFDLENBQUE7SUFDRixNQUFNLEtBQUssR0FBRyxJQUFBLGlCQUFRLEVBQUMsT0FBTyxDQUFDLENBQUE7SUFFL0IsT0FBTztRQUNMLGdCQUFnQixFQUFFLGVBQWU7UUFDakMsS0FBSztRQUNMLFFBQVEsRUFBRSxJQUFBLDBCQUFnQixFQUFDLEVBQUUsS0FBSyxFQUFFLGVBQWUsRUFBRSxDQUFDO1FBQ3RELGNBQWMsRUFBRSxJQUFBLG9CQUFVLEVBQUMsS0FBSyxFQUFFLElBQUksQ0FBQztLQUN4QyxDQUFBO0FBQ0gsQ0FBQyxDQUFBO0FBakJZLFFBQUEsZUFBZSxtQkFpQjNCO0FBRUQsdUVBQXVFO0FBQ2hFLE1BQU0sYUFBYSxHQUFHLEtBQUssRUFDaEMsU0FBMEIsRUFDNEMsRUFBRTtJQUN4RSxNQUFNLENBQUMsT0FBTyxFQUFFLGVBQWUsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUNuRCxJQUFBLGdDQUFjLEVBQUMsU0FBUyxDQUFDO1FBQ3pCLElBQUEscUNBQW1CLEVBQUMsU0FBUyxDQUFDO0tBQy9CLENBQUMsQ0FBQTtJQUVGLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxlQUFlLEVBQUUsS0FBSyxFQUFFLElBQUEsaUJBQVEsRUFBQyxPQUFPLENBQUMsRUFBRSxDQUFBO0FBQ3hFLENBQUMsQ0FBQTtBQVRZLFFBQUEsYUFBYSxpQkFTekI7QUFFRCw4RUFBOEU7QUFDdkUsTUFBTSxhQUFhLEdBQUcsQ0FDM0IsS0FBc0IsRUFDdEIsZUFBOEIsRUFDSyxFQUFFO0lBQ3JDLE1BQU0sS0FBSyxHQUFHLElBQUksR0FBRyxFQUEyQixDQUFBO0lBQ2hELEtBQUssTUFBTSxJQUFJLElBQUksS0FBSyxFQUFFLENBQUM7UUFDekIsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUE7SUFDL0UsQ0FBQztJQUVELE9BQU8sTUFBTSxDQUFDLFdBQVcsQ0FDdkIsQ0FBQyxHQUFHLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQztRQUM5QyxLQUFLO1FBQ0wsSUFBQSwwQkFBZ0IsRUFBQyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsZUFBZSxFQUFFLENBQUM7S0FDdkQsQ0FBQyxDQUNILENBQUE7QUFDSCxDQUFDLENBQUE7QUFmWSxRQUFBLGFBQWEsaUJBZXpCO0FBRU0sTUFBTSxlQUFlLEdBQUcsQ0FBQyxPQUFnQixFQUFFLGVBQThCLEVBQUUsRUFBRSxDQUNsRixJQUFBLDBCQUFnQixFQUFDLEVBQUUsS0FBSyxFQUFFLElBQUEsaUJBQVEsRUFBQyxPQUFPLENBQUMsRUFBRSxlQUFlLEVBQUUsQ0FBQyxDQUFBO0FBRHBELFFBQUEsZUFBZSxtQkFDcUM7QUFFakUsK0VBQStFO0FBQ3hFLE1BQU0sVUFBVSxHQUFHLENBQUMsRUFDekIsS0FBSyxFQUNMLFVBQVUsRUFDVixZQUFZLEVBQ1osZUFBZSxHQU1oQixFQUFVLEVBQUUsQ0FDWCxJQUFBLDBCQUFnQixFQUFDO0lBQ2YsS0FBSyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQ2pCLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FDUCxJQUFJLENBQUMsWUFBWSxLQUFLLFVBQVUsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLFlBQVksQ0FDMUU7SUFDRCxlQUFlO0NBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLElBQUksQ0FBQyxDQUFBO0FBakJSLFFBQUEsVUFBVSxjQWlCRiJ9