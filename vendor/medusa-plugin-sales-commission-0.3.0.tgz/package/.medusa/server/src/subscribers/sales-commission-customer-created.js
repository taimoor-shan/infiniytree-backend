"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = salesCommissionCustomerCreated;
const client_links_1 = require("../utils/client-links");
/**
 * A new account. When the storefront saw a client link on the way (it puts the
 * code in the customer's metadata), the client is linked to that rep. Accounts
 * without a code are none of this plugin's business, and cost one query.
 */
async function salesCommissionCustomerCreated({ event: { data }, container, }) {
    const logger = container.resolve("logger");
    try {
        const result = await (0, client_links_1.claimClientLink)(container, data.id);
        if (result.status === "claimed") {
            logger.info(`[sales-commission] Client link: customer ${data.id} came through a rep's link (${result.outcome})`);
        }
    }
    catch (error) {
        logger.error(`[sales-commission] Failed to apply the client link of customer ${data.id}: ${error.message}`);
    }
}
exports.config = {
    event: "customer.created",
    context: { subscriberId: "sales-commission-customer-created" },
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2FsZXMtY29tbWlzc2lvbi1jdXN0b21lci1jcmVhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3N1YnNjcmliZXJzL3NhbGVzLWNvbW1pc3Npb24tY3VzdG9tZXItY3JlYXRlZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFRQSxpREFrQkM7QUF6QkQsd0RBQXVEO0FBRXZEOzs7O0dBSUc7QUFDWSxLQUFLLFVBQVUsOEJBQThCLENBQUMsRUFDM0QsS0FBSyxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQ2YsU0FBUyxHQUNzQjtJQUMvQixNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBRTFDLElBQUksQ0FBQztRQUNILE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBQSw4QkFBZSxFQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUE7UUFDeEQsSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQ2hDLE1BQU0sQ0FBQyxJQUFJLENBQ1QsNENBQTRDLElBQUksQ0FBQyxFQUFFLCtCQUErQixNQUFNLENBQUMsT0FBTyxHQUFHLENBQ3BHLENBQUE7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixNQUFNLENBQUMsS0FBSyxDQUNWLGtFQUFrRSxJQUFJLENBQUMsRUFBRSxLQUFLLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FDOUYsQ0FBQTtJQUNILENBQUM7QUFDSCxDQUFDO0FBRVksUUFBQSxNQUFNLEdBQXFCO0lBQ3RDLEtBQUssRUFBRSxrQkFBa0I7SUFDekIsT0FBTyxFQUFFLEVBQUUsWUFBWSxFQUFFLG1DQUFtQyxFQUFFO0NBQy9ELENBQUEifQ==