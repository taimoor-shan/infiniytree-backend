"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.draftPayout = void 0;
const utils_1 = require("@medusajs/framework/utils");
const money_1 = require("../lib/money");
const period_1 = require("../lib/period");
const balances_1 = require("./balances");
const payout_rules_1 = require("./payout-rules");
const invalid = (message) => new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, message);
/**
 * Checks a payout and works out what was payable when it was made. Paying
 * less than that leaves the rest due; paying more is an advance, recovered
 * from what the rep earns next.
 */
const draftPayout = ({ rep, input, lines, approvedThrough, timezone, }) => {
    if (!(input.amount > 0)) {
        throw invalid("A payout must be more than zero");
    }
    (0, payout_rules_1.assertMoney)(input.amount, input.currency_code, "A payout");
    (0, payout_rules_1.assertPayoutCurrency)(rep, input.currency_code);
    if (Number.isNaN(new Date(input.paid_at).getTime())) {
        throw invalid("A payout needs a valid payment date");
    }
    if (input.period && !(0, period_1.isPeriod)(input.period)) {
        throw invalid(`${input.period} is not a month (YYYY-MM)`);
    }
    const currency = input.currency_code.toLowerCase();
    const payable = (0, balances_1.payableFor)({
        lines,
        salesRepId: rep.id,
        currencyCode: currency,
        approvedThrough,
    });
    return {
        payout: {
            sales_rep_id: rep.id,
            currency_code: currency,
            amount: input.amount,
            period: input.period ?? (0, period_1.toPeriod)(input.paid_at, timezone),
            paid_at: input.paid_at,
            reference: input.reference?.trim() || null,
            run_id: input.run_id ?? null,
            payable_before: payable,
            created_by: input.created_by ?? null,
        },
        excess: Math.max((0, money_1.roundMoney)(utils_1.MathBN.sub(input.amount, payable), currency), 0),
    };
};
exports.draftPayout = draftPayout;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGF5b3V0cy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy91dGlscy9wYXlvdXRzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFEQUErRDtBQUMvRCx3Q0FBeUM7QUFDekMsMENBQWtEO0FBRWxELHlDQUF1QztBQUN2QyxpREFBa0U7QUFFbEUsTUFBTSxPQUFPLEdBQUcsQ0FBQyxPQUFlLEVBQUUsRUFBRSxDQUNsQyxJQUFJLG1CQUFXLENBQUMsbUJBQVcsQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxDQUFBO0FBMEIxRDs7OztHQUlHO0FBQ0ksTUFBTSxXQUFXLEdBQUcsQ0FBQyxFQUMxQixHQUFHLEVBQ0gsS0FBSyxFQUNMLEtBQUssRUFDTCxlQUFlLEVBQ2YsUUFBUSxHQU9ULEVBQTJDLEVBQUU7SUFDNUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQ3hCLE1BQU0sT0FBTyxDQUFDLGlDQUFpQyxDQUFDLENBQUE7SUFDbEQsQ0FBQztJQUNELElBQUEsMEJBQVcsRUFBQyxLQUFLLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxhQUFhLEVBQUUsVUFBVSxDQUFDLENBQUE7SUFDMUQsSUFBQSxtQ0FBb0IsRUFBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFBO0lBQzlDLElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDO1FBQ3BELE1BQU0sT0FBTyxDQUFDLHFDQUFxQyxDQUFDLENBQUE7SUFDdEQsQ0FBQztJQUNELElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUEsaUJBQVEsRUFBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUM1QyxNQUFNLE9BQU8sQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLDJCQUEyQixDQUFDLENBQUE7SUFDM0QsQ0FBQztJQUVELE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLENBQUE7SUFDbEQsTUFBTSxPQUFPLEdBQUcsSUFBQSxxQkFBVSxFQUFDO1FBQ3pCLEtBQUs7UUFDTCxVQUFVLEVBQUUsR0FBRyxDQUFDLEVBQUU7UUFDbEIsWUFBWSxFQUFFLFFBQVE7UUFDdEIsZUFBZTtLQUNoQixDQUFDLENBQUE7SUFFRixPQUFPO1FBQ0wsTUFBTSxFQUFFO1lBQ04sWUFBWSxFQUFFLEdBQUcsQ0FBQyxFQUFFO1lBQ3BCLGFBQWEsRUFBRSxRQUFRO1lBQ3ZCLE1BQU0sRUFBRSxLQUFLLENBQUMsTUFBTTtZQUNwQixNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU0sSUFBSSxJQUFBLGlCQUFRLEVBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUM7WUFDekQsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO1lBQ3RCLFNBQVMsRUFBRSxLQUFLLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxJQUFJLElBQUk7WUFDMUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxNQUFNLElBQUksSUFBSTtZQUM1QixjQUFjLEVBQUUsT0FBTztZQUN2QixVQUFVLEVBQUUsS0FBSyxDQUFDLFVBQVUsSUFBSSxJQUFJO1NBQ3JDO1FBQ0QsTUFBTSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBQSxrQkFBVSxFQUFDLGNBQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsRUFBRSxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDN0UsQ0FBQTtBQUNILENBQUMsQ0FBQTtBQS9DWSxRQUFBLFdBQVcsZUErQ3ZCIn0=