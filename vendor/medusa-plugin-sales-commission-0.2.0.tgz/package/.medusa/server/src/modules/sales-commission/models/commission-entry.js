"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const sales_rep_1 = __importDefault(require("./sales-rep"));
/**
 * What one rep earned on one paid order, with the rate and net value
 * snapshotted. Voiding keeps the row and records the month of the void.
 */
const CommissionEntry = utils_1.model
    .define("commission_entry", {
    id: utils_1.model.id({ prefix: "sce" }).primaryKey(),
    type: utils_1.model.enum(["direct", "level2"]),
    order_id: utils_1.model.text(),
    order_display_id: utils_1.model.number(),
    order_created_at: utils_1.model.dateTime(),
    customer_id: utils_1.model.text(),
    client_name: utils_1.model.text(),
    source_sales_rep_id: utils_1.model.text().nullable(),
    client_assignment_id: utils_1.model.text(),
    rep_referral_id: utils_1.model.text().nullable(),
    currency_code: utils_1.model.text(),
    base_amount: utils_1.model.bigNumber(),
    rate: utils_1.model.bigNumber(),
    amount: utils_1.model.bigNumber(),
    /** The currency of the rep's balance; same as `currency_code` without conversion */
    settlement_currency_code: utils_1.model.text().nullable(),
    /** `amount` in the settlement currency, rounded once when earned */
    settlement_amount: utils_1.model.bigNumber().nullable(),
    /** Settlement currency per unit of the order's currency; null without conversion */
    fx_rate: utils_1.model.bigNumber().nullable(),
    fx_rate_date: utils_1.model.text().nullable(),
    fx_source: utils_1.model.text().nullable(),
    payment_id: utils_1.model.text().nullable(),
    earned_at: utils_1.model.dateTime(),
    period: utils_1.model.text(),
    voided_at: utils_1.model.dateTime().nullable(),
    void_period: utils_1.model.text().nullable(),
    void_reason: utils_1.model.text().nullable(),
    sales_rep: utils_1.model.belongsTo(() => sales_rep_1.default, {
        mappedBy: "commission_entries",
    }),
})
    .indexes([
    { on: ["order_id", "type"], unique: true, where: "deleted_at IS NULL" },
    { on: ["period"] },
    { on: ["void_period"] },
    { on: ["customer_id"] },
]);
exports.default = CommissionEntry;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbWlzc2lvbi1lbnRyeS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL3NhbGVzLWNvbW1pc3Npb24vbW9kZWxzL2NvbW1pc3Npb24tZW50cnkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxxREFBaUQ7QUFDakQsNERBQWtDO0FBRWxDOzs7R0FHRztBQUNILE1BQU0sZUFBZSxHQUFHLGFBQUs7S0FDMUIsTUFBTSxDQUFDLGtCQUFrQixFQUFFO0lBQzFCLEVBQUUsRUFBRSxhQUFLLENBQUMsRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsVUFBVSxFQUFFO0lBQzVDLElBQUksRUFBRSxhQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO0lBQ3RDLFFBQVEsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBQ3RCLGdCQUFnQixFQUFFLGFBQUssQ0FBQyxNQUFNLEVBQUU7SUFDaEMsZ0JBQWdCLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRTtJQUNsQyxXQUFXLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUN6QixXQUFXLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUN6QixtQkFBbUIsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQzVDLG9CQUFvQixFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDbEMsZUFBZSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDeEMsYUFBYSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDM0IsV0FBVyxFQUFFLGFBQUssQ0FBQyxTQUFTLEVBQUU7SUFDOUIsSUFBSSxFQUFFLGFBQUssQ0FBQyxTQUFTLEVBQUU7SUFDdkIsTUFBTSxFQUFFLGFBQUssQ0FBQyxTQUFTLEVBQUU7SUFDekIsb0ZBQW9GO0lBQ3BGLHdCQUF3QixFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDakQsb0VBQW9FO0lBQ3BFLGlCQUFpQixFQUFFLGFBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDL0Msb0ZBQW9GO0lBQ3BGLE9BQU8sRUFBRSxhQUFLLENBQUMsU0FBUyxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ3JDLFlBQVksRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ3JDLFNBQVMsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ2xDLFVBQVUsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ25DLFNBQVMsRUFBRSxhQUFLLENBQUMsUUFBUSxFQUFFO0lBQzNCLE1BQU0sRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBQ3BCLFNBQVMsRUFBRSxhQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ3RDLFdBQVcsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ3BDLFdBQVcsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ3BDLFNBQVMsRUFBRSxhQUFLLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLG1CQUFRLEVBQUU7UUFDekMsUUFBUSxFQUFFLG9CQUFvQjtLQUMvQixDQUFDO0NBQ0gsQ0FBQztLQUNELE9BQU8sQ0FBQztJQUNQLEVBQUUsRUFBRSxFQUFFLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLG9CQUFvQixFQUFFO0lBQ3ZFLEVBQUUsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUU7SUFDbEIsRUFBRSxFQUFFLEVBQUUsQ0FBQyxhQUFhLENBQUMsRUFBRTtJQUN2QixFQUFFLEVBQUUsRUFBRSxDQUFDLGFBQWEsQ0FBQyxFQUFFO0NBQ3hCLENBQUMsQ0FBQTtBQUVKLGtCQUFlLGVBQWUsQ0FBQSJ9