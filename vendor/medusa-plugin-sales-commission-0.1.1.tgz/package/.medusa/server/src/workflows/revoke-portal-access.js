"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.revokePortalAccessWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const set_sales_rep_auth_identity_1 = require("./steps/set-sales-rep-auth-identity");
/**
 * Ends a rep's portal access at once by unlinking their login. Every portal
 * request checks that link, so a token that is still valid stops working too.
 * The login itself stays: it can't be changed back to "no actor" (Medusa
 * merges app metadata), and keeping it means granting access again needs no new
 * password. Does nothing for a rep without access.
 */
exports.revokePortalAccessWorkflow = (0, workflows_sdk_1.createWorkflow)("revoke-portal-access", function (input) {
    const previousIdentityId = (0, set_sales_rep_auth_identity_1.setSalesRepAuthIdentityStep)({
        sales_rep_id: input.sales_rep_id,
        auth_identity_id: null,
    });
    return new workflows_sdk_1.WorkflowResponse((0, workflows_sdk_1.transform)({ previousIdentityId }, ({ previousIdentityId }) => ({
        had_access: !!previousIdentityId,
    })));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmV2b2tlLXBvcnRhbC1hY2Nlc3MuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL3Jldm9rZS1wb3J0YWwtYWNjZXNzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFFQUkwQztBQUMxQyxxRkFBaUY7QUFJakY7Ozs7OztHQU1HO0FBQ1UsUUFBQSwwQkFBMEIsR0FBRyxJQUFBLDhCQUFjLEVBQ3RELHNCQUFzQixFQUN0QixVQUFVLEtBQXNDO0lBQzlDLE1BQU0sa0JBQWtCLEdBQUcsSUFBQSx5REFBMkIsRUFBQztRQUNyRCxZQUFZLEVBQUUsS0FBSyxDQUFDLFlBQVk7UUFDaEMsZ0JBQWdCLEVBQUUsSUFBSTtLQUN2QixDQUFDLENBQUE7SUFFRixPQUFPLElBQUksZ0NBQWdCLENBQ3pCLElBQUEseUJBQVMsRUFBQyxFQUFFLGtCQUFrQixFQUFFLEVBQUUsQ0FBQyxFQUFFLGtCQUFrQixFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDN0QsVUFBVSxFQUFFLENBQUMsQ0FBQyxrQkFBa0I7S0FDakMsQ0FBQyxDQUFDLENBQ0osQ0FBQTtBQUNILENBQUMsQ0FDRixDQUFBIn0=