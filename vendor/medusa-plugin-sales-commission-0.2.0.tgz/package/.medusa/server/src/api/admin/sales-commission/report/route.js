"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const export_1 = require("../../../../lib/export");
const report_1 = require("../../../../lib/report");
const period_activity_1 = require("../../../../utils/period-activity");
const helpers_1 = require("../helpers");
/**
 * Every rep's month per currency: what was owed at the start, what the month
 * earned, what was paid, and what is owed at the end.
 */
async function GET(req, res) {
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { period } = (0, helpers_1.requestedPeriod)(req);
    const [{ data: reps }, history, approvedThrough] = await Promise.all([
        query.graph({
            entity: "sales_rep",
            fields: ["id", "name", "email"],
        }),
        (0, period_activity_1.loadAllHistory)(req.scope),
        (0, period_activity_1.loadApprovedThrough)(req.scope),
    ]);
    const rows = (0, report_1.buildReport)({ period, reps, ...history });
    if ((0, helpers_1.wantsCsv)(req)) {
        return (0, helpers_1.sendCsv)(res, `commission-report-${period}.csv`, (0, export_1.reportCsv)({ period, rows }));
    }
    res.json({
        period,
        approved: approvedThrough !== null && period <= approvedThrough,
        approved_through: approvedThrough,
        rows,
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLWNvbW1pc3Npb24vcmVwb3J0L3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBaUJBLGtCQStCQztBQTVDRCxxREFBcUU7QUFDckUsbURBQWtEO0FBQ2xELG1EQUFvRDtBQUNwRCx1RUFHMEM7QUFDMUMsd0NBQStEO0FBRS9EOzs7R0FHRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQStCLEVBQy9CLEdBQW1CO0lBRW5CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFBO0lBQ2hFLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFBLHlCQUFlLEVBQUMsR0FBRyxDQUFDLENBQUE7SUFFdkMsTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxlQUFlLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7UUFDbkUsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUNWLE1BQU0sRUFBRSxXQUFXO1lBQ25CLE1BQU0sRUFBRSxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsT0FBTyxDQUFDO1NBQ2hDLENBQUM7UUFDRixJQUFBLGdDQUFjLEVBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztRQUN6QixJQUFBLHFDQUFtQixFQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7S0FDL0IsQ0FBQyxDQUFBO0lBQ0YsTUFBTSxJQUFJLEdBQUcsSUFBQSxvQkFBVyxFQUFDLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxHQUFHLE9BQU8sRUFBRSxDQUFDLENBQUE7SUFFdEQsSUFBSSxJQUFBLGtCQUFRLEVBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztRQUNsQixPQUFPLElBQUEsaUJBQU8sRUFDWixHQUFHLEVBQ0gscUJBQXFCLE1BQU0sTUFBTSxFQUNqQyxJQUFBLGtCQUFTLEVBQUMsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FDNUIsQ0FBQTtJQUNILENBQUM7SUFFRCxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ1AsTUFBTTtRQUNOLFFBQVEsRUFBRSxlQUFlLEtBQUssSUFBSSxJQUFJLE1BQU0sSUFBSSxlQUFlO1FBQy9ELGdCQUFnQixFQUFFLGVBQWU7UUFDakMsSUFBSTtLQUNMLENBQUMsQ0FBQTtBQUNKLENBQUMifQ==