"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveLevel2ExpiryStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const invite_1 = require("../../lib/invite");
const sales_commission_1 = require("../../modules/sales-commission");
/** When Level 2 stops for a recruit approved today: that many months on, or never (null). */
exports.resolveLevel2ExpiryStep = (0, workflows_sdk_1.createStep)("resolve-level2-expiry", async ({ months }, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    return new workflows_sdk_1.StepResponse(months ? (0, invite_1.monthsFrom)(new Date(), months, service.getOptions().timezone) : null);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVzb2x2ZS1sZXZlbDItZXhwaXJ5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9yZXNvbHZlLWxldmVsMi1leHBpcnkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscUVBQTRFO0FBQzVFLDZDQUE2QztBQUM3QyxxRUFBd0U7QUFHeEUsNkZBQTZGO0FBQ2hGLFFBQUEsdUJBQXVCLEdBQUcsSUFBQSwwQkFBVSxFQUMvQyx1QkFBdUIsRUFDdkIsS0FBSyxFQUFFLEVBQUUsTUFBTSxFQUE2QixFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUM3RCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFFRCxPQUFPLElBQUksNEJBQVksQ0FDckIsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFBLG1CQUFVLEVBQUMsSUFBSSxJQUFJLEVBQUUsRUFBRSxNQUFNLEVBQUUsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQzlFLENBQUE7QUFDSCxDQUFDLENBQ0YsQ0FBQSJ9