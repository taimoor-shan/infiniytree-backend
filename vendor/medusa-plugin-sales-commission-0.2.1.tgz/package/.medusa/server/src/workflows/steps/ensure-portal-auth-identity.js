"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ensurePortalAuthIdentityStep = void 0;
const crypto_1 = require("crypto");
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const portal_login_1 = require("../../lib/portal-login");
const sales_commission_1 = require("../../modules/sales-commission");
const portal_login_2 = require("../../utils/portal-login");
const PROVIDER = "emailpass";
/** A password nobody sees: the rep sets their own with forgot-password */
const unknownPassword = () => (0, crypto_1.randomBytes)(32).toString("base64url");
/**
 * The login (Medusa auth identity) for a rep's email, created through the auth
 * module's own `register` with a random password nobody sees: the rep sets
 * their first password with Medusa's forgot-password flow, which proves they
 * own the mailbox.
 *
 * An existing login is reused when it belongs to an admin user or was already
 * linked to this rep. One that is linked to nothing, such as what Medusa
 * leaves behind when it deletes a customer or a registration that was never
 * finished, is taken over, but only after its password is replaced by one
 * nobody knows. Anyone can register a login for any email through Medusa's
 * public register routes without proving they own it, so whoever set the old
 * password must not get into the rep's portal. A login linked to a customer
 * account, or to anything else, is refused.
 */
exports.ensurePortalAuthIdentityStep = (0, workflows_sdk_1.createStep)("ensure-portal-auth-identity", async ({ email, sales_rep_id }, { container }) => {
    const auth = container.resolve(utils_1.Modules.AUTH);
    const [existing] = await auth.listAuthIdentities({ provider_identities: { provider: PROVIDER, entity_id: email } }, { take: 1 });
    if (existing) {
        const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
        const kind = (0, portal_login_1.classifyExistingLogin)(existing.app_metadata, sales_rep_id, await (0, portal_login_2.linkedRepExists)(service, existing.app_metadata, sales_rep_id));
        if (kind === "other_rep") {
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, `The login for ${email} already belongs to another sales rep`);
        }
        if (kind === "in_use") {
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, `${email} already has a login linked to another account on the shop (such as a customer account), so it can't be linked automatically. Use a different email for the rep`);
        }
        if (kind === "unclaimed") {
            // Not undone if a later step fails: the login has no owner either way
            const reset = await auth.updateProvider(PROVIDER, {
                entity_id: email,
                password: unknownPassword(),
            });
            if (!reset.success) {
                throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, reset.error ?? `Could not reset the old password for ${email}`);
            }
        }
        return new workflows_sdk_1.StepResponse({ auth_identity_id: existing.id, already_linked: kind === "linked" }, { id: existing.id, created: false });
    }
    const { success, authIdentity, error } = await auth.register(PROVIDER, {
        url: "",
        headers: {},
        query: {},
        protocol: "",
        body: { email, password: unknownPassword() },
    });
    if (!success || !authIdentity) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, error ?? `Could not create a login for ${email}`);
    }
    return new workflows_sdk_1.StepResponse({ auth_identity_id: authIdentity.id, already_linked: false }, { id: authIdentity.id, created: true });
}, async (prior, { container }) => {
    if (!prior?.created) {
        return;
    }
    await container.resolve(utils_1.Modules.AUTH).deleteAuthIdentities([prior.id]);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW5zdXJlLXBvcnRhbC1hdXRoLWlkZW50aXR5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9lbnN1cmUtcG9ydGFsLWF1dGgtaWRlbnRpdHkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsbUNBQW9DO0FBQ3BDLHFEQUFnRTtBQUNoRSxxRUFBNEU7QUFDNUUseURBQThEO0FBQzlELHFFQUF3RTtBQUV4RSwyREFBMEQ7QUFFMUQsTUFBTSxRQUFRLEdBQUcsV0FBVyxDQUFBO0FBRTVCLDBFQUEwRTtBQUMxRSxNQUFNLGVBQWUsR0FBRyxHQUFHLEVBQUUsQ0FBQyxJQUFBLG9CQUFXLEVBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFBO0FBRW5FOzs7Ozs7Ozs7Ozs7OztHQWNHO0FBQ1UsUUFBQSw0QkFBNEIsR0FBRyxJQUFBLDBCQUFVLEVBQ3BELDZCQUE2QixFQUM3QixLQUFLLEVBQ0gsRUFBRSxLQUFLLEVBQUUsWUFBWSxFQUEyQyxFQUNoRSxFQUFFLFNBQVMsRUFBRSxFQUNiLEVBQUU7SUFDRixNQUFNLElBQUksR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGVBQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQTtJQUU1QyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQzlDLEVBQUUsbUJBQW1CLEVBQUUsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUNqRSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FDWixDQUFBO0lBQ0QsSUFBSSxRQUFRLEVBQUUsQ0FBQztRQUNiLE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtRQUNELE1BQU0sSUFBSSxHQUFHLElBQUEsb0NBQXFCLEVBQ2hDLFFBQVEsQ0FBQyxZQUFZLEVBQ3JCLFlBQVksRUFDWixNQUFNLElBQUEsOEJBQWUsRUFBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLFlBQVksRUFBRSxZQUFZLENBQUMsQ0FDcEUsQ0FBQTtRQUNELElBQUksSUFBSSxLQUFLLFdBQVcsRUFBRSxDQUFDO1lBQ3pCLE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQzlCLGlCQUFpQixLQUFLLHVDQUF1QyxDQUM5RCxDQUFBO1FBQ0gsQ0FBQztRQUNELElBQUksSUFBSSxLQUFLLFFBQVEsRUFBRSxDQUFDO1lBQ3RCLE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQzlCLEdBQUcsS0FBSyxpS0FBaUssQ0FDMUssQ0FBQTtRQUNILENBQUM7UUFDRCxJQUFJLElBQUksS0FBSyxXQUFXLEVBQUUsQ0FBQztZQUN6QixzRUFBc0U7WUFDdEUsTUFBTSxLQUFLLEdBQUcsTUFBTSxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRTtnQkFDaEQsU0FBUyxFQUFFLEtBQUs7Z0JBQ2hCLFFBQVEsRUFBRSxlQUFlLEVBQUU7YUFDNUIsQ0FBQyxDQUFBO1lBQ0YsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDbkIsTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFDOUIsS0FBSyxDQUFDLEtBQUssSUFBSSx3Q0FBd0MsS0FBSyxFQUFFLENBQy9ELENBQUE7WUFDSCxDQUFDO1FBQ0gsQ0FBQztRQUVELE9BQU8sSUFBSSw0QkFBWSxDQUNyQixFQUFFLGdCQUFnQixFQUFFLFFBQVEsQ0FBQyxFQUFFLEVBQUUsY0FBYyxFQUFFLElBQUksS0FBSyxRQUFRLEVBQUUsRUFDcEUsRUFBRSxFQUFFLEVBQUUsUUFBUSxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLENBQ3BDLENBQUE7SUFDSCxDQUFDO0lBRUQsTUFBTSxFQUFFLE9BQU8sRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRTtRQUNyRSxHQUFHLEVBQUUsRUFBRTtRQUNQLE9BQU8sRUFBRSxFQUFFO1FBQ1gsS0FBSyxFQUFFLEVBQUU7UUFDVCxRQUFRLEVBQUUsRUFBRTtRQUNaLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsZUFBZSxFQUFFLEVBQUU7S0FDN0MsQ0FBQyxDQUFBO0lBQ0YsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQzlCLE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQzlCLEtBQUssSUFBSSxnQ0FBZ0MsS0FBSyxFQUFFLENBQ2pELENBQUE7SUFDSCxDQUFDO0lBRUQsT0FBTyxJQUFJLDRCQUFZLENBQ3JCLEVBQUUsZ0JBQWdCLEVBQUUsWUFBWSxDQUFDLEVBQUUsRUFBRSxjQUFjLEVBQUUsS0FBSyxFQUFFLEVBQzVELEVBQUUsRUFBRSxFQUFFLFlBQVksQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxDQUN2QyxDQUFBO0FBQ0gsQ0FBQyxFQUNELEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQzdCLElBQUksQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLENBQUM7UUFDcEIsT0FBTTtJQUNSLENBQUM7SUFDRCxNQUFNLFNBQVMsQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLElBQUksQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUE7QUFDeEUsQ0FBQyxDQUNGLENBQUEifQ==