"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.uploadSalesRepContractWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const create_sales_rep_contract_1 = require("./steps/create-sales-rep-contract");
exports.uploadSalesRepContractWorkflow = (0, workflows_sdk_1.createWorkflow)("upload-sales-rep-contract", function (input) {
    const contract = (0, create_sales_rep_contract_1.createSalesRepContractStep)(input);
    return new workflows_sdk_1.WorkflowResponse(contract);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXBsb2FkLXNhbGVzLXJlcC1jb250cmFjdC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3MvdXBsb2FkLXNhbGVzLXJlcC1jb250cmFjdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxRUFHMEM7QUFDMUMsaUZBRzBDO0FBRTdCLFFBQUEsOEJBQThCLEdBQUcsSUFBQSw4QkFBYyxFQUMxRCwyQkFBMkIsRUFDM0IsVUFBVSxLQUFzQztJQUM5QyxNQUFNLFFBQVEsR0FBRyxJQUFBLHNEQUEwQixFQUFDLEtBQUssQ0FBQyxDQUFBO0lBRWxELE9BQU8sSUFBSSxnQ0FBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQTtBQUN2QyxDQUFDLENBQ0YsQ0FBQSJ9