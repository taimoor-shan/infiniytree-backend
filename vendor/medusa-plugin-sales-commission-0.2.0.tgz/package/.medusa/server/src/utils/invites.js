"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeLocale = exports.recruitingSettings = exports.RESEND_COOLDOWN_MS = void 0;
/** A resend has to wait this long after the link was last emailed */
exports.RESEND_COOLDOWN_MS = 60_000;
const positive = (value, fallback) => typeof value === "number" && Number.isFinite(value) && value > 0
    ? Math.floor(value)
    : fallback;
/** The recruiting settings, with defaults for what the owner left unset. */
const recruitingSettings = (service) => {
    const options = service.getOptions();
    const months = options.level2_default_months;
    return {
        invite_days: positive(options.invite_days, 14),
        max_open_invites: positive(options.max_open_invites, 20),
        level2_default_rate: typeof options.level2_default_rate === "number" &&
            options.level2_default_rate >= 0 &&
            options.level2_default_rate <= 100
            ? options.level2_default_rate
            : 2,
        /** null means until the owner ends it */
        level2_default_months: months === 0 ? null : positive(months, 24),
    };
};
exports.recruitingSettings = recruitingSettings;
/** A language tag such as "en" or "hu-HU", or null for anything else. */
const normalizeLocale = (locale) => {
    const value = locale?.trim();
    return value && /^[a-z]{2,3}(-[A-Za-z]{2,4})?$/.test(value) ? value : null;
};
exports.normalizeLocale = normalizeLocale;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW52aXRlcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy91dGlscy9pbnZpdGVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUVBLHFFQUFxRTtBQUN4RCxRQUFBLGtCQUFrQixHQUFHLE1BQU0sQ0FBQTtBQUV4QyxNQUFNLFFBQVEsR0FBRyxDQUFDLEtBQWMsRUFBRSxRQUFnQixFQUFFLEVBQUUsQ0FDcEQsT0FBTyxLQUFLLEtBQUssUUFBUSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxHQUFHLENBQUM7SUFDOUQsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO0lBQ25CLENBQUMsQ0FBQyxRQUFRLENBQUE7QUFFZCw0RUFBNEU7QUFDckUsTUFBTSxrQkFBa0IsR0FBRyxDQUFDLE9BQXFDLEVBQUUsRUFBRTtJQUMxRSxNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxFQUFFLENBQUE7SUFDcEMsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLHFCQUFxQixDQUFBO0lBRTVDLE9BQU87UUFDTCxXQUFXLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDO1FBQzlDLGdCQUFnQixFQUFFLFFBQVEsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsRUFBRSxDQUFDO1FBQ3hELG1CQUFtQixFQUNqQixPQUFPLE9BQU8sQ0FBQyxtQkFBbUIsS0FBSyxRQUFRO1lBQy9DLE9BQU8sQ0FBQyxtQkFBbUIsSUFBSSxDQUFDO1lBQ2hDLE9BQU8sQ0FBQyxtQkFBbUIsSUFBSSxHQUFHO1lBQ2hDLENBQUMsQ0FBQyxPQUFPLENBQUMsbUJBQW1CO1lBQzdCLENBQUMsQ0FBQyxDQUFDO1FBQ1AseUNBQXlDO1FBQ3pDLHFCQUFxQixFQUNuQixNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDO0tBQzdDLENBQUE7QUFDSCxDQUFDLENBQUE7QUFqQlksUUFBQSxrQkFBa0Isc0JBaUI5QjtBQUVELHlFQUF5RTtBQUNsRSxNQUFNLGVBQWUsR0FBRyxDQUFDLE1BQXNCLEVBQWlCLEVBQUU7SUFDdkUsTUFBTSxLQUFLLEdBQUcsTUFBTSxFQUFFLElBQUksRUFBRSxDQUFBO0lBRTVCLE9BQU8sS0FBSyxJQUFJLCtCQUErQixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUE7QUFDNUUsQ0FBQyxDQUFBO0FBSlksUUFBQSxlQUFlLG1CQUkzQiJ9