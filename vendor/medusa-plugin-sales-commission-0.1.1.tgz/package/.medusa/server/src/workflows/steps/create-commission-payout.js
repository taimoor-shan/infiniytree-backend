"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCommissionPayoutStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const money_1 = require("../../lib/money");
const period_1 = require("../../lib/period");
const sales_commission_1 = require("../../modules/sales-commission");
const invalid = (message) => new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, message);
/** Records a bank transfer made outside the system, against a month. */
exports.createCommissionPayoutStep = (0, workflows_sdk_1.createStep)("create-commission-payout", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.retrieveSalesRep(input.sales_rep_id);
    if (!(input.amount > 0)) {
        throw invalid("A payout must be more than zero");
    }
    if (!(0, money_1.isCurrencyCode)(input.currency_code)) {
        throw invalid(`${input.currency_code} is not a currency code (use EUR or HUF)`);
    }
    if (!(0, money_1.hasValidPrecision)(input.amount, input.currency_code)) {
        throw invalid(`${input.currency_code.toUpperCase()} amounts can have at most ${(0, money_1.currencyDecimals)(input.currency_code)} decimals`);
    }
    if (!(0, period_1.isPeriod)(input.period)) {
        throw invalid(`${input.period} is not a month (YYYY-MM)`);
    }
    if (Number.isNaN(new Date(input.paid_at).getTime())) {
        throw invalid("A payout needs a valid payment date");
    }
    const payout = await service.createCommissionPayouts({
        ...input,
        currency_code: input.currency_code.toLowerCase(),
        reference: input.reference?.trim() || null,
        created_by: input.created_by ?? null,
    });
    return new workflows_sdk_1.StepResponse(payout, payout.id);
}, async (payoutId, { container }) => {
    if (!payoutId) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.deleteCommissionPayouts(payoutId);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLWNvbW1pc3Npb24tcGF5b3V0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9jcmVhdGUtY29tbWlzc2lvbi1wYXlvdXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQXVEO0FBQ3ZELHFFQUE0RTtBQUM1RSwyQ0FBcUY7QUFDckYsNkNBQTJDO0FBQzNDLHFFQUF3RTtBQWF4RSxNQUFNLE9BQU8sR0FBRyxDQUFDLE9BQWUsRUFBRSxFQUFFLENBQ2xDLElBQUksbUJBQVcsQ0FBQyxtQkFBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsT0FBTyxDQUFDLENBQUE7QUFFMUQsd0VBQXdFO0FBQzNELFFBQUEsMEJBQTBCLEdBQUcsSUFBQSwwQkFBVSxFQUNsRCwwQkFBMEIsRUFDMUIsS0FBSyxFQUFFLEtBQXNDLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQzlELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQTtJQUVsRCxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDeEIsTUFBTSxPQUFPLENBQUMsaUNBQWlDLENBQUMsQ0FBQTtJQUNsRCxDQUFDO0lBQ0QsSUFBSSxDQUFDLElBQUEsc0JBQWMsRUFBQyxLQUFLLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQztRQUN6QyxNQUFNLE9BQU8sQ0FBQyxHQUFHLEtBQUssQ0FBQyxhQUFhLDBDQUEwQyxDQUFDLENBQUE7SUFDakYsQ0FBQztJQUNELElBQUksQ0FBQyxJQUFBLHlCQUFpQixFQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUM7UUFDMUQsTUFBTSxPQUFPLENBQ1gsR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSw2QkFBNkIsSUFBQSx3QkFBZ0IsRUFBQyxLQUFLLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FDbEgsQ0FBQTtJQUNILENBQUM7SUFDRCxJQUFJLENBQUMsSUFBQSxpQkFBUSxFQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQzVCLE1BQU0sT0FBTyxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sMkJBQTJCLENBQUMsQ0FBQTtJQUMzRCxDQUFDO0lBQ0QsSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUM7UUFDcEQsTUFBTSxPQUFPLENBQUMscUNBQXFDLENBQUMsQ0FBQTtJQUN0RCxDQUFDO0lBRUQsTUFBTSxNQUFNLEdBQUcsTUFBTSxPQUFPLENBQUMsdUJBQXVCLENBQUM7UUFDbkQsR0FBRyxLQUFLO1FBQ1IsYUFBYSxFQUFFLEtBQUssQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFO1FBQ2hELFNBQVMsRUFBRSxLQUFLLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxJQUFJLElBQUk7UUFDMUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxVQUFVLElBQUksSUFBSTtLQUNyQyxDQUFDLENBQUE7SUFFRixPQUFPLElBQUksNEJBQVksQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQzVDLENBQUMsRUFDRCxLQUFLLEVBQUUsUUFBUSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUNoQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDZCxPQUFNO0lBQ1IsQ0FBQztJQUNELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sT0FBTyxDQUFDLHVCQUF1QixDQUFDLFFBQVEsQ0FBQyxDQUFBO0FBQ2pELENBQUMsQ0FDRixDQUFBIn0=