"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const sales_commission_1 = require("../../../../../modules/sales-commission");
const rep_deletion_1 = require("../../../../../utils/rep-deletion");
/**
 * Whether the rep can be deleted, and if not, everything that is in the way.
 * `DELETE /admin/sales-reps/:id` checks the same and refuses with it.
 */
async function GET(req, res) {
    const service = req.scope.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const [rep] = await service.listSalesReps({ id: req.params.id }, { take: 1, select: ["id"] });
    if (!rep) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, `Sales rep ${req.params.id} was not found`);
    }
    const blockers = await (0, rep_deletion_1.loadRepDeletionBlockers)(req.scope, rep.id);
    res.json({ can_delete: blockers.length === 0, blockers });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLXJlcHMvW2lkXS9kZWxldGlvbi9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQWFBLGtCQXNCQztBQS9CRCxxREFBdUQ7QUFDdkQsOEVBQWlGO0FBRWpGLG9FQUEyRTtBQUUzRTs7O0dBR0c7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUErQixFQUMvQixHQUFtQjtJQUVuQixNQUFNLE9BQU8sR0FBaUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBRUQsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLGFBQWEsQ0FDdkMsRUFBRSxFQUFFLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsRUFDckIsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQzVCLENBQUE7SUFDRCxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDVCxNQUFNLElBQUksbUJBQVcsQ0FDbkIsbUJBQVcsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUMzQixhQUFhLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxnQkFBZ0IsQ0FDM0MsQ0FBQTtJQUNILENBQUM7SUFFRCxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUEsc0NBQXVCLEVBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUE7SUFFakUsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLFVBQVUsRUFBRSxRQUFRLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFBO0FBQzNELENBQUMifQ==