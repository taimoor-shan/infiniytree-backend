"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const utils_1 = require("@medusajs/framework/utils");
const payment_run_1 = require("../../../../lib/payment-run");
const sales_commission_1 = require("../../../../modules/sales-commission");
const balances_1 = require("../../../../utils/balances");
const period_status_1 = require("../../../../utils/period-status");
const record_payment_run_1 = require("../../../../workflows/record-payment-run");
const lowercaseKeys = (record = {}) => Object.fromEntries(Object.entries(record).map(([key, value]) => [key.toLowerCase(), value]));
/**
 * Who is owed something now: one row per rep and currency with the amount
 * payable, what was paid ahead and has to be netted first, and whether the
 * amount is below the minimum payout.
 */
async function GET(req, res) {
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const service = req.scope.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const options = service.getOptions();
    const minimums = lowercaseKeys(options.minimum_payout);
    const [{ data: reps }, { lines }, status] = await Promise.all([
        query.graph({ entity: "sales_rep", fields: ["id", "name", "email"] }),
        (0, balances_1.loadEveryLine)(req.scope),
        (0, period_status_1.loadPeriodStatus)(req.scope),
    ]);
    res.json({
        ...status,
        minimums,
        payout_day: options.payout_day ?? null,
        rows: (0, payment_run_1.paymentRunRows)({
            reps,
            lines,
            approvedThrough: status.approved_through,
            minimums,
        }),
    });
}
/** Records the payouts of one payment run together, all or nothing. */
async function POST(req, res) {
    const { result } = await (0, record_payment_run_1.recordPaymentRunWorkflow)(req.scope).run({
        input: { ...req.validatedBody, created_by: req.auth_context.actor_id },
    });
    res.json(result);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLWNvbW1pc3Npb24vcGF5bWVudC1ydW4vcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUF1QkEsa0JBNEJDO0FBR0Qsb0JBU0M7QUEzREQscURBQXFFO0FBQ3JFLDZEQUE0RDtBQUM1RCwyRUFBOEU7QUFFOUUseURBQTBEO0FBQzFELG1FQUFrRTtBQUNsRSxpRkFBbUY7QUFHbkYsTUFBTSxhQUFhLEdBQUcsQ0FBQyxTQUFpQyxFQUFFLEVBQUUsRUFBRSxDQUM1RCxNQUFNLENBQUMsV0FBVyxDQUNoQixNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUN6RSxDQUFBO0FBRUg7Ozs7R0FJRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQStCLEVBQy9CLEdBQW1CO0lBRW5CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFBO0lBQ2hFLE1BQU0sT0FBTyxHQUFpQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsVUFBVSxFQUFFLENBQUE7SUFDcEMsTUFBTSxRQUFRLEdBQUcsYUFBYSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQTtJQUV0RCxNQUFNLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxNQUFNLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7UUFDNUQsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFLE1BQU0sRUFBRSxXQUFXLEVBQUUsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDO1FBQ3JFLElBQUEsd0JBQWEsRUFBQyxHQUFHLENBQUMsS0FBSyxDQUFDO1FBQ3hCLElBQUEsZ0NBQWdCLEVBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztLQUM1QixDQUFDLENBQUE7SUFFRixHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ1AsR0FBRyxNQUFNO1FBQ1QsUUFBUTtRQUNSLFVBQVUsRUFBRSxPQUFPLENBQUMsVUFBVSxJQUFJLElBQUk7UUFDdEMsSUFBSSxFQUFFLElBQUEsNEJBQWMsRUFBQztZQUNuQixJQUFJO1lBQ0osS0FBSztZQUNMLGVBQWUsRUFBRSxNQUFNLENBQUMsZ0JBQWdCO1lBQ3hDLFFBQVE7U0FDVCxDQUFDO0tBQ0gsQ0FBQyxDQUFBO0FBQ0osQ0FBQztBQUVELHVFQUF1RTtBQUNoRSxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUEwRCxFQUMxRCxHQUFtQjtJQUVuQixNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsTUFBTSxJQUFBLDZDQUF3QixFQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUM7UUFDL0QsS0FBSyxFQUFFLEVBQUUsR0FBRyxHQUFHLENBQUMsYUFBYSxFQUFFLFVBQVUsRUFBRSxHQUFHLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRTtLQUN2RSxDQUFDLENBQUE7SUFFRixHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0FBQ2xCLENBQUMifQ==