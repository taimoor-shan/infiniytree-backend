"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadApprovedThrough = exports.loadApprovedPeriods = exports.loadAllHistory = exports.loadRepHistory = exports.loadPeriodActivity = void 0;
const utils_1 = require("@medusajs/framework/utils");
const approval_1 = require("../lib/approval");
const ENTRY_FIELDS = [
    "id",
    "sales_rep_id",
    "type",
    "order_id",
    "order_display_id",
    "customer_id",
    "source_sales_rep_id",
    "client_name",
    "currency_code",
    "base_amount",
    "rate",
    "amount",
    "settlement_currency_code",
    "settlement_amount",
    "fx_rate",
    "earned_at",
    "period",
    "voided_at",
    "void_period",
    "void_reason",
];
const ADJUSTMENT_FIELDS = [
    "id",
    "sales_rep_id",
    "currency_code",
    "amount",
    "period",
    "reason",
    "order_id",
    "created_at",
    "created_by",
];
const PAYOUT_FIELDS = [
    "id",
    "sales_rep_id",
    "currency_code",
    "amount",
    "period",
    "paid_at",
    "reference",
];
/**
 * Everything that moves a month's balance: entries earned or voided in the
 * month, and the month's adjustments and payouts. Optionally for one rep.
 */
const loadPeriodActivity = async (container, { period, salesRepId }) => {
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const ofRep = salesRepId ? { sales_rep_id: salesRepId } : {};
    const [earned, voided, adjustments, payouts] = await Promise.all([
        query.graph({
            entity: "commission_entry",
            fields: ENTRY_FIELDS,
            filters: { ...ofRep, period },
        }),
        query.graph({
            entity: "commission_entry",
            fields: ENTRY_FIELDS,
            filters: { ...ofRep, void_period: period },
        }),
        query.graph({
            entity: "commission_adjustment",
            fields: ADJUSTMENT_FIELDS,
            filters: { ...ofRep, period },
        }),
        query.graph({
            entity: "commission_payout",
            fields: PAYOUT_FIELDS,
            filters: { ...ofRep, period },
        }),
    ]);
    const entries = new Map([...earned.data, ...voided.data].map((entry) => [entry.id, entry]));
    return {
        entries: [...entries.values()],
        adjustments: adjustments.data,
        payouts: payouts.data,
    };
};
exports.loadPeriodActivity = loadPeriodActivity;
/** All of one rep's entries, adjustments and payouts, for month-by-month history. */
const loadRepHistory = async (container, salesRepId) => loadHistory(container, { sales_rep_id: salesRepId });
exports.loadRepHistory = loadRepHistory;
/** Every rep's entries, adjustments and payouts. */
const loadAllHistory = async (container) => loadHistory(container, {});
exports.loadAllHistory = loadAllHistory;
const loadHistory = async (container, filters) => {
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const [entries, adjustments, payouts] = await Promise.all([
        query.graph({ entity: "commission_entry", fields: ENTRY_FIELDS, filters }),
        query.graph({
            entity: "commission_adjustment",
            fields: ADJUSTMENT_FIELDS,
            filters,
        }),
        query.graph({ entity: "commission_payout", fields: PAYOUT_FIELDS, filters }),
    ]);
    return {
        entries: entries.data,
        adjustments: adjustments.data,
        payouts: payouts.data,
    };
};
/** The months the owner has approved, oldest first. */
const loadApprovedPeriods = async (container) => {
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { data } = await query.graph({
        entity: "period_approval",
        fields: ["period"],
    });
    return data.map((row) => row.period).sort();
};
exports.loadApprovedPeriods = loadApprovedPeriods;
/** The latest approved month, or null. Everything up to it is payable. */
const loadApprovedThrough = async (container) => (0, approval_1.latestApproved)(await (0, exports.loadApprovedPeriods)(container));
exports.loadApprovedThrough = loadApprovedThrough;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGVyaW9kLWFjdGl2aXR5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3V0aWxzL3BlcmlvZC1hY3Rpdml0eS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxxREFBcUU7QUFDckUsOENBQWdEO0FBR2hELE1BQU0sWUFBWSxHQUFHO0lBQ25CLElBQUk7SUFDSixjQUFjO0lBQ2QsTUFBTTtJQUNOLFVBQVU7SUFDVixrQkFBa0I7SUFDbEIsYUFBYTtJQUNiLHFCQUFxQjtJQUNyQixhQUFhO0lBQ2IsZUFBZTtJQUNmLGFBQWE7SUFDYixNQUFNO0lBQ04sUUFBUTtJQUNSLDBCQUEwQjtJQUMxQixtQkFBbUI7SUFDbkIsU0FBUztJQUNULFdBQVc7SUFDWCxRQUFRO0lBQ1IsV0FBVztJQUNYLGFBQWE7SUFDYixhQUFhO0NBQ2QsQ0FBQTtBQUVELE1BQU0saUJBQWlCLEdBQUc7SUFDeEIsSUFBSTtJQUNKLGNBQWM7SUFDZCxlQUFlO0lBQ2YsUUFBUTtJQUNSLFFBQVE7SUFDUixRQUFRO0lBQ1IsVUFBVTtJQUNWLFlBQVk7SUFDWixZQUFZO0NBQ2IsQ0FBQTtBQUVELE1BQU0sYUFBYSxHQUFHO0lBQ3BCLElBQUk7SUFDSixjQUFjO0lBQ2QsZUFBZTtJQUNmLFFBQVE7SUFDUixRQUFRO0lBQ1IsU0FBUztJQUNULFdBQVc7Q0FDWixDQUFBO0FBUUQ7OztHQUdHO0FBQ0ksTUFBTSxrQkFBa0IsR0FBRyxLQUFLLEVBQ3JDLFNBQTBCLEVBQzFCLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBMkMsRUFDN0MsRUFBRTtJQUNwQixNQUFNLEtBQUssR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFBO0lBQ2hFLE1BQU0sS0FBSyxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxZQUFZLEVBQUUsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtJQUU1RCxNQUFNLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxXQUFXLEVBQUUsT0FBTyxDQUFDLEdBQUcsTUFBTSxPQUFPLENBQUMsR0FBRyxDQUFDO1FBQy9ELEtBQUssQ0FBQyxLQUFLLENBQUM7WUFDVixNQUFNLEVBQUUsa0JBQWtCO1lBQzFCLE1BQU0sRUFBRSxZQUFZO1lBQ3BCLE9BQU8sRUFBRSxFQUFFLEdBQUcsS0FBSyxFQUFFLE1BQU0sRUFBRTtTQUM5QixDQUFDO1FBQ0YsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUNWLE1BQU0sRUFBRSxrQkFBa0I7WUFDMUIsTUFBTSxFQUFFLFlBQVk7WUFDcEIsT0FBTyxFQUFFLEVBQUUsR0FBRyxLQUFLLEVBQUUsV0FBVyxFQUFFLE1BQU0sRUFBRTtTQUMzQyxDQUFDO1FBQ0YsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUNWLE1BQU0sRUFBRSx1QkFBdUI7WUFDL0IsTUFBTSxFQUFFLGlCQUFpQjtZQUN6QixPQUFPLEVBQUUsRUFBRSxHQUFHLEtBQUssRUFBRSxNQUFNLEVBQUU7U0FDOUIsQ0FBQztRQUNGLEtBQUssQ0FBQyxLQUFLLENBQUM7WUFDVixNQUFNLEVBQUUsbUJBQW1CO1lBQzNCLE1BQU0sRUFBRSxhQUFhO1lBQ3JCLE9BQU8sRUFBRSxFQUFFLEdBQUcsS0FBSyxFQUFFLE1BQU0sRUFBRTtTQUM5QixDQUFDO0tBQ0gsQ0FBQyxDQUFBO0lBRUYsTUFBTSxPQUFPLEdBQUcsSUFBSSxHQUFHLENBQ3JCLENBQUMsR0FBRyxNQUFNLENBQUMsSUFBSSxFQUFFLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQ25FLENBQUE7SUFFRCxPQUFPO1FBQ0wsT0FBTyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQWU7UUFDNUMsV0FBVyxFQUFFLFdBQVcsQ0FBQyxJQUF1QjtRQUNoRCxPQUFPLEVBQUUsT0FBTyxDQUFDLElBQW1CO0tBQ3JDLENBQUE7QUFDSCxDQUFDLENBQUE7QUF2Q1ksUUFBQSxrQkFBa0Isc0JBdUM5QjtBQUVELHFGQUFxRjtBQUM5RSxNQUFNLGNBQWMsR0FBRyxLQUFLLEVBQ2pDLFNBQTBCLEVBQzFCLFVBQWtCLEVBQ0EsRUFBRSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsRUFBRSxZQUFZLEVBQUUsVUFBVSxFQUFFLENBQUMsQ0FBQTtBQUg5RCxRQUFBLGNBQWMsa0JBR2dEO0FBRTNFLG9EQUFvRDtBQUM3QyxNQUFNLGNBQWMsR0FBRyxLQUFLLEVBQ2pDLFNBQTBCLEVBQ1IsRUFBRSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDLENBQUE7QUFGcEMsUUFBQSxjQUFjLGtCQUVzQjtBQUVqRCxNQUFNLFdBQVcsR0FBRyxLQUFLLEVBQ3ZCLFNBQTBCLEVBQzFCLE9BQWdDLEVBQ2QsRUFBRTtJQUNwQixNQUFNLEtBQUssR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFBO0lBRWhFLE1BQU0sQ0FBQyxPQUFPLEVBQUUsV0FBVyxFQUFFLE9BQU8sQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUN4RCxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUUsTUFBTSxFQUFFLGtCQUFrQixFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsT0FBTyxFQUFFLENBQUM7UUFDMUUsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUNWLE1BQU0sRUFBRSx1QkFBdUI7WUFDL0IsTUFBTSxFQUFFLGlCQUFpQjtZQUN6QixPQUFPO1NBQ1IsQ0FBQztRQUNGLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRSxNQUFNLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSxFQUFFLGFBQWEsRUFBRSxPQUFPLEVBQUUsQ0FBQztLQUM3RSxDQUFDLENBQUE7SUFFRixPQUFPO1FBQ0wsT0FBTyxFQUFFLE9BQU8sQ0FBQyxJQUFrQjtRQUNuQyxXQUFXLEVBQUUsV0FBVyxDQUFDLElBQXVCO1FBQ2hELE9BQU8sRUFBRSxPQUFPLENBQUMsSUFBbUI7S0FDckMsQ0FBQTtBQUNILENBQUMsQ0FBQTtBQUVELHVEQUF1RDtBQUNoRCxNQUFNLG1CQUFtQixHQUFHLEtBQUssRUFDdEMsU0FBMEIsRUFDUCxFQUFFO0lBQ3JCLE1BQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUE7SUFDaEUsTUFBTSxFQUFFLElBQUksRUFBRSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztRQUNqQyxNQUFNLEVBQUUsaUJBQWlCO1FBQ3pCLE1BQU0sRUFBRSxDQUFDLFFBQVEsQ0FBQztLQUNuQixDQUFDLENBQUE7SUFFRixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxNQUFnQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUE7QUFDdkQsQ0FBQyxDQUFBO0FBVlksUUFBQSxtQkFBbUIsdUJBVS9CO0FBRUQsMEVBQTBFO0FBQ25FLE1BQU0sbUJBQW1CLEdBQUcsS0FBSyxFQUN0QyxTQUEwQixFQUNGLEVBQUUsQ0FBQyxJQUFBLHlCQUFjLEVBQUMsTUFBTSxJQUFBLDJCQUFtQixFQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUE7QUFGcEUsUUFBQSxtQkFBbUIsdUJBRWlEIn0=