"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DELETE = DELETE;
const reopen_commission_period_1 = require("../../../../../workflows/reopen-commission-period");
const period_status_1 = require("../../../../../utils/period-status");
/** Undoes the latest approval, while no payout has been recorded since. */
async function DELETE(req, res) {
    await (0, reopen_commission_period_1.reopenCommissionPeriodWorkflow)(req.scope).run({});
    res.json(await (0, period_status_1.loadPeriodStatus)(req.scope));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLWNvbW1pc3Npb24vcGVyaW9kcy9sYXRlc3Qvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFRQSx3QkFPQztBQVhELGdHQUFrRztBQUNsRyxzRUFBcUU7QUFFckUsMkVBQTJFO0FBQ3BFLEtBQUssVUFBVSxNQUFNLENBQzFCLEdBQStCLEVBQy9CLEdBQW1CO0lBRW5CLE1BQU0sSUFBQSx5REFBOEIsRUFBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBRXZELEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFBLGdDQUFnQixFQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFBO0FBQzdDLENBQUMifQ==