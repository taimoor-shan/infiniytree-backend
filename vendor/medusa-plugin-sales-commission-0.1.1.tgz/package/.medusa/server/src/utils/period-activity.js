"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadRepHistory = exports.loadPeriodActivity = void 0;
const utils_1 = require("@medusajs/framework/utils");
const ENTRY_FIELDS = [
    "id",
    "sales_rep_id",
    "type",
    "order_id",
    "order_display_id",
    "customer_id",
    "source_sales_rep_id",
    "client_name",
    "currency_code",
    "base_amount",
    "rate",
    "amount",
    "earned_at",
    "period",
    "voided_at",
    "void_period",
    "void_reason",
];
/**
 * Everything that moves a month's balance: entries earned or voided in the
 * month, and the month's adjustments and payouts. Optionally for one rep.
 */
const loadPeriodActivity = async (container, { period, salesRepId }) => {
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const ofRep = salesRepId ? { sales_rep_id: salesRepId } : {};
    const [earned, voided, adjustments, payouts] = await Promise.all([
        query.graph({
            entity: "commission_entry",
            fields: ENTRY_FIELDS,
            filters: { ...ofRep, period },
        }),
        query.graph({
            entity: "commission_entry",
            fields: ENTRY_FIELDS,
            filters: { ...ofRep, void_period: period },
        }),
        query.graph({
            entity: "commission_adjustment",
            fields: [
                "id",
                "sales_rep_id",
                "currency_code",
                "amount",
                "period",
                "reason",
                "order_id",
                "created_at",
                "created_by",
            ],
            filters: { ...ofRep, period },
        }),
        query.graph({
            entity: "commission_payout",
            fields: [
                "id",
                "sales_rep_id",
                "currency_code",
                "amount",
                "period",
                "paid_at",
                "reference",
            ],
            filters: { ...ofRep, period },
        }),
    ]);
    const entries = new Map([...earned.data, ...voided.data].map((entry) => [entry.id, entry]));
    return {
        entries: [...entries.values()],
        adjustments: adjustments.data,
        payouts: payouts.data,
    };
};
exports.loadPeriodActivity = loadPeriodActivity;
/** All of one rep's entries, adjustments and payouts, for month-by-month history. */
const loadRepHistory = async (container, salesRepId) => {
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const filters = { sales_rep_id: salesRepId };
    const [entries, adjustments, payouts] = await Promise.all([
        query.graph({ entity: "commission_entry", fields: ENTRY_FIELDS, filters }),
        query.graph({
            entity: "commission_adjustment",
            fields: [
                "id",
                "sales_rep_id",
                "currency_code",
                "amount",
                "period",
                "reason",
                "order_id",
                "created_at",
            ],
            filters,
        }),
        query.graph({
            entity: "commission_payout",
            fields: [
                "id",
                "sales_rep_id",
                "currency_code",
                "amount",
                "period",
                "paid_at",
                "reference",
            ],
            filters,
        }),
    ]);
    return {
        entries: entries.data,
        adjustments: adjustments.data,
        payouts: payouts.data,
    };
};
exports.loadRepHistory = loadRepHistory;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGVyaW9kLWFjdGl2aXR5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3V0aWxzL3BlcmlvZC1hY3Rpdml0eS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxxREFBcUU7QUFHckUsTUFBTSxZQUFZLEdBQUc7SUFDbkIsSUFBSTtJQUNKLGNBQWM7SUFDZCxNQUFNO0lBQ04sVUFBVTtJQUNWLGtCQUFrQjtJQUNsQixhQUFhO0lBQ2IscUJBQXFCO0lBQ3JCLGFBQWE7SUFDYixlQUFlO0lBQ2YsYUFBYTtJQUNiLE1BQU07SUFDTixRQUFRO0lBQ1IsV0FBVztJQUNYLFFBQVE7SUFDUixXQUFXO0lBQ1gsYUFBYTtJQUNiLGFBQWE7Q0FDZCxDQUFBO0FBRUQ7OztHQUdHO0FBQ0ksTUFBTSxrQkFBa0IsR0FBRyxLQUFLLEVBQ3JDLFNBQTBCLEVBQzFCLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBMkMsRUFLOUQsRUFBRTtJQUNILE1BQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUE7SUFDaEUsTUFBTSxLQUFLLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFFLFlBQVksRUFBRSxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFBO0lBRTVELE1BQU0sQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLFdBQVcsRUFBRSxPQUFPLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7UUFDL0QsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUNWLE1BQU0sRUFBRSxrQkFBa0I7WUFDMUIsTUFBTSxFQUFFLFlBQVk7WUFDcEIsT0FBTyxFQUFFLEVBQUUsR0FBRyxLQUFLLEVBQUUsTUFBTSxFQUFFO1NBQzlCLENBQUM7UUFDRixLQUFLLENBQUMsS0FBSyxDQUFDO1lBQ1YsTUFBTSxFQUFFLGtCQUFrQjtZQUMxQixNQUFNLEVBQUUsWUFBWTtZQUNwQixPQUFPLEVBQUUsRUFBRSxHQUFHLEtBQUssRUFBRSxXQUFXLEVBQUUsTUFBTSxFQUFFO1NBQzNDLENBQUM7UUFDRixLQUFLLENBQUMsS0FBSyxDQUFDO1lBQ1YsTUFBTSxFQUFFLHVCQUF1QjtZQUMvQixNQUFNLEVBQUU7Z0JBQ04sSUFBSTtnQkFDSixjQUFjO2dCQUNkLGVBQWU7Z0JBQ2YsUUFBUTtnQkFDUixRQUFRO2dCQUNSLFFBQVE7Z0JBQ1IsVUFBVTtnQkFDVixZQUFZO2dCQUNaLFlBQVk7YUFDYjtZQUNELE9BQU8sRUFBRSxFQUFFLEdBQUcsS0FBSyxFQUFFLE1BQU0sRUFBRTtTQUM5QixDQUFDO1FBQ0YsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUNWLE1BQU0sRUFBRSxtQkFBbUI7WUFDM0IsTUFBTSxFQUFFO2dCQUNOLElBQUk7Z0JBQ0osY0FBYztnQkFDZCxlQUFlO2dCQUNmLFFBQVE7Z0JBQ1IsUUFBUTtnQkFDUixTQUFTO2dCQUNULFdBQVc7YUFDWjtZQUNELE9BQU8sRUFBRSxFQUFFLEdBQUcsS0FBSyxFQUFFLE1BQU0sRUFBRTtTQUM5QixDQUFDO0tBQ0gsQ0FBQyxDQUFBO0lBRUYsTUFBTSxPQUFPLEdBQUcsSUFBSSxHQUFHLENBQ3JCLENBQUMsR0FBRyxNQUFNLENBQUMsSUFBSSxFQUFFLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQ25FLENBQUE7SUFFRCxPQUFPO1FBQ0wsT0FBTyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQWU7UUFDNUMsV0FBVyxFQUFFLFdBQVcsQ0FBQyxJQUF1QjtRQUNoRCxPQUFPLEVBQUUsT0FBTyxDQUFDLElBQW1CO0tBQ3JDLENBQUE7QUFDSCxDQUFDLENBQUE7QUE3RFksUUFBQSxrQkFBa0Isc0JBNkQ5QjtBQUVELHFGQUFxRjtBQUM5RSxNQUFNLGNBQWMsR0FBRyxLQUFLLEVBQ2pDLFNBQTBCLEVBQzFCLFVBQWtCLEVBS2pCLEVBQUU7SUFDSCxNQUFNLEtBQUssR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFBO0lBQ2hFLE1BQU0sT0FBTyxHQUFHLEVBQUUsWUFBWSxFQUFFLFVBQVUsRUFBRSxDQUFBO0lBRTVDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsV0FBVyxFQUFFLE9BQU8sQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUN4RCxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUUsTUFBTSxFQUFFLGtCQUFrQixFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsT0FBTyxFQUFFLENBQUM7UUFDMUUsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUNWLE1BQU0sRUFBRSx1QkFBdUI7WUFDL0IsTUFBTSxFQUFFO2dCQUNOLElBQUk7Z0JBQ0osY0FBYztnQkFDZCxlQUFlO2dCQUNmLFFBQVE7Z0JBQ1IsUUFBUTtnQkFDUixRQUFRO2dCQUNSLFVBQVU7Z0JBQ1YsWUFBWTthQUNiO1lBQ0QsT0FBTztTQUNSLENBQUM7UUFDRixLQUFLLENBQUMsS0FBSyxDQUFDO1lBQ1YsTUFBTSxFQUFFLG1CQUFtQjtZQUMzQixNQUFNLEVBQUU7Z0JBQ04sSUFBSTtnQkFDSixjQUFjO2dCQUNkLGVBQWU7Z0JBQ2YsUUFBUTtnQkFDUixRQUFRO2dCQUNSLFNBQVM7Z0JBQ1QsV0FBVzthQUNaO1lBQ0QsT0FBTztTQUNSLENBQUM7S0FDSCxDQUFDLENBQUE7SUFFRixPQUFPO1FBQ0wsT0FBTyxFQUFFLE9BQU8sQ0FBQyxJQUFrQjtRQUNuQyxXQUFXLEVBQUUsV0FBVyxDQUFDLElBQXVCO1FBQ2hELE9BQU8sRUFBRSxPQUFPLENBQUMsSUFBbUI7S0FDckMsQ0FBQTtBQUNILENBQUMsQ0FBQTtBQS9DWSxRQUFBLGNBQWMsa0JBK0MxQiJ9