"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cancelRepInviteWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const cancel_rep_invite_1 = require("./steps/cancel-rep-invite");
exports.cancelRepInviteWorkflow = (0, workflows_sdk_1.createWorkflow)("cancel-rep-invite", function (input) {
    const invite = (0, cancel_rep_invite_1.cancelRepInviteStep)(input);
    return new workflows_sdk_1.WorkflowResponse(invite);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FuY2VsLXJlcC1pbnZpdGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL2NhbmNlbC1yZXAtaW52aXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFFQUcwQztBQUMxQyxpRUFBK0Q7QUFFbEQsUUFBQSx1QkFBdUIsR0FBRyxJQUFBLDhCQUFjLEVBQ25ELG1CQUFtQixFQUNuQixVQUFVLEtBQTREO0lBQ3BFLE1BQU0sTUFBTSxHQUFHLElBQUEsdUNBQW1CLEVBQUMsS0FBSyxDQUFDLENBQUE7SUFFekMsT0FBTyxJQUFJLGdDQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFBO0FBQ3JDLENBQUMsQ0FDRixDQUFBIn0=