"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateSalesRepStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const sales_commission_1 = require("../../modules/sales-commission");
const sales_rep_email_1 = require("./sales-rep-email");
exports.updateSalesRepStep = (0, workflows_sdk_1.createStep)("update-sales-rep", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const previous = await service.retrieveSalesRep(input.id);
    const data = { ...input };
    if (data.name !== undefined) {
        data.name = data.name.trim();
    }
    if (data.email !== undefined) {
        data.email = (0, sales_rep_email_1.normalizeEmail)(data.email);
        await (0, sales_rep_email_1.assertEmailAvailable)(service, data.email, input.id);
    }
    const salesRep = await service.updateSalesReps(data);
    return new workflows_sdk_1.StepResponse(salesRep, previous);
}, async (previous, { container }) => {
    if (!previous) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.updateSalesReps({
        id: previous.id,
        name: previous.name,
        email: previous.email,
        phone: previous.phone,
        notes: previous.notes,
        is_active: previous.is_active,
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXBkYXRlLXNhbGVzLXJlcC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3Mvc3RlcHMvdXBkYXRlLXNhbGVzLXJlcC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxRUFBNEU7QUFDNUUscUVBQXdFO0FBRXhFLHVEQUF3RTtBQVczRCxRQUFBLGtCQUFrQixHQUFHLElBQUEsMEJBQVUsRUFDMUMsa0JBQWtCLEVBQ2xCLEtBQUssRUFBRSxLQUE4QixFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUN0RCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLFFBQVEsR0FBRyxNQUFNLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUE7SUFFekQsTUFBTSxJQUFJLEdBQUcsRUFBRSxHQUFHLEtBQUssRUFBRSxDQUFBO0lBQ3pCLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUM1QixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUE7SUFDOUIsQ0FBQztJQUNELElBQUksSUFBSSxDQUFDLEtBQUssS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUM3QixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUEsZ0NBQWMsRUFBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUE7UUFDdkMsTUFBTSxJQUFBLHNDQUFvQixFQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUMzRCxDQUFDO0lBRUQsTUFBTSxRQUFRLEdBQUcsTUFBTSxPQUFPLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFBO0lBRXBELE9BQU8sSUFBSSw0QkFBWSxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQTtBQUM3QyxDQUFDLEVBQ0QsS0FBSyxFQUFFLFFBQVEsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDaEMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2QsT0FBTTtJQUNSLENBQUM7SUFDRCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLE9BQU8sQ0FBQyxlQUFlLENBQUM7UUFDNUIsRUFBRSxFQUFFLFFBQVEsQ0FBQyxFQUFFO1FBQ2YsSUFBSSxFQUFFLFFBQVEsQ0FBQyxJQUFJO1FBQ25CLEtBQUssRUFBRSxRQUFRLENBQUMsS0FBSztRQUNyQixLQUFLLEVBQUUsUUFBUSxDQUFDLEtBQUs7UUFDckIsS0FBSyxFQUFFLFFBQVEsQ0FBQyxLQUFLO1FBQ3JCLFNBQVMsRUFBRSxRQUFRLENBQUMsU0FBUztLQUM5QixDQUFDLENBQUE7QUFDSixDQUFDLENBQ0YsQ0FBQSJ9