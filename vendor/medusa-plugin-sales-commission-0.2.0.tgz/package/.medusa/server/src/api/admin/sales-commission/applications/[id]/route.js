"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const sales_commission_1 = require("../../../../../modules/sales-commission");
const applications_1 = require("../../../../../utils/applications");
const invites_1 = require("../../../../../utils/invites");
/**
 * One application with the recruiter, the terms the approval form starts
 * with, and anything that would stop an approval, so it is shown up front.
 */
async function GET(req, res) {
    const service = req.scope.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const invite = await service.retrieveRepInvite(req.params.id);
    const recruiter = await service.retrieveSalesRep(invite.recruiter_sales_rep_id);
    const settings = (0, invites_1.recruitingSettings)(service);
    res.json({
        application: (0, applications_1.adminApplicationView)(invite, recruiter),
        recruiter: {
            id: recruiter.id,
            name: recruiter.name,
            email: recruiter.email,
            is_active: recruiter.is_active,
        },
        defaults: {
            level2_rate: settings.level2_default_rate,
            level2_months: settings.level2_default_months,
        },
        blockers: await (0, applications_1.approvalBlockers)(req.scope, invite, recruiter),
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLWNvbW1pc3Npb24vYXBwbGljYXRpb25zL1tpZF0vcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFnQkEsa0JBMEJDO0FBdENELDhFQUFpRjtBQUVqRixvRUFHMEM7QUFDMUMsMERBQWlFO0FBRWpFOzs7R0FHRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQStCLEVBQy9CLEdBQW1CO0lBRW5CLE1BQU0sT0FBTyxHQUFpQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFFRCxNQUFNLE1BQU0sR0FBRyxNQUFNLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBQzdELE1BQU0sU0FBUyxHQUFHLE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFBO0lBQy9FLE1BQU0sUUFBUSxHQUFHLElBQUEsNEJBQWtCLEVBQUMsT0FBTyxDQUFDLENBQUE7SUFFNUMsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNQLFdBQVcsRUFBRSxJQUFBLG1DQUFvQixFQUFDLE1BQU0sRUFBRSxTQUFTLENBQUM7UUFDcEQsU0FBUyxFQUFFO1lBQ1QsRUFBRSxFQUFFLFNBQVMsQ0FBQyxFQUFFO1lBQ2hCLElBQUksRUFBRSxTQUFTLENBQUMsSUFBSTtZQUNwQixLQUFLLEVBQUUsU0FBUyxDQUFDLEtBQUs7WUFDdEIsU0FBUyxFQUFFLFNBQVMsQ0FBQyxTQUFTO1NBQy9CO1FBQ0QsUUFBUSxFQUFFO1lBQ1IsV0FBVyxFQUFFLFFBQVEsQ0FBQyxtQkFBbUI7WUFDekMsYUFBYSxFQUFFLFFBQVEsQ0FBQyxxQkFBcUI7U0FDOUM7UUFDRCxRQUFRLEVBQUUsTUFBTSxJQUFBLCtCQUFnQixFQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLFNBQVMsQ0FBQztLQUMvRCxDQUFDLENBQUE7QUFDSixDQUFDIn0=