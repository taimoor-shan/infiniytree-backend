"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.endOpenClientAssignmentStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const sales_commission_1 = require("../../modules/sales-commission");
exports.endOpenClientAssignmentStep = (0, workflows_sdk_1.createStep)("end-open-client-assignment", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const [open] = await service.listClientAssignments({ customer_id: input.customer_id, ends_at: null }, { take: 1 });
    if (!open) {
        if (input.required) {
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, `Customer ${input.customer_id} has no current sales rep`);
        }
        return new workflows_sdk_1.StepResponse(null, null);
    }
    const ended = await service.updateClientAssignments({
        id: open.id,
        ends_at: input.ended_at,
        ended_by: input.ended_by ?? null,
    });
    return new workflows_sdk_1.StepResponse(ended, open.id);
}, async (assignmentId, { container }) => {
    if (!assignmentId) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.updateClientAssignments({
        id: assignmentId,
        ends_at: null,
        ended_by: null,
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW5kLW9wZW4tY2xpZW50LWFzc2lnbm1lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL3N0ZXBzL2VuZC1vcGVuLWNsaWVudC1hc3NpZ25tZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFEQUF1RDtBQUN2RCxxRUFBNEU7QUFDNUUscUVBQXdFO0FBVzNELFFBQUEsMkJBQTJCLEdBQUcsSUFBQSwwQkFBVSxFQUNuRCw0QkFBNEIsRUFDNUIsS0FBSyxFQUFFLEtBQXVDLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQy9ELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxxQkFBcUIsQ0FDaEQsRUFBRSxXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVcsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQ2pELEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUNaLENBQUE7SUFFRCxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDVixJQUFJLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNuQixNQUFNLElBQUksbUJBQVcsQ0FDbkIsbUJBQVcsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUMzQixZQUFZLEtBQUssQ0FBQyxXQUFXLDJCQUEyQixDQUN6RCxDQUFBO1FBQ0gsQ0FBQztRQUNELE9BQU8sSUFBSSw0QkFBWSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQTtJQUNyQyxDQUFDO0lBRUQsTUFBTSxLQUFLLEdBQUcsTUFBTSxPQUFPLENBQUMsdUJBQXVCLENBQUM7UUFDbEQsRUFBRSxFQUFFLElBQUksQ0FBQyxFQUFFO1FBQ1gsT0FBTyxFQUFFLEtBQUssQ0FBQyxRQUFRO1FBQ3ZCLFFBQVEsRUFBRSxLQUFLLENBQUMsUUFBUSxJQUFJLElBQUk7S0FDakMsQ0FBQyxDQUFBO0lBRUYsT0FBTyxJQUFJLDRCQUFZLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQTtBQUN6QyxDQUFDLEVBQ0QsS0FBSyxFQUFFLFlBQVksRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDcEMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ2xCLE9BQU07SUFDUixDQUFDO0lBQ0QsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxPQUFPLENBQUMsdUJBQXVCLENBQUM7UUFDcEMsRUFBRSxFQUFFLFlBQVk7UUFDaEIsT0FBTyxFQUFFLElBQUk7UUFDYixRQUFRLEVBQUUsSUFBSTtLQUNmLENBQUMsQ0FBQTtBQUNKLENBQUMsQ0FDRixDQUFBIn0=