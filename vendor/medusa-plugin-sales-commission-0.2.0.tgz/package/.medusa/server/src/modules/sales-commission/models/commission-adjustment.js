"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const sales_rep_1 = __importDefault(require("./sales-rep"));
/** A manual, signed correction with a required reason. Never edited. */
const CommissionAdjustment = utils_1.model
    .define("commission_adjustment", {
    id: utils_1.model.id({ prefix: "scadj" }).primaryKey(),
    currency_code: utils_1.model.text(),
    amount: utils_1.model.bigNumber(),
    period: utils_1.model.text(),
    reason: utils_1.model.text(),
    order_id: utils_1.model.text().nullable(),
    /** What made it: "partial_refund" or "payout_bonus"; null for manual ones */
    kind: utils_1.model.text().nullable(),
    /** The entry (partial refund) or payout (bonus) it comes from */
    source_id: utils_1.model.text().nullable(),
    created_by: utils_1.model.text().nullable(),
    sales_rep: utils_1.model.belongsTo(() => sales_rep_1.default, { mappedBy: "adjustments" }),
})
    .indexes([{ on: ["period"] }]);
exports.default = CommissionAdjustment;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbWlzc2lvbi1hZGp1c3RtZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL21vZHVsZXMvc2FsZXMtY29tbWlzc2lvbi9tb2RlbHMvY29tbWlzc2lvbi1hZGp1c3RtZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEscURBQWlEO0FBQ2pELDREQUFrQztBQUVsQyx3RUFBd0U7QUFDeEUsTUFBTSxvQkFBb0IsR0FBRyxhQUFLO0tBQy9CLE1BQU0sQ0FBQyx1QkFBdUIsRUFBRTtJQUMvQixFQUFFLEVBQUUsYUFBSyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDLFVBQVUsRUFBRTtJQUM5QyxhQUFhLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUMzQixNQUFNLEVBQUUsYUFBSyxDQUFDLFNBQVMsRUFBRTtJQUN6QixNQUFNLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUNwQixNQUFNLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUNwQixRQUFRLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNqQyw2RUFBNkU7SUFDN0UsSUFBSSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDN0IsaUVBQWlFO0lBQ2pFLFNBQVMsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ2xDLFVBQVUsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ25DLFNBQVMsRUFBRSxhQUFLLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLG1CQUFRLEVBQUUsRUFBRSxRQUFRLEVBQUUsYUFBYSxFQUFFLENBQUM7Q0FDeEUsQ0FBQztLQUNELE9BQU8sQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUE7QUFFaEMsa0JBQWUsb0JBQW9CLENBQUEifQ==