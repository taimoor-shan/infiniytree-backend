"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migration20261004124806 = void 0;
const migrations_1 = require("@medusajs/framework/mikro-orm/migrations");
class Migration20261004124806 extends migrations_1.Migration {
    async up() {
        this.addSql(`alter table if exists "sales_rep" drop constraint if exists "sales_rep_auth_identity_id_unique";`);
        this.addSql(`alter table if exists "sales_rep" add column if not exists "auth_identity_id" text null;`);
        this.addSql(`CREATE UNIQUE INDEX IF NOT EXISTS "IDX_sales_rep_auth_identity_id_unique" ON "sales_rep" ("auth_identity_id") WHERE auth_identity_id IS NOT NULL AND deleted_at IS NULL;`);
    }
    async down() {
        this.addSql(`drop index if exists "IDX_sales_rep_auth_identity_id_unique";`);
        this.addSql(`alter table if exists "sales_rep" drop column if exists "auth_identity_id";`);
    }
}
exports.Migration20261004124806 = Migration20261004124806;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWlncmF0aW9uMjAyNjEwMDQxMjQ4MDYuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9zYWxlcy1jb21taXNzaW9uL21pZ3JhdGlvbnMvTWlncmF0aW9uMjAyNjEwMDQxMjQ4MDYudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEseUVBQXFFO0FBRXJFLE1BQWEsdUJBQXdCLFNBQVEsc0JBQVM7SUFFM0MsS0FBSyxDQUFDLEVBQUU7UUFDZixJQUFJLENBQUMsTUFBTSxDQUFDLGtHQUFrRyxDQUFDLENBQUM7UUFDaEgsSUFBSSxDQUFDLE1BQU0sQ0FBQywwRkFBMEYsQ0FBQyxDQUFDO1FBQ3hHLElBQUksQ0FBQyxNQUFNLENBQUMsMEtBQTBLLENBQUMsQ0FBQztJQUMxTCxDQUFDO0lBRVEsS0FBSyxDQUFDLElBQUk7UUFDakIsSUFBSSxDQUFDLE1BQU0sQ0FBQywrREFBK0QsQ0FBQyxDQUFDO1FBQzdFLElBQUksQ0FBQyxNQUFNLENBQUMsNkVBQTZFLENBQUMsQ0FBQztJQUM3RixDQUFDO0NBRUY7QUFiRCwwREFhQyJ9