"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
exports.DELETE = DELETE;
const end_rep_referral_1 = require("../../../../../workflows/end-rep-referral");
const set_rep_referral_1 = require("../../../../../workflows/set-rep-referral");
/** Set or replace who referred this rep, with the Level 2 rate. */
async function POST(req, res) {
    const { result } = await (0, set_rep_referral_1.setRepReferralWorkflow)(req.scope).run({
        input: {
            ...req.validatedBody,
            referred_sales_rep_id: req.params.id,
            actor_id: req.auth_context.actor_id,
        },
    });
    res.json({ referral: result });
}
async function DELETE(req, res) {
    const { result } = await (0, end_rep_referral_1.endRepReferralWorkflow)(req.scope).run({
        input: {
            referred_sales_rep_id: req.params.id,
            actor_id: req.auth_context.actor_id,
        },
    });
    res.json({ referral: result });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLXJlcHMvW2lkXS9yZWZlcnJhbC9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVNBLG9CQWFDO0FBRUQsd0JBWUM7QUFoQ0QsZ0ZBQWtGO0FBQ2xGLGdGQUFrRjtBQUdsRixtRUFBbUU7QUFDNUQsS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBd0QsRUFDeEQsR0FBbUI7SUFFbkIsTUFBTSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sSUFBQSx5Q0FBc0IsRUFBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDO1FBQzdELEtBQUssRUFBRTtZQUNMLEdBQUcsR0FBRyxDQUFDLGFBQWE7WUFDcEIscUJBQXFCLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ3BDLFFBQVEsRUFBRSxHQUFHLENBQUMsWUFBWSxDQUFDLFFBQVE7U0FDcEM7S0FDRixDQUFDLENBQUE7SUFFRixHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUE7QUFDaEMsQ0FBQztBQUVNLEtBQUssVUFBVSxNQUFNLENBQzFCLEdBQStCLEVBQy9CLEdBQW1CO0lBRW5CLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLElBQUEseUNBQXNCLEVBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUM3RCxLQUFLLEVBQUU7WUFDTCxxQkFBcUIsRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDcEMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxZQUFZLENBQUMsUUFBUTtTQUNwQztLQUNGLENBQUMsQ0FBQTtJQUVGLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQTtBQUNoQyxDQUFDIn0=