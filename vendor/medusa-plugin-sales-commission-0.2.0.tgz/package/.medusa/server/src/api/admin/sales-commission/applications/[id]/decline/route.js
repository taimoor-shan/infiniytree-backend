"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const decline_rep_application_1 = require("../../../../../../workflows/decline-rep-application");
/** Declines an application. The candidate and the recruiter are told, without the reason. */
async function POST(req, res) {
    await (0, decline_rep_application_1.declineRepApplicationWorkflow)(req.scope).run({
        input: {
            invite_id: req.params.id,
            reason: req.validatedBody.reason,
            actor_id: req.auth_context.actor_id,
        },
    });
    res.json({ id: req.params.id, status: "declined" });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLWNvbW1pc3Npb24vYXBwbGljYXRpb25zL1tpZF0vZGVjbGluZS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVFBLG9CQWFDO0FBakJELGlHQUFtRztBQUduRyw2RkFBNkY7QUFDdEYsS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBNEQsRUFDNUQsR0FBbUI7SUFFbkIsTUFBTSxJQUFBLHVEQUE2QixFQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUM7UUFDakQsS0FBSyxFQUFFO1lBQ0wsU0FBUyxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUN4QixNQUFNLEVBQUUsR0FBRyxDQUFDLGFBQWEsQ0FBQyxNQUFNO1lBQ2hDLFFBQVEsRUFBRSxHQUFHLENBQUMsWUFBWSxDQUFDLFFBQVE7U0FDcEM7S0FDRixDQUFDLENBQUE7SUFFRixHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsQ0FBQyxDQUFBO0FBQ3JELENBQUMifQ==