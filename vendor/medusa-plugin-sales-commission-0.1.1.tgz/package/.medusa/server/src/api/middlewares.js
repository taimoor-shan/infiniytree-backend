"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = require("@medusajs/framework/http");
const validators_1 = require("./admin/customers/validators");
const validators_2 = require("./admin/sales-commission/validators");
const query_config_1 = require("./admin/sales-reps/query-config");
const middlewares_1 = require("./sales-portal/middlewares");
const validators_3 = require("./sales-portal/validators");
const validators_4 = require("./admin/sales-reps/validators");
exports.default = (0, http_1.defineMiddlewares)({
    routes: [
        {
            matcher: "/admin/sales-reps",
            method: "GET",
            middlewares: [
                (0, http_1.validateAndTransformQuery)(validators_4.AdminGetSalesRepsParams, query_config_1.listSalesRepsQueryConfig),
            ],
        },
        {
            matcher: "/admin/sales-reps",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_4.AdminCreateSalesRep)],
        },
        {
            matcher: "/admin/sales-reps/:id",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_4.AdminUpdateSalesRep)],
        },
        {
            matcher: "/admin/sales-reps/:id/contracts",
            method: "POST",
            // base64 of a 10 MB contract is ~13.4 MB
            bodyParser: { sizeLimit: "15mb" },
            middlewares: [(0, http_1.validateAndTransformBody)(validators_4.AdminUploadSalesRepContract)],
        },
        {
            matcher: "/admin/sales-reps/:id/referral",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_4.AdminSetRepReferral)],
        },
        {
            matcher: "/admin/sales-reps/:id/adjustments",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_2.AdminCreateCommissionAdjustment)],
        },
        {
            matcher: "/admin/sales-reps/:id/payouts",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_2.AdminCreateCommissionPayout)],
        },
        {
            matcher: "/admin/sales-reps/:id/statement",
            method: "GET",
            middlewares: [(0, http_1.validateAndTransformQuery)(validators_2.AdminCommissionPeriodParams, {})],
        },
        {
            matcher: "/admin/sales-commission/report",
            method: "GET",
            middlewares: [(0, http_1.validateAndTransformQuery)(validators_2.AdminCommissionPeriodParams, {})],
        },
        {
            matcher: "/admin/customers/:id/sales-rep-assignment",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_1.AdminAssignClient)],
        },
        // Sales portal: everything under /sales-portal needs a signed-in rep who
        // currently has access. Listed first so a route added later is protected
        // by default.
        {
            matcher: "/sales-portal*",
            middlewares: [
                (0, http_1.authenticate)("sales_rep", ["session", "bearer"]),
                middlewares_1.ensureActiveSalesRep,
            ],
        },
        ...["/sales-portal/summary", "/sales-portal/statement", "/sales-portal/clients"].map((matcher) => ({
            matcher,
            method: "GET",
            middlewares: [(0, http_1.validateAndTransformQuery)(validators_3.PortalPeriodParams, {})],
        })),
        ...["/sales-portal/clients/:customer_id/orders", "/sales-portal/statements"].map((matcher) => ({
            matcher,
            method: "GET",
            middlewares: [(0, http_1.validateAndTransformQuery)(validators_3.PortalPageParams, {})],
        })),
    ],
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWlkZGxld2FyZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvYXBpL21pZGRsZXdhcmVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsbURBS2lDO0FBQ2pDLDZEQUFnRTtBQUNoRSxvRUFJNEM7QUFDNUMsa0VBQTBFO0FBQzFFLDREQUFpRTtBQUNqRSwwREFBZ0Y7QUFDaEYsOERBTXNDO0FBRXRDLGtCQUFlLElBQUEsd0JBQWlCLEVBQUM7SUFDL0IsTUFBTSxFQUFFO1FBQ047WUFDRSxPQUFPLEVBQUUsbUJBQW1CO1lBQzVCLE1BQU0sRUFBRSxLQUFLO1lBQ2IsV0FBVyxFQUFFO2dCQUNYLElBQUEsZ0NBQXlCLEVBQ3ZCLG9DQUF1QixFQUN2Qix1Q0FBd0IsQ0FDekI7YUFDRjtTQUNGO1FBQ0Q7WUFDRSxPQUFPLEVBQUUsbUJBQW1CO1lBQzVCLE1BQU0sRUFBRSxNQUFNO1lBQ2QsV0FBVyxFQUFFLENBQUMsSUFBQSwrQkFBd0IsRUFBQyxnQ0FBbUIsQ0FBQyxDQUFDO1NBQzdEO1FBQ0Q7WUFDRSxPQUFPLEVBQUUsdUJBQXVCO1lBQ2hDLE1BQU0sRUFBRSxNQUFNO1lBQ2QsV0FBVyxFQUFFLENBQUMsSUFBQSwrQkFBd0IsRUFBQyxnQ0FBbUIsQ0FBQyxDQUFDO1NBQzdEO1FBQ0Q7WUFDRSxPQUFPLEVBQUUsaUNBQWlDO1lBQzFDLE1BQU0sRUFBRSxNQUFNO1lBQ2QseUNBQXlDO1lBQ3pDLFVBQVUsRUFBRSxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUU7WUFDakMsV0FBVyxFQUFFLENBQUMsSUFBQSwrQkFBd0IsRUFBQyx3Q0FBMkIsQ0FBQyxDQUFDO1NBQ3JFO1FBQ0Q7WUFDRSxPQUFPLEVBQUUsZ0NBQWdDO1lBQ3pDLE1BQU0sRUFBRSxNQUFNO1lBQ2QsV0FBVyxFQUFFLENBQUMsSUFBQSwrQkFBd0IsRUFBQyxnQ0FBbUIsQ0FBQyxDQUFDO1NBQzdEO1FBQ0Q7WUFDRSxPQUFPLEVBQUUsbUNBQW1DO1lBQzVDLE1BQU0sRUFBRSxNQUFNO1lBQ2QsV0FBVyxFQUFFLENBQUMsSUFBQSwrQkFBd0IsRUFBQyw0Q0FBK0IsQ0FBQyxDQUFDO1NBQ3pFO1FBQ0Q7WUFDRSxPQUFPLEVBQUUsK0JBQStCO1lBQ3hDLE1BQU0sRUFBRSxNQUFNO1lBQ2QsV0FBVyxFQUFFLENBQUMsSUFBQSwrQkFBd0IsRUFBQyx3Q0FBMkIsQ0FBQyxDQUFDO1NBQ3JFO1FBQ0Q7WUFDRSxPQUFPLEVBQUUsaUNBQWlDO1lBQzFDLE1BQU0sRUFBRSxLQUFLO1lBQ2IsV0FBVyxFQUFFLENBQUMsSUFBQSxnQ0FBeUIsRUFBQyx3Q0FBMkIsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUMxRTtRQUNEO1lBQ0UsT0FBTyxFQUFFLGdDQUFnQztZQUN6QyxNQUFNLEVBQUUsS0FBSztZQUNiLFdBQVcsRUFBRSxDQUFDLElBQUEsZ0NBQXlCLEVBQUMsd0NBQTJCLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDMUU7UUFDRDtZQUNFLE9BQU8sRUFBRSwyQ0FBMkM7WUFDcEQsTUFBTSxFQUFFLE1BQU07WUFDZCxXQUFXLEVBQUUsQ0FBQyxJQUFBLCtCQUF3QixFQUFDLDhCQUFpQixDQUFDLENBQUM7U0FDM0Q7UUFFRCx5RUFBeUU7UUFDekUseUVBQXlFO1FBQ3pFLGNBQWM7UUFDZDtZQUNFLE9BQU8sRUFBRSxnQkFBZ0I7WUFDekIsV0FBVyxFQUFFO2dCQUNYLElBQUEsbUJBQVksRUFBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTLEVBQUUsUUFBUSxDQUFDLENBQUM7Z0JBQ2hELGtDQUFvQjthQUNyQjtTQUNGO1FBQ0QsR0FBRyxDQUFDLHVCQUF1QixFQUFFLHlCQUF5QixFQUFFLHVCQUF1QixDQUFDLENBQUMsR0FBRyxDQUNsRixDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQztZQUNaLE9BQU87WUFDUCxNQUFNLEVBQUUsS0FBYztZQUN0QixXQUFXLEVBQUUsQ0FBQyxJQUFBLGdDQUF5QixFQUFDLCtCQUFrQixFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQ2pFLENBQUMsQ0FDSDtRQUNELEdBQUcsQ0FBQywyQ0FBMkMsRUFBRSwwQkFBMEIsQ0FBQyxDQUFDLEdBQUcsQ0FDOUUsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDWixPQUFPO1lBQ1AsTUFBTSxFQUFFLEtBQWM7WUFDdEIsV0FBVyxFQUFFLENBQUMsSUFBQSxnQ0FBeUIsRUFBQyw2QkFBZ0IsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUMvRCxDQUFDLENBQ0g7S0FDRjtDQUNGLENBQUMsQ0FBQSJ9