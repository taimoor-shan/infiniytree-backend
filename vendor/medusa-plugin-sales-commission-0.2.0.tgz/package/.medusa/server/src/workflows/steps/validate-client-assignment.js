"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateClientAssignmentStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const sales_commission_1 = require("../../modules/sales-commission");
exports.validateClientAssignmentStep = (0, workflows_sdk_1.createStep)("validate-client-assignment", async (input, { container }) => {
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { data: [customer], } = await query.graph({
        entity: "customer",
        fields: ["id", "email"],
        filters: { id: input.customer_id },
    });
    if (!customer) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, `Customer ${input.customer_id} was not found`);
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const salesRep = await service.retrieveSalesRep(input.sales_rep_id);
    if (!salesRep.is_active) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, `Sales rep ${salesRep.name} is inactive and can't take new clients`);
    }
    // A rep earning commission on their own purchases isn't selling anything
    if (customer.email &&
        customer.email.trim().toLowerCase() === salesRep.email.trim().toLowerCase()) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, `${salesRep.name} can't be assigned their own customer account`);
    }
    if (input.commission_rate < 0 || input.commission_rate > 100) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, "Commission rate must be between 0 and 100 percent");
    }
    const [open] = await service.listClientAssignments({ customer_id: input.customer_id, ends_at: null }, { take: 1 });
    if (open &&
        open.sales_rep_id === input.sales_rep_id &&
        utils_1.MathBN.eq(open.commission_rate, input.commission_rate)) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, "The customer already has this sales rep at this rate");
    }
    return new workflows_sdk_1.StepResponse(open ?? null);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdGUtY2xpZW50LWFzc2lnbm1lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL3N0ZXBzL3ZhbGlkYXRlLWNsaWVudC1hc3NpZ25tZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFEQUlrQztBQUNsQyxxRUFBNEU7QUFDNUUscUVBQXdFO0FBUzNELFFBQUEsNEJBQTRCLEdBQUcsSUFBQSwwQkFBVSxFQUNwRCw0QkFBNEIsRUFDNUIsS0FBSyxFQUFFLEtBQXdDLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQ2hFLE1BQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUE7SUFDaEUsTUFBTSxFQUNKLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUNqQixHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztRQUNwQixNQUFNLEVBQUUsVUFBVTtRQUNsQixNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDO1FBQ3ZCLE9BQU8sRUFBRSxFQUFFLEVBQUUsRUFBRSxLQUFLLENBQUMsV0FBVyxFQUFFO0tBQ25DLENBQUMsQ0FBQTtJQUNGLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNkLE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQzNCLFlBQVksS0FBSyxDQUFDLFdBQVcsZ0JBQWdCLENBQzlDLENBQUE7SUFDSCxDQUFDO0lBRUQsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxRQUFRLEdBQUcsTUFBTSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFBO0lBQ25FLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDeEIsTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFDOUIsYUFBYSxRQUFRLENBQUMsSUFBSSx5Q0FBeUMsQ0FDcEUsQ0FBQTtJQUNILENBQUM7SUFFRCx5RUFBeUU7SUFDekUsSUFDRSxRQUFRLENBQUMsS0FBSztRQUNkLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLEtBQUssUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsRUFDM0UsQ0FBQztRQUNELE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQzlCLEdBQUcsUUFBUSxDQUFDLElBQUksK0NBQStDLENBQ2hFLENBQUE7SUFDSCxDQUFDO0lBRUQsSUFBSSxLQUFLLENBQUMsZUFBZSxHQUFHLENBQUMsSUFBSSxLQUFLLENBQUMsZUFBZSxHQUFHLEdBQUcsRUFBRSxDQUFDO1FBQzdELE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQzlCLG1EQUFtRCxDQUNwRCxDQUFBO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxxQkFBcUIsQ0FDaEQsRUFBRSxXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVcsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQ2pELEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUNaLENBQUE7SUFDRCxJQUNFLElBQUk7UUFDSixJQUFJLENBQUMsWUFBWSxLQUFLLEtBQUssQ0FBQyxZQUFZO1FBQ3hDLGNBQU0sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsZUFBZSxDQUFDLEVBQ3RELENBQUM7UUFDRCxNQUFNLElBQUksbUJBQVcsQ0FDbkIsbUJBQVcsQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUM5QixzREFBc0QsQ0FDdkQsQ0FBQTtJQUNILENBQUM7SUFFRCxPQUFPLElBQUksNEJBQVksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUE7QUFDdkMsQ0FBQyxDQUNGLENBQUEifQ==