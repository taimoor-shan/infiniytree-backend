"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const sales_commission_1 = require("../../../../../modules/sales-commission");
const client_links_1 = require("../../../../../utils/client-links");
/**
 * The rep's client link: the code and address, whether it links clients (the
 * rep must be active and have a standard rate), and the latest clients who
 * came through it, including those who were not linked and why. A rep who has
 * no code yet gets one the first time the owner looks.
 */
async function GET(req, res) {
    res.json({ client_link: await (0, client_links_1.loadAdminClientLink)(req.scope, req.params.id) });
}
/**
 * Makes the rep a new code. The old link stops working at once, which is the
 * remedy for a link that got into the wrong hands.
 */
async function POST(req, res) {
    const service = req.scope.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    // 404 for a rep that doesn't exist
    await service.retrieveSalesRep(req.params.id);
    await (0, client_links_1.makeClientLinkCode)(service, req.params.id);
    res.json({ client_link: await (0, client_links_1.loadAdminClientLink)(req.scope, req.params.id) });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLXJlcHMvW2lkXS9jbGllbnQtbGluay9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQWlCQSxrQkFLQztBQU1ELG9CQVlDO0FBcENELDhFQUFpRjtBQUVqRixvRUFHMEM7QUFFMUM7Ozs7O0dBS0c7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUErQixFQUMvQixHQUFtQjtJQUVuQixHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsV0FBVyxFQUFFLE1BQU0sSUFBQSxrQ0FBbUIsRUFBQyxHQUFHLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQ2hGLENBQUM7QUFFRDs7O0dBR0c7QUFDSSxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUErQixFQUMvQixHQUFtQjtJQUVuQixNQUFNLE9BQU8sR0FBaUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsbUNBQW1DO0lBQ25DLE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUE7SUFDN0MsTUFBTSxJQUFBLGlDQUFrQixFQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBRWhELEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxXQUFXLEVBQUUsTUFBTSxJQUFBLGtDQUFtQixFQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUE7QUFDaEYsQ0FBQyJ9