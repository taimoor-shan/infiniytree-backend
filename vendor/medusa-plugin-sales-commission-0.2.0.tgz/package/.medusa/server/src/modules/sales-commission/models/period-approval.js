"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
/**
 * The owner approved a month's statements. Everything earned up to and
 * including the latest approved month is payable. Approval only moves
 * forward; the latest one can be undone while nothing has been paid after it.
 */
const PeriodApproval = utils_1.model
    .define("period_approval", {
    id: utils_1.model.id({ prefix: "scpa" }).primaryKey(),
    period: utils_1.model.text(),
    approved_by: utils_1.model.text().nullable(),
    approved_at: utils_1.model.dateTime(),
})
    .indexes([{ on: ["period"], unique: true, where: "deleted_at IS NULL" }]);
exports.default = PeriodApproval;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGVyaW9kLWFwcHJvdmFsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL21vZHVsZXMvc2FsZXMtY29tbWlzc2lvbi9tb2RlbHMvcGVyaW9kLWFwcHJvdmFsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEscURBQWlEO0FBRWpEOzs7O0dBSUc7QUFDSCxNQUFNLGNBQWMsR0FBRyxhQUFLO0tBQ3pCLE1BQU0sQ0FBQyxpQkFBaUIsRUFBRTtJQUN6QixFQUFFLEVBQUUsYUFBSyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDLFVBQVUsRUFBRTtJQUM3QyxNQUFNLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUNwQixXQUFXLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNwQyxXQUFXLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRTtDQUM5QixDQUFDO0tBQ0QsT0FBTyxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxvQkFBb0IsRUFBRSxDQUFDLENBQUMsQ0FBQTtBQUUzRSxrQkFBZSxjQUFjLENBQUEifQ==