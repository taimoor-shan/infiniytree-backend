"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const report_1 = require("../../../lib/report");
const period_activity_1 = require("../../../utils/period-activity");
const middlewares_1 = require("../middlewares");
/** Every month with activity, newest first, with its totals per currency. */
async function GET(req, res) {
    const { limit, offset } = req.validatedQuery;
    const history = await (0, period_activity_1.loadRepHistory)(req.scope, (0, middlewares_1.portalRep)(req).id);
    const periods = new Set();
    for (const entry of history.entries) {
        periods.add(entry.period);
        if (entry.void_period) {
            periods.add(entry.void_period);
        }
    }
    for (const item of [...history.adjustments, ...history.payouts]) {
        periods.add(item.period);
    }
    const statements = [...periods]
        .sort()
        .reverse()
        .map((period) => ({
        period,
        totals: (0, report_1.summarize)((0, report_1.statementLines)({ period, ...history })),
    }))
        .filter((statement) => statement.totals.length);
    res.json({
        statements: statements.slice(offset, offset + limit),
        count: statements.length,
        offset,
        limit,
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLXBvcnRhbC9zdGF0ZW1lbnRzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBT0Esa0JBOEJDO0FBcENELGdEQUErRDtBQUMvRCxvRUFBK0Q7QUFDL0QsZ0RBQTBDO0FBRzFDLDZFQUE2RTtBQUN0RSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsY0FBc0MsQ0FBQTtJQUNwRSxNQUFNLE9BQU8sR0FBRyxNQUFNLElBQUEsZ0NBQWMsRUFBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUEsdUJBQVMsRUFBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUVsRSxNQUFNLE9BQU8sR0FBRyxJQUFJLEdBQUcsRUFBVSxDQUFBO0lBQ2pDLEtBQUssTUFBTSxLQUFLLElBQUksT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ3BDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFBO1FBQ3pCLElBQUksS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3RCLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFBO1FBQ2hDLENBQUM7SUFDSCxDQUFDO0lBQ0QsS0FBSyxNQUFNLElBQUksSUFBSSxDQUFDLEdBQUcsT0FBTyxDQUFDLFdBQVcsRUFBRSxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1FBQ2hFLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQzFCLENBQUM7SUFFRCxNQUFNLFVBQVUsR0FBRyxDQUFDLEdBQUcsT0FBTyxDQUFDO1NBQzVCLElBQUksRUFBRTtTQUNOLE9BQU8sRUFBRTtTQUNULEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNoQixNQUFNO1FBQ04sTUFBTSxFQUFFLElBQUEsa0JBQVMsRUFBQyxJQUFBLHVCQUFjLEVBQUMsRUFBRSxNQUFNLEVBQUUsR0FBRyxPQUFPLEVBQUUsQ0FBQyxDQUFDO0tBQzFELENBQUMsQ0FBQztTQUNGLE1BQU0sQ0FBQyxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUVqRCxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ1AsVUFBVSxFQUFFLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFDcEQsS0FBSyxFQUFFLFVBQVUsQ0FBQyxNQUFNO1FBQ3hCLE1BQU07UUFDTixLQUFLO0tBQ04sQ0FBQyxDQUFBO0FBQ0osQ0FBQyJ9