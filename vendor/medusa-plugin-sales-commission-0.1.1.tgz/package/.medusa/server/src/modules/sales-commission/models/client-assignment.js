"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const sales_rep_1 = __importDefault(require("./sales-rep"));
/**
 * A customer's salesperson and rate over [starts_at, ends_at). Rows are never
 * edited in place: a change closes the open row and opens a new one.
 */
const ClientAssignment = utils_1.model
    .define("client_assignment", {
    id: utils_1.model.id({ prefix: "sca" }).primaryKey(),
    customer_id: utils_1.model.text(),
    commission_rate: utils_1.model.bigNumber(),
    starts_at: utils_1.model.dateTime(),
    ends_at: utils_1.model.dateTime().nullable(),
    created_by: utils_1.model.text().nullable(),
    ended_by: utils_1.model.text().nullable(),
    sales_rep: utils_1.model.belongsTo(() => sales_rep_1.default, { mappedBy: "assignments" }),
})
    .indexes([
    {
        on: ["customer_id"],
        unique: true,
        where: "ends_at IS NULL AND deleted_at IS NULL",
    },
]);
exports.default = ClientAssignment;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xpZW50LWFzc2lnbm1lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9zYWxlcy1jb21taXNzaW9uL21vZGVscy9jbGllbnQtYXNzaWdubWVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLHFEQUFpRDtBQUNqRCw0REFBa0M7QUFFbEM7OztHQUdHO0FBQ0gsTUFBTSxnQkFBZ0IsR0FBRyxhQUFLO0tBQzNCLE1BQU0sQ0FBQyxtQkFBbUIsRUFBRTtJQUMzQixFQUFFLEVBQUUsYUFBSyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLFVBQVUsRUFBRTtJQUM1QyxXQUFXLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUN6QixlQUFlLEVBQUUsYUFBSyxDQUFDLFNBQVMsRUFBRTtJQUNsQyxTQUFTLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRTtJQUMzQixPQUFPLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNwQyxVQUFVLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNuQyxRQUFRLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNqQyxTQUFTLEVBQUUsYUFBSyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxtQkFBUSxFQUFFLEVBQUUsUUFBUSxFQUFFLGFBQWEsRUFBRSxDQUFDO0NBQ3hFLENBQUM7S0FDRCxPQUFPLENBQUM7SUFDUDtRQUNFLEVBQUUsRUFBRSxDQUFDLGFBQWEsQ0FBQztRQUNuQixNQUFNLEVBQUUsSUFBSTtRQUNaLEtBQUssRUFBRSx3Q0FBd0M7S0FDaEQ7Q0FDRixDQUFDLENBQUE7QUFFSixrQkFBZSxnQkFBZ0IsQ0FBQSJ9