import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { defineWidgetConfig, defineRouteConfig } from "@medusajs/admin-sdk";
import { Spinner, PencilSquare, Users, TriangleRightMini, ArrowUpTray, ArrowDownTray, Trash } from "@medusajs/icons";
import { usePrompt, toast, Container, Heading, Button, Text, Drawer, Label, Select, Input, FocusModal, Textarea, createDataTableColumnHelper, useDataTable, DataTable, Switch, Badge, IconButton, Alert, Checkbox, Table, Tabs } from "@medusajs/ui";
import { useQueryClient, useQuery, useMutation, keepPreviousData } from "@tanstack/react-query";
import { useState, useMemo, useRef, useEffect } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import Medusa from "@medusajs/js-sdk";
const sdk = new Medusa({
  baseUrl: "/",
  debug: false,
  auth: {
    type: "session"
  }
});
const TIME_ZONE = "Europe/Budapest";
const ZERO_DECIMAL_CURRENCIES = /* @__PURE__ */ new Set([
  "HUF",
  "JPY",
  "KRW",
  "TWD",
  "VND",
  "CLP",
  "PYG",
  "UGX",
  "RWF",
  "UZS",
  "KES"
]);
const CURRENCIES = ["eur", "huf"];
const formatMoney = (amount, currencyCode) => {
  const currency = currencyCode.toUpperCase();
  const decimals2 = ZERO_DECIMAL_CURRENCIES.has(currency) ? 0 : 2;
  return new Intl.NumberFormat("en-GB", {
    style: "currency",
    currency,
    minimumFractionDigits: decimals2,
    maximumFractionDigits: decimals2
  }).format(amount);
};
const formatDate = (date) => new Intl.DateTimeFormat("en-GB", {
  timeZone: TIME_ZONE,
  year: "numeric",
  month: "short",
  day: "numeric"
}).format(new Date(date));
const formatSize = (bytes) => bytes < 1024 * 1024 ? `${Math.max(1, Math.round(bytes / 1024))} KB` : `${(bytes / 1024 / 1024).toFixed(1)} MB`;
const today = () => new Intl.DateTimeFormat("en-CA", {
  timeZone: TIME_ZONE,
  year: "numeric",
  month: "2-digit",
  day: "2-digit"
}).format(/* @__PURE__ */ new Date());
const recentPeriods = (count = 24) => {
  const [year, month] = today().split("-").map(Number);
  return Array.from({ length: count }, (_, i) => {
    const date = new Date(Date.UTC(year, month - 1 - i, 1));
    return {
      value: date.toISOString().slice(0, 7),
      label: new Intl.DateTimeFormat("en-GB", {
        timeZone: "UTC",
        month: "long",
        year: "numeric"
      }).format(date)
    };
  });
};
const currentPeriod = () => recentPeriods(1)[0].value;
const STATUS_BADGES = {
  paid: { label: "Settled", color: "green" },
  partial: { label: "Partly paid", color: "orange" },
  unpaid: { label: "Owed", color: "red" },
  overpaid: { label: "Paid ahead", color: "orange" },
  none: { label: "Nothing due", color: "grey" }
};
const LINE_BADGES = {
  earned: { label: "Earned", color: "blue" },
  payable: { label: "Payable", color: "green" },
  reversed: { label: "Reversed", color: "orange" },
  adjustment: { label: "Adjustment", color: "grey" },
  paid: { label: "Paid", color: "green" }
};
const monthLabel = (period) => new Intl.DateTimeFormat("en-GB", {
  timeZone: "UTC",
  month: "long",
  year: "numeric"
}).format(/* @__PURE__ */ new Date(`${period}-01T00:00:00Z`));
const currencyStep = (currencyCode) => ZERO_DECIMAL_CURRENCIES.has(currencyCode.toUpperCase()) ? "1" : "0.01";
const currentYear = () => today().slice(0, 4);
const clientName = (customer) => (customer == null ? void 0 : customer.company_name) || [customer == null ? void 0 : customer.first_name, customer == null ? void 0 : customer.last_name].filter(Boolean).join(" ") || (customer == null ? void 0 : customer.email) || "Unknown client";
const errorMessage = (error) => error instanceof Error ? error.message : "Something went wrong";
const applicationBadge = (application) => {
  if (application.status === "invited" && application.expired) {
    return { label: "Link expired", color: "grey" };
  }
  const badges = {
    invited: { label: "Invited", color: "blue" },
    applied: { label: "Waiting for review", color: "orange" },
    approved: { label: "Approved", color: "green" },
    declined: { label: "Declined", color: "red" },
    canceled: { label: "Canceled", color: "grey" }
  };
  return badges[application.status];
};
const level2Duration = (months) => months ? `${months} months from approval` : "Until I end it";
const Loading = () => /* @__PURE__ */ jsx("div", { className: "flex justify-center p-6", children: /* @__PURE__ */ jsx(Spinner, { className: "text-ui-fg-interactive animate-spin" }) });
const CustomerSalesRepWidget = ({
  data: customer
}) => {
  var _a, _b;
  const [open, setOpen] = useState(false);
  const [repId, setRepId] = useState("");
  const [rate, setRate] = useState("");
  const queryClient = useQueryClient();
  const prompt = usePrompt();
  const queryKey = ["customer-sales-rep", customer.id];
  const { data, isLoading } = useQuery({
    queryKey,
    queryFn: () => sdk.client.fetch(
      `/admin/customers/${customer.id}/sales-rep-assignment`
    )
  });
  const { data: reps } = useQuery({
    queryKey: ["sales-reps", "active-options"],
    queryFn: () => sdk.client.fetch("/admin/sales-reps", {
      query: { is_active: "true", limit: 200, order: "name" }
    }),
    enabled: open
  });
  const refresh = () => {
    queryClient.invalidateQueries({ queryKey });
    queryClient.invalidateQueries({ queryKey: ["sales-rep-clients"] });
  };
  const assign = useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/customers/${customer.id}/sales-rep-assignment`, {
      method: "POST",
      body: { sales_rep_id: repId, commission_rate: Number(rate) }
    }),
    onSuccess: () => {
      refresh();
      toast.success("Sales rep saved");
      setOpen(false);
    },
    onError: (error) => toast.error(errorMessage(error))
  });
  const end = useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/customers/${customer.id}/sales-rep-assignment`, {
      method: "DELETE"
    }),
    onSuccess: () => {
      refresh();
      toast.success("Assignment ended");
    },
    onError: (error) => toast.error(errorMessage(error))
  });
  const confirmEnd = async () => {
    const confirmed = await prompt({
      title: "End assignment?",
      description: "Orders placed today or later won't earn commission. Earlier orders keep theirs.",
      confirmText: "End assignment",
      cancelText: "Cancel"
    });
    if (confirmed) {
      end.mutate();
    }
  };
  const current = data == null ? void 0 : data.current;
  const past = (data == null ? void 0 : data.history.filter((a) => a.ends_at !== null)) ?? [];
  return /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Sales rep" }),
      /* @__PURE__ */ jsxs(
        Button,
        {
          size: "small",
          variant: "secondary",
          onClick: () => {
            var _a2;
            setRepId(((_a2 = current == null ? void 0 : current.sales_rep) == null ? void 0 : _a2.id) ?? "");
            setRate(current ? String(current.commission_rate) : "");
            setOpen(true);
          },
          children: [
            /* @__PURE__ */ jsx(PencilSquare, {}),
            current ? "Change" : "Assign"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex flex-col gap-y-1 px-6 py-4", children: isLoading ? /* @__PURE__ */ jsx(Loading, {}) : current ? /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(
        Link,
        {
          to: `/sales-reps/${(_a = current.sales_rep) == null ? void 0 : _a.id}`,
          className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
          children: /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", weight: "plus", children: (_b = current.sales_rep) == null ? void 0 : _b.name })
        }
      ),
      /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
        current.commission_rate,
        "% commission since",
        " ",
        formatDate(current.starts_at)
      ] }),
      current.source === "link" && /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Joined through their client link" }),
      /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
        Button,
        {
          size: "small",
          variant: "transparent",
          className: "-ml-3 mt-1",
          isLoading: end.isPending,
          onClick: confirmEnd,
          children: "End assignment"
        }
      ) })
    ] }) : /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "No sales rep assigned. Orders earn no commission." }) }),
    past.length > 0 && /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", weight: "plus", children: "History" }),
      past.map((a) => {
        var _a2;
        return /* @__PURE__ */ jsxs(
          Text,
          {
            size: "small",
            leading: "compact",
            className: "text-ui-fg-subtle",
            children: [
              (_a2 = a.sales_rep) == null ? void 0 : _a2.name,
              " · ",
              a.commission_rate,
              "% ·",
              " ",
              formatDate(a.starts_at),
              " – ",
              formatDate(a.ends_at)
            ]
          },
          a.id
        );
      })
    ] }),
    /* @__PURE__ */ jsx(Drawer, { open, onOpenChange: setOpen, children: /* @__PURE__ */ jsxs(Drawer.Content, { children: [
      /* @__PURE__ */ jsx(Drawer.Header, { children: /* @__PURE__ */ jsx(Drawer.Title, { children: "Sales rep and commission rate" }) }),
      /* @__PURE__ */ jsxs(Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
        /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "Takes effect from the start of today (Budapest time), so orders placed earlier today count too. Earlier days keep the rep and rate they were placed with." }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Sales rep" }),
          /* @__PURE__ */ jsxs(Select, { value: repId, onValueChange: setRepId, children: [
            /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, { placeholder: "Choose a sales rep" }) }),
            /* @__PURE__ */ jsx(Select.Content, { children: ((reps == null ? void 0 : reps.sales_reps) ?? []).map((rep) => /* @__PURE__ */ jsx(Select.Item, { value: rep.id, children: rep.name }, rep.id)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "commission-rate", children: "Commission rate (%)" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "commission-rate",
              type: "number",
              min: 0,
              max: 100,
              step: "0.01",
              value: rate,
              onChange: (e) => setRate(e.target.value)
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs(Drawer.Footer, { children: [
        /* @__PURE__ */ jsx(Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", disabled: assign.isPending, children: "Cancel" }) }),
        /* @__PURE__ */ jsx(
          Button,
          {
            size: "small",
            disabled: !repId || rate === "",
            isLoading: assign.isPending,
            onClick: () => assign.mutate(),
            children: "Save"
          }
        )
      ] })
    ] }) })
  ] });
};
defineWidgetConfig({
  zone: "customer.details.side.after"
});
const parseClientRate = (text) => text.trim() === "" ? null : Number(text);
const clientRateError = (text) => {
  const rate = parseClientRate(text);
  return rate === null || Number.isFinite(rate) && rate >= 0 && rate <= 100 ? null : "Enter a percentage from 0 to 100, or leave it empty";
};
const ClientRateField = ({
  id,
  value,
  onChange
}) => {
  const error = clientRateError(value);
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
    /* @__PURE__ */ jsx(Label, { htmlFor: id, children: "Standard rate for new clients (%)" }),
    /* @__PURE__ */ jsx(
      Input,
      {
        id,
        type: "number",
        min: 0,
        max: 100,
        step: "0.01",
        placeholder: "Not set",
        value,
        onChange: (e) => onChange(e.target.value),
        "aria-invalid": !!error
      }
    ),
    error ? /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-error", children: error }) : /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "What a client who joins through this rep's link is credited at, from the day they join. Empty keeps the link off until you set one. You can still change the rate for each client afterwards." })
  ] });
};
const EMPTY$2 = {
  name: "",
  email: "",
  phone: "",
  notes: "",
  payout: "as-earned",
  client_rate: ""
};
const CreateSalesRepModal = () => {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(EMPTY$2);
  const [errors, setErrors] = useState({});
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const create = useMutation({
    mutationFn: () => sdk.client.fetch("/admin/sales-reps", {
      method: "POST",
      body: {
        name: form.name,
        email: form.email,
        phone: form.phone || null,
        notes: form.notes || null,
        payout_currency_code: form.payout === "as-earned" ? null : form.payout,
        default_client_rate: parseClientRate(form.client_rate)
      }
    }),
    onSuccess: ({ sales_rep }) => {
      queryClient.invalidateQueries({ queryKey: ["sales-reps"] });
      toast.success(`${sales_rep.name} was added`);
      setOpen(false);
      setForm(EMPTY$2);
      navigate(`/sales-reps/${sales_rep.id}`);
    },
    onError: (error) => toast.error(errorMessage(error))
  });
  const submit = () => {
    const next = {};
    if (!form.name.trim()) next.name = "Name is required";
    if (!/^\S+@\S+\.\S+$/.test(form.email.trim())) next.email = "Enter a valid email";
    const rateError = clientRateError(form.client_rate);
    if (rateError) next.client_rate = rateError;
    setErrors(next);
    if (!Object.keys(next).length) {
      create.mutate();
    }
  };
  const field = (key) => ({
    value: form[key],
    onChange: (e) => {
      setForm({ ...form, [key]: e.target.value });
      setErrors({ ...errors, [key]: void 0 });
    }
  });
  return /* @__PURE__ */ jsxs(FocusModal, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsx(FocusModal.Trigger, { asChild: true, children: /* @__PURE__ */ jsx(Button, { size: "small", children: "Create" }) }),
    /* @__PURE__ */ jsxs(FocusModal.Content, { children: [
      /* @__PURE__ */ jsx(FocusModal.Header, { children: /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-end gap-x-2", children: [
        /* @__PURE__ */ jsx(FocusModal.Close, { asChild: true, children: /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", disabled: create.isPending, children: "Cancel" }) }),
        /* @__PURE__ */ jsx(Button, { size: "small", onClick: submit, isLoading: create.isPending, children: "Save" })
      ] }) }),
      /* @__PURE__ */ jsx(FocusModal.Body, { className: "flex flex-1 flex-col items-center overflow-y-auto py-16", children: /* @__PURE__ */ jsxs("div", { className: "flex w-full max-w-lg flex-col gap-y-6", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-1", children: [
          /* @__PURE__ */ jsx(FocusModal.Title, { asChild: true, children: /* @__PURE__ */ jsx(Heading, { children: "Create sales rep" }) }),
          /* @__PURE__ */ jsx(FocusModal.Description, { asChild: true, children: /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "Add a salesperson. You can assign clients and upload their contract afterwards." }) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "rep-name", children: "Name" }),
          /* @__PURE__ */ jsx(Input, { id: "rep-name", ...field("name") }),
          errors.name && /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-error", children: errors.name })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "rep-email", children: "Email" }),
          /* @__PURE__ */ jsx(Input, { id: "rep-email", type: "email", ...field("email") }),
          errors.email && /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-error", children: errors.email })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "rep-phone", children: "Phone (optional)" }),
          /* @__PURE__ */ jsx(Input, { id: "rep-phone", ...field("phone") })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Paid in" }),
          /* @__PURE__ */ jsxs(
            Select,
            {
              value: form.payout,
              onValueChange: (value) => setForm({ ...form, payout: value }),
              children: [
                /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, {}) }),
                /* @__PURE__ */ jsxs(Select.Content, { children: [
                  /* @__PURE__ */ jsx(Select.Item, { value: "as-earned", children: "Each currency as earned" }),
                  /* @__PURE__ */ jsx(Select.Item, { value: "eur", children: "EUR" }),
                  /* @__PURE__ */ jsx(Select.Item, { value: "huf", children: "HUF" })
                ] })
              ]
            }
          ),
          /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "Choose one currency to get a single balance and one payout. Commission in the other currency is converted when it is earned." })
        ] }),
        /* @__PURE__ */ jsx(
          ClientRateField,
          {
            id: "rep-client-rate",
            value: form.client_rate,
            onChange: (client_rate) => setForm({ ...form, client_rate })
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "rep-notes", children: "Notes (optional)" }),
          /* @__PURE__ */ jsx(Textarea, { id: "rep-notes", ...field("notes") })
        ] })
      ] }) })
    ] })
  ] });
};
const PAGE_SIZE$1 = 20;
const HIDE_INACTIVE_KEY = "sales-reps-hide-inactive";
const readHideInactive = () => {
  try {
    return localStorage.getItem(HIDE_INACTIVE_KEY) === "1";
  } catch {
    return false;
  }
};
const columnHelper$1 = createDataTableColumnHelper();
const buildColumns = (balances) => [
  columnHelper$1.accessor("name", { header: "Name" }),
  columnHelper$1.accessor("email", { header: "Email" }),
  columnHelper$1.accessor("payout_currency_code", {
    header: "Paid in",
    cell: ({ getValue }) => getValue() ? getValue().toUpperCase() : "As earned"
  }),
  columnHelper$1.display({
    id: "payable",
    header: "Payable now",
    cell: ({ row }) => {
      const payable = (balances[row.original.id] ?? []).filter((b) => b.payable > 0);
      return payable.length ? payable.map((b) => formatMoney(b.payable, b.currency_code)).join(", ") : "-";
    }
  }),
  columnHelper$1.accessor("is_active", {
    header: "Status",
    cell: ({ getValue }) => /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: getValue() ? "green" : "grey", children: getValue() ? "Active" : "Inactive" })
  })
];
const SalesRepsPage = () => {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [hideInactive, setHideInactive] = useState(readHideInactive);
  const [pagination, setPagination] = useState({
    pageIndex: 0,
    pageSize: PAGE_SIZE$1
  });
  const offset = pagination.pageIndex * PAGE_SIZE$1;
  const changeHideInactive = (hide) => {
    setHideInactive(hide);
    setPagination((current) => ({ ...current, pageIndex: 0 }));
    try {
      localStorage.setItem(HIDE_INACTIVE_KEY, hide ? "1" : "0");
    } catch {
    }
  };
  const { data: balanceData } = useQuery({
    queryKey: ["rep-balances"],
    queryFn: () => sdk.client.fetch("/admin/sales-commission/balances")
  });
  const columns2 = useMemo(
    () => buildColumns((balanceData == null ? void 0 : balanceData.balances) ?? {}),
    [balanceData]
  );
  const { data: applicationData } = useQuery({
    queryKey: ["applications", "waiting"],
    queryFn: () => sdk.client.fetch("/admin/sales-commission/applications", {
      query: { status: "applied", limit: 1 }
    })
  });
  const waiting = (applicationData == null ? void 0 : applicationData.counts.applied) ?? 0;
  const { data, isLoading } = useQuery({
    queryKey: ["sales-reps", offset, search, hideInactive],
    queryFn: () => sdk.client.fetch(
      "/admin/sales-reps",
      {
        query: {
          limit: PAGE_SIZE$1,
          offset,
          order: "name",
          q: search || void 0,
          is_active: hideInactive ? "true" : void 0
        }
      }
    ),
    placeholderData: keepPreviousData
  });
  const table = useDataTable({
    data: (data == null ? void 0 : data.sales_reps) ?? [],
    columns: columns2,
    getRowId: (rep) => rep.id,
    rowCount: (data == null ? void 0 : data.count) ?? 0,
    isLoading,
    search: { state: search, onSearchChange: setSearch },
    pagination: { state: pagination, onPaginationChange: setPagination },
    onRowClick: (_, rep) => navigate(`/sales-reps/${rep.id}`)
  });
  return /* @__PURE__ */ jsx(Container, { className: "divide-y p-0", children: /* @__PURE__ */ jsxs(DataTable, { instance: table, children: [
    /* @__PURE__ */ jsxs(DataTable.Toolbar, { className: "flex flex-col items-start justify-between gap-2 px-6 py-4 xl:flex-row xl:items-center", children: [
      /* @__PURE__ */ jsx(Heading, { children: "Sales Reps" }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-2 pr-2", children: [
          /* @__PURE__ */ jsx(
            Switch,
            {
              id: "hide-inactive",
              checked: hideInactive,
              onCheckedChange: changeHideInactive
            }
          ),
          /* @__PURE__ */ jsx(
            Label,
            {
              htmlFor: "hide-inactive",
              size: "small",
              weight: "plus",
              className: "whitespace-nowrap",
              children: "Hide inactive"
            }
          )
        ] }),
        /* @__PURE__ */ jsx(DataTable.Search, { placeholder: "Search by name or email" }),
        /* @__PURE__ */ jsx(
          Button,
          {
            size: "small",
            variant: "secondary",
            className: "whitespace-nowrap",
            asChild: true,
            children: /* @__PURE__ */ jsxs(Link, { to: "/sales-reps/applications", children: [
              "Applications",
              waiting > 0 ? ` (${waiting})` : ""
            ] })
          }
        ),
        /* @__PURE__ */ jsx(
          Button,
          {
            size: "small",
            variant: "secondary",
            className: "whitespace-nowrap",
            asChild: true,
            children: /* @__PURE__ */ jsx(Link, { to: "/sales-reps/payment-run", children: "Payment run" })
          }
        ),
        /* @__PURE__ */ jsx(
          Button,
          {
            size: "small",
            variant: "secondary",
            className: "whitespace-nowrap",
            asChild: true,
            children: /* @__PURE__ */ jsx(Link, { to: "/sales-reps/report", children: "Monthly report" })
          }
        ),
        /* @__PURE__ */ jsx(CreateSalesRepModal, {})
      ] })
    ] }),
    /* @__PURE__ */ jsx(DataTable.Table, {}),
    /* @__PURE__ */ jsx(DataTable.Pagination, {})
  ] }) });
};
const config$3 = defineRouteConfig({
  label: "Sales Reps",
  icon: Users
});
const Metric = ({
  label,
  value,
  hint,
  tone = "base"
}) => /* @__PURE__ */ jsxs("div", { className: "bg-ui-bg-subtle border-ui-border-base flex flex-col gap-y-1 rounded-lg border px-4 py-3", children: [
  /* @__PURE__ */ jsx(Text, { size: "xsmall", leading: "compact", className: "text-ui-fg-subtle", children: label }),
  /* @__PURE__ */ jsx(
    Text,
    {
      size: "xlarge",
      leading: "compact",
      weight: "plus",
      className: tone === "warn" ? "text-ui-tag-orange-text" : "text-ui-fg-base",
      children: value
    }
  ),
  hint && /* @__PURE__ */ jsx(Text, { size: "xsmall", leading: "compact", className: "text-ui-fg-muted", children: hint })
] });
const EMPTY$1 = (currency_code) => ({
  currency_code,
  earned: 0,
  paid: 0,
  balance: 0,
  approved_earned: 0,
  open_earned: 0,
  payable: 0,
  to_recover: 0
});
const currencyCodes = (data) => [
  .../* @__PURE__ */ new Set([
    ...data.balances.map((b) => b.currency_code),
    ...data.pending.map((p) => p.currency_code)
  ])
].sort();
const BalanceSection = ({ repId }) => {
  const { data, isLoading } = useQuery({
    queryKey: ["sales-rep-balance", repId],
    queryFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/balance`)
  });
  const year = currentYear();
  return /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-start justify-between gap-1 px-6 py-4 md:flex-row md:items-center", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Balance" }),
      data && /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: data.approved_through ? `Months approved through ${monthLabel(data.approved_through)}` : "No month approved yet" })
    ] }),
    isLoading || !data ? /* @__PURE__ */ jsx(Loading, {}) : data.balances.length === 0 && data.pending.length === 0 ? /* @__PURE__ */ jsx("div", { className: "px-6 py-4", children: /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Nothing earned or paid yet." }) }) : currencyCodes(data).map((currency) => {
      const balance = data.balances.find((b) => b.currency_code === currency) ?? EMPTY$1(currency);
      const pending = data.pending.find((p) => p.currency_code === currency);
      const money = (amount) => formatMoney(amount, currency);
      return /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-3 px-6 py-4", children: [
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: "grey", children: currency.toUpperCase() }) }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-3 md:grid-cols-3", children: [
          /* @__PURE__ */ jsx(
            Metric,
            {
              label: "Pending",
              value: money((pending == null ? void 0 : pending.amount) ?? 0),
              hint: pending ? `${pending.orders} ${pending.orders === 1 ? "order" : "orders"} not paid yet` : "No unpaid orders"
            }
          ),
          /* @__PURE__ */ jsx(
            Metric,
            {
              label: "Payable now",
              value: money(balance.payable),
              hint: "Due on the next run"
            }
          ),
          /* @__PURE__ */ jsx(
            Metric,
            {
              label: "Earned, not payable yet",
              value: money(balance.open_earned),
              hint: "Waits for its month to be approved"
            }
          ),
          /* @__PURE__ */ jsx(
            Metric,
            {
              label: `Paid in ${year}`,
              value: money(data.paid_this_year[currency] ?? 0)
            }
          ),
          /* @__PURE__ */ jsx(
            Metric,
            {
              label: "To recover",
              value: money(balance.to_recover),
              hint: balance.to_recover > 0 ? "Paid ahead. Netted from what they earn next" : "Nothing owed back",
              tone: balance.to_recover > 0 ? "warn" : "base"
            }
          )
        ] })
      ] }, currency);
    })
  ] });
};
const OUTCOME_BADGES = {
  credited: { label: "Linked", color: "green" },
  no_rate: { label: "Not linked: no rate set", color: "orange" },
  rep_inactive: { label: "Not linked: rep was inactive", color: "orange" },
  own_account: { label: "Not linked: their own account", color: "grey" },
  existing_client: { label: "Not linked: already a client", color: "grey" },
  unknown_code: { label: "Not linked: unknown link", color: "grey" }
};
const copy$1 = (text) => navigator.clipboard.writeText(text).then(() => toast.success("Link copied")).catch(() => toast.error("Couldn't copy, select the link instead"));
const ClientLinkSection = ({ rep }) => {
  const queryClient = useQueryClient();
  const prompt = usePrompt();
  const queryKey = ["sales-rep-client-link", rep.id];
  const { data, isLoading, error } = useQuery({
    queryKey,
    queryFn: () => sdk.client.fetch(
      `/admin/sales-reps/${rep.id}/client-link`
    ).then((result) => result.client_link)
  });
  const renew = useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${rep.id}/client-link`, {
      method: "POST",
      body: {}
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey });
      toast.success("New link made");
    },
    onError: (failure) => toast.error(errorMessage(failure))
  });
  const confirmRenew = async () => {
    const confirmed = await prompt({
      title: "Make a new link?",
      description: `${rep.name}'s current link stops working at once, so send them the new one. Clients who already joined through it stay linked. Anyone who opens the old link later is not linked to ${rep.name}.`,
      confirmText: "Make new link",
      cancelText: "Cancel"
    });
    if (confirmed) {
      renew.mutate();
    }
  };
  const link = data ?? null;
  return /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-2", children: [
        /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Client link" }),
        link && /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: link.active ? "green" : "grey", children: link.active ? "On" : "Off" })
      ] }),
      link && /* @__PURE__ */ jsx(
        Button,
        {
          size: "small",
          variant: "secondary",
          isLoading: renew.isPending,
          onClick: confirmRenew,
          children: "New link"
        }
      )
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex flex-col gap-y-3 px-6 py-4", children: isLoading ? /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Loading…" }) : error || !link ? /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-error", children: "The client link could not be loaded." }) : /* @__PURE__ */ jsxs(Fragment, { children: [
      link.link ? /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-2", children: [
        /* @__PURE__ */ jsx("div", { className: "min-w-0 flex-1", children: /* @__PURE__ */ jsx(Input, { readOnly: true, value: link.link, "aria-label": "Client link" }) }),
        /* @__PURE__ */ jsx(
          Button,
          {
            size: "small",
            variant: "secondary",
            onClick: () => copy$1(link.link),
            children: "Copy"
          }
        )
      ] }) : /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", className: "text-ui-fg-error", children: [
        "The shop's address isn't configured (STOREFRONT_PUBLIC_URL), so there is no address to copy. The link is the shop's address followed by /?ref=",
        link.code
      ] }),
      /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: link.active ? `A client who signs up through this link, or buys through it, is linked to ${rep.name} and earns them ${link.rate}% on their paid orders, from the day they join. ${rep.name} can add the code to any page of the shop, a product included, from the sales portal.` : link.reason === "rep_inactive" ? `Off: ${rep.name} is deactivated, so new clients are not linked to them. Reactivate them in Edit to switch it on.` : `Off: ${rep.name} has no standard rate for new clients. Set one in Edit and the link starts working. Anyone who joins while it is off is not linked.` })
    ] }) }),
    link && link.claims.length > 0 && /* @__PURE__ */ jsxs("div", { className: "flex flex-col divide-y", children: [
      /* @__PURE__ */ jsx(
        Text,
        {
          size: "small",
          leading: "compact",
          weight: "plus",
          className: "px-6 py-3",
          children: "Latest sign-ups through the link"
        }
      ),
      link.claims.map((claim) => {
        const badge = OUTCOME_BADGES[claim.outcome];
        return /* @__PURE__ */ jsxs(
          "div",
          {
            className: "flex items-center justify-between gap-x-4 px-6 py-3",
            children: [
              /* @__PURE__ */ jsxs("div", { className: "min-w-0", children: [
                /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "truncate", children: claim.client_name || claim.client_email }),
                /* @__PURE__ */ jsxs(
                  Text,
                  {
                    size: "small",
                    leading: "compact",
                    className: "truncate text-ui-fg-subtle",
                    children: [
                      claim.client_email,
                      " · ",
                      formatDate(claim.created_at)
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: (badge == null ? void 0 : badge.color) ?? "grey", children: (badge == null ? void 0 : badge.label) ?? claim.outcome })
            ]
          },
          claim.id
        );
      }),
      /* @__PURE__ */ jsx(
        Text,
        {
          size: "small",
          leading: "compact",
          className: "px-6 py-3 text-ui-fg-subtle",
          children: "Anyone who was not linked can still be assigned to a rep by hand, on their customer page."
        }
      )
    ] })
  ] });
};
const ClientsSection = ({ repId }) => {
  const { data, isLoading } = useQuery({
    queryKey: ["sales-rep-clients", repId],
    queryFn: () => sdk.client.fetch(
      `/admin/sales-reps/${repId}/clients`
    )
  });
  const current = (data == null ? void 0 : data.clients.filter((a) => a.ends_at === null)) ?? [];
  const pastCount = ((data == null ? void 0 : data.clients.length) ?? 0) - current.length;
  return /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Clients" }),
      /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Assign clients from the customer page" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      isLoading ? /* @__PURE__ */ jsx(Loading, {}) : current.length === 0 ? /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "No clients assigned." }) : current.map((assignment) => /* @__PURE__ */ jsx(
        Link,
        {
          to: `/customers/${assignment.customer_id}`,
          className: "outline-none focus-within:shadow-borders-interactive-with-focus rounded-md [&:hover>div]:bg-ui-bg-component-hover",
          children: /* @__PURE__ */ jsx("div", { className: "shadow-elevation-card-rest bg-ui-bg-component rounded-md px-4 py-2 transition-colors", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex flex-1 flex-col", children: [
              /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", weight: "plus", children: clientName(assignment.customer) }),
              /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
                assignment.commission_rate,
                "% since",
                " ",
                formatDate(assignment.starts_at),
                assignment.source === "link" ? " · came through their link" : ""
              ] })
            ] }),
            /* @__PURE__ */ jsx(TriangleRightMini, { className: "text-ui-fg-muted rtl:rotate-180" })
          ] }) })
        },
        assignment.id
      )),
      pastCount > 0 && /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
        pastCount,
        " earlier assignment",
        pastCount === 1 ? "" : "s",
        " on record"
      ] })
    ] })
  ] });
};
const downloadFile = async (path, accept, fallbackName) => {
  var _a;
  const response = await sdk.client.fetch(path, {
    headers: { accept }
  });
  const blob = await response.blob();
  const disposition = response.headers.get("content-disposition") ?? "";
  const fileName = ((_a = /filename="([^"]+)"/.exec(disposition)) == null ? void 0 : _a[1]) ?? fallbackName;
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
};
const readAsBase64 = (file) => new Promise((resolve, reject) => {
  const reader = new FileReader();
  reader.onload = () => resolve(String(reader.result).split(",")[1] ?? "");
  reader.onerror = () => reject(reader.error);
  reader.readAsDataURL(file);
});
const ACCEPTED = ["application/pdf", "image/jpeg", "image/png"];
const MAX_BYTES = 10 * 1024 * 1024;
const ContractsSection = ({ repId }) => {
  const input = useRef(null);
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["sales-rep-contracts", repId],
    queryFn: () => sdk.client.fetch(
      `/admin/sales-reps/${repId}/contracts`
    )
  });
  const upload = useMutation({
    mutationFn: async (file) => sdk.client.fetch(`/admin/sales-reps/${repId}/contracts`, {
      method: "POST",
      body: {
        file_name: file.name,
        mime_type: file.type,
        content_base64: await readAsBase64(file)
      }
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["sales-rep-contracts", repId] });
      toast.success("Contract uploaded");
    },
    onError: (error) => toast.error(errorMessage(error))
  });
  const onFile = (file) => {
    if (!file) {
      return;
    }
    if (!ACCEPTED.includes(file.type)) {
      return toast.error("Upload a PDF, JPEG or PNG file");
    }
    if (file.size > MAX_BYTES) {
      return toast.error("Contracts can be at most 10 MB");
    }
    upload.mutate(file);
  };
  const download = (contract) => downloadFile(
    `/admin/sales-reps/${repId}/contracts/${contract.id}/download`,
    contract.mime_type,
    contract.file_name
  ).catch((error) => toast.error(errorMessage(error)));
  return /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Contracts" }),
      /* @__PURE__ */ jsxs(
        Button,
        {
          size: "small",
          variant: "secondary",
          isLoading: upload.isPending,
          onClick: () => {
            var _a;
            return (_a = input.current) == null ? void 0 : _a.click();
          },
          children: [
            /* @__PURE__ */ jsx(ArrowUpTray, {}),
            "Upload"
          ]
        }
      ),
      /* @__PURE__ */ jsx(
        "input",
        {
          ref: input,
          type: "file",
          accept: ACCEPTED.join(","),
          className: "hidden",
          onChange: (e) => {
            var _a;
            onFile((_a = e.target.files) == null ? void 0 : _a[0]);
            e.target.value = "";
          }
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Stored privately; only admins can download them." }),
      isLoading ? /* @__PURE__ */ jsx(Loading, {}) : !(data == null ? void 0 : data.contracts.length) ? /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "No contract uploaded yet." }) : data.contracts.map((contract) => /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-x-2", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex min-w-0 flex-col", children: [
          /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", weight: "plus", className: "truncate", children: contract.file_name }),
          /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
            formatDate(contract.created_at),
            " · ",
            formatSize(contract.size_bytes)
          ] })
        ] }),
        /* @__PURE__ */ jsx(
          IconButton,
          {
            size: "small",
            variant: "transparent",
            onClick: () => download(contract),
            children: /* @__PURE__ */ jsx(ArrowDownTray, {})
          }
        )
      ] }, contract.id))
    ] })
  ] });
};
const DeleteSection = ({ rep }) => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const prompt = usePrompt();
  const { data, isLoading, error } = useQuery({
    queryKey: ["sales-rep-deletion", rep.id],
    queryFn: () => sdk.client.fetch(`/admin/sales-reps/${rep.id}/deletion`)
  });
  const remove = useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${rep.id}`, { method: "DELETE" }),
    onSuccess: () => {
      toast.success(`${rep.name} deleted`);
      navigate("/sales-reps");
      for (const key of ["sales-reps", "rep-balances", "applications"]) {
        queryClient.invalidateQueries({ queryKey: [key] });
      }
    },
    onError: (failure) => {
      toast.error(errorMessage(failure));
      queryClient.invalidateQueries({ queryKey: ["sales-rep-deletion", rep.id] });
    }
  });
  const confirmDelete = async () => {
    const confirmed = await prompt({
      title: `Delete ${rep.name}?`,
      description: `${rep.name}'s portal login ends, the invitations they sent are withdrawn and they disappear from the lists. This can't be undone here.`,
      confirmText: "Delete",
      cancelText: "Cancel"
    });
    if (confirmed) {
      remove.mutate();
    }
  };
  const blockers = (data == null ? void 0 : data.blockers) ?? [];
  const canDelete = (data == null ? void 0 : data.can_delete) === true;
  const hasMoney = blockers.some((blocker) => blocker.code === "money");
  return /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Delete rep" }),
      /* @__PURE__ */ jsx(
        Button,
        {
          size: "small",
          variant: "danger",
          disabled: !canDelete,
          isLoading: remove.isPending,
          onClick: confirmDelete,
          children: "Delete"
        }
      )
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: isLoading ? /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Checking what is on record…" }) : error || !data ? /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", className: "text-ui-fg-error", children: [
      "Could not check whether ",
      rep.name,
      " can be deleted."
    ] }) : canDelete ? /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
      rep.name,
      " has no commission, clients or recruits on record, so they can be deleted. To keep them but stop new work, deactivate them in Edit instead."
    ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
        rep.name,
        " can't be deleted:"
      ] }),
      /* @__PURE__ */ jsx("ul", { className: "list-disc pl-5", children: blockers.map((blocker) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: blocker.message }) }, blocker.code)) }),
      /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: hasMoney ? "Money on record stays: the statements and reports are built from it. Deactivate them in Edit instead." : "Settle these first, or deactivate them in Edit instead." })
    ] }) })
  ] });
};
const copy = (text) => navigator.clipboard.writeText(text).then(() => toast.success("Link copied")).catch(() => toast.error("Couldn't copy, select the link instead"));
const PortalSection = ({
  rep,
  portal
}) => {
  const [granted, setGranted] = useState(null);
  const queryClient = useQueryClient();
  const prompt = usePrompt();
  const active = portal.status === "active";
  const refresh = () => queryClient.invalidateQueries({ queryKey: ["sales-rep", rep.id] });
  const grant = useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${rep.id}/portal-access`, {
      method: "POST",
      body: {}
    }),
    onSuccess: (result) => {
      refresh();
      setGranted(result);
    },
    onError: (error) => toast.error(errorMessage(error))
  });
  const revoke = useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${rep.id}/portal-access`, {
      method: "DELETE"
    }),
    onSuccess: () => {
      refresh();
      toast.success("Portal access ended");
    },
    onError: (error) => toast.error(errorMessage(error))
  });
  const confirmRevoke = async () => {
    const confirmed = await prompt({
      title: "End portal access?",
      description: `${rep.name} is signed out of the sales portal at once. You can give access again later, and they keep their password.`,
      confirmText: "End access",
      cancelText: "Cancel"
    });
    if (confirmed) {
      revoke.mutate();
    }
  };
  return /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-2", children: [
        /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Sales portal" }),
        /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: active ? "green" : "grey", children: active ? "Has access" : "No access" })
      ] }),
      active ? /* @__PURE__ */ jsx(
        Button,
        {
          size: "small",
          variant: "secondary",
          isLoading: revoke.isPending,
          onClick: confirmRevoke,
          children: "End access"
        }
      ) : /* @__PURE__ */ jsx(
        Button,
        {
          size: "small",
          variant: "secondary",
          disabled: !rep.is_active,
          isLoading: grant.isPending,
          onClick: () => grant.mutate(),
          children: "Give access"
        }
      )
    ] }),
    /* @__PURE__ */ jsx("div", { className: "px-6 py-4", children: /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: active ? `${rep.name} can sign in to the sales portal with ${rep.email} to see their clients, paid orders and payouts.` : rep.is_active ? `Gives ${rep.name} a login to see their clients, paid orders and payouts. They set their first password with "Forgot password" on the portal.` : "Reactivate this rep to give them portal access." }) }),
    /* @__PURE__ */ jsx(Drawer, { open: !!granted, onOpenChange: (open) => !open && setGranted(null), children: /* @__PURE__ */ jsxs(Drawer.Content, { children: [
      /* @__PURE__ */ jsx(Drawer.Header, { children: /* @__PURE__ */ jsx(Drawer.Title, { children: "Portal access given" }) }),
      /* @__PURE__ */ jsxs(Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
        /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle", children: [
          rep.name,
          ' sets a first password with "Forgot password" on the portal: they enter ',
          rep.email,
          " and follow the link in the email that Medusa sends. Pass this link on:"
        ] }),
        (granted == null ? void 0 : granted.forgot_password_url) ? /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-2", children: [
          /* @__PURE__ */ jsx(Input, { readOnly: true, value: granted.forgot_password_url }),
          /* @__PURE__ */ jsx(
            Button,
            {
              size: "small",
              variant: "secondary",
              onClick: () => copy(granted.forgot_password_url),
              children: "Copy"
            }
          )
        ] }) : /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-error", children: [
          "The portal URL isn't configured (SALES_PORTAL_URL), so there is no link to copy. Tell ",
          rep.name,
          ` to open the portal's "Forgot password" page.`
        ] })
      ] }),
      /* @__PURE__ */ jsx(Drawer.Footer, { children: /* @__PURE__ */ jsx(Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsx(Button, { size: "small", children: "Done" }) }) })
    ] }) })
  ] });
};
const Row = ({ label, value }) => /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 items-start px-6 py-4", children: [
  /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", weight: "plus", children: label }),
  /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: value })
] });
const ProfileSection = ({ rep }) => {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(rep);
  const [clientRate, setClientRate] = useState(String(rep.default_client_rate ?? ""));
  const queryClient = useQueryClient();
  const update = useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${rep.id}`, {
      method: "POST",
      body: {
        name: form.name,
        email: form.email,
        phone: form.phone || null,
        notes: form.notes || null,
        is_active: form.is_active,
        payout_currency_code: form.payout_currency_code,
        default_client_rate: parseClientRate(clientRate)
      }
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["sales-rep", rep.id] });
      queryClient.invalidateQueries({ queryKey: ["sales-reps"] });
      toast.success("Sales rep updated");
      setOpen(false);
    },
    onError: (error) => toast.error(errorMessage(error))
  });
  return /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-2", children: [
        /* @__PURE__ */ jsx(Heading, { children: rep.name }),
        /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: rep.is_active ? "green" : "grey", children: rep.is_active ? "Active" : "Inactive" })
      ] }),
      /* @__PURE__ */ jsxs(
        Button,
        {
          size: "small",
          variant: "secondary",
          onClick: () => {
            setForm(rep);
            setClientRate(String(rep.default_client_rate ?? ""));
            setOpen(true);
          },
          children: [
            /* @__PURE__ */ jsx(PencilSquare, {}),
            "Edit"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsx(Row, { label: "Email", value: rep.email }),
    /* @__PURE__ */ jsx(Row, { label: "Phone", value: rep.phone || "-" }),
    /* @__PURE__ */ jsx(
      Row,
      {
        label: "Paid in",
        value: rep.payout_currency_code ? rep.payout_currency_code.toUpperCase() : "Each currency as earned"
      }
    ),
    /* @__PURE__ */ jsx(
      Row,
      {
        label: "New clients",
        value: rep.default_client_rate === null || rep.default_client_rate === void 0 ? "Client link off: no standard rate" : `${rep.default_client_rate}% for clients who join through their link`
      }
    ),
    /* @__PURE__ */ jsx(Row, { label: "Notes", value: rep.notes || "-" }),
    /* @__PURE__ */ jsx(Drawer, { open, onOpenChange: setOpen, children: /* @__PURE__ */ jsxs(Drawer.Content, { children: [
      /* @__PURE__ */ jsx(Drawer.Header, { children: /* @__PURE__ */ jsx(Drawer.Title, { children: "Edit sales rep" }) }),
      /* @__PURE__ */ jsxs(Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "edit-name", children: "Name" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "edit-name",
              value: form.name,
              onChange: (e) => setForm({ ...form, name: e.target.value })
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "edit-email", children: "Email" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "edit-email",
              type: "email",
              value: form.email,
              onChange: (e) => setForm({ ...form, email: e.target.value })
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "edit-phone", children: "Phone" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "edit-phone",
              value: form.phone ?? "",
              onChange: (e) => setForm({ ...form, phone: e.target.value })
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Paid in" }),
          /* @__PURE__ */ jsxs(
            Select,
            {
              value: form.payout_currency_code ?? "as-earned",
              onValueChange: (value) => setForm({
                ...form,
                payout_currency_code: value === "as-earned" ? null : value
              }),
              children: [
                /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, {}) }),
                /* @__PURE__ */ jsxs(Select.Content, { children: [
                  /* @__PURE__ */ jsx(Select.Item, { value: "as-earned", children: "Each currency as earned" }),
                  /* @__PURE__ */ jsx(Select.Item, { value: "eur", children: "EUR" }),
                  /* @__PURE__ */ jsx(Select.Item, { value: "huf", children: "HUF" })
                ] })
              ]
            }
          ),
          /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "With one currency, commission earned in the other is converted once, when it is earned, at the ECB rate of that day. What is already earned stays in the currency it was earned in." })
        ] }),
        /* @__PURE__ */ jsx(
          ClientRateField,
          {
            id: "edit-client-rate",
            value: clientRate,
            onChange: setClientRate
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "edit-notes", children: "Notes" }),
          /* @__PURE__ */ jsx(
            Textarea,
            {
              id: "edit-notes",
              value: form.notes ?? "",
              onChange: (e) => setForm({ ...form, notes: e.target.value })
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-x-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-1", children: [
            /* @__PURE__ */ jsx(Label, { htmlFor: "edit-active", children: "Active" }),
            /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "Inactive reps can't get new clients or referrals. Their current clients keep earning until you move them." })
          ] }),
          /* @__PURE__ */ jsx(
            Switch,
            {
              id: "edit-active",
              checked: form.is_active,
              onCheckedChange: (checked) => setForm({ ...form, is_active: checked })
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs(Drawer.Footer, { children: [
        /* @__PURE__ */ jsx(Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", disabled: update.isPending, children: "Cancel" }) }),
        /* @__PURE__ */ jsx(
          Button,
          {
            size: "small",
            onClick: () => update.mutate(),
            isLoading: update.isPending,
            disabled: !!clientRateError(clientRate),
            children: "Save"
          }
        )
      ] })
    ] }) })
  ] });
};
const ReferralSection = ({
  repId,
  referral,
  referredReps
}) => {
  var _a;
  const [open, setOpen] = useState(false);
  const [referrerId, setReferrerId] = useState("");
  const [rate, setRate] = useState("");
  const queryClient = useQueryClient();
  const prompt = usePrompt();
  const { data: reps } = useQuery({
    queryKey: ["sales-reps", "active-options"],
    queryFn: () => sdk.client.fetch("/admin/sales-reps", {
      query: { is_active: "true", limit: 200, order: "name" }
    }),
    enabled: open
  });
  const refresh = () => queryClient.invalidateQueries({ queryKey: ["sales-rep"] });
  const save = useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/referral`, {
      method: "POST",
      body: { referrer_sales_rep_id: referrerId, level2_rate: Number(rate) }
    }),
    onSuccess: () => {
      refresh();
      toast.success("Referral saved");
      setOpen(false);
    },
    onError: (error) => toast.error(errorMessage(error))
  });
  const end = useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/referral`, {
      method: "DELETE"
    }),
    onSuccess: () => {
      refresh();
      toast.success("Referral ended");
    },
    onError: (error) => toast.error(errorMessage(error))
  });
  const confirmEnd = async () => {
    const confirmed = await prompt({
      title: "End referral?",
      description: "The referrer stops earning Level 2 commission on orders placed today or later. Earlier days are not affected.",
      confirmText: "End referral",
      cancelText: "Cancel"
    });
    if (confirmed) {
      end.mutate();
    }
  };
  return /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Referral" }),
      /* @__PURE__ */ jsxs(
        Button,
        {
          size: "small",
          variant: "secondary",
          onClick: () => {
            setReferrerId((referral == null ? void 0 : referral.referrer_sales_rep_id) ?? "");
            setRate(referral ? String(referral.level2_rate) : "");
            setOpen(true);
          },
          children: [
            /* @__PURE__ */ jsx(PencilSquare, {}),
            referral ? "Change" : "Set referrer"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex flex-col gap-y-1 px-6 py-4", children: referral ? /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", weight: "plus", children: [
        "Referred by",
        " ",
        /* @__PURE__ */ jsx(
          Link,
          {
            to: `/sales-reps/${referral.referrer_sales_rep_id}`,
            className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
            children: ((_a = referral.referrer) == null ? void 0 : _a.name) ?? "another rep"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
        "Level 2: ",
        referral.level2_rate,
        "% of this rep's client turnover, since ",
        formatDate(referral.starts_at),
        referral.expires_at ? new Date(referral.expires_at) > /* @__PURE__ */ new Date() ? `, until ${formatDate(referral.expires_at)}` : `. It ended on ${formatDate(referral.expires_at)}, so orders placed since earn nothing` : ", until you end it"
      ] }),
      /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
        Button,
        {
          size: "small",
          variant: "transparent",
          className: "-ml-3 mt-1",
          isLoading: end.isPending,
          onClick: confirmEnd,
          children: "End referral"
        }
      ) })
    ] }) : /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Not referred by another rep." }) }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", weight: "plus", children: "Reps they referred" }),
      referredReps.length === 0 ? /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "None" }) : referredReps.map((r) => {
        var _a2;
        return /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsx(
            Link,
            {
              to: `/sales-reps/${r.referred_sales_rep_id}`,
              className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
              children: /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", children: ((_a2 = r.referred) == null ? void 0 : _a2.name) ?? r.referred_sales_rep_id })
            }
          ),
          /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
            r.level2_rate,
            "%"
          ] })
        ] }, r.id);
      })
    ] }),
    /* @__PURE__ */ jsx(Drawer, { open, onOpenChange: setOpen, children: /* @__PURE__ */ jsxs(Drawer.Content, { children: [
      /* @__PURE__ */ jsx(Drawer.Header, { children: /* @__PURE__ */ jsx(Drawer.Title, { children: "Referrer and Level 2 rate" }) }),
      /* @__PURE__ */ jsxs(Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
        /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "The referrer earns this percentage of the net turnover of this rep's clients, on top of this rep's own commission. It takes effect from the start of today (Budapest time); earlier days are not affected." }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Referred by" }),
          /* @__PURE__ */ jsxs(Select, { value: referrerId, onValueChange: setReferrerId, children: [
            /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, { placeholder: "Choose a sales rep" }) }),
            /* @__PURE__ */ jsx(Select.Content, { children: ((reps == null ? void 0 : reps.sales_reps) ?? []).filter((rep) => rep.id !== repId).map((rep) => /* @__PURE__ */ jsx(Select.Item, { value: rep.id, children: rep.name }, rep.id)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "level2-rate", children: "Level 2 rate (%)" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "level2-rate",
              type: "number",
              min: 0,
              max: 100,
              step: "0.01",
              value: rate,
              onChange: (e) => setRate(e.target.value)
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs(Drawer.Footer, { children: [
        /* @__PURE__ */ jsx(Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", disabled: save.isPending, children: "Cancel" }) }),
        /* @__PURE__ */ jsx(
          Button,
          {
            size: "small",
            disabled: !referrerId || rate === "",
            isLoading: save.isPending,
            onClick: () => save.mutate(),
            children: "Save"
          }
        )
      ] })
    ] }) })
  ] });
};
const AdjustmentDrawer = ({
  repId,
  payoutCurrency
}) => {
  const currencies = payoutCurrency ? [payoutCurrency] : CURRENCIES;
  const [open, setOpen] = useState(false);
  const [currency, setCurrency] = useState(currencies[0]);
  const [amount, setAmount] = useState("");
  const [period, setPeriod] = useState(currentPeriod());
  const [reason, setReason] = useState("");
  const [error, setError] = useState(null);
  const queryClient = useQueryClient();
  const { data: status } = useQuery({
    queryKey: ["periods"],
    queryFn: () => sdk.client.fetch("/admin/sales-commission/periods"),
    enabled: open
  });
  const openMonths = recentPeriods().filter(
    (p) => !(status == null ? void 0 : status.approved_through) || p.value > status.approved_through
  );
  const save = useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/adjustments`, {
      method: "POST",
      body: {
        currency_code: currency,
        amount: Number(amount),
        period,
        reason: reason.trim()
      }
    }),
    onSuccess: () => {
      for (const key of [
        "sales-rep-balance",
        "sales-rep-statement",
        "commission-report",
        "payment-run"
      ]) {
        queryClient.invalidateQueries({ queryKey: [key] });
      }
      toast.success("Adjustment added");
      setOpen(false);
    },
    onError: (e) => toast.error(errorMessage(e))
  });
  const submit = () => {
    const value = Number(amount);
    if (!amount || Number.isNaN(value) || value === 0) {
      return setError("Enter an amount");
    }
    if (!reason.trim()) {
      return setError("A reason is required");
    }
    setError(null);
    save.mutate();
  };
  return /* @__PURE__ */ jsxs(
    Drawer,
    {
      open,
      onOpenChange: (next) => {
        setOpen(next);
        if (next) {
          setCurrency(currencies[0]);
          setAmount("");
          setPeriod(currentPeriod());
          setReason("");
          setError(null);
        }
      },
      children: [
        /* @__PURE__ */ jsx(Drawer.Trigger, { asChild: true, children: /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", children: "Add adjustment" }) }),
        /* @__PURE__ */ jsxs(Drawer.Content, { children: [
          /* @__PURE__ */ jsx(Drawer.Header, { children: /* @__PURE__ */ jsx(Drawer.Title, { children: "Add commission adjustment" }) }),
          /* @__PURE__ */ jsxs(Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
            /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "Correct what a rep earned, for example after a partial return. Use a negative amount to reduce it. The reason is shown to the rep. Adjustments can't be edited or deleted; add a reversing one to undo." }),
            /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
                /* @__PURE__ */ jsx(Label, { children: "Month" }),
                /* @__PURE__ */ jsxs(Select, { value: period, onValueChange: setPeriod, children: [
                  /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, {}) }),
                  /* @__PURE__ */ jsx(Select.Content, { children: openMonths.map((p) => /* @__PURE__ */ jsx(Select.Item, { value: p.value, children: p.label }, p.value)) })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
                /* @__PURE__ */ jsx(Label, { children: "Currency" }),
                /* @__PURE__ */ jsxs(
                  Select,
                  {
                    value: currency,
                    onValueChange: setCurrency,
                    disabled: currencies.length === 1,
                    children: [
                      /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, {}) }),
                      /* @__PURE__ */ jsx(Select.Content, { children: currencies.map((code) => /* @__PURE__ */ jsx(Select.Item, { value: code, children: code.toUpperCase() }, code)) })
                    ]
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "adjustment-amount", children: "Amount" }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "adjustment-amount",
                  type: "number",
                  step: currencyStep(currency),
                  value: amount,
                  onChange: (e) => {
                    setAmount(e.target.value);
                    setError(null);
                  }
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "adjustment-reason", children: "Reason" }),
              /* @__PURE__ */ jsx(
                Textarea,
                {
                  id: "adjustment-reason",
                  value: reason,
                  onChange: (e) => {
                    setReason(e.target.value);
                    setError(null);
                  }
                }
              )
            ] }),
            error && /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-error", children: error })
          ] }),
          /* @__PURE__ */ jsxs(Drawer.Footer, { children: [
            /* @__PURE__ */ jsx(Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", disabled: save.isPending, children: "Cancel" }) }),
            /* @__PURE__ */ jsx(Button, { size: "small", onClick: submit, isLoading: save.isPending, children: "Save" })
          ] })
        ] })
      ]
    }
  );
};
const payoutOutcome = ({
  amount,
  payable,
  decimals: decimals2
}) => {
  const scale = 10 ** decimals2;
  const paid = Math.round(amount * scale);
  const owed = Math.round(payable * scale);
  if (!Number.isFinite(paid) || paid <= 0) {
    return { kind: "invalid", difference: 0 };
  }
  return {
    kind: paid === owed ? "full" : paid < owed ? "short" : "over",
    difference: Math.abs(paid - owed) / scale
  };
};
const decimals = (currencyCode) => currencyStep(currencyCode) === "1" ? 0 : 2;
const PayoutDrawer = ({
  repId,
  payoutCurrency
}) => {
  const currencies = payoutCurrency ? [payoutCurrency] : CURRENCIES;
  const [open, setOpen] = useState(false);
  const [currency, setCurrency] = useState(currencies[0]);
  const [amount, setAmount] = useState("");
  const [touched, setTouched] = useState(false);
  const [paidAt, setPaidAt] = useState(today());
  const [reference, setReference] = useState("");
  const [asBonus, setAsBonus] = useState(false);
  const [bonusReason, setBonusReason] = useState("");
  const [error, setError] = useState(null);
  const queryClient = useQueryClient();
  const { data: balance } = useQuery({
    queryKey: ["sales-rep-balance", repId],
    queryFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/balance`),
    enabled: open
  });
  const current = balance == null ? void 0 : balance.balances.find((b) => b.currency_code === currency);
  const payable = (current == null ? void 0 : current.payable) ?? 0;
  const toRecover = (current == null ? void 0 : current.to_recover) ?? 0;
  useEffect(() => {
    if (open && !touched) {
      setAmount(payable > 0 ? String(payable) : "");
    }
  }, [open, touched, payable, currency]);
  const parsed = Number(amount);
  const outcome = payoutOutcome({
    amount: parsed,
    payable,
    decimals: decimals(currency)
  });
  const money = (value) => formatMoney(value, currency);
  const save = useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/payouts`, {
      method: "POST",
      body: {
        currency_code: currency,
        amount: parsed,
        paid_at: paidAt,
        reference: reference.trim() || null,
        bonus_reason: asBonus ? bonusReason.trim() : null
      }
    }),
    onSuccess: () => {
      for (const key of [
        "sales-rep-balance",
        "sales-rep-statement",
        "commission-report",
        "payment-run",
        "rep-balances"
      ]) {
        queryClient.invalidateQueries({ queryKey: [key] });
      }
      toast.success("Payout recorded");
      setOpen(false);
    },
    onError: (e) => toast.error(errorMessage(e))
  });
  const submit = () => {
    if (outcome.kind === "invalid") {
      return setError("Enter an amount above zero");
    }
    if (asBonus && outcome.kind === "over" && !bonusReason.trim()) {
      return setError("Give a reason for the bonus");
    }
    setError(null);
    save.mutate();
  };
  const reset = () => {
    setCurrency(currencies[0]);
    setAmount("");
    setTouched(false);
    setPaidAt(today());
    setReference("");
    setAsBonus(false);
    setBonusReason("");
    setError(null);
  };
  return /* @__PURE__ */ jsxs(
    Drawer,
    {
      open,
      onOpenChange: (next) => {
        setOpen(next);
        if (next) reset();
      },
      children: [
        /* @__PURE__ */ jsx(Drawer.Trigger, { asChild: true, children: /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", children: "Record payout" }) }),
        /* @__PURE__ */ jsxs(Drawer.Content, { children: [
          /* @__PURE__ */ jsx(Drawer.Header, { children: /* @__PURE__ */ jsx(Drawer.Title, { children: "Record payout" }) }),
          /* @__PURE__ */ jsxs(Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
            /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "Record a bank transfer you made to the rep. It counts against everything approved so far, whichever month that was earned in." }),
            currencies.length > 1 && /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
              /* @__PURE__ */ jsx(Label, { children: "Currency" }),
              /* @__PURE__ */ jsxs(
                Select,
                {
                  value: currency,
                  onValueChange: (value) => {
                    setCurrency(value);
                    setTouched(false);
                  },
                  children: [
                    /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, {}) }),
                    /* @__PURE__ */ jsx(Select.Content, { children: currencies.map((code) => /* @__PURE__ */ jsx(Select.Item, { value: code, children: code.toUpperCase() }, code)) })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "bg-ui-bg-subtle border-ui-border-base flex flex-col gap-y-1 rounded-lg border px-4 py-3", children: [
              /* @__PURE__ */ jsx(Text, { size: "xsmall", leading: "compact", className: "text-ui-fg-subtle", children: "Payable now" }),
              /* @__PURE__ */ jsx(Text, { size: "xlarge", leading: "compact", weight: "plus", children: money(payable) }),
              toRecover > 0 && /* @__PURE__ */ jsxs(Text, { size: "xsmall", leading: "compact", className: "text-ui-tag-orange-text", children: [
                money(toRecover),
                " was paid ahead and is netted first"
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
              /* @__PURE__ */ jsx(Label, { htmlFor: "payout-amount", children: "Amount paid" }),
              /* @__PURE__ */ jsx(
                Input,
                {
                  id: "payout-amount",
                  type: "number",
                  min: 0,
                  step: currencyStep(currency),
                  value: amount,
                  onChange: (e) => {
                    setAmount(e.target.value);
                    setTouched(true);
                    setError(null);
                  }
                }
              )
            ] }),
            outcome.kind === "full" && /* @__PURE__ */ jsx(Alert, { variant: "success", children: "Pays in full. Nothing is left due." }),
            outcome.kind === "short" && /* @__PURE__ */ jsxs(Alert, { variant: "warning", children: [
              "Short by ",
              money(outcome.difference),
              ". The remainder stays due and shows on the next run."
            ] }),
            outcome.kind === "over" && /* @__PURE__ */ jsxs(Alert, { variant: "warning", children: [
              payable > 0 ? `Over by ${money(outcome.difference)}.` : "Nothing is payable yet.",
              " ",
              "This is recorded as an advance and recovered from what the rep earns next."
            ] }),
            outcome.kind === "over" && payable > 0 && /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-3", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-2", children: [
                /* @__PURE__ */ jsx(
                  Checkbox,
                  {
                    id: "payout-bonus",
                    checked: asBonus,
                    onCheckedChange: (checked) => setAsBonus(checked === true)
                  }
                ),
                /* @__PURE__ */ jsxs(Label, { htmlFor: "payout-bonus", children: [
                  "Record the extra ",
                  money(outcome.difference),
                  " as a bonus instead"
                ] })
              ] }),
              asBonus && /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
                /* @__PURE__ */ jsx(Label, { htmlFor: "payout-bonus-reason", children: "Reason for the bonus" }),
                /* @__PURE__ */ jsx(
                  Textarea,
                  {
                    id: "payout-bonus-reason",
                    value: bonusReason,
                    onChange: (e) => setBonusReason(e.target.value)
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
                /* @__PURE__ */ jsx(Label, { htmlFor: "payout-date", children: "Paid on" }),
                /* @__PURE__ */ jsx(
                  Input,
                  {
                    id: "payout-date",
                    type: "date",
                    value: paidAt,
                    onChange: (e) => setPaidAt(e.target.value)
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
                /* @__PURE__ */ jsx(Label, { htmlFor: "payout-reference", children: "Reference (optional)" }),
                /* @__PURE__ */ jsx(
                  Input,
                  {
                    id: "payout-reference",
                    value: reference,
                    onChange: (e) => setReference(e.target.value)
                  }
                )
              ] })
            ] }),
            error && /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-error", children: error })
          ] }),
          /* @__PURE__ */ jsxs(Drawer.Footer, { children: [
            /* @__PURE__ */ jsx(Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", disabled: save.isPending, children: "Cancel" }) }),
            /* @__PURE__ */ jsx(Button, { size: "small", onClick: submit, isLoading: save.isPending, children: "Record payout" })
          ] })
        ] })
      ]
    }
  );
};
const PeriodSelect = ({
  value,
  onChange
}) => /* @__PURE__ */ jsx("div", { className: "w-44", children: /* @__PURE__ */ jsxs(Select, { size: "small", value, onValueChange: onChange, children: [
  /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, {}) }),
  /* @__PURE__ */ jsx(Select.Content, { children: recentPeriods().map((period) => /* @__PURE__ */ jsx(Select.Item, { value: period.value, children: period.label }, period.value)) })
] }) });
const KIND_LABELS = {
  direct: "Commission",
  level2: "Level 2",
  reversal: "Reversal",
  adjustment: "Adjustment",
  payout: "Payout"
};
const Totals = ({ summary }) => {
  const money = (amount) => formatMoney(amount, summary.currency_code);
  const badge = STATUS_BADGES[summary.status];
  const cells = [
    ["Owed at start", money(summary.opening)],
    ["Turnover", money(summary.turnover)],
    ["Direct", money(summary.direct)],
    ["Level 2", money(summary.level2)],
    ["Adjustments", money(summary.adjustments)],
    ["Earned", money(summary.total)],
    ["Paid", money(summary.paid)],
    ["Owed at end", money(summary.closing)]
  ];
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-3 px-6 py-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-2", children: [
      /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", weight: "plus", children: summary.currency_code.toUpperCase() }),
      /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: badge.color, children: badge.label })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "grid grid-cols-2 gap-3 md:grid-cols-4", children: cells.map(([label, value]) => /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-1", children: [
      /* @__PURE__ */ jsx(Text, { size: "xsmall", leading: "compact", className: "text-ui-fg-subtle", children: label }),
      /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", weight: "plus", children: value })
    ] }, label)) })
  ] });
};
const StatementSection = ({
  repId,
  payoutCurrency
}) => {
  const [period, setPeriod] = useState(currentPeriod());
  const queryClient = useQueryClient();
  const prompt = usePrompt();
  const { data, isLoading } = useQuery({
    queryKey: ["sales-rep-statement", repId, period],
    queryFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/statement`, {
      query: { period }
    })
  });
  const deletePayout = useMutation({
    mutationFn: (payoutId) => sdk.client.fetch(`/admin/sales-commission/payouts/${payoutId}`, {
      method: "DELETE"
    }),
    onSuccess: () => {
      for (const key of [
        "sales-rep-statement",
        "sales-rep-balance",
        "commission-report",
        "payment-run"
      ]) {
        queryClient.invalidateQueries({ queryKey: [key] });
      }
      toast.success("Payout removed");
    },
    onError: (error) => toast.error(errorMessage(error))
  });
  const confirmDelete = async (line) => {
    const confirmed = await prompt({
      title: "Remove payout?",
      description: `Removes the ${formatMoney(line.amount, line.currency_code)} payout recorded by mistake. What it paid becomes payable again, and a bonus recorded with it is removed too.`,
      confirmText: "Remove",
      cancelText: "Cancel"
    });
    if (confirmed) {
      deletePayout.mutate(line.source_id);
    }
  };
  const exportCsv = () => downloadFile(
    `/admin/sales-reps/${repId}/statement?period=${period}&format=csv`,
    "text/csv",
    `commission-statement-${period}.csv`
  ).catch((error) => toast.error(errorMessage(error)));
  const carried = ((data == null ? void 0 : data.totals) ?? []).filter((summary) => summary.opening !== 0);
  return /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-start justify-between gap-2 px-6 py-4 md:flex-row md:items-center", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-2", children: [
        /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Commission statement" }),
        data && /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: data.approved ? "green" : "orange", children: data.approved ? "Approved" : "Open" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
        /* @__PURE__ */ jsx(PeriodSelect, { value: period, onChange: setPeriod }),
        /* @__PURE__ */ jsxs(Button, { size: "small", variant: "secondary", onClick: exportCsv, children: [
          /* @__PURE__ */ jsx(ArrowDownTray, {}),
          "CSV"
        ] }),
        /* @__PURE__ */ jsx(AdjustmentDrawer, { repId, payoutCurrency }),
        /* @__PURE__ */ jsx(PayoutDrawer, { repId, payoutCurrency })
      ] })
    ] }),
    isLoading || !data ? /* @__PURE__ */ jsx(Loading, {}) : data.lines.length === 0 && carried.length === 0 ? /* @__PURE__ */ jsx("div", { className: "px-6 py-4", children: /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Nothing recorded for this month." }) }) : /* @__PURE__ */ jsxs(Fragment, { children: [
      data.totals.map((summary) => /* @__PURE__ */ jsx(Totals, { summary }, summary.currency_code)),
      /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs(Table, { children: [
        /* @__PURE__ */ jsx(Table.Header, { children: /* @__PURE__ */ jsxs(Table.Row, { children: [
          /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Date" }),
          /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Type" }),
          /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Order" }),
          /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Client" }),
          /* @__PURE__ */ jsx(Table.HeaderCell, { className: "text-right", children: "Net value" }),
          /* @__PURE__ */ jsx(Table.HeaderCell, { className: "text-right", children: "Rate" }),
          /* @__PURE__ */ jsx(Table.HeaderCell, { className: "text-right", children: "Amount" }),
          /* @__PURE__ */ jsx(Table.HeaderCell, { className: "text-right", children: "Balance" }),
          /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Status" }),
          /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Note" }),
          /* @__PURE__ */ jsx(Table.HeaderCell, {})
        ] }) }),
        /* @__PURE__ */ jsxs(Table.Body, { children: [
          carried.map((summary) => /* @__PURE__ */ jsxs(Table.Row, { children: [
            /* @__PURE__ */ jsx(Table.Cell, {}),
            /* @__PURE__ */ jsx(Table.Cell, { children: "Brought forward" }),
            /* @__PURE__ */ jsx(Table.Cell, { children: "-" }),
            /* @__PURE__ */ jsx(Table.Cell, { children: "Left over from earlier months" }),
            /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: "-" }),
            /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: "-" }),
            /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: "-" }),
            /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: formatMoney(summary.opening, summary.currency_code) }),
            /* @__PURE__ */ jsx(Table.Cell, {}),
            /* @__PURE__ */ jsx(Table.Cell, {}),
            /* @__PURE__ */ jsx(Table.Cell, {})
          ] }, `carried-${summary.currency_code}`)),
          data.lines.map((line) => {
            const badge = LINE_BADGES[line.status];
            return /* @__PURE__ */ jsxs(Table.Row, { children: [
              /* @__PURE__ */ jsx(Table.Cell, { children: formatDate(line.date) }),
              /* @__PURE__ */ jsx(Table.Cell, { children: KIND_LABELS[line.kind] }),
              /* @__PURE__ */ jsx(Table.Cell, { children: line.order_display_id ? `#${line.order_display_id}` : "-" }),
              /* @__PURE__ */ jsx(Table.Cell, { children: line.client_name ?? "-" }),
              /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: line.base_amount === null ? "-" : formatMoney(line.base_amount, line.currency_code) }),
              /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: line.rate === null ? "-" : `${line.rate}%` }),
              /* @__PURE__ */ jsxs(Table.Cell, { className: "text-right", children: [
                formatMoney(line.amount, line.currency_code),
                line.fx_rate && line.order_currency_code && line.order_amount !== null && /* @__PURE__ */ jsxs(Text, { size: "xsmall", leading: "compact", className: "text-ui-fg-muted", children: [
                  formatMoney(line.order_amount, line.order_currency_code),
                  " ×",
                  " ",
                  line.fx_rate
                ] })
              ] }),
              /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: formatMoney(line.balance, line.currency_code) }),
              /* @__PURE__ */ jsx(Table.Cell, { children: /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: badge.color, children: badge.label }) }),
              /* @__PURE__ */ jsx(Table.Cell, { children: line.note ?? "" }),
              /* @__PURE__ */ jsx(Table.Cell, { children: line.kind === "payout" && /* @__PURE__ */ jsx(
                IconButton,
                {
                  size: "small",
                  variant: "transparent",
                  disabled: deletePayout.isPending,
                  onClick: () => confirmDelete(line),
                  children: /* @__PURE__ */ jsx(Trash, {})
                }
              ) })
            ] }, `${line.kind}-${line.source_id}-${line.date}`);
          })
        ] })
      ] }) })
    ] })
  ] });
};
const SalesRepDetailPage = () => {
  const { id } = useParams();
  const { data, isLoading, error } = useQuery({
    queryKey: ["sales-rep", id],
    queryFn: () => sdk.client.fetch(`/admin/sales-reps/${id}`),
    enabled: !!id
  });
  if (isLoading) {
    return /* @__PURE__ */ jsx(Loading, {});
  }
  if (error || !data) {
    return /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-error", children: "This sales rep could not be loaded." });
  }
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-3 xl:flex-row xl:items-start xl:gap-x-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex w-full flex-col gap-y-3", children: [
      /* @__PURE__ */ jsx(ProfileSection, { rep: data.sales_rep }, data.sales_rep.id),
      /* @__PURE__ */ jsx(BalanceSection, { repId: data.sales_rep.id }),
      /* @__PURE__ */ jsx(
        StatementSection,
        {
          repId: data.sales_rep.id,
          payoutCurrency: data.sales_rep.payout_currency_code
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex w-full flex-col gap-y-3 xl:max-w-[400px]", children: [
      /* @__PURE__ */ jsx(
        ReferralSection,
        {
          repId: data.sales_rep.id,
          referral: data.referral,
          referredReps: data.referred_reps
        }
      ),
      /* @__PURE__ */ jsx(PortalSection, { rep: data.sales_rep, portal: data.portal }),
      /* @__PURE__ */ jsx(ClientLinkSection, { rep: data.sales_rep }),
      /* @__PURE__ */ jsx(ClientsSection, { repId: data.sales_rep.id }),
      /* @__PURE__ */ jsx(ContractsSection, { repId: data.sales_rep.id }),
      /* @__PURE__ */ jsx(DeleteSection, { rep: data.sales_rep })
    ] })
  ] });
};
const PAGE_SIZE = 20;
const TABS = [
  { value: "applied", label: "Waiting" },
  { value: "approved", label: "Approved" },
  { value: "declined", label: "Declined" },
  { value: "invited", label: "Invited" }
];
const EMPTY = {
  applied: "Nothing is waiting. When someone a rep invited applies, it shows up here and you get an email.",
  approved: "No application has been approved yet.",
  declined: "No application has been declined.",
  invited: "No invitation is waiting for an answer.",
  canceled: "No invitation was withdrawn."
};
const columnHelper = createDataTableColumnHelper();
const columns = [
  columnHelper.display({
    id: "candidate",
    header: "Candidate",
    cell: ({ row }) => /* @__PURE__ */ jsxs("div", { className: "flex flex-col py-1", children: [
      /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", weight: "plus", children: row.original.name }),
      /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: row.original.email })
    ] })
  }),
  columnHelper.display({
    id: "recruiter",
    header: "Recruited by",
    cell: ({ row }) => {
      var _a;
      return ((_a = row.original.recruiter) == null ? void 0 : _a.name) ?? "-";
    }
  }),
  columnHelper.display({
    id: "date",
    header: "Date",
    cell: ({ row }) => {
      const { status, applied_at, decided_at, expires_at, invited_at, expired } = row.original;
      if (status === "applied") return `Applied ${formatDate(applied_at ?? invited_at)}`;
      if (status === "approved" || status === "declined") {
        return `${status === "approved" ? "Approved" : "Declined"} ${formatDate(decided_at ?? invited_at)}`;
      }
      return expired ? `Link ended ${formatDate(expires_at)}` : `Link works until ${formatDate(expires_at)}`;
    }
  }),
  columnHelper.display({
    id: "currency",
    header: "Wants paid in",
    cell: ({ row }) => {
      var _a;
      return ((_a = row.original.requested_currency_code) == null ? void 0 : _a.toUpperCase()) ?? "-";
    }
  }),
  columnHelper.display({
    id: "status",
    header: "Status",
    cell: ({ row }) => {
      const badge = applicationBadge(row.original);
      return /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: badge.color, children: badge.label });
    }
  })
];
const ApplicationsPage = () => {
  const navigate = useNavigate();
  const [status, setStatus] = useState("applied");
  const [pagination, setPagination] = useState({
    pageIndex: 0,
    pageSize: PAGE_SIZE
  });
  const offset = pagination.pageIndex * PAGE_SIZE;
  const { data, isLoading } = useQuery({
    queryKey: ["applications", status, offset],
    queryFn: () => sdk.client.fetch("/admin/sales-commission/applications", {
      query: { status, limit: PAGE_SIZE, offset }
    }),
    placeholderData: keepPreviousData
  });
  const table = useDataTable({
    data: (data == null ? void 0 : data.applications) ?? [],
    columns,
    getRowId: (application) => application.id,
    rowCount: (data == null ? void 0 : data.count) ?? 0,
    isLoading,
    pagination: { state: pagination, onPaginationChange: setPagination },
    // The review page also shows an application after it was decided
    onRowClick: (_, application) => navigate(`/sales-reps/applications/${application.id}`)
  });
  const counts = useMemo(() => data == null ? void 0 : data.counts, [data]);
  return /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-1 px-6 py-4", children: [
      /* @__PURE__ */ jsx(Heading, { children: "Applications" }),
      /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "Reps invite people to join. They apply from a personal link, and nothing is created or paid until you approve." })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "px-6 py-3", children: /* @__PURE__ */ jsx(
      Tabs,
      {
        value: status,
        onValueChange: (value) => {
          setStatus(value);
          setPagination({ pageIndex: 0, pageSize: PAGE_SIZE });
        },
        children: /* @__PURE__ */ jsx(Tabs.List, { children: TABS.map((tab) => /* @__PURE__ */ jsxs(Tabs.Trigger, { value: tab.value, children: [
          tab.label,
          counts ? ` (${counts[tab.value]})` : ""
        ] }, tab.value)) })
      }
    ) }),
    !isLoading && (data == null ? void 0 : data.applications.length) === 0 ? /* @__PURE__ */ jsx("div", { className: "px-6 py-6", children: /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: EMPTY[status] }) }) : /* @__PURE__ */ jsxs(DataTable, { instance: table, children: [
      /* @__PURE__ */ jsx(DataTable.Table, {}),
      /* @__PURE__ */ jsx(DataTable.Pagination, {})
    ] })
  ] });
};
const config$2 = defineRouteConfig({
  label: "Applications"
});
const FxRatesSection = () => {
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState(today());
  const [rate, setRate] = useState("");
  const [error, setError] = useState(null);
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["fx-rates"],
    queryFn: () => sdk.client.fetch("/admin/sales-commission/fx-rates")
  });
  const add = useMutation({
    mutationFn: () => sdk.client.fetch("/admin/sales-commission/fx-rates", {
      method: "POST",
      body: { rate_date: date, rate: Number(rate) }
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["fx-rates"] });
      toast.success("Rate added");
      setOpen(false);
      setRate("");
    },
    onError: (e) => toast.error(errorMessage(e))
  });
  const submit = () => {
    if (!(Number(rate) > 0)) {
      return setError("Enter the forint per euro");
    }
    setError(null);
    add.mutate();
  };
  const latest = data == null ? void 0 : data.rates[0];
  return /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-1", children: [
        /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Exchange rates" }),
        /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Commission is converted once, when it is earned, at the rate of that day. Reps paid in one currency see a single balance." })
      ] }),
      /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", onClick: () => setOpen(true), children: "Add a rate" })
    ] }),
    isLoading || !data ? /* @__PURE__ */ jsx(Loading, {}) : /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      latest ? /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-x-3 gap-y-1", children: [
        /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", weight: "plus", children: [
          "1 EUR = ",
          latest.rate,
          " HUF"
        ] }),
        /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
          "on ",
          formatDate(latest.rate_date)
        ] }),
        /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: latest.source === "ecb" ? "green" : "orange", children: latest.source === "ecb" ? "ECB" : "Entered by hand" })
      ] }) : /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
        "No rate stored yet.",
        " ",
        data.auto_fetch ? "The first one is fetched from the ECB when a rep paid in a different currency earns commission." : "Automatic fetching is off, so add one."
      ] }),
      /* @__PURE__ */ jsx(Text, { size: "xsmall", leading: "compact", className: "text-ui-fg-muted", children: data.auto_fetch ? "Fetched from the ECB every working day." : "Automatic fetching is off. Enter each day's rate by hand." })
    ] }),
    /* @__PURE__ */ jsx(Drawer, { open, onOpenChange: setOpen, children: /* @__PURE__ */ jsxs(Drawer.Content, { children: [
      /* @__PURE__ */ jsx(Drawer.Header, { children: /* @__PURE__ */ jsx(Drawer.Title, { children: "Add an exchange rate" }) }),
      /* @__PURE__ */ jsxs(Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
        /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "Use this for a day the ECB rate is missing. A day that already has a rate can't be changed, and commission already earned keeps the rate it was earned at." }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "fx-date", children: "Day" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "fx-date",
              type: "date",
              value: date,
              onChange: (e) => setDate(e.target.value)
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "fx-rate", children: "Forint per euro" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "fx-rate",
              type: "number",
              min: 0,
              step: "0.01",
              value: rate,
              onChange: (e) => {
                setRate(e.target.value);
                setError(null);
              }
            }
          )
        ] }),
        error && /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-error", children: error })
      ] }),
      /* @__PURE__ */ jsxs(Drawer.Footer, { children: [
        /* @__PURE__ */ jsx(Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", disabled: add.isPending, children: "Cancel" }) }),
        /* @__PURE__ */ jsx(Button, { size: "small", onClick: submit, isLoading: add.isPending, children: "Save" })
      ] })
    ] }) })
  ] });
};
const rowKey = (row) => `${row.sales_rep_id}:${row.currency_code}`;
const csvCell = (value) => {
  const text = String(value);
  const safe = /^[=+\-@]/.test(text) ? `'${text}` : text;
  return /[",\r\n]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe;
};
const downloadCsv = (fileName, rows) => {
  const csv = "\uFEFF" + rows.map((row) => row.map(csvCell).join(",")).join("\r\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  link.click();
  URL.revokeObjectURL(url);
};
const rowNote = (row, minimums) => {
  const money = (amount) => formatMoney(amount, row.currency_code);
  const notes = [];
  if (row.to_recover > 0) {
    notes.push(
      `Paid ahead ${money(row.to_recover)}. Netted from what they earn next`
    );
  }
  if (row.below_minimum) {
    notes.push(
      `Below the minimum of ${money(minimums[row.currency_code] ?? 0)}. Rolls over to the next run`
    );
  }
  if (row.brought_forward > 0) {
    notes.push(`Includes ${money(row.brought_forward)} from earlier months`);
  }
  if (row.open_earned > 0) {
    notes.push(`${money(row.open_earned)} more waits for its month to be approved`);
  }
  return notes;
};
const PaymentRunPage = () => {
  const queryClient = useQueryClient();
  const prompt = usePrompt();
  const [selected, setSelected] = useState({});
  const [amounts, setAmounts] = useState({});
  const [open, setOpen] = useState(false);
  const [paidAt, setPaidAt] = useState(today());
  const [reference, setReference] = useState("");
  const { data, isLoading } = useQuery({
    queryKey: ["payment-run"],
    queryFn: () => sdk.client.fetch("/admin/sales-commission/payment-run")
  });
  const signature = JSON.stringify((data == null ? void 0 : data.rows) ?? []);
  useEffect(() => {
    if (!data) return;
    setSelected(
      Object.fromEntries(
        data.rows.map((row) => [rowKey(row), row.payable > 0 && !row.below_minimum])
      )
    );
    setAmounts(
      Object.fromEntries(
        data.rows.map((row) => [rowKey(row), row.payable > 0 ? String(row.payable) : ""])
      )
    );
  }, [signature]);
  const refresh = () => {
    for (const key of [
      "payment-run",
      "periods",
      "sales-rep-balance",
      "sales-rep-statement",
      "commission-report",
      "rep-balances"
    ]) {
      queryClient.invalidateQueries({ queryKey: [key] });
    }
  };
  const approve = useMutation({
    mutationFn: (through) => sdk.client.fetch("/admin/sales-commission/periods", {
      method: "POST",
      body: { through }
    }),
    onSuccess: () => {
      refresh();
      toast.success("Months approved");
    },
    onError: (e) => toast.error(errorMessage(e))
  });
  const reopen = useMutation({
    mutationFn: () => sdk.client.fetch("/admin/sales-commission/periods/latest", { method: "DELETE" }),
    onSuccess: () => {
      refresh();
      toast.success("Approval undone");
    },
    onError: (e) => toast.error(errorMessage(e))
  });
  const items = useMemo(
    () => ((data == null ? void 0 : data.rows) ?? []).filter((row) => selected[rowKey(row)] && Number(amounts[rowKey(row)]) > 0).map((row) => ({
      sales_rep_id: row.sales_rep_id,
      currency_code: row.currency_code,
      amount: Number(amounts[rowKey(row)])
    })),
    [data, selected, amounts]
  );
  const totals = useMemo(() => {
    const byCurrency = /* @__PURE__ */ new Map();
    for (const item of items) {
      byCurrency.set(item.currency_code, (byCurrency.get(item.currency_code) ?? 0) + item.amount);
    }
    return [...byCurrency.entries()].sort(([a], [b]) => a.localeCompare(b));
  }, [items]);
  const record = useMutation({
    mutationFn: () => sdk.client.fetch("/admin/sales-commission/payment-run", {
      method: "POST",
      body: { items, paid_at: paidAt, reference: reference.trim() || null }
    }),
    onSuccess: () => {
      refresh();
      toast.success("Payouts recorded");
      setOpen(false);
    },
    onError: (e) => toast.error(errorMessage(e))
  });
  const confirmApprove = async (through, count) => {
    const confirmed = await prompt({
      title: `Approve through ${monthLabel(through)}?`,
      description: `What reps earned in ${count === 1 ? "this month" : `these ${count} months`} becomes payable. Statements of an approved month don't change; later refunds and adjustments land in the month they happen. You can undo the latest approval until you record a payout.`,
      confirmText: "Approve",
      cancelText: "Cancel"
    });
    if (confirmed) approve.mutate(through);
  };
  const confirmReopen = async (period) => {
    const confirmed = await prompt({
      title: `Undo the approval of ${monthLabel(period)}?`,
      description: "What was earned in it stops being payable until you approve it again.",
      confirmText: "Undo approval",
      cancelText: "Cancel"
    });
    if (confirmed) reopen.mutate();
  };
  const exportCsv = () => downloadCsv(`payment-run-${today()}.csv`, [
    ["Rep", "Email", "Currency", "Amount"],
    ...((data == null ? void 0 : data.rows) ?? []).filter((row) => selected[rowKey(row)] && Number(amounts[rowKey(row)]) > 0).map((row) => [
      row.sales_rep_name,
      row.sales_rep_email,
      row.currency_code.toUpperCase(),
      Number(amounts[rowKey(row)])
    ])
  ]);
  const lastClosed = data == null ? void 0 : data.closed_unapproved[data.closed_unapproved.length - 1];
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-3", children: [
    /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-start justify-between gap-2 px-6 py-4 md:flex-row md:items-center", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-1", children: [
          /* @__PURE__ */ jsx(Heading, { children: "Payment run" }),
          /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: "Pay what reps are owed. Only months you have approved are payable; the amounts are filled in from each rep's balance." })
        ] }),
        /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", asChild: true, children: /* @__PURE__ */ jsx(Link, { to: "/sales-reps/report", children: "Monthly report" }) })
      ] }),
      isLoading || !data ? /* @__PURE__ */ jsx(Loading, {}) : /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-3 px-6 py-4", children: [
        data.closed_unapproved.length > 0 && lastClosed ? /* @__PURE__ */ jsxs(Alert, { variant: "warning", children: [
          data.closed_unapproved.length === 1 ? `${monthLabel(lastClosed)} is over and not approved yet.` : `${data.closed_unapproved.map(monthLabel).join(", ")} are over and not approved yet.`,
          " ",
          "Check the monthly report, then approve it to make what reps earned payable."
        ] }) : /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: data.approved_through ? `All finished months are approved, through ${monthLabel(data.approved_through)}.` : "Nothing to approve yet." }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
          lastClosed && /* @__PURE__ */ jsxs(
            Button,
            {
              size: "small",
              isLoading: approve.isPending,
              onClick: () => confirmApprove(lastClosed, data.closed_unapproved.length),
              children: [
                "Approve through ",
                monthLabel(lastClosed)
              ]
            }
          ),
          data.approved_through && /* @__PURE__ */ jsxs(
            Button,
            {
              size: "small",
              variant: "secondary",
              isLoading: reopen.isPending,
              onClick: () => confirmReopen(data.approved_through),
              children: [
                "Undo approval of ",
                monthLabel(data.approved_through)
              ]
            }
          )
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
        /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Payable now" }),
        (data == null ? void 0 : data.payout_day) && /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
          "Usual payout day: the ",
          data.payout_day,
          "th"
        ] })
      ] }),
      isLoading || !data ? /* @__PURE__ */ jsx(Loading, {}) : data.rows.length === 0 ? /* @__PURE__ */ jsx("div", { className: "px-6 py-4", children: /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Nobody is owed anything right now." }) }) : /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs(Table, { children: [
          /* @__PURE__ */ jsx(Table.Header, { children: /* @__PURE__ */ jsxs(Table.Row, { children: [
            /* @__PURE__ */ jsx(Table.HeaderCell, {}),
            /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Rep" }),
            /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Currency" }),
            /* @__PURE__ */ jsx(Table.HeaderCell, { className: "text-right", children: "Payable" }),
            /* @__PURE__ */ jsx(Table.HeaderCell, { className: "text-right", children: "Pay" }),
            /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Note" })
          ] }) }),
          /* @__PURE__ */ jsx(Table.Body, { children: data.rows.map((row) => {
            const key = rowKey(row);
            const payable = row.payable > 0;
            const notes = rowNote(row, data.minimums);
            return /* @__PURE__ */ jsxs(Table.Row, { children: [
              /* @__PURE__ */ jsx(Table.Cell, { children: payable && /* @__PURE__ */ jsx(
                Checkbox,
                {
                  checked: selected[key] ?? false,
                  onCheckedChange: (checked) => setSelected({ ...selected, [key]: checked === true })
                }
              ) }),
              /* @__PURE__ */ jsx(Table.Cell, { children: /* @__PURE__ */ jsx(
                Link,
                {
                  to: `/sales-reps/${row.sales_rep_id}`,
                  className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
                  children: row.sales_rep_name
                }
              ) }),
              /* @__PURE__ */ jsx(Table.Cell, { children: row.currency_code.toUpperCase() }),
              /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: formatMoney(row.payable, row.currency_code) }),
              /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: payable ? /* @__PURE__ */ jsx("div", { className: "ml-auto w-32", children: /* @__PURE__ */ jsx(
                Input,
                {
                  size: "small",
                  type: "number",
                  min: 0,
                  step: currencyStep(row.currency_code),
                  "aria-label": `Amount to pay ${row.sales_rep_name} in ${row.currency_code.toUpperCase()}`,
                  value: amounts[key] ?? "",
                  onChange: (e) => setAmounts({ ...amounts, [key]: e.target.value })
                }
              ) }) : "-" }),
              /* @__PURE__ */ jsx(Table.Cell, { children: notes.map((note) => /* @__PURE__ */ jsx(
                Text,
                {
                  size: "small",
                  leading: "compact",
                  className: "text-ui-fg-subtle",
                  children: note
                },
                note
              )) })
            ] }, key);
          }) })
        ] }) }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-start justify-between gap-3 px-6 py-4 md:flex-row md:items-center", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
            /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Selected" }),
            totals.length === 0 ? /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", children: "nothing" }) : totals.map(([currency, total]) => /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: "blue", children: formatMoney(total, currency) }, currency)),
            /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
              "in ",
              items.length,
              " ",
              items.length === 1 ? "transfer" : "transfers"
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-2", children: [
            /* @__PURE__ */ jsxs(
              Button,
              {
                size: "small",
                variant: "secondary",
                disabled: items.length === 0,
                onClick: exportCsv,
                children: [
                  /* @__PURE__ */ jsx(ArrowDownTray, {}),
                  "Export CSV"
                ]
              }
            ),
            /* @__PURE__ */ jsx(
              Button,
              {
                size: "small",
                disabled: items.length === 0,
                onClick: () => {
                  setPaidAt(today());
                  setReference(
                    data.approved_through ? `${data.approved_through} run` : ""
                  );
                  setOpen(true);
                },
                children: "Mark selected as paid"
              }
            )
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx(FxRatesSection, {}),
    /* @__PURE__ */ jsx(Drawer, { open, onOpenChange: setOpen, children: /* @__PURE__ */ jsxs(Drawer.Content, { children: [
      /* @__PURE__ */ jsx(Drawer.Header, { children: /* @__PURE__ */ jsx(Drawer.Title, { children: "Mark as paid" }) }),
      /* @__PURE__ */ jsxs(Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
        /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle", children: [
          "Records ",
          items.length,
          " ",
          items.length === 1 ? "payout" : "payouts",
          " together, one per rep and currency. Do this after you have made the transfers. A payout that differs from what is payable leaves the rest due, or becomes an advance."
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "run-date", children: "Paid on" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "run-date",
              type: "date",
              value: paidAt,
              onChange: (e) => setPaidAt(e.target.value)
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "run-reference", children: "Reference (optional)" }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "run-reference",
              value: reference,
              onChange: (e) => setReference(e.target.value)
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs(Drawer.Footer, { children: [
        /* @__PURE__ */ jsx(Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", disabled: record.isPending, children: "Cancel" }) }),
        /* @__PURE__ */ jsx(Button, { size: "small", isLoading: record.isPending, onClick: () => record.mutate(), children: "Record payouts" })
      ] })
    ] }) })
  ] });
};
const config$1 = defineRouteConfig({
  label: "Payment run"
});
const CommissionReportPage = () => {
  const [period, setPeriod] = useState(currentPeriod());
  const { data, isLoading } = useQuery({
    queryKey: ["commission-report", period],
    queryFn: () => sdk.client.fetch(
      "/admin/sales-commission/report",
      { query: { period } }
    )
  });
  const exportCsv = () => downloadFile(
    `/admin/sales-commission/report?period=${period}&format=csv`,
    "text/csv",
    `commission-report-${period}.csv`
  ).catch((error) => toast.error(errorMessage(error)));
  return /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-start justify-between gap-2 px-6 py-4 md:flex-row md:items-center", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-1", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-2", children: [
          /* @__PURE__ */ jsx(Heading, { children: "Commission report" }),
          data && /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: data.approved ? "green" : "orange", children: data.approved ? "Approved" : "Open" })
        ] }),
        /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle", children: [
          "What each rep was owed at the start of ",
          monthLabel(period),
          ", what the month earned and paid, and what is owed at the end. Commission counts in the month the order was paid. Totals are per currency."
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-2", children: [
        /* @__PURE__ */ jsx(PeriodSelect, { value: period, onChange: setPeriod }),
        /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", asChild: true, children: /* @__PURE__ */ jsx(Link, { to: "/sales-reps/payment-run", children: "Payment run" }) }),
        /* @__PURE__ */ jsxs(Button, { size: "small", variant: "secondary", onClick: exportCsv, children: [
          /* @__PURE__ */ jsx(ArrowDownTray, {}),
          "Export CSV"
        ] })
      ] })
    ] }),
    isLoading || !data ? /* @__PURE__ */ jsx(Loading, {}) : data.rows.length === 0 ? /* @__PURE__ */ jsx("div", { className: "px-6 py-4", children: /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "No commission recorded for this month." }) }) : /* @__PURE__ */ jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs(Table, { children: [
      /* @__PURE__ */ jsx(Table.Header, { children: /* @__PURE__ */ jsxs(Table.Row, { children: [
        /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Sales rep" }),
        /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Currency" }),
        /* @__PURE__ */ jsx(Table.HeaderCell, { className: "text-right", children: "Owed at start" }),
        /* @__PURE__ */ jsx(Table.HeaderCell, { className: "text-right", children: "Direct" }),
        /* @__PURE__ */ jsx(Table.HeaderCell, { className: "text-right", children: "Level 2" }),
        /* @__PURE__ */ jsx(Table.HeaderCell, { className: "text-right", children: "Adjustments" }),
        /* @__PURE__ */ jsx(Table.HeaderCell, { className: "text-right", children: "Earned" }),
        /* @__PURE__ */ jsx(Table.HeaderCell, { className: "text-right", children: "Paid" }),
        /* @__PURE__ */ jsx(Table.HeaderCell, { className: "text-right", children: "Owed at end" }),
        /* @__PURE__ */ jsx(Table.HeaderCell, { children: "Status" })
      ] }) }),
      /* @__PURE__ */ jsx(Table.Body, { children: data.rows.map((row) => {
        const money = (amount) => formatMoney(amount, row.currency_code);
        const badge = STATUS_BADGES[row.status];
        return /* @__PURE__ */ jsxs(Table.Row, { children: [
          /* @__PURE__ */ jsx(Table.Cell, { children: /* @__PURE__ */ jsx(
            Link,
            {
              to: `/sales-reps/${row.sales_rep_id}`,
              className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
              children: row.sales_rep_name
            }
          ) }),
          /* @__PURE__ */ jsx(Table.Cell, { children: row.currency_code.toUpperCase() }),
          /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: money(row.opening) }),
          /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: money(row.direct) }),
          /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: money(row.level2) }),
          /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: money(row.adjustments) }),
          /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: money(row.total) }),
          /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: money(row.paid) }),
          /* @__PURE__ */ jsx(Table.Cell, { className: "text-right", children: money(row.closing) }),
          /* @__PURE__ */ jsx(Table.Cell, { children: /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: badge.color, children: badge.label }) })
        ] }, `${row.sales_rep_id}-${row.currency_code}`);
      }) })
    ] }) })
  ] });
};
const config = defineRouteConfig({
  label: "Commission report"
});
const DeclineApplicationDrawer = ({
  applicationId,
  name,
  open,
  onOpenChange
}) => {
  const queryClient = useQueryClient();
  const [reason, setReason] = useState("");
  const decline = useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-commission/applications/${applicationId}/decline`, {
      method: "POST",
      body: { reason: reason.trim() }
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["applications"] });
      queryClient.invalidateQueries({ queryKey: ["application", applicationId] });
      toast.success("Application declined");
      setReason("");
      onOpenChange(false);
    },
    onError: (error) => toast.error(errorMessage(error))
  });
  return /* @__PURE__ */ jsx(Drawer, { open, onOpenChange, children: /* @__PURE__ */ jsxs(Drawer.Content, { children: [
    /* @__PURE__ */ jsx(Drawer.Header, { children: /* @__PURE__ */ jsxs(Drawer.Title, { children: [
      "Decline ",
      name
    ] }) }),
    /* @__PURE__ */ jsxs(Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
      /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle", children: [
        name,
        " and the rep who invited them are emailed that the application was not approved. They are not told why; your reason stays here for your records."
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
        /* @__PURE__ */ jsx(Label, { htmlFor: "decline-reason", children: "Reason (only you see it)" }),
        /* @__PURE__ */ jsx(
          Textarea,
          {
            id: "decline-reason",
            rows: 4,
            maxLength: 500,
            value: reason,
            onChange: (e) => setReason(e.target.value)
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs(Drawer.Footer, { children: [
      /* @__PURE__ */ jsx(Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsx(Button, { size: "small", variant: "secondary", disabled: decline.isPending, children: "Cancel" }) }),
      /* @__PURE__ */ jsx(
        Button,
        {
          size: "small",
          variant: "danger",
          disabled: !reason.trim(),
          isLoading: decline.isPending,
          onClick: () => decline.mutate(),
          children: "Decline application"
        }
      )
    ] })
  ] }) });
};
const CONTRACT_TYPES = ["application/pdf", "image/jpeg", "image/png"];
const MAX_CONTRACT_BYTES = 10 * 1024 * 1024;
const DURATIONS = [12, 24, 36];
const Field = ({ label, children }) => /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-[10rem_1fr] items-baseline gap-x-4 py-1.5", children: [
  /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: label }),
  /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", children: children || "-" })
] });
const ApplicationPage = () => {
  const { id = "" } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const fileInput = useRef(null);
  const [rate, setRate] = useState("");
  const [months, setMonths] = useState("none");
  const [currency, setCurrency] = useState("as_earned");
  const [clientRate, setClientRate] = useState("");
  const [contract, setContract] = useState(null);
  const [declining, setDeclining] = useState(false);
  const { data, isLoading, error } = useQuery({
    queryKey: ["application", id],
    queryFn: () => sdk.client.fetch(`/admin/sales-commission/applications/${id}`),
    enabled: !!id
  });
  const loaded = data == null ? void 0 : data.application.id;
  useEffect(() => {
    if (!data) return;
    setRate(String(data.defaults.level2_rate));
    setMonths(data.defaults.level2_months ? String(data.defaults.level2_months) : "none");
    const asked = data.application.requested_currency_code;
    setCurrency(asked === "eur" || asked === "huf" ? asked : "as_earned");
  }, [loaded]);
  const approve = useMutation({
    mutationFn: async () => sdk.client.fetch(
      `/admin/sales-commission/applications/${id}/approve`,
      {
        method: "POST",
        body: {
          level2_rate: Number(rate),
          level2_months: months === "none" ? null : Number(months),
          payout_currency_code: currency === "as_earned" ? null : currency,
          client_rate: parseClientRate(clientRate),
          contract: contract ? {
            file_name: contract.name,
            mime_type: contract.type,
            content_base64: await readAsBase64(contract)
          } : null
        }
      }
    ),
    onSuccess: ({ sales_rep }) => {
      for (const key of ["applications", "application", "sales-reps", "rep-balances"]) {
        queryClient.invalidateQueries({ queryKey: [key] });
      }
      toast.success("Rep created. A welcome email with a link to set a password is on its way");
      navigate(`/sales-reps/${sales_rep.id}`);
    },
    onError: (e) => toast.error(errorMessage(e))
  });
  const onFile = (file) => {
    if (!file) return;
    if (!CONTRACT_TYPES.includes(file.type)) {
      return toast.error("Upload a PDF, JPEG or PNG file");
    }
    if (file.size > MAX_CONTRACT_BYTES) {
      return toast.error("Contracts can be at most 10 MB");
    }
    setContract(file);
  };
  if (isLoading) {
    return /* @__PURE__ */ jsx(Container, { className: "p-0", children: /* @__PURE__ */ jsx(Loading, {}) });
  }
  if (error || !data) {
    return /* @__PURE__ */ jsx(Container, { children: /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: error ? errorMessage(error) : "Application not found" }) });
  }
  const { application, recruiter, defaults, blockers } = data;
  const recruiterName = (recruiter == null ? void 0 : recruiter.name) ?? "The recruiter";
  const badge = applicationBadge(application);
  const waiting = application.status === "applied";
  const rateValid = rate !== "" && Number(rate) >= 0 && Number(rate) <= 100;
  const durations = [.../* @__PURE__ */ new Set([...DURATIONS, ...defaults.level2_months ? [defaults.level2_months] : []])].sort(
    (a, b) => a - b
  );
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-3", children: [
    /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
      /* @__PURE__ */ jsx("div", { className: "flex flex-col items-start justify-between gap-2 px-6 py-4 md:flex-row md:items-center", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-1", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-2", children: [
          /* @__PURE__ */ jsx(Heading, { children: application.name }),
          /* @__PURE__ */ jsx(Badge, { size: "2xsmall", color: badge.color, children: badge.label })
        ] }),
        /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: /* @__PURE__ */ jsx(
          Link,
          {
            to: "/sales-reps/applications",
            className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
            children: "Applications"
          }
        ) })
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "px-6 py-4", children: [
        /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", weight: "plus", className: "mb-2", children: "Application" }),
        /* @__PURE__ */ jsx(Field, { label: "Email", children: application.email }),
        /* @__PURE__ */ jsx(Field, { label: "Phone", children: application.phone }),
        /* @__PURE__ */ jsx(Field, { label: "Company or tax number", children: application.company }),
        /* @__PURE__ */ jsx(Field, { label: "Applied", children: application.applied_at ? formatDate(application.applied_at) : "Has not applied yet" }),
        /* @__PURE__ */ jsx(Field, { label: "Recruited by", children: application.recruiter ? /* @__PURE__ */ jsx(
          Link,
          {
            to: `/sales-reps/${application.recruiter.id}`,
            className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
            children: application.recruiter.name
          }
        ) : null }),
        application.note && /* @__PURE__ */ jsx(Field, { label: "Note from the recruiter", children: application.note }),
        application.status === "invited" && /* @__PURE__ */ jsx(Field, { label: "Link", children: application.expired ? `Ended ${formatDate(application.expires_at)}` : `Works until ${formatDate(application.expires_at)}` })
      ] })
    ] }),
    waiting && /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
      /* @__PURE__ */ jsxs("div", { className: "px-6 py-4", children: [
        /* @__PURE__ */ jsx(Heading, { level: "h2", children: "Terms" }),
        /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle", children: [
          "Level 2 is what ",
          recruiterName,
          " earns on ",
          application.name,
          "'s clients' net sales, on top of ",
          application.name,
          "'s own commission."
        ] })
      ] }),
      blockers.length > 0 && /* @__PURE__ */ jsx("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: blockers.map((blocker) => /* @__PURE__ */ jsx(Alert, { variant: "error", children: blocker }, blocker)) }),
      /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-4 px-6 py-4 md:grid-cols-2", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxs(Label, { htmlFor: "level2-rate", children: [
            "Level 2 for ",
            recruiterName,
            " (%)"
          ] }),
          /* @__PURE__ */ jsx(
            Input,
            {
              id: "level2-rate",
              type: "number",
              min: 0,
              max: 100,
              step: "0.01",
              value: rate,
              onChange: (e) => setRate(e.target.value)
            }
          ),
          String(defaults.level2_rate) === rate && /* @__PURE__ */ jsx(Text, { size: "xsmall", leading: "compact", className: "text-ui-fg-muted", children: "Default from the settings" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Level 2 lasts" }),
          /* @__PURE__ */ jsxs(Select, { value: months, onValueChange: setMonths, children: [
            /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, {}) }),
            /* @__PURE__ */ jsxs(Select.Content, { children: [
              /* @__PURE__ */ jsx(Select.Item, { value: "none", children: level2Duration(null) }),
              durations.map((n) => /* @__PURE__ */ jsx(Select.Item, { value: String(n), children: level2Duration(n) }, n))
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxs(Label, { children: [
            "Paid in",
            application.requested_currency_code ? ` (requested: ${application.requested_currency_code.toUpperCase()})` : ""
          ] }),
          /* @__PURE__ */ jsxs(Select, { value: currency, onValueChange: setCurrency, children: [
            /* @__PURE__ */ jsx(Select.Trigger, { children: /* @__PURE__ */ jsx(Select.Value, {}) }),
            /* @__PURE__ */ jsxs(Select.Content, { children: [
              /* @__PURE__ */ jsx(Select.Item, { value: "as_earned", children: "As earned, in the order's currency" }),
              /* @__PURE__ */ jsx(Select.Item, { value: "eur", children: "EUR" }),
              /* @__PURE__ */ jsx(Select.Item, { value: "huf", children: "HUF" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx(
          ClientRateField,
          {
            id: "client-rate",
            value: clientRate,
            onChange: setClientRate
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsx(Label, { children: "Contract (optional)" }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-2", children: [
            /* @__PURE__ */ jsxs(
              Button,
              {
                size: "small",
                variant: "secondary",
                type: "button",
                onClick: () => {
                  var _a;
                  return (_a = fileInput.current) == null ? void 0 : _a.click();
                },
                children: [
                  /* @__PURE__ */ jsx(ArrowUpTray, {}),
                  contract ? "Change file" : "Upload the signed PDF"
                ]
              }
            ),
            contract && /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", className: "truncate", children: [
              contract.name,
              " · ",
              formatSize(contract.size)
            ] }),
            /* @__PURE__ */ jsx(
              "input",
              {
                ref: fileInput,
                type: "file",
                accept: CONTRACT_TYPES.join(","),
                className: "hidden",
                onChange: (e) => {
                  var _a;
                  onFile((_a = e.target.files) == null ? void 0 : _a[0]);
                  e.target.value = "";
                }
              }
            )
          ] }),
          /* @__PURE__ */ jsx(Text, { size: "xsmall", leading: "compact", className: "text-ui-fg-muted", children: "You can also add it later on the rep's page." })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-start justify-between gap-3 px-6 py-4 md:flex-row md:items-center", children: [
        /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle md:max-w-md", children: [
          "Approving creates the rep, links ",
          recruiterName,
          " as their recruiter from today, and emails them a link to set a password and sign in to the sales portal."
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-x-2", children: [
          /* @__PURE__ */ jsx(
            Button,
            {
              size: "small",
              variant: "secondary",
              disabled: approve.isPending,
              onClick: () => setDeclining(true),
              children: "Decline…"
            }
          ),
          /* @__PURE__ */ jsx(
            Button,
            {
              size: "small",
              disabled: !rateValid || !!clientRateError(clientRate) || blockers.length > 0,
              isLoading: approve.isPending,
              onClick: () => approve.mutate(),
              children: "Approve and create rep"
            }
          )
        ] })
      ] })
    ] }),
    application.status === "approved" && /* @__PURE__ */ jsxs(Container, { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", weight: "plus", children: [
        "Approved ",
        application.decided_at ? formatDate(application.decided_at) : ""
      ] }),
      application.sales_rep_id && /* @__PURE__ */ jsx(Text, { size: "small", leading: "compact", children: /* @__PURE__ */ jsx(
        Link,
        {
          to: `/sales-reps/${application.sales_rep_id}`,
          className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
          children: "Open the rep"
        }
      ) })
    ] }),
    application.status === "declined" && /* @__PURE__ */ jsxs(Container, { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", weight: "plus", children: [
        "Declined ",
        application.decided_at ? formatDate(application.decided_at) : ""
      ] }),
      application.decision_reason && /* @__PURE__ */ jsxs(Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
        "Your reason: ",
        application.decision_reason
      ] })
    ] }),
    (application.status === "invited" || application.status === "canceled") && /* @__PURE__ */ jsx(Container, { className: "px-6 py-4", children: /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: application.status === "canceled" ? "The rep withdrew this invitation." : "This person has not applied yet. You will get an email when they do." }) }),
    /* @__PURE__ */ jsx(
      DeclineApplicationDrawer,
      {
        applicationId: application.id,
        name: application.name,
        open: declining,
        onOpenChange: setDeclining
      }
    )
  ] });
};
const i18nTranslations0 = {};
const widgetModule = { widgets: [
  {
    Component: CustomerSalesRepWidget,
    zone: ["customer.details.side.after"],
    widgetId: "Widget-cf9f"
  }
] };
const routeModule = {
  routes: [
    {
      Component: SalesRepsPage,
      path: "/sales-reps",
      handle: { label: config$3.label, translationNs: config$3.translationNs }
    },
    {
      Component: SalesRepDetailPage,
      path: "/sales-reps/:id"
    },
    {
      Component: ApplicationsPage,
      path: "/sales-reps/applications",
      handle: { label: config$2.label, translationNs: config$2.translationNs }
    },
    {
      Component: PaymentRunPage,
      path: "/sales-reps/payment-run",
      handle: { label: config$1.label, translationNs: config$1.translationNs }
    },
    {
      Component: CommissionReportPage,
      path: "/sales-reps/report",
      handle: { label: config.label, translationNs: config.translationNs }
    },
    {
      Component: ApplicationPage,
      path: "/sales-reps/applications/:id"
    }
  ]
};
const menuItemModule = {
  menuItems: [
    {
      label: config$3.label,
      icon: config$3.icon,
      path: "/sales-reps",
      nested: void 0,
      rank: void 0,
      translationNs: void 0
    },
    {
      label: config$2.label,
      icon: void 0,
      path: "/sales-reps/applications",
      nested: void 0,
      rank: void 0,
      translationNs: void 0
    },
    {
      label: config$1.label,
      icon: void 0,
      path: "/sales-reps/payment-run",
      nested: void 0,
      rank: void 0,
      translationNs: void 0
    },
    {
      label: config.label,
      icon: void 0,
      path: "/sales-reps/report",
      nested: void 0,
      rank: void 0,
      translationNs: void 0
    }
  ]
};
const formModule = { customFields: {} };
const displayModule = {
  displays: {}
};
const i18nModule = { resources: i18nTranslations0 };
const cellRendererModule = {};
const layoutModule = { layouts: [] };
const plugin = {
  widgetModule,
  routeModule,
  menuItemModule,
  formModule,
  displayModule,
  i18nModule,
  cellRendererModule,
  layoutModule
};
export {
  plugin as default
};
