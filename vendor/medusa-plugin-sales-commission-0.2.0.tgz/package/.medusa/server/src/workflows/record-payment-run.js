"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.recordPaymentRunWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const record_payment_run_1 = require("./steps/record-payment-run");
exports.recordPaymentRunWorkflow = (0, workflows_sdk_1.createWorkflow)("record-payment-run", function (input) {
    return new workflows_sdk_1.WorkflowResponse((0, record_payment_run_1.recordPaymentRunStep)(input));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVjb3JkLXBheW1lbnQtcnVuLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9yZWNvcmQtcGF5bWVudC1ydW4udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscUVBRzBDO0FBQzFDLG1FQUdtQztBQUV0QixRQUFBLHdCQUF3QixHQUFHLElBQUEsOEJBQWMsRUFDcEQsb0JBQW9CLEVBQ3BCLFVBQVUsS0FBZ0M7SUFDeEMsT0FBTyxJQUFJLGdDQUFnQixDQUFDLElBQUEseUNBQW9CLEVBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQTtBQUMxRCxDQUFDLENBQ0YsQ0FBQSJ9