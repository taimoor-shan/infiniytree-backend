"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.voidOrderCommissionStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const period_1 = require("../../lib/period");
const sales_commission_1 = require("../../modules/sales-commission");
/**
 * Marks the order's live entries void. They stay on record; the report
 * reverses them in the month of the void if that is a later month.
 */
exports.voidOrderCommissionStep = (0, workflows_sdk_1.createStep)("void-order-commission", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const live = await service.listCommissionEntries({
        order_id: input.order_id,
        voided_at: null,
    });
    if (!live.length) {
        return new workflows_sdk_1.StepResponse([], []);
    }
    const voidPeriod = (0, period_1.toPeriod)(input.voided_at, service.getOptions().timezone);
    const voided = await service.updateCommissionEntries(live.map((entry) => ({
        id: entry.id,
        voided_at: input.voided_at,
        void_period: voidPeriod,
        void_reason: input.reason,
    })));
    return new workflows_sdk_1.StepResponse(voided, live.map((entry) => entry.id));
}, async (entryIds, { container }) => {
    if (!entryIds?.length) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.updateCommissionEntries(entryIds.map((id) => ({
        id,
        voided_at: null,
        void_period: null,
        void_reason: null,
    })));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidm9pZC1vcmRlci1jb21taXNzaW9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy92b2lkLW9yZGVyLWNvbW1pc3Npb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscUVBQTRFO0FBQzVFLDZDQUEyQztBQUMzQyxxRUFBd0U7QUFXeEU7OztHQUdHO0FBQ1UsUUFBQSx1QkFBdUIsR0FBRyxJQUFBLDBCQUFVLEVBQy9DLHVCQUF1QixFQUN2QixLQUFLLEVBQUUsS0FBbUMsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDM0QsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxJQUFJLEdBQUcsTUFBTSxPQUFPLENBQUMscUJBQXFCLENBQUM7UUFDL0MsUUFBUSxFQUFFLEtBQUssQ0FBQyxRQUFRO1FBQ3hCLFNBQVMsRUFBRSxJQUFJO0tBQ2hCLENBQUMsQ0FBQTtJQUNGLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDakIsT0FBTyxJQUFJLDRCQUFZLENBQUMsRUFBRSxFQUFFLEVBQWMsQ0FBQyxDQUFBO0lBQzdDLENBQUM7SUFFRCxNQUFNLFVBQVUsR0FBRyxJQUFBLGlCQUFRLEVBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsVUFBVSxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUE7SUFDM0UsTUFBTSxNQUFNLEdBQUcsTUFBTSxPQUFPLENBQUMsdUJBQXVCLENBQ2xELElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDbkIsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFO1FBQ1osU0FBUyxFQUFFLEtBQUssQ0FBQyxTQUFTO1FBQzFCLFdBQVcsRUFBRSxVQUFVO1FBQ3ZCLFdBQVcsRUFBRSxLQUFLLENBQUMsTUFBTTtLQUMxQixDQUFDLENBQUMsQ0FDSixDQUFBO0lBRUQsT0FBTyxJQUFJLDRCQUFZLENBQ3JCLE1BQU0sRUFDTixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQzlCLENBQUE7QUFDSCxDQUFDLEVBQ0QsS0FBSyxFQUFFLFFBQVEsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDaEMsSUFBSSxDQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUUsQ0FBQztRQUN0QixPQUFNO0lBQ1IsQ0FBQztJQUNELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sT0FBTyxDQUFDLHVCQUF1QixDQUNuQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ3BCLEVBQUU7UUFDRixTQUFTLEVBQUUsSUFBSTtRQUNmLFdBQVcsRUFBRSxJQUFJO1FBQ2pCLFdBQVcsRUFBRSxJQUFJO0tBQ2xCLENBQUMsQ0FBQyxDQUNKLENBQUE7QUFDSCxDQUFDLENBQ0YsQ0FBQSJ9