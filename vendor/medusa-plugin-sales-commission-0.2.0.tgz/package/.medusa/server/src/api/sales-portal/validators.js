"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PortalResendInvite = exports.PortalInviteRecruit = exports.PortalPageParams = exports.PortalPeriodParams = void 0;
const zod_1 = require("@medusajs/framework/zod");
exports.PortalPeriodParams = zod_1.z.object({
    period: zod_1.z
        .string()
        .regex(/^\d{4}-(0[1-9]|1[0-2])$/, "Use a month in the form YYYY-MM")
        .optional(),
});
exports.PortalPageParams = zod_1.z.object({
    limit: zod_1.z.coerce.number().int().min(1).max(100).default(50),
    offset: zod_1.z.coerce.number().int().min(0).default(0),
});
const email = zod_1.z.string().trim().pipe(zod_1.z.email());
/**
 * A rep's invitation of someone to join. `locale` is the portal's language,
 * for the emails; one we don't recognise is ignored rather than refused.
 */
exports.PortalInviteRecruit = zod_1.z.object({
    name: zod_1.z.string().trim().min(1).max(120),
    email,
    note: zod_1.z.string().trim().max(500).nullish(),
    locale: zod_1.z.string().max(64).nullish(),
});
exports.PortalResendInvite = zod_1.z.object({
    locale: zod_1.z.string().max(64).nullish(),
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdG9ycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9hcGkvc2FsZXMtcG9ydGFsL3ZhbGlkYXRvcnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsaURBQTJDO0FBRTlCLFFBQUEsa0JBQWtCLEdBQUcsT0FBQyxDQUFDLE1BQU0sQ0FBQztJQUN6QyxNQUFNLEVBQUUsT0FBQztTQUNOLE1BQU0sRUFBRTtTQUNSLEtBQUssQ0FBQyx5QkFBeUIsRUFBRSxpQ0FBaUMsQ0FBQztTQUNuRSxRQUFRLEVBQUU7Q0FDZCxDQUFDLENBQUE7QUFFVyxRQUFBLGdCQUFnQixHQUFHLE9BQUMsQ0FBQyxNQUFNLENBQUM7SUFDdkMsS0FBSyxFQUFFLE9BQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO0lBQzFELE1BQU0sRUFBRSxPQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0NBQ2xELENBQUMsQ0FBQTtBQUdGLE1BQU0sS0FBSyxHQUFHLE9BQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsT0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUE7QUFFL0M7OztHQUdHO0FBQ1UsUUFBQSxtQkFBbUIsR0FBRyxPQUFDLENBQUMsTUFBTSxDQUFDO0lBQzFDLElBQUksRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDdkMsS0FBSztJQUNMLElBQUksRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRTtJQUMxQyxNQUFNLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLEVBQUU7Q0FDckMsQ0FBQyxDQUFBO0FBR1csUUFBQSxrQkFBa0IsR0FBRyxPQUFDLENBQUMsTUFBTSxDQUFDO0lBQ3pDLE1BQU0sRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sRUFBRTtDQUNyQyxDQUFDLENBQUEifQ==