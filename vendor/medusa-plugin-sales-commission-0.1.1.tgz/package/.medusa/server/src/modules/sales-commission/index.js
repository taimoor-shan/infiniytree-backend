"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SALES_COMMISSION_MODULE = void 0;
const utils_1 = require("@medusajs/framework/utils");
const service_1 = __importDefault(require("./service"));
exports.SALES_COMMISSION_MODULE = "salesCommission";
exports.default = (0, utils_1.Module)(exports.SALES_COMMISSION_MODULE, {
    service: service_1.default,
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9zYWxlcy1jb21taXNzaW9uL2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBLHFEQUFrRDtBQUNsRCx3REFBb0Q7QUFFdkMsUUFBQSx1QkFBdUIsR0FBRyxpQkFBaUIsQ0FBQTtBQUV4RCxrQkFBZSxJQUFBLGNBQU0sRUFBQywrQkFBdUIsRUFBRTtJQUM3QyxPQUFPLEVBQUUsaUJBQTRCO0NBQ3RDLENBQUMsQ0FBQSJ9