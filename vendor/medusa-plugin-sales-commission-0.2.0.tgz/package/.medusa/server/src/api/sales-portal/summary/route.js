"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const report_1 = require("../../../lib/report");
const period_activity_1 = require("../../../utils/period-activity");
const helpers_1 = require("../../admin/sales-commission/helpers");
const middlewares_1 = require("../middlewares");
/** The month's totals per currency: direct, Level 2, adjustments, earned, paid, balance. */
async function GET(req, res) {
    const { period } = (0, helpers_1.requestedPeriod)(req);
    const history = await (0, period_activity_1.loadRepHistory)(req.scope, (0, middlewares_1.portalRep)(req).id);
    res.json({ period, totals: (0, report_1.monthSummary)((0, report_1.allLines)(history), period) });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLXBvcnRhbC9zdW1tYXJ5L3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBT0Esa0JBS0M7QUFYRCxnREFBNEQ7QUFDNUQsb0VBQStEO0FBQy9ELGtFQUFzRTtBQUN0RSxnREFBMEM7QUFFMUMsNEZBQTRGO0FBQ3JGLEtBQUssVUFBVSxHQUFHLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUMvRCxNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsSUFBQSx5QkFBZSxFQUFDLEdBQUcsQ0FBQyxDQUFBO0lBQ3ZDLE1BQU0sT0FBTyxHQUFHLE1BQU0sSUFBQSxnQ0FBYyxFQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsSUFBQSx1QkFBUyxFQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBRWxFLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUEscUJBQVksRUFBQyxJQUFBLGlCQUFRLEVBQUMsT0FBTyxDQUFDLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQ3ZFLENBQUMifQ==