"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.orderLockKey = exports.withLock = void 0;
const utils_1 = require("@medusajs/framework/utils");
/**
 * Runs `job` while holding a lock on `key`, so two events about the same order
 * (two refunds in a row, a refund and a cancellation) are handled one after
 * the other instead of both reading the same state. Without a locking module
 * the job just runs.
 */
const withLock = async (container, key, job) => {
    const locking = container.resolve(utils_1.Modules.LOCKING, { allowUnregistered: true });
    return locking ? locking.execute(key, job, { timeout: 15 }) : job();
};
exports.withLock = withLock;
/** What orders are locked by while their commission changes. */
const orderLockKey = (orderId) => `sales-commission:order:${orderId}`;
exports.orderLockKey = orderLockKey;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9ja3MuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvdXRpbHMvbG9ja3MudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQ0EscURBQW1EO0FBRW5EOzs7OztHQUtHO0FBQ0ksTUFBTSxRQUFRLEdBQUcsS0FBSyxFQUMzQixTQUEwQixFQUMxQixHQUFXLEVBQ1gsR0FBcUIsRUFDVCxFQUFFO0lBQ2QsTUFBTSxPQUFPLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsT0FBTyxFQUFFLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtJQUUvRSxPQUFPLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFBO0FBQ3JFLENBQUMsQ0FBQTtBQVJZLFFBQUEsUUFBUSxZQVFwQjtBQUVELGdFQUFnRTtBQUN6RCxNQUFNLFlBQVksR0FBRyxDQUFDLE9BQWUsRUFBRSxFQUFFLENBQUMsMEJBQTBCLE9BQU8sRUFBRSxDQUFBO0FBQXZFLFFBQUEsWUFBWSxnQkFBMkQifQ==