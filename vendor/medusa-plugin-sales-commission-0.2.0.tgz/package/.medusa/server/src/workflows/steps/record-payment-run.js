"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.recordPaymentRunStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const report_1 = require("../../lib/report");
const sales_commission_1 = require("../../modules/sales-commission");
const period_activity_1 = require("../../utils/period-activity");
const payouts_1 = require("../../utils/payouts");
const invalid = (message) => new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, message);
/**
 * Records the transfers of one payment run together, one payout per rep and
 * currency, all or nothing. Each keeps what was payable when it was made.
 */
exports.recordPaymentRunStep = (0, workflows_sdk_1.createStep)("record-payment-run", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    if (!input.items.length) {
        throw invalid("Choose at least one payout");
    }
    const keys = input.items.map((item) => `${item.sales_rep_id}:${item.currency_code.toLowerCase()}`);
    if (new Set(keys).size !== keys.length) {
        throw invalid("A payment run has one payout per rep and currency");
    }
    const [history, approvedThrough, reps] = await Promise.all([
        (0, period_activity_1.loadAllHistory)(container),
        (0, period_activity_1.loadApprovedThrough)(container),
        service.listSalesReps({ id: input.items.map((item) => item.sales_rep_id) }),
    ]);
    const lines = (0, report_1.allLines)(history);
    const repById = new Map(reps.map((rep) => [rep.id, rep]));
    const runId = (0, utils_1.generateEntityId)(undefined, "scrun");
    const drafts = input.items.map((item) => {
        const rep = repById.get(item.sales_rep_id);
        if (!rep) {
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, `Sales rep ${item.sales_rep_id} was not found`);
        }
        return (0, payouts_1.draftPayout)({
            rep,
            input: {
                ...item,
                paid_at: input.paid_at,
                reference: input.reference,
                created_by: input.created_by,
                run_id: runId,
            },
            lines,
            approvedThrough,
            timezone: service.getOptions().timezone,
        }).payout;
    });
    const payouts = await service.createCommissionPayouts(drafts);
    return new workflows_sdk_1.StepResponse({ run_id: runId, payouts }, payouts.map((payout) => payout.id));
}, async (payoutIds, { container }) => {
    if (!payoutIds?.length) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.deleteCommissionPayouts(payoutIds);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVjb3JkLXBheW1lbnQtcnVuLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9yZWNvcmQtcGF5bWVudC1ydW4udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBR2tDO0FBQ2xDLHFFQUE0RTtBQUM1RSw2Q0FBMkM7QUFDM0MscUVBQXdFO0FBRXhFLGlFQUFpRjtBQUNqRixpREFBaUQ7QUFTakQsTUFBTSxPQUFPLEdBQUcsQ0FBQyxPQUFlLEVBQUUsRUFBRSxDQUNsQyxJQUFJLG1CQUFXLENBQUMsbUJBQVcsQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxDQUFBO0FBRTFEOzs7R0FHRztBQUNVLFFBQUEsb0JBQW9CLEdBQUcsSUFBQSwwQkFBVSxFQUM1QyxvQkFBb0IsRUFDcEIsS0FBSyxFQUFFLEtBQWdDLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQ3hELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3hCLE1BQU0sT0FBTyxDQUFDLDRCQUE0QixDQUFDLENBQUE7SUFDN0MsQ0FBQztJQUNELE1BQU0sSUFBSSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUMxQixDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FDckUsQ0FBQTtJQUNELElBQUksSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUN2QyxNQUFNLE9BQU8sQ0FBQyxtREFBbUQsQ0FBQyxDQUFBO0lBQ3BFLENBQUM7SUFFRCxNQUFNLENBQUMsT0FBTyxFQUFFLGVBQWUsRUFBRSxJQUFJLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7UUFDekQsSUFBQSxnQ0FBYyxFQUFDLFNBQVMsQ0FBQztRQUN6QixJQUFBLHFDQUFtQixFQUFDLFNBQVMsQ0FBQztRQUM5QixPQUFPLENBQUMsYUFBYSxDQUFDLEVBQUUsRUFBRSxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztLQUM1RSxDQUFDLENBQUE7SUFDRixNQUFNLEtBQUssR0FBRyxJQUFBLGlCQUFRLEVBQUMsT0FBTyxDQUFDLENBQUE7SUFDL0IsTUFBTSxPQUFPLEdBQUcsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUN6RCxNQUFNLEtBQUssR0FBRyxJQUFBLHdCQUFnQixFQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQTtJQUVsRCxNQUFNLE1BQU0sR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFO1FBQ3RDLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFBO1FBQzFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUNULE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQzNCLGFBQWEsSUFBSSxDQUFDLFlBQVksZ0JBQWdCLENBQy9DLENBQUE7UUFDSCxDQUFDO1FBRUQsT0FBTyxJQUFBLHFCQUFXLEVBQUM7WUFDakIsR0FBRztZQUNILEtBQUssRUFBRTtnQkFDTCxHQUFHLElBQUk7Z0JBQ1AsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO2dCQUN0QixTQUFTLEVBQUUsS0FBSyxDQUFDLFNBQVM7Z0JBQzFCLFVBQVUsRUFBRSxLQUFLLENBQUMsVUFBVTtnQkFDNUIsTUFBTSxFQUFFLEtBQUs7YUFDZDtZQUNELEtBQUs7WUFDTCxlQUFlO1lBQ2YsUUFBUSxFQUFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxRQUFRO1NBQ3hDLENBQUMsQ0FBQyxNQUFNLENBQUE7SUFDWCxDQUFDLENBQUMsQ0FBQTtJQUVGLE1BQU0sT0FBTyxHQUFHLE1BQU0sT0FBTyxDQUFDLHVCQUF1QixDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBRTdELE9BQU8sSUFBSSw0QkFBWSxDQUNyQixFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQzFCLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FDbkMsQ0FBQTtBQUNILENBQUMsRUFDRCxLQUFLLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUNqQyxJQUFJLENBQUMsU0FBUyxFQUFFLE1BQU0sRUFBRSxDQUFDO1FBQ3ZCLE9BQU07SUFDUixDQUFDO0lBQ0QsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxPQUFPLENBQUMsdUJBQXVCLENBQUMsU0FBUyxDQUFDLENBQUE7QUFDbEQsQ0FBQyxDQUNGLENBQUEifQ==