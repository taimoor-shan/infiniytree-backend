"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const sales_rep_1 = __importDefault(require("./sales-rep"));
/** A bank transfer to a rep, recorded against the month it settles. */
const CommissionPayout = utils_1.model
    .define("commission_payout", {
    id: utils_1.model.id({ prefix: "scpay" }).primaryKey(),
    currency_code: utils_1.model.text(),
    amount: utils_1.model.bigNumber(),
    period: utils_1.model.text(),
    paid_at: utils_1.model.dateTime(),
    reference: utils_1.model.text().nullable(),
    created_by: utils_1.model.text().nullable(),
    sales_rep: utils_1.model.belongsTo(() => sales_rep_1.default, { mappedBy: "payouts" }),
})
    .indexes([{ on: ["period"] }]);
exports.default = CommissionPayout;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbWlzc2lvbi1wYXlvdXQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9zYWxlcy1jb21taXNzaW9uL21vZGVscy9jb21taXNzaW9uLXBheW91dC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLHFEQUFpRDtBQUNqRCw0REFBa0M7QUFFbEMsdUVBQXVFO0FBQ3ZFLE1BQU0sZ0JBQWdCLEdBQUcsYUFBSztLQUMzQixNQUFNLENBQUMsbUJBQW1CLEVBQUU7SUFDM0IsRUFBRSxFQUFFLGFBQUssQ0FBQyxFQUFFLENBQUMsRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQyxVQUFVLEVBQUU7SUFDOUMsYUFBYSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDM0IsTUFBTSxFQUFFLGFBQUssQ0FBQyxTQUFTLEVBQUU7SUFDekIsTUFBTSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDcEIsT0FBTyxFQUFFLGFBQUssQ0FBQyxRQUFRLEVBQUU7SUFDekIsU0FBUyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDbEMsVUFBVSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDbkMsU0FBUyxFQUFFLGFBQUssQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsbUJBQVEsRUFBRSxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsQ0FBQztDQUNwRSxDQUFDO0tBQ0QsT0FBTyxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQTtBQUVoQyxrQkFBZSxnQkFBZ0IsQ0FBQSJ9