"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.convertCommissionEntriesStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const fx_1 = require("../../lib/fx");
const sales_commission_1 = require("../../modules/sales-commission");
const fx_2 = require("../../utils/fx");
/**
 * Converts each entry into the currency its rep is paid in, once, at the
 * rate of the day it was earned, and stores the rate on the entry. Reps
 * without a payout currency keep the order's currency. Fails, and records
 * nothing, if no rate is available; the nightly reconcile tries again.
 */
exports.convertCommissionEntriesStep = (0, workflows_sdk_1.createStep)("convert-commission-entries", async (drafts, { container }) => {
    if (!drafts.length) {
        return new workflows_sdk_1.StepResponse([]);
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const reps = await service.listSalesReps({ id: [...new Set(drafts.map((draft) => draft.sales_rep_id))] }, { select: ["id", "payout_currency_code"] });
    const payoutCurrency = new Map(reps.map((rep) => [rep.id, rep.payout_currency_code?.toLowerCase() ?? null]));
    const converted = [];
    for (const draft of drafts) {
        const settlement = payoutCurrency.get(draft.sales_rep_id) ?? draft.currency_code;
        const fx = await (0, fx_2.resolveFxRate)(container, {
            from: draft.currency_code,
            to: settlement,
            at: draft.earned_at,
        });
        converted.push({
            ...draft,
            settlement_currency_code: settlement,
            settlement_amount: fx
                ? (0, fx_1.convertAmount)({ amount: draft.amount, rate: fx.rate, to: settlement })
                : draft.amount,
            fx_rate: fx?.rate ?? null,
            fx_rate_date: fx?.rate_date ?? null,
            fx_source: fx?.source ?? null,
        });
    }
    return new workflows_sdk_1.StepResponse(converted);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udmVydC1jb21taXNzaW9uLWVudHJpZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL3N0ZXBzL2NvbnZlcnQtY29tbWlzc2lvbi1lbnRyaWVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFFQUE0RTtBQUU1RSxxQ0FBNEM7QUFDNUMscUVBQXdFO0FBRXhFLHVDQUE4QztBQUU5Qzs7Ozs7R0FLRztBQUNVLFFBQUEsNEJBQTRCLEdBQUcsSUFBQSwwQkFBVSxFQUNwRCw0QkFBNEIsRUFDNUIsS0FBSyxFQUFFLE1BQThCLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQ3RELElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDbkIsT0FBTyxJQUFJLDRCQUFZLENBQXlCLEVBQUUsQ0FBQyxDQUFBO0lBQ3JELENBQUM7SUFDRCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLElBQUksR0FBRyxNQUFNLE9BQU8sQ0FBQyxhQUFhLENBQ3RDLEVBQUUsRUFBRSxFQUFFLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQy9ELEVBQUUsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLHNCQUFzQixDQUFDLEVBQUUsQ0FDM0MsQ0FBQTtJQUNELE1BQU0sY0FBYyxHQUFHLElBQUksR0FBRyxDQUM1QixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLG9CQUFvQixFQUFFLFdBQVcsRUFBRSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQzdFLENBQUE7SUFFRCxNQUFNLFNBQVMsR0FBMkIsRUFBRSxDQUFBO0lBQzVDLEtBQUssTUFBTSxLQUFLLElBQUksTUFBTSxFQUFFLENBQUM7UUFDM0IsTUFBTSxVQUFVLEdBQUcsY0FBYyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLElBQUksS0FBSyxDQUFDLGFBQWEsQ0FBQTtRQUNoRixNQUFNLEVBQUUsR0FBRyxNQUFNLElBQUEsa0JBQWEsRUFBQyxTQUFTLEVBQUU7WUFDeEMsSUFBSSxFQUFFLEtBQUssQ0FBQyxhQUFhO1lBQ3pCLEVBQUUsRUFBRSxVQUFVO1lBQ2QsRUFBRSxFQUFFLEtBQUssQ0FBQyxTQUFTO1NBQ3BCLENBQUMsQ0FBQTtRQUVGLFNBQVMsQ0FBQyxJQUFJLENBQUM7WUFDYixHQUFHLEtBQUs7WUFDUix3QkFBd0IsRUFBRSxVQUFVO1lBQ3BDLGlCQUFpQixFQUFFLEVBQUU7Z0JBQ25CLENBQUMsQ0FBQyxJQUFBLGtCQUFhLEVBQUMsRUFBRSxNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksRUFBRSxFQUFFLEVBQUUsVUFBVSxFQUFFLENBQUM7Z0JBQ3hFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTTtZQUNoQixPQUFPLEVBQUUsRUFBRSxFQUFFLElBQUksSUFBSSxJQUFJO1lBQ3pCLFlBQVksRUFBRSxFQUFFLEVBQUUsU0FBUyxJQUFJLElBQUk7WUFDbkMsU0FBUyxFQUFFLEVBQUUsRUFBRSxNQUFNLElBQUksSUFBSTtTQUM5QixDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsT0FBTyxJQUFJLDRCQUFZLENBQUMsU0FBUyxDQUFDLENBQUE7QUFDcEMsQ0FBQyxDQUNGLENBQUEifQ==