"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.applyRefundToCommission = void 0;
const reverse_refunded_commission_1 = require("../workflows/reverse-refunded-commission");
const void_order_commission_1 = require("../workflows/void-order-commission");
/**
 * What a refund does to the order's commission: a refund of the whole order
 * voids it, a part refund takes back that part. Safe to repeat, so the
 * nightly reconcile runs it for every recent refund again.
 */
const applyRefundToCommission = async (container, orderId) => {
    const { result: voided } = await (0, void_order_commission_1.voidOrderCommissionWorkflow)(container).run({
        input: { order_id: orderId, reason: "order_refunded" },
    });
    if (voided?.length) {
        return { voided: voided.length, reversed: 0 };
    }
    const { result: reversed } = await (0, reverse_refunded_commission_1.reverseRefundedCommissionWorkflow)(container).run({
        input: { order_id: orderId },
    });
    return { voided: 0, reversed: reversed?.length ?? 0 };
};
exports.applyRefundToCommission = applyRefundToCommission;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVmdW5kcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy91dGlscy9yZWZ1bmRzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUNBLDBGQUE0RjtBQUM1Riw4RUFBZ0Y7QUFFaEY7Ozs7R0FJRztBQUNJLE1BQU0sdUJBQXVCLEdBQUcsS0FBSyxFQUMxQyxTQUEwQixFQUMxQixPQUFlLEVBQ2dDLEVBQUU7SUFDakQsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLElBQUEsbURBQTJCLEVBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDO1FBQzFFLEtBQUssRUFBRSxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLGdCQUFnQixFQUFFO0tBQ3ZELENBQUMsQ0FBQTtJQUNGLElBQUksTUFBTSxFQUFFLE1BQU0sRUFBRSxDQUFDO1FBQ25CLE9BQU8sRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsQ0FBQyxFQUFFLENBQUE7SUFDL0MsQ0FBQztJQUVELE1BQU0sRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLEdBQUcsTUFBTSxJQUFBLCtEQUFpQyxFQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUNsRixLQUFLLEVBQUUsRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFO0tBQzdCLENBQUMsQ0FBQTtJQUVGLE9BQU8sRUFBRSxNQUFNLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsTUFBTSxJQUFJLENBQUMsRUFBRSxDQUFBO0FBQ3ZELENBQUMsQ0FBQTtBQWhCWSxRQUFBLHVCQUF1QiwyQkFnQm5DIn0=