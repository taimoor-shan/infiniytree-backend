"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const client_assignment_1 = __importDefault(require("./client-assignment"));
const commission_adjustment_1 = __importDefault(require("./commission-adjustment"));
const commission_entry_1 = __importDefault(require("./commission-entry"));
const commission_payout_1 = __importDefault(require("./commission-payout"));
const sales_rep_contract_1 = __importDefault(require("./sales-rep-contract"));
const SalesRep = utils_1.model
    .define("sales_rep", {
    id: utils_1.model.id({ prefix: "srep" }).primaryKey(),
    name: utils_1.model.text().searchable(),
    email: utils_1.model.text().searchable(),
    phone: utils_1.model.text().nullable(),
    is_active: utils_1.model.boolean().default(true),
    notes: utils_1.model.text().nullable(),
    /**
     * The currency the rep is paid in ("eur" or "huf"). Commission earned in
     * the other one is converted when it is earned. Null pays each currency as
     * it was earned, with a balance and a payout per currency.
     */
    payout_currency_code: utils_1.model.text().nullable(),
    /** The auth identity of the rep's sales portal login; null means no portal access */
    auth_identity_id: utils_1.model.text().nullable(),
    assignments: utils_1.model.hasMany(() => client_assignment_1.default, { mappedBy: "sales_rep" }),
    contracts: utils_1.model.hasMany(() => sales_rep_contract_1.default, { mappedBy: "sales_rep" }),
    commission_entries: utils_1.model.hasMany(() => commission_entry_1.default, {
        mappedBy: "sales_rep",
    }),
    adjustments: utils_1.model.hasMany(() => commission_adjustment_1.default, {
        mappedBy: "sales_rep",
    }),
    payouts: utils_1.model.hasMany(() => commission_payout_1.default, { mappedBy: "sales_rep" }),
})
    .indexes([
    { on: ["email"], unique: true, where: "deleted_at IS NULL" },
    {
        on: ["auth_identity_id"],
        unique: true,
        where: "auth_identity_id IS NOT NULL AND deleted_at IS NULL",
    },
]);
exports.default = SalesRep;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2FsZXMtcmVwLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL21vZHVsZXMvc2FsZXMtY29tbWlzc2lvbi9tb2RlbHMvc2FsZXMtcmVwLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEscURBQWlEO0FBQ2pELDRFQUFrRDtBQUNsRCxvRkFBMEQ7QUFDMUQsMEVBQWdEO0FBQ2hELDRFQUFrRDtBQUNsRCw4RUFBbUQ7QUFFbkQsTUFBTSxRQUFRLEdBQUcsYUFBSztLQUNuQixNQUFNLENBQUMsV0FBVyxFQUFFO0lBQ25CLEVBQUUsRUFBRSxhQUFLLENBQUMsRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUMsVUFBVSxFQUFFO0lBQzdDLElBQUksRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsVUFBVSxFQUFFO0lBQy9CLEtBQUssRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsVUFBVSxFQUFFO0lBQ2hDLEtBQUssRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQzlCLFNBQVMsRUFBRSxhQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztJQUN4QyxLQUFLLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUM5Qjs7OztPQUlHO0lBQ0gsb0JBQW9CLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUM3QyxxRkFBcUY7SUFDckYsZ0JBQWdCLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUN6QyxXQUFXLEVBQUUsYUFBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQywyQkFBZ0IsRUFBRSxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsQ0FBQztJQUM3RSxTQUFTLEVBQUUsYUFBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyw0QkFBZ0IsRUFBRSxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsQ0FBQztJQUMzRSxrQkFBa0IsRUFBRSxhQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLDBCQUFlLEVBQUU7UUFDdkQsUUFBUSxFQUFFLFdBQVc7S0FDdEIsQ0FBQztJQUNGLFdBQVcsRUFBRSxhQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDLCtCQUFvQixFQUFFO1FBQ3JELFFBQVEsRUFBRSxXQUFXO0tBQ3RCLENBQUM7SUFDRixPQUFPLEVBQUUsYUFBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQywyQkFBZ0IsRUFBRSxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsQ0FBQztDQUMxRSxDQUFDO0tBQ0QsT0FBTyxDQUFDO0lBQ1AsRUFBRSxFQUFFLEVBQUUsQ0FBQyxPQUFPLENBQUMsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxvQkFBb0IsRUFBRTtJQUM1RDtRQUNFLEVBQUUsRUFBRSxDQUFDLGtCQUFrQixDQUFDO1FBQ3hCLE1BQU0sRUFBRSxJQUFJO1FBQ1osS0FBSyxFQUFFLHFEQUFxRDtLQUM3RDtDQUNGLENBQUMsQ0FBQTtBQUVKLGtCQUFlLFFBQVEsQ0FBQSJ9