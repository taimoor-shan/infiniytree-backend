"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validatePortalAccessTargetStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const sales_commission_1 = require("../../modules/sales-commission");
const invalid = (message) => new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, message);
/** Only an active rep without portal access can be given access. */
exports.validatePortalAccessTargetStep = (0, workflows_sdk_1.createStep)("validate-portal-access-target", async ({ sales_rep_id }, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const rep = await service.retrieveSalesRep(sales_rep_id);
    if (!rep.is_active) {
        throw invalid(`${rep.name} is inactive and can't be given portal access`);
    }
    if (rep.auth_identity_id) {
        throw invalid(`${rep.name} already has portal access`);
    }
    return new workflows_sdk_1.StepResponse({ id: rep.id, email: rep.email });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdGUtcG9ydGFsLWFjY2Vzcy10YXJnZXQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL3N0ZXBzL3ZhbGlkYXRlLXBvcnRhbC1hY2Nlc3MtdGFyZ2V0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFEQUF1RDtBQUN2RCxxRUFBNEU7QUFDNUUscUVBQXdFO0FBR3hFLE1BQU0sT0FBTyxHQUFHLENBQUMsT0FBZSxFQUFFLEVBQUUsQ0FDbEMsSUFBSSxtQkFBVyxDQUFDLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQTtBQUUxRCxvRUFBb0U7QUFDdkQsUUFBQSw4QkFBOEIsR0FBRyxJQUFBLDBCQUFVLEVBQ3RELCtCQUErQixFQUMvQixLQUFLLEVBQUUsRUFBRSxZQUFZLEVBQTRCLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQ2xFLE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sR0FBRyxHQUFHLE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxDQUFBO0lBRXhELElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDbkIsTUFBTSxPQUFPLENBQUMsR0FBRyxHQUFHLENBQUMsSUFBSSwrQ0FBK0MsQ0FBQyxDQUFBO0lBQzNFLENBQUM7SUFDRCxJQUFJLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQ3pCLE1BQU0sT0FBTyxDQUFDLEdBQUcsR0FBRyxDQUFDLElBQUksNEJBQTRCLENBQUMsQ0FBQTtJQUN4RCxDQUFDO0lBRUQsT0FBTyxJQUFJLDRCQUFZLENBQUMsRUFBRSxFQUFFLEVBQUUsR0FBRyxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsR0FBRyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUE7QUFDM0QsQ0FBQyxDQUNGLENBQUEifQ==