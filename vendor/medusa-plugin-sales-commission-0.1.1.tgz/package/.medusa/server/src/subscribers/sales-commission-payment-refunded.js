"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = salesCommissionPaymentRefunded;
const orders_for_payments_1 = require("../utils/orders-for-payments");
const void_order_commission_1 = require("../workflows/void-order-commission");
async function salesCommissionPaymentRefunded({ event: { data }, container, }) {
    const logger = container.resolve("logger");
    try {
        for (const orderId of await (0, orders_for_payments_1.orderIdsForPayments)(container, [data.id])) {
            const { result } = await (0, void_order_commission_1.voidOrderCommissionWorkflow)(container).run({
                input: { order_id: orderId, reason: "order_refunded" },
            });
            if (result?.length) {
                logger.info(`[sales-commission] Voided ${result.length} commission entries of refunded order ${orderId}`);
            }
            else {
                logger.info(`[sales-commission] Order ${orderId} was refunded in part; adjust its commission by hand if needed`);
            }
        }
    }
    catch (error) {
        logger.error(`[sales-commission] Failed to handle refund of payment ${data.id}: ${error.message}`);
    }
}
exports.config = {
    event: "payment.refunded",
    context: { subscriberId: "sales-commission-payment-refunded" },
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2FsZXMtY29tbWlzc2lvbi1wYXltZW50LXJlZnVuZGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3N1YnNjcmliZXJzL3NhbGVzLWNvbW1pc3Npb24tcGF5bWVudC1yZWZ1bmRlZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFJQSxpREEwQkM7QUE3QkQsc0VBQWtFO0FBQ2xFLDhFQUFnRjtBQUVqRSxLQUFLLFVBQVUsOEJBQThCLENBQUMsRUFDM0QsS0FBSyxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQ2YsU0FBUyxHQUNzQjtJQUMvQixNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBRTFDLElBQUksQ0FBQztRQUNILEtBQUssTUFBTSxPQUFPLElBQUksTUFBTSxJQUFBLHlDQUFtQixFQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFDdEUsTUFBTSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sSUFBQSxtREFBMkIsRUFBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLENBQUM7Z0JBQ2xFLEtBQUssRUFBRSxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLGdCQUFnQixFQUFFO2FBQ3ZELENBQUMsQ0FBQTtZQUNGLElBQUksTUFBTSxFQUFFLE1BQU0sRUFBRSxDQUFDO2dCQUNuQixNQUFNLENBQUMsSUFBSSxDQUNULDZCQUE2QixNQUFNLENBQUMsTUFBTSx5Q0FBeUMsT0FBTyxFQUFFLENBQzdGLENBQUE7WUFDSCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sTUFBTSxDQUFDLElBQUksQ0FDVCw0QkFBNEIsT0FBTyxnRUFBZ0UsQ0FDcEcsQ0FBQTtZQUNILENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixNQUFNLENBQUMsS0FBSyxDQUNWLHlEQUF5RCxJQUFJLENBQUMsRUFBRSxLQUFLLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FDckYsQ0FBQTtJQUNILENBQUM7QUFDSCxDQUFDO0FBRVksUUFBQSxNQUFNLEdBQXFCO0lBQ3RDLEtBQUssRUFBRSxrQkFBa0I7SUFDekIsT0FBTyxFQUFFLEVBQUUsWUFBWSxFQUFFLG1DQUFtQyxFQUFFO0NBQy9ELENBQUEifQ==