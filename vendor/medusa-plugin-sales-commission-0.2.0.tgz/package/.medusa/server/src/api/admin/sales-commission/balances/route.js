"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const balances_1 = require("../../../../utils/balances");
/** What every rep with activity is owed, per currency. */
async function GET(req, res) {
    const { approved_through, lines } = await (0, balances_1.loadEveryLine)(req.scope);
    res.json({
        approved_through,
        balances: (0, balances_1.balancesByRep)(lines, approved_through),
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLWNvbW1pc3Npb24vYmFsYW5jZXMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFPQSxrQkFVQztBQWJELHlEQUF5RTtBQUV6RSwwREFBMEQ7QUFDbkQsS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBK0IsRUFDL0IsR0FBbUI7SUFFbkIsTUFBTSxFQUFFLGdCQUFnQixFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sSUFBQSx3QkFBYSxFQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUVsRSxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ1AsZ0JBQWdCO1FBQ2hCLFFBQVEsRUFBRSxJQUFBLHdCQUFhLEVBQUMsS0FBSyxFQUFFLGdCQUFnQixDQUFDO0tBQ2pELENBQUMsQ0FBQTtBQUNKLENBQUMifQ==