"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DELETE = DELETE;
const cancel_rep_invite_1 = require("../../../../workflows/cancel-rep-invite");
const middlewares_1 = require("../../middlewares");
/** Withdraws an invitation nobody has answered yet; its link stops working. */
async function DELETE(req, res) {
    await (0, cancel_rep_invite_1.cancelRepInviteWorkflow)(req.scope).run({
        input: {
            invite_id: req.params.id,
            recruiter_sales_rep_id: (0, middlewares_1.portalRep)(req).id,
        },
    });
    res.json({ id: req.params.id, object: "recruit", deleted: true });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLXBvcnRhbC9yZWNydWl0cy9baWRdL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBS0Esd0JBU0M7QUFiRCwrRUFBaUY7QUFDakYsbURBQTZDO0FBRTdDLCtFQUErRTtBQUN4RSxLQUFLLFVBQVUsTUFBTSxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDbEUsTUFBTSxJQUFBLDJDQUF1QixFQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUM7UUFDM0MsS0FBSyxFQUFFO1lBQ0wsU0FBUyxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUN4QixzQkFBc0IsRUFBRSxJQUFBLHVCQUFTLEVBQUMsR0FBRyxDQUFDLENBQUMsRUFBRTtTQUMxQztLQUNGLENBQUMsQ0FBQTtJQUVGLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtBQUNuRSxDQUFDIn0=