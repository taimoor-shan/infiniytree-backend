"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const fx_1 = require("../../../../lib/fx");
const sales_commission_1 = require("../../../../modules/sales-commission");
const add_fx_rate_1 = require("../../../../workflows/add-fx-rate");
/** The latest euro-forint rates, newest first, and whether the ECB is fetched automatically. */
async function GET(req, res) {
    const service = req.scope.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const rates = await service.listFxRates({ base_currency_code: fx_1.FX_BASE, quote_currency_code: fx_1.FX_QUOTE }, { order: { rate_date: "DESC" }, take: 30 });
    res.json({
        base_currency_code: fx_1.FX_BASE,
        quote_currency_code: fx_1.FX_QUOTE,
        auto_fetch: service.getOptions().fx_auto_fetch !== false,
        rates: rates.map((row) => ({
            rate_date: row.rate_date,
            rate: Number(row.rate),
            source: row.source,
        })),
    });
}
/** Adds a rate for one day by hand. A day that has one can't be changed. */
async function POST(req, res) {
    const { result } = await (0, add_fx_rate_1.addFxRateWorkflow)(req.scope).run({
        input: { ...req.validatedBody, created_by: req.auth_context.actor_id },
    });
    res.json({
        rate: {
            rate_date: result.rate_date,
            rate: Number(result.rate),
            source: result.source,
        },
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLWNvbW1pc3Npb24vZngtcmF0ZXMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFXQSxrQkFzQkM7QUFHRCxvQkFlQztBQS9DRCwyQ0FBc0Q7QUFDdEQsMkVBQThFO0FBRTlFLG1FQUFxRTtBQUdyRSxnR0FBZ0c7QUFDekYsS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBK0IsRUFDL0IsR0FBbUI7SUFFbkIsTUFBTSxPQUFPLEdBQWlDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sS0FBSyxHQUFHLE1BQU0sT0FBTyxDQUFDLFdBQVcsQ0FDckMsRUFBRSxrQkFBa0IsRUFBRSxZQUFPLEVBQUUsbUJBQW1CLEVBQUUsYUFBUSxFQUFFLEVBQzlELEVBQUUsS0FBSyxFQUFFLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsQ0FDM0MsQ0FBQTtJQUVELEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDUCxrQkFBa0IsRUFBRSxZQUFPO1FBQzNCLG1CQUFtQixFQUFFLGFBQVE7UUFDN0IsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxhQUFhLEtBQUssS0FBSztRQUN4RCxLQUFLLEVBQUUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUN6QixTQUFTLEVBQUUsR0FBRyxDQUFDLFNBQVM7WUFDeEIsSUFBSSxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ3RCLE1BQU0sRUFBRSxHQUFHLENBQUMsTUFBTTtTQUNuQixDQUFDLENBQUM7S0FDSixDQUFDLENBQUE7QUFDSixDQUFDO0FBRUQsNEVBQTRFO0FBQ3JFLEtBQUssVUFBVSxJQUFJLENBQ3hCLEdBQW1ELEVBQ25ELEdBQW1CO0lBRW5CLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLElBQUEsK0JBQWlCLEVBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUN4RCxLQUFLLEVBQUUsRUFBRSxHQUFHLEdBQUcsQ0FBQyxhQUFhLEVBQUUsVUFBVSxFQUFFLEdBQUcsQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFO0tBQ3ZFLENBQUMsQ0FBQTtJQUVGLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDUCxJQUFJLEVBQUU7WUFDSixTQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVM7WUFDM0IsSUFBSSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1lBQ3pCLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtTQUN0QjtLQUNGLENBQUMsQ0FBQTtBQUNKLENBQUMifQ==