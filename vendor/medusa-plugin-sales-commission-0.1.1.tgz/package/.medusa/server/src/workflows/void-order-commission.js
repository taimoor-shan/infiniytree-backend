"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.voidOrderCommissionWorkflow = void 0;
const core_flows_1 = require("@medusajs/medusa/core-flows");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const refund_1 = require("../lib/refund");
const void_order_commission_1 = require("./steps/void-order-commission");
/**
 * Voids an order's commission when the order is canceled, or when it is fully
 * refunded without being canceled. A partial refund changes nothing: those
 * are corrected with a manual adjustment.
 */
exports.voidOrderCommissionWorkflow = (0, workflows_sdk_1.createWorkflow)("void-order-commission", function (input) {
    const { data: orders } = (0, core_flows_1.useQueryGraphStep)({
        entity: "order",
        fields: [
            "id",
            "status",
            "canceled_at",
            "payment_collections.payments.captures.amount",
            "payment_collections.payments.refunds.amount",
        ],
        filters: { id: input.order_id },
    });
    const shouldVoid = (0, workflows_sdk_1.transform)({ input, orders }, ({ input, orders }) => {
        const order = orders[0];
        if (!order) {
            return false;
        }
        const canceled = !!order.canceled_at || order.status === "canceled";
        if (input.reason === "order_canceled") {
            return canceled;
        }
        // Canceling refunds the payments too; the cancellation is the reason then
        return (!canceled &&
            (0, refund_1.isFullyRefunded)((order.payment_collections ?? []).flatMap((collection) => collection?.payments ?? [])));
    });
    const voided = (0, workflows_sdk_1.when)({ shouldVoid }, ({ shouldVoid }) => shouldVoid).then(() => (0, void_order_commission_1.voidOrderCommissionStep)((0, workflows_sdk_1.transform)({ input }, ({ input }) => ({
        order_id: input.order_id,
        reason: input.reason,
        voided_at: new Date(),
    }))));
    return new workflows_sdk_1.WorkflowResponse(voided);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidm9pZC1vcmRlci1jb21taXNzaW9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy92b2lkLW9yZGVyLWNvbW1pc3Npb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsNERBQStEO0FBQy9ELHFFQUswQztBQUMxQywwQ0FBK0M7QUFDL0MseUVBR3NDO0FBT3RDOzs7O0dBSUc7QUFDVSxRQUFBLDJCQUEyQixHQUFHLElBQUEsOEJBQWMsRUFDdkQsdUJBQXVCLEVBQ3ZCLFVBQVUsS0FBdUM7SUFDL0MsTUFBTSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFBLDhCQUFpQixFQUFDO1FBQ3pDLE1BQU0sRUFBRSxPQUFPO1FBQ2YsTUFBTSxFQUFFO1lBQ04sSUFBSTtZQUNKLFFBQVE7WUFDUixhQUFhO1lBQ2IsOENBQThDO1lBQzlDLDZDQUE2QztTQUM5QztRQUNELE9BQU8sRUFBRSxFQUFFLEVBQUUsRUFBRSxLQUFLLENBQUMsUUFBUSxFQUFFO0tBQ2hDLENBQUMsQ0FBQTtJQUVGLE1BQU0sVUFBVSxHQUFHLElBQUEseUJBQVMsRUFBQyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUU7UUFDcEUsTUFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBQ3ZCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNYLE9BQU8sS0FBSyxDQUFBO1FBQ2QsQ0FBQztRQUNELE1BQU0sUUFBUSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssVUFBVSxDQUFBO1FBQ25FLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3RDLE9BQU8sUUFBUSxDQUFBO1FBQ2pCLENBQUM7UUFDRCwwRUFBMEU7UUFDMUUsT0FBTyxDQUNMLENBQUMsUUFBUTtZQUNULElBQUEsd0JBQWUsRUFDYixDQUFDLEtBQUssQ0FBQyxtQkFBbUIsSUFBSSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQ3ZDLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQyxVQUFVLEVBQUUsUUFBUSxJQUFJLEVBQUUsQ0FDbEMsQ0FDWCxDQUNGLENBQUE7SUFDSCxDQUFDLENBQUMsQ0FBQTtJQUVGLE1BQU0sTUFBTSxHQUFHLElBQUEsb0JBQUksRUFBQyxFQUFFLFVBQVUsRUFBRSxFQUFFLENBQUMsRUFBRSxVQUFVLEVBQUUsRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUN0RSxHQUFHLEVBQUUsQ0FDSCxJQUFBLCtDQUF1QixFQUNyQixJQUFBLHlCQUFTLEVBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDbkMsUUFBUSxFQUFFLEtBQUssQ0FBQyxRQUFRO1FBQ3hCLE1BQU0sRUFBRSxLQUFLLENBQUMsTUFBTTtRQUNwQixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7S0FDdEIsQ0FBQyxDQUFDLENBQ0osQ0FDSixDQUFBO0lBRUQsT0FBTyxJQUFJLGdDQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFBO0FBQ3JDLENBQUMsQ0FDRixDQUFBIn0=