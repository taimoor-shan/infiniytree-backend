"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const report_1 = require("../../../lib/report");
const period_activity_1 = require("../../../utils/period-activity");
const middlewares_1 = require("../middlewares");
/** Every month with activity, newest first, with its totals per currency. */
async function GET(req, res) {
    const { limit, offset } = req.validatedQuery;
    const [history, approvedThrough] = await Promise.all([
        (0, period_activity_1.loadRepHistory)(req.scope, (0, middlewares_1.portalRep)(req).id),
        (0, period_activity_1.loadApprovedThrough)(req.scope),
    ]);
    const lines = (0, report_1.allLines)(history);
    const statements = [...new Set(lines.map((line) => line.period))]
        .sort()
        .reverse()
        .map((period) => ({
        period,
        approved: approvedThrough !== null && period <= approvedThrough,
        totals: (0, report_1.monthSummary)(lines, period),
    }));
    res.json({
        statements: statements.slice(offset, offset + limit),
        count: statements.length,
        offset,
        limit,
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLXBvcnRhbC9zdGF0ZW1lbnRzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBVUEsa0JBdUJDO0FBaENELGdEQUE0RDtBQUM1RCxvRUFHdUM7QUFDdkMsZ0RBQTBDO0FBRzFDLDZFQUE2RTtBQUN0RSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsY0FBc0MsQ0FBQTtJQUNwRSxNQUFNLENBQUMsT0FBTyxFQUFFLGVBQWUsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUNuRCxJQUFBLGdDQUFjLEVBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxJQUFBLHVCQUFTLEVBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQzVDLElBQUEscUNBQW1CLEVBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztLQUMvQixDQUFDLENBQUE7SUFDRixNQUFNLEtBQUssR0FBRyxJQUFBLGlCQUFRLEVBQUMsT0FBTyxDQUFDLENBQUE7SUFFL0IsTUFBTSxVQUFVLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1NBQzlELElBQUksRUFBRTtTQUNOLE9BQU8sRUFBRTtTQUNULEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNoQixNQUFNO1FBQ04sUUFBUSxFQUFFLGVBQWUsS0FBSyxJQUFJLElBQUksTUFBTSxJQUFJLGVBQWU7UUFDL0QsTUFBTSxFQUFFLElBQUEscUJBQVksRUFBQyxLQUFLLEVBQUUsTUFBTSxDQUFDO0tBQ3BDLENBQUMsQ0FBQyxDQUFBO0lBRUwsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNQLFVBQVUsRUFBRSxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQ3BELEtBQUssRUFBRSxVQUFVLENBQUMsTUFBTTtRQUN4QixNQUFNO1FBQ04sS0FBSztLQUNOLENBQUMsQ0FBQTtBQUNKLENBQUMifQ==