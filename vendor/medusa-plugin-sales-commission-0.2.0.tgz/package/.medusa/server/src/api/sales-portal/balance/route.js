"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const payout_day_1 = require("../../../lib/payout-day");
const pending_1 = require("../../../lib/pending");
const period_1 = require("../../../lib/period");
const sales_commission_1 = require("../../../modules/sales-commission");
const balances_1 = require("../../../utils/balances");
const pending_2 = require("../../../utils/pending");
const middlewares_1 = require("../middlewares");
/**
 * What the rep is owed, per currency: what can be paid now, what is earned
 * but not yet payable, what was paid ahead, and what was paid this year. Also
 * what the rep's unpaid orders would earn if paid now, and the day the owner
 * usually pays next, when one is set.
 */
async function GET(req, res) {
    const service = req.scope.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const { timezone, payout_day } = service.getOptions();
    const now = new Date();
    const [{ approved_through, balances, paid_this_year }, pending] = await Promise.all([
        (0, balances_1.loadRepBalances)(req.scope, (0, middlewares_1.portalRep)(req).id, {
            year: (0, period_1.toPeriod)(now, timezone).slice(0, 4),
        }),
        (0, pending_2.loadPendingLines)(req.scope, { salesRepId: (0, middlewares_1.portalRep)(req).id }),
    ]);
    res.json({
        approved_through,
        balances,
        paid_this_year,
        pending: (0, pending_1.pendingTotals)(pending),
        next_run: payout_day
            ? (0, payout_day_1.nextRunDate)({ now, payoutDay: payout_day, timezone })
            : null,
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLXBvcnRhbC9iYWxhbmNlL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBZ0JBLGtCQXdCQztBQXZDRCx3REFBcUQ7QUFDckQsa0RBQW9EO0FBQ3BELGdEQUE4QztBQUM5Qyx3RUFBMkU7QUFFM0Usc0RBQXlEO0FBQ3pELG9EQUF5RDtBQUN6RCxnREFBMEM7QUFFMUM7Ozs7O0dBS0c7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxPQUFPLEdBQWlDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sRUFBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLEdBQUcsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFBO0lBQ3JELE1BQU0sR0FBRyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUE7SUFFdEIsTUFBTSxDQUFDLEVBQUUsZ0JBQWdCLEVBQUUsUUFBUSxFQUFFLGNBQWMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxHQUM3RCxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7UUFDaEIsSUFBQSwwQkFBZSxFQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsSUFBQSx1QkFBUyxFQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUM1QyxJQUFJLEVBQUUsSUFBQSxpQkFBUSxFQUFDLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUMxQyxDQUFDO1FBQ0YsSUFBQSwwQkFBZ0IsRUFBQyxHQUFHLENBQUMsS0FBSyxFQUFFLEVBQUUsVUFBVSxFQUFFLElBQUEsdUJBQVMsRUFBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztLQUMvRCxDQUFDLENBQUE7SUFFSixHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ1AsZ0JBQWdCO1FBQ2hCLFFBQVE7UUFDUixjQUFjO1FBQ2QsT0FBTyxFQUFFLElBQUEsdUJBQWEsRUFBQyxPQUFPLENBQUM7UUFDL0IsUUFBUSxFQUFFLFVBQVU7WUFDbEIsQ0FBQyxDQUFDLElBQUEsd0JBQVcsRUFBQyxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsVUFBVSxFQUFFLFFBQVEsRUFBRSxDQUFDO1lBQ3ZELENBQUMsQ0FBQyxJQUFJO0tBQ1QsQ0FBQyxDQUFBO0FBQ0osQ0FBQyJ9