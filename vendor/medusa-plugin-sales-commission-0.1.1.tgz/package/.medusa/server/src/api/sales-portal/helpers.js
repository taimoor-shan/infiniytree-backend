"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.referredRepNames = exports.clientDisplayName = exports.toNumber = void 0;
const utils_1 = require("@medusajs/framework/utils");
const toNumber = (value) => utils_1.MathBN.convert(value).toNumber();
exports.toNumber = toNumber;
/** A customer's name for a rep: the company, else the person's name. */
const clientDisplayName = (customer) => customer?.company_name?.trim() ||
    [customer?.first_name, customer?.last_name].filter(Boolean).join(" ").trim() ||
    "Client";
exports.clientDisplayName = clientDisplayName;
/** Names of the reps behind a statement's Level 2 lines. */
const referredRepNames = async (container, lines) => {
    const repIds = [
        ...new Set(lines
            .map((line) => line.source_sales_rep_id)
            .filter((id) => !!id)),
    ];
    if (!repIds.length) {
        return new Map();
    }
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { data: reps } = await query.graph({
        entity: "sales_rep",
        fields: ["id", "name"],
        filters: { id: repIds },
    });
    return new Map(reps.map((rep) => [rep.id, rep.name]));
};
exports.referredRepNames = referredRepNames;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGVscGVycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9hcGkvc2FsZXMtcG9ydGFsL2hlbHBlcnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQ0EscURBQTZFO0FBR3RFLE1BQU0sUUFBUSxHQUFHLENBQUMsS0FBYyxFQUFVLEVBQUUsQ0FDakQsY0FBTSxDQUFDLE9BQU8sQ0FBQyxLQUFlLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQTtBQUQvQixRQUFBLFFBQVEsWUFDdUI7QUFFNUMsd0VBQXdFO0FBQ2pFLE1BQU0saUJBQWlCLEdBQUcsQ0FBQyxRQUlqQyxFQUFVLEVBQUUsQ0FDWCxRQUFRLEVBQUUsWUFBWSxFQUFFLElBQUksRUFBRTtJQUM5QixDQUFDLFFBQVEsRUFBRSxVQUFVLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFO0lBQzVFLFFBQVEsQ0FBQTtBQVBHLFFBQUEsaUJBQWlCLHFCQU9wQjtBQUVWLDREQUE0RDtBQUNyRCxNQUFNLGdCQUFnQixHQUFHLEtBQUssRUFDbkMsU0FBMEIsRUFDMUIsS0FBc0IsRUFDUSxFQUFFO0lBQ2hDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsR0FBRyxJQUFJLEdBQUcsQ0FDUixLQUFLO2FBQ0YsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7YUFDdkMsTUFBTSxDQUFDLENBQUMsRUFBRSxFQUFnQixFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUN0QztLQUNGLENBQUE7SUFDRCxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ25CLE9BQU8sSUFBSSxHQUFHLEVBQUUsQ0FBQTtJQUNsQixDQUFDO0lBRUQsTUFBTSxLQUFLLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxpQ0FBeUIsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUNoRSxNQUFNLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztRQUN2QyxNQUFNLEVBQUUsV0FBVztRQUNuQixNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDO1FBQ3RCLE9BQU8sRUFBRSxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUU7S0FDeEIsQ0FBQyxDQUFBO0lBRUYsT0FBTyxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQTtBQUN2RCxDQUFDLENBQUE7QUF2QlksUUFBQSxnQkFBZ0Isb0JBdUI1QiJ9