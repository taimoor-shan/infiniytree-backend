"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminCommissionPeriodParams = exports.AdminCreateCommissionPayout = exports.AdminCreateCommissionAdjustment = void 0;
const zod_1 = require("@medusajs/framework/zod");
const period = zod_1.z
    .string()
    .regex(/^\d{4}-(0[1-9]|1[0-2])$/, "Use a month in the form YYYY-MM");
exports.AdminCreateCommissionAdjustment = zod_1.z.object({
    currency_code: zod_1.z.string().length(3),
    amount: zod_1.z.number(),
    period: zod_1.z.string(),
    reason: zod_1.z.string(),
    order_id: zod_1.z.string().nullish(),
});
exports.AdminCreateCommissionPayout = zod_1.z.object({
    currency_code: zod_1.z.string().length(3),
    amount: zod_1.z.number(),
    period: zod_1.z.string(),
    paid_at: zod_1.z.coerce.date(),
    reference: zod_1.z.string().nullish(),
});
exports.AdminCommissionPeriodParams = zod_1.z.object({
    period: period.optional(),
    format: zod_1.z.enum(["json", "csv"]).optional(),
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdG9ycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcGkvYWRtaW4vc2FsZXMtY29tbWlzc2lvbi92YWxpZGF0b3JzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLGlEQUEyQztBQUUzQyxNQUFNLE1BQU0sR0FBRyxPQUFDO0tBQ2IsTUFBTSxFQUFFO0tBQ1IsS0FBSyxDQUFDLHlCQUF5QixFQUFFLGlDQUFpQyxDQUFDLENBQUE7QUFFekQsUUFBQSwrQkFBK0IsR0FBRyxPQUFDLENBQUMsTUFBTSxDQUFDO0lBQ3RELGFBQWEsRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztJQUNuQyxNQUFNLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRTtJQUNsQixNQUFNLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRTtJQUNsQixNQUFNLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRTtJQUNsQixRQUFRLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLE9BQU8sRUFBRTtDQUMvQixDQUFDLENBQUE7QUFLVyxRQUFBLDJCQUEyQixHQUFHLE9BQUMsQ0FBQyxNQUFNLENBQUM7SUFDbEQsYUFBYSxFQUFFLE9BQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQ25DLE1BQU0sRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFO0lBQ2xCLE1BQU0sRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFO0lBQ2xCLE9BQU8sRUFBRSxPQUFDLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRTtJQUN4QixTQUFTLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLE9BQU8sRUFBRTtDQUNoQyxDQUFDLENBQUE7QUFLVyxRQUFBLDJCQUEyQixHQUFHLE9BQUMsQ0FBQyxNQUFNLENBQUM7SUFDbEQsTUFBTSxFQUFFLE1BQU0sQ0FBQyxRQUFRLEVBQUU7SUFDekIsTUFBTSxFQUFFLE9BQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUU7Q0FDM0MsQ0FBQyxDQUFBIn0=