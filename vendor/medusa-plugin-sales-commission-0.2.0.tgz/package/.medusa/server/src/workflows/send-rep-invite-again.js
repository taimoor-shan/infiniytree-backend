"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendRepInviteAgainWorkflow = void 0;
const core_flows_1 = require("@medusajs/medusa/core-flows");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const events_1 = require("../events");
const create_rep_invite_1 = require("./create-rep-invite");
const send_rep_invite_again_1 = require("./steps/send-rep-invite-again");
/** Emails an unanswered invite again with a new link; the old link stops working. */
exports.sendRepInviteAgainWorkflow = (0, workflows_sdk_1.createWorkflow)("send-rep-invite-again", function (input) {
    const sent = (0, send_rep_invite_again_1.sendRepInviteAgainStep)(input);
    (0, core_flows_1.emitEventStep)({
        eventName: events_1.SalesCommissionEvents.INVITE_SENT,
        data: (0, workflows_sdk_1.transform)({ sent }, ({ sent }) => (0, create_rep_invite_1.inviteSentEvent)(sent)),
    });
    return new workflows_sdk_1.WorkflowResponse((0, workflows_sdk_1.transform)({ sent }, ({ sent }) => sent.invite));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VuZC1yZXAtaW52aXRlLWFnYWluLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zZW5kLXJlcC1pbnZpdGUtYWdhaW4udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsNERBQTJEO0FBQzNELHFFQUkwQztBQUMxQyxzQ0FBaUQ7QUFDakQsMkRBQXFEO0FBQ3JELHlFQUdzQztBQUV0QyxxRkFBcUY7QUFDeEUsUUFBQSwwQkFBMEIsR0FBRyxJQUFBLDhCQUFjLEVBQ3RELHVCQUF1QixFQUN2QixVQUFVLEtBQWtDO0lBQzFDLE1BQU0sSUFBSSxHQUFHLElBQUEsOENBQXNCLEVBQUMsS0FBSyxDQUFDLENBQUE7SUFFMUMsSUFBQSwwQkFBYSxFQUFDO1FBQ1osU0FBUyxFQUFFLDhCQUFxQixDQUFDLFdBQVc7UUFDNUMsSUFBSSxFQUFFLElBQUEseUJBQVMsRUFBQyxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsSUFBQSxtQ0FBZSxFQUFDLElBQUksQ0FBQyxDQUFDO0tBQy9ELENBQUMsQ0FBQTtJQUVGLE9BQU8sSUFBSSxnQ0FBZ0IsQ0FBQyxJQUFBLHlCQUFTLEVBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFBO0FBQzdFLENBQUMsQ0FDRixDQUFBIn0=