"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
/** The rep's clients, current and past, newest assignment first. */
async function GET(req, res) {
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { data: clients } = await query.graph({
        entity: "client_assignment",
        fields: [
            "id",
            "customer_id",
            "commission_rate",
            "starts_at",
            "ends_at",
            "customer.id",
            "customer.email",
            "customer.company_name",
            "customer.first_name",
            "customer.last_name",
        ],
        filters: { sales_rep_id: req.params.id },
        pagination: { order: { starts_at: "DESC", created_at: "DESC" } },
    });
    res.json({ clients });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLXJlcHMvW2lkXS9jbGllbnRzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBT0Esa0JBeUJDO0FBNUJELHFEQUFxRTtBQUVyRSxvRUFBb0U7QUFDN0QsS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBK0IsRUFDL0IsR0FBbUI7SUFFbkIsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUE7SUFFaEUsTUFBTSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDMUMsTUFBTSxFQUFFLG1CQUFtQjtRQUMzQixNQUFNLEVBQUU7WUFDTixJQUFJO1lBQ0osYUFBYTtZQUNiLGlCQUFpQjtZQUNqQixXQUFXO1lBQ1gsU0FBUztZQUNULGFBQWE7WUFDYixnQkFBZ0I7WUFDaEIsdUJBQXVCO1lBQ3ZCLHFCQUFxQjtZQUNyQixvQkFBb0I7U0FDckI7UUFDRCxPQUFPLEVBQUUsRUFBRSxZQUFZLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUU7UUFDeEMsVUFBVSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLEVBQUU7S0FDakUsQ0FBQyxDQUFBO0lBRUYsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUE7QUFDdkIsQ0FBQyJ9