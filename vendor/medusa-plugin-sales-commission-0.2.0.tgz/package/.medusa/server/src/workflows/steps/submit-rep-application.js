"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.submitRepApplicationStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const invite_1 = require("../../lib/invite");
const recruiting_errors_1 = require("../../lib/recruiting-errors");
const sales_commission_1 = require("../../modules/sales-commission");
const BAD_LINK = "This invitation link isn't valid";
/**
 * The candidate's application, made from the personal link in their invite.
 * The email stays the one the recruiter invited, so a link can't be used for
 * another address. Applying once uses the link up: nothing is paid and nobody
 * gets access until the owner approves.
 */
exports.submitRepApplicationStep = (0, workflows_sdk_1.createStep)("submit-rep-application", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const now = new Date();
    if (!(0, invite_1.isInviteToken)(input.token)) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, BAD_LINK, recruiting_errors_1.RECRUITING_ERRORS.LINK_INVALID);
    }
    const [invite] = await service.listRepInvites({ token_hash: (0, invite_1.hashInviteToken)(input.token) }, { take: 1 });
    if (!invite) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, BAD_LINK, recruiting_errors_1.RECRUITING_ERRORS.LINK_INVALID);
    }
    const state = (0, invite_1.inviteState)(invite, now);
    if (state === "expired") {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, "This invitation has expired. Ask the person who invited you to send a new one", recruiting_errors_1.RECRUITING_ERRORS.LINK_EXPIRED);
    }
    if (state === "canceled") {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, BAD_LINK, recruiting_errors_1.RECRUITING_ERRORS.LINK_INVALID);
    }
    if (state !== "invited") {
        throw new utils_1.MedusaError(
        // Not CONFLICT: Medusa answers that with a canned retry message and drops our code
        utils_1.MedusaError.Types.INVALID_DATA, "This invitation has already been used", recruiting_errors_1.RECRUITING_ERRORS.LINK_USED);
    }
    if (!input.accept_terms) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, "You need to accept the terms to apply", recruiting_errors_1.RECRUITING_ERRORS.TERMS_REQUIRED);
    }
    const [existingRep] = await service.listSalesReps({ email: invite.email }, { take: 1, select: ["id"] });
    if (existingRep) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, "You already have a sales account. Sign in to the sales portal instead", recruiting_errors_1.RECRUITING_ERRORS.ALREADY_REP);
    }
    const recruiter = await service.retrieveSalesRep(invite.recruiter_sales_rep_id);
    const updated = await service.updateRepInvites({
        id: invite.id,
        status: "applied",
        applicant_name: input.name.trim(),
        applicant_phone: input.phone?.trim() || null,
        applicant_company: input.company?.trim() || null,
        requested_currency_code: input.requested_currency_code?.toLowerCase() || null,
        terms_accepted_at: now,
        applied_at: now,
    });
    return new workflows_sdk_1.StepResponse({ invite: updated, recruiter_name: recruiter.name }, invite.id);
}, async (inviteId, { container }) => {
    if (!inviteId) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.updateRepInvites({
        id: inviteId,
        status: "invited",
        applicant_name: null,
        applicant_phone: null,
        applicant_company: null,
        requested_currency_code: null,
        terms_accepted_at: null,
        applied_at: null,
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3VibWl0LXJlcC1hcHBsaWNhdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3Mvc3RlcHMvc3VibWl0LXJlcC1hcHBsaWNhdGlvbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxREFBdUQ7QUFDdkQscUVBQTRFO0FBQzVFLDZDQUE4RTtBQUM5RSxtRUFBd0U7QUFDeEUscUVBQXdFO0FBWXhFLE1BQU0sUUFBUSxHQUFHLGtDQUFrQyxDQUFBO0FBRW5EOzs7OztHQUtHO0FBQ1UsUUFBQSx3QkFBd0IsR0FBRyxJQUFBLDBCQUFVLEVBQ2hELHdCQUF3QixFQUN4QixLQUFLLEVBQUUsS0FBb0MsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDNUQsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxHQUFHLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQTtJQUV0QixJQUFJLENBQUMsSUFBQSxzQkFBYSxFQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO1FBQ2hDLE1BQU0sSUFBSSxtQkFBVyxDQUFDLG1CQUFXLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUscUNBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQTtJQUNsRixDQUFDO0lBQ0QsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLGNBQWMsQ0FDM0MsRUFBRSxVQUFVLEVBQUUsSUFBQSx3QkFBZSxFQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUM1QyxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FDWixDQUFBO0lBQ0QsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ1osTUFBTSxJQUFJLG1CQUFXLENBQUMsbUJBQVcsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxxQ0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFBO0lBQ2xGLENBQUM7SUFFRCxNQUFNLEtBQUssR0FBRyxJQUFBLG9CQUFXLEVBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxDQUFBO0lBQ3RDLElBQUksS0FBSyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQ3hCLE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQzlCLCtFQUErRSxFQUMvRSxxQ0FBSyxDQUFDLFlBQVksQ0FDbkIsQ0FBQTtJQUNILENBQUM7SUFDRCxJQUFJLEtBQUssS0FBSyxVQUFVLEVBQUUsQ0FBQztRQUN6QixNQUFNLElBQUksbUJBQVcsQ0FBQyxtQkFBVyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsUUFBUSxFQUFFLHFDQUFLLENBQUMsWUFBWSxDQUFDLENBQUE7SUFDbEYsQ0FBQztJQUNELElBQUksS0FBSyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQ3hCLE1BQU0sSUFBSSxtQkFBVztRQUNuQixtRkFBbUY7UUFDbkYsbUJBQVcsQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUM5Qix1Q0FBdUMsRUFDdkMscUNBQUssQ0FBQyxTQUFTLENBQ2hCLENBQUE7SUFDSCxDQUFDO0lBQ0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUN4QixNQUFNLElBQUksbUJBQVcsQ0FDbkIsbUJBQVcsQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUM5Qix1Q0FBdUMsRUFDdkMscUNBQUssQ0FBQyxjQUFjLENBQ3JCLENBQUE7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLGFBQWEsQ0FDL0MsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUssRUFBRSxFQUN2QixFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FDNUIsQ0FBQTtJQUNELElBQUksV0FBVyxFQUFFLENBQUM7UUFDaEIsTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFDOUIsdUVBQXVFLEVBQ3ZFLHFDQUFLLENBQUMsV0FBVyxDQUNsQixDQUFBO0lBQ0gsQ0FBQztJQUVELE1BQU0sU0FBUyxHQUFHLE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFBO0lBQy9FLE1BQU0sT0FBTyxHQUFHLE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUFDO1FBQzdDLEVBQUUsRUFBRSxNQUFNLENBQUMsRUFBRTtRQUNiLE1BQU0sRUFBRSxTQUFTO1FBQ2pCLGNBQWMsRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRTtRQUNqQyxlQUFlLEVBQUUsS0FBSyxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsSUFBSSxJQUFJO1FBQzVDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLElBQUksSUFBSTtRQUNoRCx1QkFBdUIsRUFBRSxLQUFLLENBQUMsdUJBQXVCLEVBQUUsV0FBVyxFQUFFLElBQUksSUFBSTtRQUM3RSxpQkFBaUIsRUFBRSxHQUFHO1FBQ3RCLFVBQVUsRUFBRSxHQUFHO0tBQ2hCLENBQUMsQ0FBQTtJQUVGLE9BQU8sSUFBSSw0QkFBWSxDQUNyQixFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsY0FBYyxFQUFFLFNBQVMsQ0FBQyxJQUFJLEVBQUUsRUFDbkQsTUFBTSxDQUFDLEVBQUUsQ0FDVixDQUFBO0FBQ0gsQ0FBQyxFQUNELEtBQUssRUFBRSxRQUFRLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQ2hDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNkLE9BQU07SUFDUixDQUFDO0lBQ0QsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxPQUFPLENBQUMsZ0JBQWdCLENBQUM7UUFDN0IsRUFBRSxFQUFFLFFBQVE7UUFDWixNQUFNLEVBQUUsU0FBUztRQUNqQixjQUFjLEVBQUUsSUFBSTtRQUNwQixlQUFlLEVBQUUsSUFBSTtRQUNyQixpQkFBaUIsRUFBRSxJQUFJO1FBQ3ZCLHVCQUF1QixFQUFFLElBQUk7UUFDN0IsaUJBQWlCLEVBQUUsSUFBSTtRQUN2QixVQUFVLEVBQUUsSUFBSTtLQUNqQixDQUFDLENBQUE7QUFDSixDQUFDLENBQ0YsQ0FBQSJ9