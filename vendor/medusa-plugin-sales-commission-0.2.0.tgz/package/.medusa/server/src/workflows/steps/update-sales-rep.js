"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateSalesRepStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const sales_commission_1 = require("../../modules/sales-commission");
const sales_rep_email_1 = require("./sales-rep-email");
exports.updateSalesRepStep = (0, workflows_sdk_1.createStep)("update-sales-rep", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const previous = await service.retrieveSalesRep(input.id);
    const data = { ...input };
    if (data.payout_currency_code) {
        data.payout_currency_code = data.payout_currency_code.toLowerCase();
    }
    if (data.name !== undefined) {
        data.name = data.name.trim();
    }
    if (data.email !== undefined) {
        data.email = (0, sales_rep_email_1.normalizeEmail)(data.email);
        await (0, sales_rep_email_1.assertEmailAvailable)(service, data.email, input.id);
    }
    const salesRep = await service.updateSalesReps(data);
    return new workflows_sdk_1.StepResponse(salesRep, previous);
}, async (previous, { container }) => {
    if (!previous) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.updateSalesReps({
        id: previous.id,
        name: previous.name,
        email: previous.email,
        phone: previous.phone,
        notes: previous.notes,
        is_active: previous.is_active,
        payout_currency_code: previous.payout_currency_code,
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXBkYXRlLXNhbGVzLXJlcC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3Mvc3RlcHMvdXBkYXRlLXNhbGVzLXJlcC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxRUFBNEU7QUFDNUUscUVBQXdFO0FBRXhFLHVEQUF3RTtBQVkzRCxRQUFBLGtCQUFrQixHQUFHLElBQUEsMEJBQVUsRUFDMUMsa0JBQWtCLEVBQ2xCLEtBQUssRUFBRSxLQUE4QixFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUN0RCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLFFBQVEsR0FBRyxNQUFNLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUE7SUFFekQsTUFBTSxJQUFJLEdBQUcsRUFBRSxHQUFHLEtBQUssRUFBRSxDQUFBO0lBQ3pCLElBQUksSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDOUIsSUFBSSxDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQTtJQUNyRSxDQUFDO0lBQ0QsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQzVCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQTtJQUM5QixDQUFDO0lBQ0QsSUFBSSxJQUFJLENBQUMsS0FBSyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQzdCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBQSxnQ0FBYyxFQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQTtRQUN2QyxNQUFNLElBQUEsc0NBQW9CLEVBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBQzNELENBQUM7SUFFRCxNQUFNLFFBQVEsR0FBRyxNQUFNLE9BQU8sQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUE7SUFFcEQsT0FBTyxJQUFJLDRCQUFZLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFBO0FBQzdDLENBQUMsRUFDRCxLQUFLLEVBQUUsUUFBUSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUNoQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDZCxPQUFNO0lBQ1IsQ0FBQztJQUNELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sT0FBTyxDQUFDLGVBQWUsQ0FBQztRQUM1QixFQUFFLEVBQUUsUUFBUSxDQUFDLEVBQUU7UUFDZixJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUk7UUFDbkIsS0FBSyxFQUFFLFFBQVEsQ0FBQyxLQUFLO1FBQ3JCLEtBQUssRUFBRSxRQUFRLENBQUMsS0FBSztRQUNyQixLQUFLLEVBQUUsUUFBUSxDQUFDLEtBQUs7UUFDckIsU0FBUyxFQUFFLFFBQVEsQ0FBQyxTQUFTO1FBQzdCLG9CQUFvQixFQUFFLFFBQVEsQ0FBQyxvQkFBb0I7S0FDcEQsQ0FBQyxDQUFBO0FBQ0osQ0FBQyxDQUNGLENBQUEifQ==