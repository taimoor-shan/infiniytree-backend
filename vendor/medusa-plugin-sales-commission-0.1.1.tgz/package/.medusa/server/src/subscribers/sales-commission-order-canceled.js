"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = salesCommissionOrderCanceled;
const void_order_commission_1 = require("../workflows/void-order-commission");
async function salesCommissionOrderCanceled({ event: { data }, container, }) {
    const logger = container.resolve("logger");
    try {
        const { result } = await (0, void_order_commission_1.voidOrderCommissionWorkflow)(container).run({
            input: { order_id: data.id, reason: "order_canceled" },
        });
        if (result?.length) {
            logger.info(`[sales-commission] Voided ${result.length} commission entries of canceled order ${data.id}`);
        }
    }
    catch (error) {
        logger.error(`[sales-commission] Failed to void commission of order ${data.id}: ${error.message}`);
    }
}
exports.config = {
    event: "order.canceled",
    context: { subscriberId: "sales-commission-order-canceled" },
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2FsZXMtY29tbWlzc2lvbi1vcmRlci1jYW5jZWxlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zdWJzY3JpYmVycy9zYWxlcy1jb21taXNzaW9uLW9yZGVyLWNhbmNlbGVkLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUdBLCtDQW9CQztBQXRCRCw4RUFBZ0Y7QUFFakUsS0FBSyxVQUFVLDRCQUE0QixDQUFDLEVBQ3pELEtBQUssRUFBRSxFQUFFLElBQUksRUFBRSxFQUNmLFNBQVMsR0FDc0I7SUFDL0IsTUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQTtJQUUxQyxJQUFJLENBQUM7UUFDSCxNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsTUFBTSxJQUFBLG1EQUEyQixFQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztZQUNsRSxLQUFLLEVBQUUsRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRSxNQUFNLEVBQUUsZ0JBQWdCLEVBQUU7U0FDdkQsQ0FBQyxDQUFBO1FBQ0YsSUFBSSxNQUFNLEVBQUUsTUFBTSxFQUFFLENBQUM7WUFDbkIsTUFBTSxDQUFDLElBQUksQ0FDVCw2QkFBNkIsTUFBTSxDQUFDLE1BQU0seUNBQXlDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FDN0YsQ0FBQTtRQUNILENBQUM7SUFDSCxDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE1BQU0sQ0FBQyxLQUFLLENBQ1YseURBQXlELElBQUksQ0FBQyxFQUFFLEtBQUssS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUNyRixDQUFBO0lBQ0gsQ0FBQztBQUNILENBQUM7QUFFWSxRQUFBLE1BQU0sR0FBcUI7SUFDdEMsS0FBSyxFQUFFLGdCQUFnQjtJQUN2QixPQUFPLEVBQUUsRUFBRSxZQUFZLEVBQUUsaUNBQWlDLEVBQUU7Q0FDN0QsQ0FBQSJ9