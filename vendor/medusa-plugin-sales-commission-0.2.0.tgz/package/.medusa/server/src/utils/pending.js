"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadPendingLines = exports.PENDING_DAYS = void 0;
const utils_1 = require("@medusajs/framework/utils");
const fx_1 = require("../lib/fx");
const pending_1 = require("../lib/pending");
const sales_commission_1 = require("../modules/sales-commission");
const client_name_1 = require("./client-name");
/** How far back an unpaid order still counts as expected. Make.com cancels unpaid orders long before. */
exports.PENDING_DAYS = 21;
const isFullyCaptured = (order) => {
    const payments = (order.payment_collections ?? [])
        .flatMap((collection) => collection?.payments ?? [])
        .filter((payment) => !!payment && !payment.canceled_at);
    return payments.length > 0 && payments.every((payment) => payment.captured_at);
};
/**
 * What the unpaid orders of assigned clients would earn if they were paid
 * now. Nothing is stored: it is worked out from the orders as they are, so it
 * moves with them. Optionally for one rep.
 */
const loadPendingLines = async (container, { salesRepId } = {}) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const assignments = await service.listClientAssignments({});
    if (!assignments.length) {
        return [];
    }
    const repIds = [...new Set(assignments.map((row) => row.sales_rep_id))];
    const [{ data: orders }, referrals, reps, [latestRate]] = await Promise.all([
        query.graph({
            entity: "order",
            fields: [
                "id",
                "display_id",
                "created_at",
                "canceled_at",
                "status",
                "email",
                "currency_code",
                "customer_id",
                "item_total",
                "item_tax_total",
                "customer.email",
                "customer.company_name",
                "customer.first_name",
                "customer.last_name",
                "payment_collections.payments.captured_at",
                "payment_collections.payments.canceled_at",
            ],
            filters: {
                customer_id: [...new Set(assignments.map((row) => row.customer_id))],
                created_at: { $gte: new Date(Date.now() - exports.PENDING_DAYS * 86_400_000) },
            },
        }),
        service.listRepReferrals({ referred_sales_rep_id: repIds }),
        service.listSalesReps({ id: repIds }, { select: ["id", "payout_currency_code"] }),
        service.listFxRates({ base_currency_code: fx_1.FX_BASE, quote_currency_code: fx_1.FX_QUOTE }, { order: { rate_date: "DESC" }, take: 1 }),
    ]);
    const unpaid = orders.filter((order) => order.customer_id &&
        !order.canceled_at &&
        order.status !== "canceled" &&
        !isFullyCaptured(order));
    if (!unpaid.length) {
        return [];
    }
    const recorded = new Set((await service.listCommissionEntries({ order_id: unpaid.map((order) => order.id) }, { select: ["order_id"] })).map((entry) => entry.order_id));
    const lines = (0, pending_1.pendingLines)({
        orders: unpaid
            .filter((order) => !recorded.has(order.id))
            .map((order) => ({
            id: order.id,
            display_id: order.display_id,
            created_at: order.created_at,
            currency_code: order.currency_code,
            customer_id: order.customer_id,
            client_name: (0, client_name_1.orderClientName)(order),
            item_total: order.item_total,
            item_tax_total: order.item_tax_total,
        })),
        assignments,
        referrals,
        payoutCurrencies: new Map(reps.map((rep) => [rep.id, rep.payout_currency_code?.toLowerCase() ?? null])),
        eurRate: latestRate ? Number(latestRate.rate) : null,
        now: new Date(),
        timezone: service.getOptions().timezone,
    });
    return salesRepId
        ? lines.filter((line) => line.sales_rep_id === salesRepId)
        : lines;
};
exports.loadPendingLines = loadPendingLines;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGVuZGluZy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy91dGlscy9wZW5kaW5nLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUNBLHFEQUFxRTtBQUNyRSxrQ0FBNkM7QUFDN0MsNENBQTBEO0FBQzFELGtFQUFxRTtBQUVyRSwrQ0FBK0M7QUFFL0MseUdBQXlHO0FBQzVGLFFBQUEsWUFBWSxHQUFHLEVBQUUsQ0FBQTtBQUk5QixNQUFNLGVBQWUsR0FBRyxDQUFDLEtBQTZDLEVBQUUsRUFBRTtJQUN4RSxNQUFNLFFBQVEsR0FBRyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsSUFBSSxFQUFFLENBQUM7U0FDL0MsT0FBTyxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQyxVQUFVLEVBQUUsUUFBUSxJQUFJLEVBQUUsQ0FBQztTQUNuRCxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQXlCLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFBO0lBRWhGLE9BQU8sUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFBO0FBQ2hGLENBQUMsQ0FBQTtBQUVEOzs7O0dBSUc7QUFDSSxNQUFNLGdCQUFnQixHQUFHLEtBQUssRUFDbkMsU0FBMEIsRUFDMUIsRUFBRSxVQUFVLEtBQThCLEVBQUUsRUFDcEIsRUFBRTtJQUMxQixNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLEtBQUssR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFBO0lBRWhFLE1BQU0sV0FBVyxHQUFHLE1BQU0sT0FBTyxDQUFDLHFCQUFxQixDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBQzNELElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDeEIsT0FBTyxFQUFFLENBQUE7SUFDWCxDQUFDO0lBQ0QsTUFBTSxNQUFNLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFFdkUsTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUMxRSxLQUFLLENBQUMsS0FBSyxDQUFDO1lBQ1YsTUFBTSxFQUFFLE9BQU87WUFDZixNQUFNLEVBQUU7Z0JBQ04sSUFBSTtnQkFDSixZQUFZO2dCQUNaLFlBQVk7Z0JBQ1osYUFBYTtnQkFDYixRQUFRO2dCQUNSLE9BQU87Z0JBQ1AsZUFBZTtnQkFDZixhQUFhO2dCQUNiLFlBQVk7Z0JBQ1osZ0JBQWdCO2dCQUNoQixnQkFBZ0I7Z0JBQ2hCLHVCQUF1QjtnQkFDdkIscUJBQXFCO2dCQUNyQixvQkFBb0I7Z0JBQ3BCLDBDQUEwQztnQkFDMUMsMENBQTBDO2FBQzNDO1lBQ0QsT0FBTyxFQUFFO2dCQUNQLFdBQVcsRUFBRSxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BFLFVBQVUsRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsb0JBQVksR0FBRyxVQUFVLENBQUMsRUFBRTthQUN2RTtTQUNGLENBQUM7UUFDRixPQUFPLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxxQkFBcUIsRUFBRSxNQUFNLEVBQUUsQ0FBQztRQUMzRCxPQUFPLENBQUMsYUFBYSxDQUNuQixFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsRUFDZCxFQUFFLE1BQU0sRUFBRSxDQUFDLElBQUksRUFBRSxzQkFBc0IsQ0FBQyxFQUFFLENBQzNDO1FBQ0QsT0FBTyxDQUFDLFdBQVcsQ0FDakIsRUFBRSxrQkFBa0IsRUFBRSxZQUFPLEVBQUUsbUJBQW1CLEVBQUUsYUFBUSxFQUFFLEVBQzlELEVBQUUsS0FBSyxFQUFFLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FDMUM7S0FDRixDQUFDLENBQUE7SUFFRixNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUMxQixDQUFDLEtBQUssRUFBRSxFQUFFLENBQ1IsS0FBSyxDQUFDLFdBQVc7UUFDakIsQ0FBQyxLQUFLLENBQUMsV0FBVztRQUNsQixLQUFLLENBQUMsTUFBTSxLQUFLLFVBQVU7UUFDM0IsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQzFCLENBQUE7SUFDRCxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ25CLE9BQU8sRUFBRSxDQUFBO0lBQ1gsQ0FBQztJQUNELE1BQU0sUUFBUSxHQUFHLElBQUksR0FBRyxDQUN0QixDQUNFLE1BQU0sT0FBTyxDQUFDLHFCQUFxQixDQUNqQyxFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFDN0MsRUFBRSxNQUFNLEVBQUUsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUN6QixDQUNGLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQ2pDLENBQUE7SUFFRCxNQUFNLEtBQUssR0FBRyxJQUFBLHNCQUFZLEVBQUM7UUFDekIsTUFBTSxFQUFFLE1BQU07YUFDWCxNQUFNLENBQUMsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7YUFDMUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQ2YsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFO1lBQ1osVUFBVSxFQUFFLEtBQUssQ0FBQyxVQUFXO1lBQzdCLFVBQVUsRUFBRSxLQUFLLENBQUMsVUFBVztZQUM3QixhQUFhLEVBQUUsS0FBSyxDQUFDLGFBQWE7WUFDbEMsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFZO1lBQy9CLFdBQVcsRUFBRSxJQUFBLDZCQUFlLEVBQUMsS0FBWSxDQUFDO1lBQzFDLFVBQVUsRUFBRSxLQUFLLENBQUMsVUFBb0I7WUFDdEMsY0FBYyxFQUFFLEtBQUssQ0FBQyxjQUF3QjtTQUMvQyxDQUFDLENBQUM7UUFDTCxXQUFXO1FBQ1gsU0FBUztRQUNULGdCQUFnQixFQUFFLElBQUksR0FBRyxDQUN2QixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLG9CQUFvQixFQUFFLFdBQVcsRUFBRSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQzdFO1FBQ0QsT0FBTyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtRQUNwRCxHQUFHLEVBQUUsSUFBSSxJQUFJLEVBQUU7UUFDZixRQUFRLEVBQUUsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFDLFFBQVE7S0FDeEMsQ0FBQyxDQUFBO0lBRUYsT0FBTyxVQUFVO1FBQ2YsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxZQUFZLEtBQUssVUFBVSxDQUFDO1FBQzFELENBQUMsQ0FBQyxLQUFLLENBQUE7QUFDWCxDQUFDLENBQUE7QUFqR1ksUUFBQSxnQkFBZ0Isb0JBaUc1QiJ9