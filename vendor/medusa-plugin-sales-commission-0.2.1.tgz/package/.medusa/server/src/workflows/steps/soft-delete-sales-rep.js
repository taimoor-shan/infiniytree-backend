"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.softDeleteSalesRepStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const sales_commission_1 = require("../../modules/sales-commission");
/**
 * Deletes the rep. The row is kept with a deletion date, like every other
 * deleted record in Medusa: it drops out of every list and the rep's email can
 * be used again, because the email's uniqueness only covers rows not deleted.
 */
exports.softDeleteSalesRepStep = (0, workflows_sdk_1.createStep)("soft-delete-sales-rep", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.softDeleteSalesReps([input.id]);
    return new workflows_sdk_1.StepResponse({ id: input.id }, input.id);
}, async (id, { container }) => {
    if (!id) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.restoreSalesReps([id]);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic29mdC1kZWxldGUtc2FsZXMtcmVwLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9zb2Z0LWRlbGV0ZS1zYWxlcy1yZXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscUVBQTRFO0FBQzVFLHFFQUF3RTtBQUd4RTs7OztHQUlHO0FBQ1UsUUFBQSxzQkFBc0IsR0FBRyxJQUFBLDBCQUFVLEVBQzlDLHVCQUF1QixFQUN2QixLQUFLLEVBQUUsS0FBcUIsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDN0MsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQTtJQUU3QyxPQUFPLElBQUksNEJBQVksQ0FBQyxFQUFFLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQ3JELENBQUMsRUFDRCxLQUFLLEVBQUUsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUMxQixJQUFJLENBQUMsRUFBRSxFQUFFLENBQUM7UUFDUixPQUFNO0lBQ1IsQ0FBQztJQUNELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQTtBQUN0QyxDQUFDLENBQ0YsQ0FBQSJ9