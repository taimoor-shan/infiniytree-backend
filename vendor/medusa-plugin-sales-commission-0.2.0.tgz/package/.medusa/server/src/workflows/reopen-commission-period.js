"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reopenCommissionPeriodWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const reopen_commission_period_1 = require("./steps/reopen-commission-period");
exports.reopenCommissionPeriodWorkflow = (0, workflows_sdk_1.createWorkflow)("reopen-commission-period", function () {
    return new workflows_sdk_1.WorkflowResponse((0, reopen_commission_period_1.reopenCommissionPeriodStep)());
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVvcGVuLWNvbW1pc3Npb24tcGVyaW9kLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9yZW9wZW4tY29tbWlzc2lvbi1wZXJpb2QudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscUVBRzBDO0FBQzFDLCtFQUE2RTtBQUVoRSxRQUFBLDhCQUE4QixHQUFHLElBQUEsOEJBQWMsRUFDMUQsMEJBQTBCLEVBQzFCO0lBQ0UsT0FBTyxJQUFJLGdDQUFnQixDQUFDLElBQUEscURBQTBCLEdBQUUsQ0FBQyxDQUFBO0FBQzNELENBQUMsQ0FDRixDQUFBIn0=