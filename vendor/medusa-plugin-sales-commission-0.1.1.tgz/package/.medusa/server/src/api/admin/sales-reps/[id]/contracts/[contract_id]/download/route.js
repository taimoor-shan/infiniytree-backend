"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
/** Streams a stored contract; only admins reach this route. */
async function GET(req, res) {
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { data: [contract], } = await query.graph({
        entity: "sales_rep_contract",
        fields: ["id", "file_name", "mime_type", "content_base64"],
        filters: { id: req.params.contract_id, sales_rep_id: req.params.id },
    });
    if (!contract) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, `Contract ${req.params.contract_id} was not found`);
    }
    const bytes = Buffer.from(contract.content_base64, "base64");
    res.setHeader("Content-Type", contract.mime_type);
    res.setHeader("Content-Length", bytes.length);
    res.setHeader("Content-Disposition", `attachment; filename="${contract.file_name}"; filename*=UTF-8''${encodeURIComponent(contract.file_name)}`);
    res.setHeader("Cache-Control", "private, no-store");
    res.send(bytes);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLXJlcHMvW2lkXS9jb250cmFjdHMvW2NvbnRyYWN0X2lkXS9kb3dubG9hZC9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVVBLGtCQWlDQztBQXZDRCxxREFHa0M7QUFFbEMsK0RBQStEO0FBQ3hELEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQStCLEVBQy9CLEdBQW1CO0lBRW5CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFBO0lBRWhFLE1BQU0sRUFDSixJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsR0FDakIsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDcEIsTUFBTSxFQUFFLG9CQUFvQjtRQUM1QixNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxnQkFBZ0IsQ0FBQztRQUMxRCxPQUFPLEVBQUUsRUFBRSxFQUFFLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsWUFBWSxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFO0tBQ3JFLENBQUMsQ0FBQTtJQUVGLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNkLE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQzNCLFlBQVksR0FBRyxDQUFDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixDQUNuRCxDQUFBO0lBQ0gsQ0FBQztJQUVELE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGNBQWMsRUFBRSxRQUFRLENBQUMsQ0FBQTtJQUU1RCxHQUFHLENBQUMsU0FBUyxDQUFDLGNBQWMsRUFBRSxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUE7SUFDakQsR0FBRyxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUE7SUFDN0MsR0FBRyxDQUFDLFNBQVMsQ0FDWCxxQkFBcUIsRUFDckIseUJBQXlCLFFBQVEsQ0FBQyxTQUFTLHVCQUF1QixrQkFBa0IsQ0FDbEYsUUFBUSxDQUFDLFNBQVMsQ0FDbkIsRUFBRSxDQUNKLENBQUE7SUFDRCxHQUFHLENBQUMsU0FBUyxDQUFDLGVBQWUsRUFBRSxtQkFBbUIsQ0FBQyxDQUFBO0lBQ25ELEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDakIsQ0FBQyJ9