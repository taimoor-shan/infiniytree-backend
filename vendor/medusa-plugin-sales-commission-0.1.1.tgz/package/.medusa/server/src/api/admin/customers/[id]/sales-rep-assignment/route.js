"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
exports.DELETE = DELETE;
const utils_1 = require("@medusajs/framework/utils");
const assign_client_1 = require("../../../../../workflows/assign-client");
const end_client_assignment_1 = require("../../../../../workflows/end-client-assignment");
const ASSIGNMENT_FIELDS = [
    "id",
    "customer_id",
    "commission_rate",
    "starts_at",
    "ends_at",
    "created_by",
    "ended_by",
    "created_at",
    "sales_rep.id",
    "sales_rep.name",
    "sales_rep.email",
    "sales_rep.is_active",
];
/** The customer's current salesperson and their full assignment history. */
async function GET(req, res) {
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { data: history } = await query.graph({
        entity: "client_assignment",
        fields: ASSIGNMENT_FIELDS,
        filters: { customer_id: req.params.id },
        pagination: { order: { starts_at: "DESC", created_at: "DESC" } },
    });
    res.json({
        current: history.find((assignment) => assignment.ends_at === null) ?? null,
        history,
    });
}
/** Assign, move to another rep, or change the rate. */
async function POST(req, res) {
    const { result } = await (0, assign_client_1.assignClientWorkflow)(req.scope).run({
        input: {
            ...req.validatedBody,
            customer_id: req.params.id,
            actor_id: req.auth_context.actor_id,
        },
    });
    res.json({ assignment: result });
}
/** End the current assignment; orders placed afterwards earn no commission. */
async function DELETE(req, res) {
    const { result } = await (0, end_client_assignment_1.endClientAssignmentWorkflow)(req.scope).run({
        input: {
            customer_id: req.params.id,
            actor_id: req.auth_context.actor_id,
        },
    });
    res.json({ assignment: result });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2N1c3RvbWVycy9baWRdL3NhbGVzLXJlcC1hc3NpZ25tZW50L3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBeUJBLGtCQWlCQztBQUdELG9CQWFDO0FBR0Qsd0JBWUM7QUFyRUQscURBQXFFO0FBQ3JFLDBFQUE2RTtBQUM3RSwwRkFBNEY7QUFHNUYsTUFBTSxpQkFBaUIsR0FBRztJQUN4QixJQUFJO0lBQ0osYUFBYTtJQUNiLGlCQUFpQjtJQUNqQixXQUFXO0lBQ1gsU0FBUztJQUNULFlBQVk7SUFDWixVQUFVO0lBQ1YsWUFBWTtJQUNaLGNBQWM7SUFDZCxnQkFBZ0I7SUFDaEIsaUJBQWlCO0lBQ2pCLHFCQUFxQjtDQUN0QixDQUFBO0FBRUQsNEVBQTRFO0FBQ3JFLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQStCLEVBQy9CLEdBQW1CO0lBRW5CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFBO0lBRWhFLE1BQU0sRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQzFDLE1BQU0sRUFBRSxtQkFBbUI7UUFDM0IsTUFBTSxFQUFFLGlCQUFpQjtRQUN6QixPQUFPLEVBQUUsRUFBRSxXQUFXLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUU7UUFDdkMsVUFBVSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLEVBQUU7S0FDakUsQ0FBQyxDQUFBO0lBRUYsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNQLE9BQU8sRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsT0FBTyxLQUFLLElBQUksQ0FBQyxJQUFJLElBQUk7UUFDMUUsT0FBTztLQUNSLENBQUMsQ0FBQTtBQUNKLENBQUM7QUFFRCx1REFBdUQ7QUFDaEQsS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBc0QsRUFDdEQsR0FBbUI7SUFFbkIsTUFBTSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sSUFBQSxvQ0FBb0IsRUFBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDO1FBQzNELEtBQUssRUFBRTtZQUNMLEdBQUcsR0FBRyxDQUFDLGFBQWE7WUFDcEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUMxQixRQUFRLEVBQUUsR0FBRyxDQUFDLFlBQVksQ0FBQyxRQUFRO1NBQ3BDO0tBQ0YsQ0FBQyxDQUFBO0lBRUYsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFBO0FBQ2xDLENBQUM7QUFFRCwrRUFBK0U7QUFDeEUsS0FBSyxVQUFVLE1BQU0sQ0FDMUIsR0FBK0IsRUFDL0IsR0FBbUI7SUFFbkIsTUFBTSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sSUFBQSxtREFBMkIsRUFBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDO1FBQ2xFLEtBQUssRUFBRTtZQUNMLFdBQVcsRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDMUIsUUFBUSxFQUFFLEdBQUcsQ0FBQyxZQUFZLENBQUMsUUFBUTtTQUNwQztLQUNGLENBQUMsQ0FBQTtJQUVGLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQTtBQUNsQyxDQUFDIn0=