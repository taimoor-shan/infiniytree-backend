"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createSalesRepStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const sales_commission_1 = require("../../modules/sales-commission");
const client_links_1 = require("../../utils/client-links");
const sales_rep_email_1 = require("./sales-rep-email");
exports.createSalesRepStep = (0, workflows_sdk_1.createStep)("create-sales-rep", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const email = (0, sales_rep_email_1.normalizeEmail)(input.email);
    await (0, sales_rep_email_1.assertEmailAvailable)(service, email);
    const salesRep = await service.createSalesReps({
        ...input,
        name: input.name.trim(),
        email,
        payout_currency_code: input.payout_currency_code?.toLowerCase() ?? null,
    });
    // Every rep has a client link from the start
    await (0, client_links_1.makeClientLinkCode)(service, salesRep.id);
    return new workflows_sdk_1.StepResponse(await service.retrieveSalesRep(salesRep.id), salesRep.id);
}, async (salesRepId, { container }) => {
    if (!salesRepId) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.deleteSalesReps(salesRepId);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLXNhbGVzLXJlcC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3Mvc3RlcHMvY3JlYXRlLXNhbGVzLXJlcC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxRUFBNEU7QUFDNUUscUVBQXdFO0FBRXhFLDJEQUE2RDtBQUM3RCx1REFBd0U7QUFjM0QsUUFBQSxrQkFBa0IsR0FBRyxJQUFBLDBCQUFVLEVBQzFDLGtCQUFrQixFQUNsQixLQUFLLEVBQUUsS0FBOEIsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDdEQsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxLQUFLLEdBQUcsSUFBQSxnQ0FBYyxFQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUN6QyxNQUFNLElBQUEsc0NBQW9CLEVBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFBO0lBRTFDLE1BQU0sUUFBUSxHQUFHLE1BQU0sT0FBTyxDQUFDLGVBQWUsQ0FBQztRQUM3QyxHQUFHLEtBQUs7UUFDUixJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUU7UUFDdkIsS0FBSztRQUNMLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxvQkFBb0IsRUFBRSxXQUFXLEVBQUUsSUFBSSxJQUFJO0tBQ3hFLENBQUMsQ0FBQTtJQUVGLDZDQUE2QztJQUM3QyxNQUFNLElBQUEsaUNBQWtCLEVBQUMsT0FBTyxFQUFFLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUU5QyxPQUFPLElBQUksNEJBQVksQ0FBQyxNQUFNLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLEVBQUUsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQ25GLENBQUMsRUFDRCxLQUFLLEVBQUUsVUFBVSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUNsQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDaEIsT0FBTTtJQUNSLENBQUM7SUFDRCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLE9BQU8sQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDLENBQUE7QUFDM0MsQ0FBQyxDQUNGLENBQUEifQ==