"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createRepInviteStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const invite_1 = require("../../lib/invite");
const recruiting_errors_1 = require("../../lib/recruiting-errors");
const sales_commission_1 = require("../../modules/sales-commission");
const invites_1 = require("../../utils/invites");
const sales_rep_email_1 = require("./sales-rep-email");
const invalid = (message, code) => new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, message, code);
/**
 * Invites someone on a rep's behalf. The invite is an application waiting to
 * happen, not a rep: it needs the owner's approval before anything is paid.
 * One email can have one invite open at a time (the first one wins); an invite
 * whose link ran out no longer blocks it. Returns the secret link token, which
 * is not stored and goes only to the candidate's email.
 */
exports.createRepInviteStep = (0, workflows_sdk_1.createStep)("create-rep-invite", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const settings = (0, invites_1.recruitingSettings)(service);
    const now = new Date();
    const email = (0, sales_rep_email_1.normalizeEmail)(input.email);
    const recruiter = await service.retrieveSalesRep(input.recruiter_sales_rep_id);
    if (!recruiter.is_active || !recruiter.auth_identity_id) {
        throw invalid("Only a rep with portal access can invite someone", recruiting_errors_1.RECRUITING_ERRORS.RECRUITER_NOT_ALLOWED);
    }
    if (email === recruiter.email) {
        throw invalid("You can't invite yourself", recruiting_errors_1.RECRUITING_ERRORS.INVITE_SELF);
    }
    const [existingRep] = await service.listSalesReps({ email }, { take: 1, select: ["id"] });
    if (existingRep) {
        throw invalid(`${email} is already a sales rep`, recruiting_errors_1.RECRUITING_ERRORS.INVITE_ALREADY_REP);
    }
    const open = await service.listRepInvites({
        email,
        status: ["invited", "applied"],
    });
    const lapsed = open.filter((invite) => (0, invite_1.inviteState)(invite, now) === "expired");
    const blocking = open.filter((invite) => !lapsed.includes(invite));
    for (const invite of blocking) {
        if (invite.status === "applied") {
            throw invalid(`${email} has already applied and is waiting for the owner's decision`, recruiting_errors_1.RECRUITING_ERRORS.INVITE_APPLIED);
        }
        throw invite.recruiter_sales_rep_id === recruiter.id
            ? invalid(`You have already invited ${email}. Send that invitation again instead`, recruiting_errors_1.RECRUITING_ERRORS.INVITE_DUPLICATE_OWN)
            : invalid(`${email} has already been invited`, recruiting_errors_1.RECRUITING_ERRORS.INVITE_DUPLICATE_OTHER);
    }
    const waiting = (await service.listRepInvites({
        recruiter_sales_rep_id: recruiter.id,
        status: ["invited", "applied"],
    })).filter((invite) => (0, invite_1.inviteState)(invite, now) !== "expired");
    if (waiting.length >= settings.max_open_invites) {
        throw invalid(`You already have ${waiting.length} invitations waiting. Cancel one, or wait until they are answered`, recruiting_errors_1.RECRUITING_ERRORS.INVITE_LIMIT);
    }
    // The link ran out, so the email is free for a new invite
    if (lapsed.length) {
        await service.updateRepInvites(lapsed.map((invite) => ({
            id: invite.id,
            status: "canceled",
            decided_at: now,
            decision_reason: "The link expired and the email was invited again",
        })));
    }
    const { token, hash } = (0, invite_1.newInviteToken)();
    const invite = await service.createRepInvites({
        recruiter_sales_rep_id: recruiter.id,
        email,
        name: input.name.trim(),
        note: input.note?.trim() || null,
        token_hash: hash,
        status: "invited",
        expires_at: (0, invite_1.inviteExpiry)(now, settings.invite_days),
        locale: (0, invites_1.normalizeLocale)(input.locale),
        last_sent_at: now,
    });
    return new workflows_sdk_1.StepResponse({ invite, token, recruiter_name: recruiter.name }, { id: invite.id, lapsed: lapsed.map((row) => row.id) });
}, async (prior, { container }) => {
    if (!prior) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.deleteRepInvites(prior.id);
    if (prior.lapsed.length) {
        await service.updateRepInvites(prior.lapsed.map((id) => ({
            id,
            status: "invited",
            decided_at: null,
            decision_reason: null,
        })));
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLXJlcC1pbnZpdGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL3N0ZXBzL2NyZWF0ZS1yZXAtaW52aXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFEQUF1RDtBQUN2RCxxRUFBNEU7QUFDNUUsNkNBQTRFO0FBQzVFLG1FQUE2RjtBQUM3RixxRUFBd0U7QUFFeEUsaURBQXlFO0FBQ3pFLHVEQUFrRDtBQVVsRCxNQUFNLE9BQU8sR0FBRyxDQUFDLE9BQWUsRUFBRSxJQUF5QixFQUFFLEVBQUUsQ0FDN0QsSUFBSSxtQkFBVyxDQUFDLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUE7QUFFaEU7Ozs7OztHQU1HO0FBQ1UsUUFBQSxtQkFBbUIsR0FBRyxJQUFBLDBCQUFVLEVBQzNDLG1CQUFtQixFQUNuQixLQUFLLEVBQUUsS0FBK0IsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDdkQsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxRQUFRLEdBQUcsSUFBQSw0QkFBa0IsRUFBQyxPQUFPLENBQUMsQ0FBQTtJQUM1QyxNQUFNLEdBQUcsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFBO0lBQ3RCLE1BQU0sS0FBSyxHQUFHLElBQUEsZ0NBQWMsRUFBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUE7SUFFekMsTUFBTSxTQUFTLEdBQUcsTUFBTSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLHNCQUFzQixDQUFDLENBQUE7SUFDOUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLElBQUksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUN4RCxNQUFNLE9BQU8sQ0FBQyxrREFBa0QsRUFBRSxxQ0FBSyxDQUFDLHFCQUFxQixDQUFDLENBQUE7SUFDaEcsQ0FBQztJQUNELElBQUksS0FBSyxLQUFLLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUM5QixNQUFNLE9BQU8sQ0FBQywyQkFBMkIsRUFBRSxxQ0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFBO0lBQy9ELENBQUM7SUFFRCxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsTUFBTSxPQUFPLENBQUMsYUFBYSxDQUMvQyxFQUFFLEtBQUssRUFBRSxFQUNULEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUM1QixDQUFBO0lBQ0QsSUFBSSxXQUFXLEVBQUUsQ0FBQztRQUNoQixNQUFNLE9BQU8sQ0FBQyxHQUFHLEtBQUsseUJBQXlCLEVBQUUscUNBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFBO0lBQzVFLENBQUM7SUFFRCxNQUFNLElBQUksR0FBRyxNQUFNLE9BQU8sQ0FBQyxjQUFjLENBQUM7UUFDeEMsS0FBSztRQUNMLE1BQU0sRUFBRSxDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUM7S0FDL0IsQ0FBQyxDQUFBO0lBQ0YsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsSUFBQSxvQkFBVyxFQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQTtJQUM5RSxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQTtJQUNsRSxLQUFLLE1BQU0sTUFBTSxJQUFJLFFBQVEsRUFBRSxDQUFDO1FBQzlCLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUNoQyxNQUFNLE9BQU8sQ0FDWCxHQUFHLEtBQUssOERBQThELEVBQ3RFLHFDQUFLLENBQUMsY0FBYyxDQUNyQixDQUFBO1FBQ0gsQ0FBQztRQUNELE1BQU0sTUFBTSxDQUFDLHNCQUFzQixLQUFLLFNBQVMsQ0FBQyxFQUFFO1lBQ2xELENBQUMsQ0FBQyxPQUFPLENBQ0wsNEJBQTRCLEtBQUssc0NBQXNDLEVBQ3ZFLHFDQUFLLENBQUMsb0JBQW9CLENBQzNCO1lBQ0gsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEtBQUssMkJBQTJCLEVBQUUscUNBQUssQ0FBQyxzQkFBc0IsQ0FBQyxDQUFBO0lBQ2hGLENBQUM7SUFFRCxNQUFNLE9BQU8sR0FBRyxDQUNkLE1BQU0sT0FBTyxDQUFDLGNBQWMsQ0FBQztRQUMzQixzQkFBc0IsRUFBRSxTQUFTLENBQUMsRUFBRTtRQUNwQyxNQUFNLEVBQUUsQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDO0tBQy9CLENBQUMsQ0FDSCxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsSUFBQSxvQkFBVyxFQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQTtJQUM1RCxJQUFJLE9BQU8sQ0FBQyxNQUFNLElBQUksUUFBUSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDaEQsTUFBTSxPQUFPLENBQ1gsb0JBQW9CLE9BQU8sQ0FBQyxNQUFNLG1FQUFtRSxFQUNyRyxxQ0FBSyxDQUFDLFlBQVksQ0FDbkIsQ0FBQTtJQUNILENBQUM7SUFFRCwwREFBMEQ7SUFDMUQsSUFBSSxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDbEIsTUFBTSxPQUFPLENBQUMsZ0JBQWdCLENBQzVCLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDdEIsRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ2IsTUFBTSxFQUFFLFVBQW1CO1lBQzNCLFVBQVUsRUFBRSxHQUFHO1lBQ2YsZUFBZSxFQUFFLGtEQUFrRDtTQUNwRSxDQUFDLENBQUMsQ0FDSixDQUFBO0lBQ0gsQ0FBQztJQUVELE1BQU0sRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsSUFBQSx1QkFBYyxHQUFFLENBQUE7SUFDeEMsTUFBTSxNQUFNLEdBQUcsTUFBTSxPQUFPLENBQUMsZ0JBQWdCLENBQUM7UUFDNUMsc0JBQXNCLEVBQUUsU0FBUyxDQUFDLEVBQUU7UUFDcEMsS0FBSztRQUNMLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRTtRQUN2QixJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxJQUFJO1FBQ2hDLFVBQVUsRUFBRSxJQUFJO1FBQ2hCLE1BQU0sRUFBRSxTQUFTO1FBQ2pCLFVBQVUsRUFBRSxJQUFBLHFCQUFZLEVBQUMsR0FBRyxFQUFFLFFBQVEsQ0FBQyxXQUFXLENBQUM7UUFDbkQsTUFBTSxFQUFFLElBQUEseUJBQWUsRUFBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1FBQ3JDLFlBQVksRUFBRSxHQUFHO0tBQ2xCLENBQUMsQ0FBQTtJQUVGLE9BQU8sSUFBSSw0QkFBWSxDQUNyQixFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFFLFNBQVMsQ0FBQyxJQUFJLEVBQUUsRUFDakQsRUFBRSxFQUFFLEVBQUUsTUFBTSxDQUFDLEVBQUUsRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQ3ZELENBQUE7QUFDSCxDQUFDLEVBQ0QsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDN0IsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ1gsT0FBTTtJQUNSLENBQUM7SUFDRCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUE7SUFDeEMsSUFBSSxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3hCLE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUM1QixLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUN4QixFQUFFO1lBQ0YsTUFBTSxFQUFFLFNBQWtCO1lBQzFCLFVBQVUsRUFBRSxJQUFJO1lBQ2hCLGVBQWUsRUFBRSxJQUFJO1NBQ3RCLENBQUMsQ0FBQyxDQUNKLENBQUE7SUFDSCxDQUFDO0FBQ0gsQ0FBQyxDQUNGLENBQUEifQ==