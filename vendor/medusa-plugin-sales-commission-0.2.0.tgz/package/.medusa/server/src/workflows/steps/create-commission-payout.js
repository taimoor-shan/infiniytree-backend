"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCommissionPayoutStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const period_1 = require("../../lib/period");
const sales_commission_1 = require("../../modules/sales-commission");
const period_activity_1 = require("../../utils/period-activity");
const payouts_1 = require("../../utils/payouts");
const report_1 = require("../../lib/report");
/**
 * Records a bank transfer made outside the system. It counts against what is
 * payable, whichever month that was earned in.
 */
exports.createCommissionPayoutStep = (0, workflows_sdk_1.createStep)("create-commission-payout", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const rep = await service.retrieveSalesRep(input.sales_rep_id);
    const [history, approvedThrough] = await Promise.all([
        (0, period_activity_1.loadRepHistory)(container, rep.id),
        (0, period_activity_1.loadApprovedThrough)(container),
    ]);
    const { timezone } = service.getOptions();
    const { payout: draft, excess } = (0, payouts_1.draftPayout)({
        rep,
        input,
        lines: (0, report_1.allLines)(history),
        approvedThrough,
        timezone,
    });
    const bonusReason = input.bonus_reason?.trim();
    if (bonusReason && excess <= 0) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, "This payout is not above what is payable, so there is no bonus to record");
    }
    const payout = await service.createCommissionPayouts(draft);
    const bonus = bonusReason
        ? await service.createCommissionAdjustments({
            sales_rep_id: rep.id,
            currency_code: draft.currency_code,
            amount: excess,
            period: (0, period_1.toPeriod)(new Date(), timezone),
            reason: `Bonus paid with a payout: ${bonusReason}`,
            kind: "payout_bonus",
            source_id: payout.id,
            created_by: draft.created_by,
        })
        : null;
    return new workflows_sdk_1.StepResponse(payout, {
        payout_id: payout.id,
        bonus_id: bonus?.id ?? null,
    });
}, async (created, { container }) => {
    if (!created) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    if (created.bonus_id) {
        await service.deleteCommissionAdjustments(created.bonus_id);
    }
    await service.deleteCommissionPayouts(created.payout_id);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLWNvbW1pc3Npb24tcGF5b3V0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9jcmVhdGUtY29tbWlzc2lvbi1wYXlvdXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQXVEO0FBQ3ZELHFFQUE0RTtBQUM1RSw2Q0FBMkM7QUFDM0MscUVBQXdFO0FBRXhFLGlFQUFpRjtBQUNqRixpREFBOEQ7QUFDOUQsNkNBQTJDO0FBVTNDOzs7R0FHRztBQUNVLFFBQUEsMEJBQTBCLEdBQUcsSUFBQSwwQkFBVSxFQUNsRCwwQkFBMEIsRUFDMUIsS0FBSyxFQUFFLEtBQXNDLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQzlELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sR0FBRyxHQUFHLE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQTtJQUM5RCxNQUFNLENBQUMsT0FBTyxFQUFFLGVBQWUsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUNuRCxJQUFBLGdDQUFjLEVBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDakMsSUFBQSxxQ0FBbUIsRUFBQyxTQUFTLENBQUM7S0FDL0IsQ0FBQyxDQUFBO0lBQ0YsTUFBTSxFQUFFLFFBQVEsRUFBRSxHQUFHLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQTtJQUV6QyxNQUFNLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFBLHFCQUFXLEVBQUM7UUFDNUMsR0FBRztRQUNILEtBQUs7UUFDTCxLQUFLLEVBQUUsSUFBQSxpQkFBUSxFQUFDLE9BQU8sQ0FBQztRQUN4QixlQUFlO1FBQ2YsUUFBUTtLQUNULENBQUMsQ0FBQTtJQUVGLE1BQU0sV0FBVyxHQUFHLEtBQUssQ0FBQyxZQUFZLEVBQUUsSUFBSSxFQUFFLENBQUE7SUFDOUMsSUFBSSxXQUFXLElBQUksTUFBTSxJQUFJLENBQUMsRUFBRSxDQUFDO1FBQy9CLE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQzlCLDBFQUEwRSxDQUMzRSxDQUFBO0lBQ0gsQ0FBQztJQUVELE1BQU0sTUFBTSxHQUFHLE1BQU0sT0FBTyxDQUFDLHVCQUF1QixDQUFDLEtBQUssQ0FBQyxDQUFBO0lBQzNELE1BQU0sS0FBSyxHQUFHLFdBQVc7UUFDdkIsQ0FBQyxDQUFDLE1BQU0sT0FBTyxDQUFDLDJCQUEyQixDQUFDO1lBQ3hDLFlBQVksRUFBRSxHQUFHLENBQUMsRUFBRTtZQUNwQixhQUFhLEVBQUUsS0FBSyxDQUFDLGFBQWE7WUFDbEMsTUFBTSxFQUFFLE1BQU07WUFDZCxNQUFNLEVBQUUsSUFBQSxpQkFBUSxFQUFDLElBQUksSUFBSSxFQUFFLEVBQUUsUUFBUSxDQUFDO1lBQ3RDLE1BQU0sRUFBRSw2QkFBNkIsV0FBVyxFQUFFO1lBQ2xELElBQUksRUFBRSxjQUFjO1lBQ3BCLFNBQVMsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNwQixVQUFVLEVBQUUsS0FBSyxDQUFDLFVBQVU7U0FDN0IsQ0FBQztRQUNKLENBQUMsQ0FBQyxJQUFJLENBQUE7SUFFUixPQUFPLElBQUksNEJBQVksQ0FBQyxNQUFNLEVBQUU7UUFDOUIsU0FBUyxFQUFFLE1BQU0sQ0FBQyxFQUFFO1FBQ3BCLFFBQVEsRUFBRSxLQUFLLEVBQUUsRUFBRSxJQUFJLElBQUk7S0FDNUIsQ0FBQyxDQUFBO0FBQ0osQ0FBQyxFQUNELEtBQUssRUFBRSxPQUFPLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQy9CLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNiLE9BQU07SUFDUixDQUFDO0lBQ0QsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsSUFBSSxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDckIsTUFBTSxPQUFPLENBQUMsMkJBQTJCLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBQzdELENBQUM7SUFDRCxNQUFNLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUE7QUFDMUQsQ0FBQyxDQUNGLENBQUEifQ==