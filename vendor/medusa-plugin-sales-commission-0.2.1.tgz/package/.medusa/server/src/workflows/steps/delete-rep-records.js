"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteRepRecordsStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const sales_commission_1 = require("../../modules/sales-commission");
const unique = (ids) => [...new Set(ids)];
/**
 * Takes away what belongs to a rep who is being deleted: invitations nobody has
 * answered are withdrawn, and the rep's invitations, the application that made
 * them a rep, their ended referrals and client assignments and their contracts
 * are deleted with them. What the rep's recruits became stays: an invitation
 * that was approved remains as the record of where that rep came from.
 *
 * Nothing here is money: the deletion was refused for a rep who has any. The
 * rows are soft-deleted, like the rep, and put back if a later step fails.
 */
exports.deleteRepRecordsStep = (0, workflows_sdk_1.createStep)("delete-rep-records", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const now = new Date();
    const [sent, createdFrom, asReferrer, asReferred, assignments, contracts] = await Promise.all([
        service.listRepInvites({ recruiter_sales_rep_id: input.id }),
        service.listRepInvites({ sales_rep_id: input.id }),
        service.listRepReferrals({ referrer_sales_rep_id: input.id }),
        service.listRepReferrals({ referred_sales_rep_id: input.id }),
        service.listClientAssignments({ sales_rep_id: input.id }),
        service.listSalesRepContracts({ sales_rep_id: input.id }),
    ]);
    // Nobody has answered these: the links stop working
    const open = sent.filter((invite) => invite.status === "invited");
    const previous = open.map((invite) => ({
        id: invite.id,
        status: invite.status,
        decided_by: invite.decided_by,
        decided_at: invite.decided_at,
        decision_reason: invite.decision_reason,
    }));
    for (const invite of open) {
        await service.updateRepInvites({
            id: invite.id,
            status: "canceled",
            decided_by: input.deleted_by ?? null,
            decided_at: now,
            decision_reason: "The rep who invited them was deleted",
        });
    }
    const inviteIds = unique([
        // Approved ones stay: they are where an existing rep came from
        ...sent
            .filter((invite) => invite.status !== "approved")
            .map((invite) => invite.id),
        ...createdFrom.map((invite) => invite.id),
    ]);
    const undo = {
        invites: previous,
        invite_ids: inviteIds,
        referral_ids: unique([...asReferrer, ...asReferred].map((row) => row.id)),
        assignment_ids: assignments.map((row) => row.id),
        contract_ids: contracts.map((row) => row.id),
    };
    if (undo.invite_ids.length) {
        await service.softDeleteRepInvites(undo.invite_ids);
    }
    if (undo.referral_ids.length) {
        await service.softDeleteRepReferrals(undo.referral_ids);
    }
    if (undo.assignment_ids.length) {
        await service.softDeleteClientAssignments(undo.assignment_ids);
    }
    if (undo.contract_ids.length) {
        await service.softDeleteSalesRepContracts(undo.contract_ids);
    }
    return new workflows_sdk_1.StepResponse({
        withdrawn_invites: open.length,
        removed: {
            invites: undo.invite_ids.length,
            referrals: undo.referral_ids.length,
            assignments: undo.assignment_ids.length,
            contracts: undo.contract_ids.length,
        },
    }, undo);
}, async (undo, { container }) => {
    if (!undo) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    if (undo.invite_ids.length) {
        await service.restoreRepInvites(undo.invite_ids);
    }
    if (undo.referral_ids.length) {
        await service.restoreRepReferrals(undo.referral_ids);
    }
    if (undo.assignment_ids.length) {
        await service.restoreClientAssignments(undo.assignment_ids);
    }
    if (undo.contract_ids.length) {
        await service.restoreSalesRepContracts(undo.contract_ids);
    }
    for (const invite of undo.invites) {
        await service.updateRepInvites({
            id: invite.id,
            status: invite.status,
            decided_by: invite.decided_by,
            decided_at: invite.decided_at ? new Date(invite.decided_at) : null,
            decision_reason: invite.decision_reason,
        });
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVsZXRlLXJlcC1yZWNvcmRzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9kZWxldGUtcmVwLXJlY29yZHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscUVBQTRFO0FBQzVFLHFFQUF3RTtBQW1CeEUsTUFBTSxNQUFNLEdBQUcsQ0FBQyxHQUFhLEVBQUUsRUFBRSxDQUFDLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFBO0FBRW5EOzs7Ozs7Ozs7R0FTRztBQUNVLFFBQUEsb0JBQW9CLEdBQUcsSUFBQSwwQkFBVSxFQUM1QyxvQkFBb0IsRUFDcEIsS0FBSyxFQUFFLEtBQWlELEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQ3pFLE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sR0FBRyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUE7SUFFdEIsTUFBTSxDQUFDLElBQUksRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRSxXQUFXLEVBQUUsU0FBUyxDQUFDLEdBQ3ZFLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUNoQixPQUFPLENBQUMsY0FBYyxDQUFDLEVBQUUsc0JBQXNCLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRSxDQUFDO1FBQzVELE9BQU8sQ0FBQyxjQUFjLENBQUMsRUFBRSxZQUFZLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRSxDQUFDO1FBQ2xELE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLHFCQUFxQixFQUFFLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQztRQUM3RCxPQUFPLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxxQkFBcUIsRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFLENBQUM7UUFDN0QsT0FBTyxDQUFDLHFCQUFxQixDQUFDLEVBQUUsWUFBWSxFQUFFLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQztRQUN6RCxPQUFPLENBQUMscUJBQXFCLENBQUMsRUFBRSxZQUFZLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRSxDQUFDO0tBQzFELENBQUMsQ0FBQTtJQUVKLG9EQUFvRDtJQUNwRCxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxLQUFLLFNBQVMsQ0FBQyxDQUFBO0lBQ2pFLE1BQU0sUUFBUSxHQUFxQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ3ZELEVBQUUsRUFBRSxNQUFNLENBQUMsRUFBRTtRQUNiLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtRQUNyQixVQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVU7UUFDN0IsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO1FBQzdCLGVBQWUsRUFBRSxNQUFNLENBQUMsZUFBZTtLQUN4QyxDQUFDLENBQUMsQ0FBQTtJQUNILEtBQUssTUFBTSxNQUFNLElBQUksSUFBSSxFQUFFLENBQUM7UUFDMUIsTUFBTSxPQUFPLENBQUMsZ0JBQWdCLENBQUM7WUFDN0IsRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ2IsTUFBTSxFQUFFLFVBQVU7WUFDbEIsVUFBVSxFQUFFLEtBQUssQ0FBQyxVQUFVLElBQUksSUFBSTtZQUNwQyxVQUFVLEVBQUUsR0FBRztZQUNmLGVBQWUsRUFBRSxzQ0FBc0M7U0FDeEQsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELE1BQU0sU0FBUyxHQUFHLE1BQU0sQ0FBQztRQUN2QiwrREFBK0Q7UUFDL0QsR0FBRyxJQUFJO2FBQ0osTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxLQUFLLFVBQVUsQ0FBQzthQUNoRCxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFDN0IsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO0tBQzFDLENBQUMsQ0FBQTtJQUNGLE1BQU0sSUFBSSxHQUFTO1FBQ2pCLE9BQU8sRUFBRSxRQUFRO1FBQ2pCLFVBQVUsRUFBRSxTQUFTO1FBQ3JCLFlBQVksRUFBRSxNQUFNLENBQUMsQ0FBQyxHQUFHLFVBQVUsRUFBRSxHQUFHLFVBQVUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3pFLGNBQWMsRUFBRSxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO1FBQ2hELFlBQVksRUFBRSxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO0tBQzdDLENBQUE7SUFFRCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDM0IsTUFBTSxPQUFPLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFBO0lBQ3JELENBQUM7SUFDRCxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDN0IsTUFBTSxPQUFPLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFBO0lBQ3pELENBQUM7SUFDRCxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDL0IsTUFBTSxPQUFPLENBQUMsMkJBQTJCLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFBO0lBQ2hFLENBQUM7SUFDRCxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDN0IsTUFBTSxPQUFPLENBQUMsMkJBQTJCLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFBO0lBQzlELENBQUM7SUFFRCxPQUFPLElBQUksNEJBQVksQ0FDckI7UUFDRSxpQkFBaUIsRUFBRSxJQUFJLENBQUMsTUFBTTtRQUM5QixPQUFPLEVBQUU7WUFDUCxPQUFPLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNO1lBQy9CLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU07WUFDbkMsV0FBVyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTTtZQUN2QyxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNO1NBQ3BDO0tBQ0YsRUFDRCxJQUFJLENBQ0wsQ0FBQTtBQUNILENBQUMsRUFDRCxLQUFLLEVBQUUsSUFBSSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUM1QixJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDVixPQUFNO0lBQ1IsQ0FBQztJQUNELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUVELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUMzQixNQUFNLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUE7SUFDbEQsQ0FBQztJQUNELElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUM3QixNQUFNLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUE7SUFDdEQsQ0FBQztJQUNELElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUMvQixNQUFNLE9BQU8sQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUE7SUFDN0QsQ0FBQztJQUNELElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUM3QixNQUFNLE9BQU8sQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUE7SUFDM0QsQ0FBQztJQUNELEtBQUssTUFBTSxNQUFNLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ2xDLE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUFDO1lBQzdCLEVBQUUsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNiLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBbUI7WUFDbEMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO1lBQzdCLFVBQVUsRUFBRSxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7WUFDbEUsZUFBZSxFQUFFLE1BQU0sQ0FBQyxlQUFlO1NBQ3hDLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDLENBQ0YsQ0FBQSJ9