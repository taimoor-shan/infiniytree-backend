"use strict";
const jsxRuntime = require("react/jsx-runtime");
const adminSdk = require("@medusajs/admin-sdk");
const icons = require("@medusajs/icons");
const ui = require("@medusajs/ui");
const reactQuery = require("@tanstack/react-query");
const react = require("react");
const reactRouterDom = require("react-router-dom");
const Medusa = require("@medusajs/js-sdk");
const _interopDefault = (e) => e && e.__esModule ? e : { default: e };
const Medusa__default = /* @__PURE__ */ _interopDefault(Medusa);
const sdk = new Medusa__default.default({
  baseUrl: "/",
  debug: false,
  auth: {
    type: "session"
  }
});
const TIME_ZONE = "Europe/Budapest";
const ZERO_DECIMAL_CURRENCIES = /* @__PURE__ */ new Set([
  "HUF",
  "JPY",
  "KRW",
  "TWD",
  "VND",
  "CLP",
  "PYG",
  "UGX",
  "RWF",
  "UZS",
  "KES"
]);
const CURRENCIES = ["eur", "huf"];
const formatMoney = (amount, currencyCode) => {
  const currency = currencyCode.toUpperCase();
  const decimals2 = ZERO_DECIMAL_CURRENCIES.has(currency) ? 0 : 2;
  return new Intl.NumberFormat("en-GB", {
    style: "currency",
    currency,
    minimumFractionDigits: decimals2,
    maximumFractionDigits: decimals2
  }).format(amount);
};
const formatDate = (date) => new Intl.DateTimeFormat("en-GB", {
  timeZone: TIME_ZONE,
  year: "numeric",
  month: "short",
  day: "numeric"
}).format(new Date(date));
const formatSize = (bytes) => bytes < 1024 * 1024 ? `${Math.max(1, Math.round(bytes / 1024))} KB` : `${(bytes / 1024 / 1024).toFixed(1)} MB`;
const today = () => new Intl.DateTimeFormat("en-CA", {
  timeZone: TIME_ZONE,
  year: "numeric",
  month: "2-digit",
  day: "2-digit"
}).format(/* @__PURE__ */ new Date());
const recentPeriods = (count = 24) => {
  const [year, month] = today().split("-").map(Number);
  return Array.from({ length: count }, (_, i) => {
    const date = new Date(Date.UTC(year, month - 1 - i, 1));
    return {
      value: date.toISOString().slice(0, 7),
      label: new Intl.DateTimeFormat("en-GB", {
        timeZone: "UTC",
        month: "long",
        year: "numeric"
      }).format(date)
    };
  });
};
const currentPeriod = () => recentPeriods(1)[0].value;
const STATUS_BADGES = {
  paid: { label: "Settled", color: "green" },
  partial: { label: "Partly paid", color: "orange" },
  unpaid: { label: "Owed", color: "red" },
  overpaid: { label: "Paid ahead", color: "orange" },
  none: { label: "Nothing due", color: "grey" }
};
const LINE_BADGES = {
  earned: { label: "Earned", color: "blue" },
  payable: { label: "Payable", color: "green" },
  reversed: { label: "Reversed", color: "orange" },
  adjustment: { label: "Adjustment", color: "grey" },
  paid: { label: "Paid", color: "green" }
};
const monthLabel = (period) => new Intl.DateTimeFormat("en-GB", {
  timeZone: "UTC",
  month: "long",
  year: "numeric"
}).format(/* @__PURE__ */ new Date(`${period}-01T00:00:00Z`));
const currencyStep = (currencyCode) => ZERO_DECIMAL_CURRENCIES.has(currencyCode.toUpperCase()) ? "1" : "0.01";
const currentYear = () => today().slice(0, 4);
const clientName = (customer) => (customer == null ? void 0 : customer.company_name) || [customer == null ? void 0 : customer.first_name, customer == null ? void 0 : customer.last_name].filter(Boolean).join(" ") || (customer == null ? void 0 : customer.email) || "Unknown client";
const errorMessage = (error) => error instanceof Error ? error.message : "Something went wrong";
const applicationBadge = (application) => {
  if (application.status === "invited" && application.expired) {
    return { label: "Link expired", color: "grey" };
  }
  const badges = {
    invited: { label: "Invited", color: "blue" },
    applied: { label: "Waiting for review", color: "orange" },
    approved: { label: "Approved", color: "green" },
    declined: { label: "Declined", color: "red" },
    canceled: { label: "Canceled", color: "grey" }
  };
  return badges[application.status];
};
const level2Duration = (months) => months ? `${months} months from approval` : "Until I end it";
const Loading = () => /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex justify-center p-6", children: /* @__PURE__ */ jsxRuntime.jsx(icons.Spinner, { className: "text-ui-fg-interactive animate-spin" }) });
const CustomerSalesRepWidget = ({
  data: customer
}) => {
  var _a, _b;
  const [open, setOpen] = react.useState(false);
  const [repId, setRepId] = react.useState("");
  const [rate, setRate] = react.useState("");
  const queryClient = reactQuery.useQueryClient();
  const prompt = ui.usePrompt();
  const queryKey = ["customer-sales-rep", customer.id];
  const { data, isLoading } = reactQuery.useQuery({
    queryKey,
    queryFn: () => sdk.client.fetch(
      `/admin/customers/${customer.id}/sales-rep-assignment`
    )
  });
  const { data: reps } = reactQuery.useQuery({
    queryKey: ["sales-reps", "active-options"],
    queryFn: () => sdk.client.fetch("/admin/sales-reps", {
      query: { is_active: "true", limit: 200, order: "name" }
    }),
    enabled: open
  });
  const refresh = () => {
    queryClient.invalidateQueries({ queryKey });
    queryClient.invalidateQueries({ queryKey: ["sales-rep-clients"] });
  };
  const assign = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/customers/${customer.id}/sales-rep-assignment`, {
      method: "POST",
      body: { sales_rep_id: repId, commission_rate: Number(rate) }
    }),
    onSuccess: () => {
      refresh();
      ui.toast.success("Sales rep saved");
      setOpen(false);
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const end = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/customers/${customer.id}/sales-rep-assignment`, {
      method: "DELETE"
    }),
    onSuccess: () => {
      refresh();
      ui.toast.success("Assignment ended");
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const confirmEnd = async () => {
    const confirmed = await prompt({
      title: "End assignment?",
      description: "Orders placed today or later won't earn commission. Earlier orders keep theirs.",
      confirmText: "End assignment",
      cancelText: "Cancel"
    });
    if (confirmed) {
      end.mutate();
    }
  };
  const current = data == null ? void 0 : data.current;
  const past = (data == null ? void 0 : data.history.filter((a) => a.ends_at !== null)) ?? [];
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h2", children: "Sales rep" }),
      /* @__PURE__ */ jsxRuntime.jsxs(
        ui.Button,
        {
          size: "small",
          variant: "secondary",
          onClick: () => {
            var _a2;
            setRepId(((_a2 = current == null ? void 0 : current.sales_rep) == null ? void 0 : _a2.id) ?? "");
            setRate(current ? String(current.commission_rate) : "");
            setOpen(true);
          },
          children: [
            /* @__PURE__ */ jsxRuntime.jsx(icons.PencilSquare, {}),
            current ? "Change" : "Assign"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex flex-col gap-y-1 px-6 py-4", children: isLoading ? /* @__PURE__ */ jsxRuntime.jsx(Loading, {}) : current ? /* @__PURE__ */ jsxRuntime.jsxs(jsxRuntime.Fragment, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(
        reactRouterDom.Link,
        {
          to: `/sales-reps/${(_a = current.sales_rep) == null ? void 0 : _a.id}`,
          className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
          children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", children: (_b = current.sales_rep) == null ? void 0 : _b.name })
        }
      ),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
        current.commission_rate,
        "% commission since",
        " ",
        formatDate(current.starts_at)
      ] }),
      /* @__PURE__ */ jsxRuntime.jsx("div", { children: /* @__PURE__ */ jsxRuntime.jsx(
        ui.Button,
        {
          size: "small",
          variant: "transparent",
          className: "-ml-3 mt-1",
          isLoading: end.isPending,
          onClick: confirmEnd,
          children: "End assignment"
        }
      ) })
    ] }) : /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "No sales rep assigned. Orders earn no commission." }) }),
    past.length > 0 && /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", children: "History" }),
      past.map((a) => {
        var _a2;
        return /* @__PURE__ */ jsxRuntime.jsxs(
          ui.Text,
          {
            size: "small",
            leading: "compact",
            className: "text-ui-fg-subtle",
            children: [
              (_a2 = a.sales_rep) == null ? void 0 : _a2.name,
              " · ",
              a.commission_rate,
              "% ·",
              " ",
              formatDate(a.starts_at),
              " – ",
              formatDate(a.ends_at)
            ]
          },
          a.id
        );
      })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer, { open, onOpenChange: setOpen, children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Content, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Header, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Title, { children: "Sales rep and commission rate" }) }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: "Takes effect from the start of today (Budapest time), so orders placed earlier today count too. Earlier days keep the rep and rate they were placed with." }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Sales rep" }),
          /* @__PURE__ */ jsxRuntime.jsxs(ui.Select, { value: repId, onValueChange: setRepId, children: [
            /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Value, { placeholder: "Choose a sales rep" }) }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Content, { children: ((reps == null ? void 0 : reps.sales_reps) ?? []).map((rep) => /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: rep.id, children: rep.name }, rep.id)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "commission-rate", children: "Commission rate (%)" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Input,
            {
              id: "commission-rate",
              type: "number",
              min: 0,
              max: 100,
              step: "0.01",
              value: rate,
              onChange: (e) => setRate(e.target.value)
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Footer, { children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", disabled: assign.isPending, children: "Cancel" }) }),
        /* @__PURE__ */ jsxRuntime.jsx(
          ui.Button,
          {
            size: "small",
            disabled: !repId || rate === "",
            isLoading: assign.isPending,
            onClick: () => assign.mutate(),
            children: "Save"
          }
        )
      ] })
    ] }) })
  ] });
};
adminSdk.defineWidgetConfig({
  zone: "customer.details.side.after"
});
const EMPTY$2 = { name: "", email: "", phone: "", notes: "", payout: "as-earned" };
const CreateSalesRepModal = () => {
  const [open, setOpen] = react.useState(false);
  const [form, setForm] = react.useState(EMPTY$2);
  const [errors, setErrors] = react.useState({});
  const queryClient = reactQuery.useQueryClient();
  const navigate = reactRouterDom.useNavigate();
  const create = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch("/admin/sales-reps", {
      method: "POST",
      body: {
        name: form.name,
        email: form.email,
        phone: form.phone || null,
        notes: form.notes || null,
        payout_currency_code: form.payout === "as-earned" ? null : form.payout
      }
    }),
    onSuccess: ({ sales_rep }) => {
      queryClient.invalidateQueries({ queryKey: ["sales-reps"] });
      ui.toast.success(`${sales_rep.name} was added`);
      setOpen(false);
      setForm(EMPTY$2);
      navigate(`/sales-reps/${sales_rep.id}`);
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const submit = () => {
    const next = {};
    if (!form.name.trim()) next.name = "Name is required";
    if (!/^\S+@\S+\.\S+$/.test(form.email.trim())) next.email = "Enter a valid email";
    setErrors(next);
    if (!Object.keys(next).length) {
      create.mutate();
    }
  };
  const field = (key) => ({
    value: form[key],
    onChange: (e) => {
      setForm({ ...form, [key]: e.target.value });
      setErrors({ ...errors, [key]: void 0 });
    }
  });
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.FocusModal, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Trigger, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", children: "Create" }) }),
    /* @__PURE__ */ jsxRuntime.jsxs(ui.FocusModal.Content, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Header, { children: /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-end gap-x-2", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", disabled: create.isPending, children: "Cancel" }) }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", onClick: submit, isLoading: create.isPending, children: "Save" })
      ] }) }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Body, { className: "flex flex-1 flex-col items-center overflow-y-auto py-16", children: /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex w-full max-w-lg flex-col gap-y-6", children: [
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-1", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Title, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { children: "Create sales rep" }) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Description, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: "Add a salesperson. You can assign clients and upload their contract afterwards." }) })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "rep-name", children: "Name" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Input, { id: "rep-name", ...field("name") }),
          errors.name && /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-error", children: errors.name })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "rep-email", children: "Email" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Input, { id: "rep-email", type: "email", ...field("email") }),
          errors.email && /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-error", children: errors.email })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "rep-phone", children: "Phone (optional)" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Input, { id: "rep-phone", ...field("phone") })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Paid in" }),
          /* @__PURE__ */ jsxRuntime.jsxs(
            ui.Select,
            {
              value: form.payout,
              onValueChange: (value) => setForm({ ...form, payout: value }),
              children: [
                /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Value, {}) }),
                /* @__PURE__ */ jsxRuntime.jsxs(ui.Select.Content, { children: [
                  /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: "as-earned", children: "Each currency as earned" }),
                  /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: "eur", children: "EUR" }),
                  /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: "huf", children: "HUF" })
                ] })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: "Choose one currency to get a single balance and one payout. Commission in the other currency is converted when it is earned." })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "rep-notes", children: "Notes (optional)" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Textarea, { id: "rep-notes", ...field("notes") })
        ] })
      ] }) })
    ] })
  ] });
};
const PAGE_SIZE$1 = 20;
const HIDE_INACTIVE_KEY = "sales-reps-hide-inactive";
const readHideInactive = () => {
  try {
    return localStorage.getItem(HIDE_INACTIVE_KEY) === "1";
  } catch {
    return false;
  }
};
const columnHelper$1 = ui.createDataTableColumnHelper();
const buildColumns = (balances) => [
  columnHelper$1.accessor("name", { header: "Name" }),
  columnHelper$1.accessor("email", { header: "Email" }),
  columnHelper$1.accessor("payout_currency_code", {
    header: "Paid in",
    cell: ({ getValue }) => getValue() ? getValue().toUpperCase() : "As earned"
  }),
  columnHelper$1.display({
    id: "payable",
    header: "Payable now",
    cell: ({ row }) => {
      const payable = (balances[row.original.id] ?? []).filter((b) => b.payable > 0);
      return payable.length ? payable.map((b) => formatMoney(b.payable, b.currency_code)).join(", ") : "-";
    }
  }),
  columnHelper$1.accessor("is_active", {
    header: "Status",
    cell: ({ getValue }) => /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: getValue() ? "green" : "grey", children: getValue() ? "Active" : "Inactive" })
  })
];
const SalesRepsPage = () => {
  const navigate = reactRouterDom.useNavigate();
  const [search, setSearch] = react.useState("");
  const [hideInactive, setHideInactive] = react.useState(readHideInactive);
  const [pagination, setPagination] = react.useState({
    pageIndex: 0,
    pageSize: PAGE_SIZE$1
  });
  const offset = pagination.pageIndex * PAGE_SIZE$1;
  const changeHideInactive = (hide) => {
    setHideInactive(hide);
    setPagination((current) => ({ ...current, pageIndex: 0 }));
    try {
      localStorage.setItem(HIDE_INACTIVE_KEY, hide ? "1" : "0");
    } catch {
    }
  };
  const { data: balanceData } = reactQuery.useQuery({
    queryKey: ["rep-balances"],
    queryFn: () => sdk.client.fetch("/admin/sales-commission/balances")
  });
  const columns2 = react.useMemo(
    () => buildColumns((balanceData == null ? void 0 : balanceData.balances) ?? {}),
    [balanceData]
  );
  const { data: applicationData } = reactQuery.useQuery({
    queryKey: ["applications", "waiting"],
    queryFn: () => sdk.client.fetch("/admin/sales-commission/applications", {
      query: { status: "applied", limit: 1 }
    })
  });
  const waiting = (applicationData == null ? void 0 : applicationData.counts.applied) ?? 0;
  const { data, isLoading } = reactQuery.useQuery({
    queryKey: ["sales-reps", offset, search, hideInactive],
    queryFn: () => sdk.client.fetch(
      "/admin/sales-reps",
      {
        query: {
          limit: PAGE_SIZE$1,
          offset,
          order: "name",
          q: search || void 0,
          is_active: hideInactive ? "true" : void 0
        }
      }
    ),
    placeholderData: reactQuery.keepPreviousData
  });
  const table = ui.useDataTable({
    data: (data == null ? void 0 : data.sales_reps) ?? [],
    columns: columns2,
    getRowId: (rep) => rep.id,
    rowCount: (data == null ? void 0 : data.count) ?? 0,
    isLoading,
    search: { state: search, onSearchChange: setSearch },
    pagination: { state: pagination, onPaginationChange: setPagination },
    onRowClick: (_, rep) => navigate(`/sales-reps/${rep.id}`)
  });
  return /* @__PURE__ */ jsxRuntime.jsx(ui.Container, { className: "divide-y p-0", children: /* @__PURE__ */ jsxRuntime.jsxs(ui.DataTable, { instance: table, children: [
    /* @__PURE__ */ jsxRuntime.jsxs(ui.DataTable.Toolbar, { className: "flex flex-col items-start justify-between gap-2 px-6 py-4 xl:flex-row xl:items-center", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { children: "Sales Reps" }),
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2 pr-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Switch,
            {
              id: "hide-inactive",
              checked: hideInactive,
              onCheckedChange: changeHideInactive
            }
          ),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Label,
            {
              htmlFor: "hide-inactive",
              size: "small",
              weight: "plus",
              className: "whitespace-nowrap",
              children: "Hide inactive"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.DataTable.Search, { placeholder: "Search by name or email" }),
        /* @__PURE__ */ jsxRuntime.jsx(
          ui.Button,
          {
            size: "small",
            variant: "secondary",
            className: "whitespace-nowrap",
            asChild: true,
            children: /* @__PURE__ */ jsxRuntime.jsxs(reactRouterDom.Link, { to: "/sales-reps/applications", children: [
              "Applications",
              waiting > 0 ? ` (${waiting})` : ""
            ] })
          }
        ),
        /* @__PURE__ */ jsxRuntime.jsx(
          ui.Button,
          {
            size: "small",
            variant: "secondary",
            className: "whitespace-nowrap",
            asChild: true,
            children: /* @__PURE__ */ jsxRuntime.jsx(reactRouterDom.Link, { to: "/sales-reps/payment-run", children: "Payment run" })
          }
        ),
        /* @__PURE__ */ jsxRuntime.jsx(
          ui.Button,
          {
            size: "small",
            variant: "secondary",
            className: "whitespace-nowrap",
            asChild: true,
            children: /* @__PURE__ */ jsxRuntime.jsx(reactRouterDom.Link, { to: "/sales-reps/report", children: "Monthly report" })
          }
        ),
        /* @__PURE__ */ jsxRuntime.jsx(CreateSalesRepModal, {})
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx(ui.DataTable.Table, {}),
    /* @__PURE__ */ jsxRuntime.jsx(ui.DataTable.Pagination, {})
  ] }) });
};
const config$3 = adminSdk.defineRouteConfig({
  label: "Sales Reps",
  icon: icons.Users
});
const Metric = ({
  label,
  value,
  hint,
  tone = "base"
}) => /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "bg-ui-bg-subtle border-ui-border-base flex flex-col gap-y-1 rounded-lg border px-4 py-3", children: [
  /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "xsmall", leading: "compact", className: "text-ui-fg-subtle", children: label }),
  /* @__PURE__ */ jsxRuntime.jsx(
    ui.Text,
    {
      size: "xlarge",
      leading: "compact",
      weight: "plus",
      className: tone === "warn" ? "text-ui-tag-orange-text" : "text-ui-fg-base",
      children: value
    }
  ),
  hint && /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "xsmall", leading: "compact", className: "text-ui-fg-muted", children: hint })
] });
const EMPTY$1 = (currency_code) => ({
  currency_code,
  earned: 0,
  paid: 0,
  balance: 0,
  approved_earned: 0,
  open_earned: 0,
  payable: 0,
  to_recover: 0
});
const currencyCodes = (data) => [
  .../* @__PURE__ */ new Set([
    ...data.balances.map((b) => b.currency_code),
    ...data.pending.map((p) => p.currency_code)
  ])
].sort();
const BalanceSection = ({ repId }) => {
  const { data, isLoading } = reactQuery.useQuery({
    queryKey: ["sales-rep-balance", repId],
    queryFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/balance`)
  });
  const year = currentYear();
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col items-start justify-between gap-1 px-6 py-4 md:flex-row md:items-center", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h2", children: "Balance" }),
      data && /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: data.approved_through ? `Months approved through ${monthLabel(data.approved_through)}` : "No month approved yet" })
    ] }),
    isLoading || !data ? /* @__PURE__ */ jsxRuntime.jsx(Loading, {}) : data.balances.length === 0 && data.pending.length === 0 ? /* @__PURE__ */ jsxRuntime.jsx("div", { className: "px-6 py-4", children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Nothing earned or paid yet." }) }) : currencyCodes(data).map((currency) => {
      const balance = data.balances.find((b) => b.currency_code === currency) ?? EMPTY$1(currency);
      const pending = data.pending.find((p) => p.currency_code === currency);
      const money = (amount) => formatMoney(amount, currency);
      return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-3 px-6 py-4", children: [
        /* @__PURE__ */ jsxRuntime.jsx("div", { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: "grey", children: currency.toUpperCase() }) }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "grid grid-cols-2 gap-3 md:grid-cols-3", children: [
          /* @__PURE__ */ jsxRuntime.jsx(
            Metric,
            {
              label: "Pending",
              value: money((pending == null ? void 0 : pending.amount) ?? 0),
              hint: pending ? `${pending.orders} ${pending.orders === 1 ? "order" : "orders"} not paid yet` : "No unpaid orders"
            }
          ),
          /* @__PURE__ */ jsxRuntime.jsx(
            Metric,
            {
              label: "Payable now",
              value: money(balance.payable),
              hint: "Due on the next run"
            }
          ),
          /* @__PURE__ */ jsxRuntime.jsx(
            Metric,
            {
              label: "Earned, not payable yet",
              value: money(balance.open_earned),
              hint: "Waits for its month to be approved"
            }
          ),
          /* @__PURE__ */ jsxRuntime.jsx(
            Metric,
            {
              label: `Paid in ${year}`,
              value: money(data.paid_this_year[currency] ?? 0)
            }
          ),
          /* @__PURE__ */ jsxRuntime.jsx(
            Metric,
            {
              label: "To recover",
              value: money(balance.to_recover),
              hint: balance.to_recover > 0 ? "Paid ahead. Netted from what they earn next" : "Nothing owed back",
              tone: balance.to_recover > 0 ? "warn" : "base"
            }
          )
        ] })
      ] }, currency);
    })
  ] });
};
const ClientsSection = ({ repId }) => {
  const { data, isLoading } = reactQuery.useQuery({
    queryKey: ["sales-rep-clients", repId],
    queryFn: () => sdk.client.fetch(
      `/admin/sales-reps/${repId}/clients`
    )
  });
  const current = (data == null ? void 0 : data.clients.filter((a) => a.ends_at === null)) ?? [];
  const pastCount = ((data == null ? void 0 : data.clients.length) ?? 0) - current.length;
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h2", children: "Clients" }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Assign clients from the customer page" })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      isLoading ? /* @__PURE__ */ jsxRuntime.jsx(Loading, {}) : current.length === 0 ? /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "No clients assigned." }) : current.map((assignment) => /* @__PURE__ */ jsxRuntime.jsx(
        reactRouterDom.Link,
        {
          to: `/customers/${assignment.customer_id}`,
          className: "outline-none focus-within:shadow-borders-interactive-with-focus rounded-md [&:hover>div]:bg-ui-bg-component-hover",
          children: /* @__PURE__ */ jsxRuntime.jsx("div", { className: "shadow-elevation-card-rest bg-ui-bg-component rounded-md px-4 py-2 transition-colors", children: /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-1 flex-col", children: [
              /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", children: clientName(assignment.customer) }),
              /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
                assignment.commission_rate,
                "% since",
                " ",
                formatDate(assignment.starts_at)
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntime.jsx(icons.TriangleRightMini, { className: "text-ui-fg-muted rtl:rotate-180" })
          ] }) })
        },
        assignment.id
      )),
      pastCount > 0 && /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
        pastCount,
        " earlier assignment",
        pastCount === 1 ? "" : "s",
        " on record"
      ] })
    ] })
  ] });
};
const downloadFile = async (path, accept, fallbackName) => {
  var _a;
  const response = await sdk.client.fetch(path, {
    headers: { accept }
  });
  const blob = await response.blob();
  const disposition = response.headers.get("content-disposition") ?? "";
  const fileName = ((_a = /filename="([^"]+)"/.exec(disposition)) == null ? void 0 : _a[1]) ?? fallbackName;
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
};
const readAsBase64 = (file) => new Promise((resolve, reject) => {
  const reader = new FileReader();
  reader.onload = () => resolve(String(reader.result).split(",")[1] ?? "");
  reader.onerror = () => reject(reader.error);
  reader.readAsDataURL(file);
});
const ACCEPTED = ["application/pdf", "image/jpeg", "image/png"];
const MAX_BYTES = 10 * 1024 * 1024;
const ContractsSection = ({ repId }) => {
  const input = react.useRef(null);
  const queryClient = reactQuery.useQueryClient();
  const { data, isLoading } = reactQuery.useQuery({
    queryKey: ["sales-rep-contracts", repId],
    queryFn: () => sdk.client.fetch(
      `/admin/sales-reps/${repId}/contracts`
    )
  });
  const upload = reactQuery.useMutation({
    mutationFn: async (file) => sdk.client.fetch(`/admin/sales-reps/${repId}/contracts`, {
      method: "POST",
      body: {
        file_name: file.name,
        mime_type: file.type,
        content_base64: await readAsBase64(file)
      }
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["sales-rep-contracts", repId] });
      ui.toast.success("Contract uploaded");
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const onFile = (file) => {
    if (!file) {
      return;
    }
    if (!ACCEPTED.includes(file.type)) {
      return ui.toast.error("Upload a PDF, JPEG or PNG file");
    }
    if (file.size > MAX_BYTES) {
      return ui.toast.error("Contracts can be at most 10 MB");
    }
    upload.mutate(file);
  };
  const download = (contract) => downloadFile(
    `/admin/sales-reps/${repId}/contracts/${contract.id}/download`,
    contract.mime_type,
    contract.file_name
  ).catch((error) => ui.toast.error(errorMessage(error)));
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h2", children: "Contracts" }),
      /* @__PURE__ */ jsxRuntime.jsxs(
        ui.Button,
        {
          size: "small",
          variant: "secondary",
          isLoading: upload.isPending,
          onClick: () => {
            var _a;
            return (_a = input.current) == null ? void 0 : _a.click();
          },
          children: [
            /* @__PURE__ */ jsxRuntime.jsx(icons.ArrowUpTray, {}),
            "Upload"
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntime.jsx(
        "input",
        {
          ref: input,
          type: "file",
          accept: ACCEPTED.join(","),
          className: "hidden",
          onChange: (e) => {
            var _a;
            onFile((_a = e.target.files) == null ? void 0 : _a[0]);
            e.target.value = "";
          }
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Stored privately; only admins can download them." }),
      isLoading ? /* @__PURE__ */ jsxRuntime.jsx(Loading, {}) : !(data == null ? void 0 : data.contracts.length) ? /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "No contract uploaded yet." }) : data.contracts.map((contract) => /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between gap-x-2", children: [
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex min-w-0 flex-col", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", className: "truncate", children: contract.file_name }),
          /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
            formatDate(contract.created_at),
            " · ",
            formatSize(contract.size_bytes)
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsx(
          ui.IconButton,
          {
            size: "small",
            variant: "transparent",
            onClick: () => download(contract),
            children: /* @__PURE__ */ jsxRuntime.jsx(icons.ArrowDownTray, {})
          }
        )
      ] }, contract.id))
    ] })
  ] });
};
const DeleteSection = ({ rep }) => {
  const queryClient = reactQuery.useQueryClient();
  const navigate = reactRouterDom.useNavigate();
  const prompt = ui.usePrompt();
  const { data, isLoading, error } = reactQuery.useQuery({
    queryKey: ["sales-rep-deletion", rep.id],
    queryFn: () => sdk.client.fetch(`/admin/sales-reps/${rep.id}/deletion`)
  });
  const remove = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${rep.id}`, { method: "DELETE" }),
    onSuccess: () => {
      ui.toast.success(`${rep.name} deleted`);
      navigate("/sales-reps");
      for (const key of ["sales-reps", "rep-balances", "applications"]) {
        queryClient.invalidateQueries({ queryKey: [key] });
      }
    },
    onError: (failure) => {
      ui.toast.error(errorMessage(failure));
      queryClient.invalidateQueries({ queryKey: ["sales-rep-deletion", rep.id] });
    }
  });
  const confirmDelete = async () => {
    const confirmed = await prompt({
      title: `Delete ${rep.name}?`,
      description: `${rep.name}'s portal login ends, the invitations they sent are withdrawn and they disappear from the lists. This can't be undone here.`,
      confirmText: "Delete",
      cancelText: "Cancel"
    });
    if (confirmed) {
      remove.mutate();
    }
  };
  const blockers = (data == null ? void 0 : data.blockers) ?? [];
  const canDelete = (data == null ? void 0 : data.can_delete) === true;
  const hasMoney = blockers.some((blocker) => blocker.code === "money");
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h2", children: "Delete rep" }),
      /* @__PURE__ */ jsxRuntime.jsx(
        ui.Button,
        {
          size: "small",
          variant: "danger",
          disabled: !canDelete,
          isLoading: remove.isPending,
          onClick: confirmDelete,
          children: "Delete"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: isLoading ? /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Checking what is on record…" }) : error || !data ? /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-error", children: [
      "Could not check whether ",
      rep.name,
      " can be deleted."
    ] }) : canDelete ? /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
      rep.name,
      " has no commission, clients or recruits on record, so they can be deleted. To keep them but stop new work, deactivate them in Edit instead."
    ] }) : /* @__PURE__ */ jsxRuntime.jsxs(jsxRuntime.Fragment, { children: [
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
        rep.name,
        " can't be deleted:"
      ] }),
      /* @__PURE__ */ jsxRuntime.jsx("ul", { className: "list-disc pl-5", children: blockers.map((blocker) => /* @__PURE__ */ jsxRuntime.jsx("li", { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: blocker.message }) }, blocker.code)) }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: hasMoney ? "Money on record stays: the statements and reports are built from it. Deactivate them in Edit instead." : "Settle these first, or deactivate them in Edit instead." })
    ] }) })
  ] });
};
const copy = (text) => navigator.clipboard.writeText(text).then(() => ui.toast.success("Link copied")).catch(() => ui.toast.error("Couldn't copy, select the link instead"));
const PortalSection = ({
  rep,
  portal
}) => {
  const [granted, setGranted] = react.useState(null);
  const queryClient = reactQuery.useQueryClient();
  const prompt = ui.usePrompt();
  const active = portal.status === "active";
  const refresh = () => queryClient.invalidateQueries({ queryKey: ["sales-rep", rep.id] });
  const grant = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${rep.id}/portal-access`, {
      method: "POST",
      body: {}
    }),
    onSuccess: (result) => {
      refresh();
      setGranted(result);
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const revoke = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${rep.id}/portal-access`, {
      method: "DELETE"
    }),
    onSuccess: () => {
      refresh();
      ui.toast.success("Portal access ended");
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const confirmRevoke = async () => {
    const confirmed = await prompt({
      title: "End portal access?",
      description: `${rep.name} is signed out of the sales portal at once. You can give access again later, and they keep their password.`,
      confirmText: "End access",
      cancelText: "Cancel"
    });
    if (confirmed) {
      revoke.mutate();
    }
  };
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h2", children: "Sales portal" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: active ? "green" : "grey", children: active ? "Has access" : "No access" })
      ] }),
      active ? /* @__PURE__ */ jsxRuntime.jsx(
        ui.Button,
        {
          size: "small",
          variant: "secondary",
          isLoading: revoke.isPending,
          onClick: confirmRevoke,
          children: "End access"
        }
      ) : /* @__PURE__ */ jsxRuntime.jsx(
        ui.Button,
        {
          size: "small",
          variant: "secondary",
          disabled: !rep.is_active,
          isLoading: grant.isPending,
          onClick: () => grant.mutate(),
          children: "Give access"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx("div", { className: "px-6 py-4", children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: active ? `${rep.name} can sign in to the sales portal with ${rep.email} to see their clients, paid orders and payouts.` : rep.is_active ? `Gives ${rep.name} a login to see their clients, paid orders and payouts. They set their first password with "Forgot password" on the portal.` : "Reactivate this rep to give them portal access." }) }),
    /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer, { open: !!granted, onOpenChange: (open) => !open && setGranted(null), children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Content, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Header, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Title, { children: "Portal access given" }) }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
        /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: [
          rep.name,
          ' sets a first password with "Forgot password" on the portal: they enter ',
          rep.email,
          " and follow the link in the email that Medusa sends. Pass this link on:"
        ] }),
        (granted == null ? void 0 : granted.forgot_password_url) ? /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Input, { readOnly: true, value: granted.forgot_password_url }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Button,
            {
              size: "small",
              variant: "secondary",
              onClick: () => copy(granted.forgot_password_url),
              children: "Copy"
            }
          )
        ] }) : /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", className: "text-ui-fg-error", children: [
          "The portal URL isn't configured (SALES_PORTAL_URL), so there is no link to copy. Tell ",
          rep.name,
          ` to open the portal's "Forgot password" page.`
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Footer, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", children: "Done" }) }) })
    ] }) })
  ] });
};
const Row = ({ label, value }) => /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "grid grid-cols-2 items-start px-6 py-4", children: [
  /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", children: label }),
  /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: value })
] });
const ProfileSection = ({ rep }) => {
  const [open, setOpen] = react.useState(false);
  const [form, setForm] = react.useState(rep);
  const queryClient = reactQuery.useQueryClient();
  const update = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${rep.id}`, {
      method: "POST",
      body: {
        name: form.name,
        email: form.email,
        phone: form.phone || null,
        notes: form.notes || null,
        is_active: form.is_active,
        payout_currency_code: form.payout_currency_code
      }
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["sales-rep", rep.id] });
      queryClient.invalidateQueries({ queryKey: ["sales-reps"] });
      ui.toast.success("Sales rep updated");
      setOpen(false);
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { children: rep.name }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: rep.is_active ? "green" : "grey", children: rep.is_active ? "Active" : "Inactive" })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs(
        ui.Button,
        {
          size: "small",
          variant: "secondary",
          onClick: () => {
            setForm(rep);
            setOpen(true);
          },
          children: [
            /* @__PURE__ */ jsxRuntime.jsx(icons.PencilSquare, {}),
            "Edit"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx(Row, { label: "Email", value: rep.email }),
    /* @__PURE__ */ jsxRuntime.jsx(Row, { label: "Phone", value: rep.phone || "-" }),
    /* @__PURE__ */ jsxRuntime.jsx(
      Row,
      {
        label: "Paid in",
        value: rep.payout_currency_code ? rep.payout_currency_code.toUpperCase() : "Each currency as earned"
      }
    ),
    /* @__PURE__ */ jsxRuntime.jsx(Row, { label: "Notes", value: rep.notes || "-" }),
    /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer, { open, onOpenChange: setOpen, children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Content, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Header, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Title, { children: "Edit sales rep" }) }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "edit-name", children: "Name" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Input,
            {
              id: "edit-name",
              value: form.name,
              onChange: (e) => setForm({ ...form, name: e.target.value })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "edit-email", children: "Email" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Input,
            {
              id: "edit-email",
              type: "email",
              value: form.email,
              onChange: (e) => setForm({ ...form, email: e.target.value })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "edit-phone", children: "Phone" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Input,
            {
              id: "edit-phone",
              value: form.phone ?? "",
              onChange: (e) => setForm({ ...form, phone: e.target.value })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Paid in" }),
          /* @__PURE__ */ jsxRuntime.jsxs(
            ui.Select,
            {
              value: form.payout_currency_code ?? "as-earned",
              onValueChange: (value) => setForm({
                ...form,
                payout_currency_code: value === "as-earned" ? null : value
              }),
              children: [
                /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Value, {}) }),
                /* @__PURE__ */ jsxRuntime.jsxs(ui.Select.Content, { children: [
                  /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: "as-earned", children: "Each currency as earned" }),
                  /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: "eur", children: "EUR" }),
                  /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: "huf", children: "HUF" })
                ] })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: "With one currency, commission earned in the other is converted once, when it is earned, at the ECB rate of that day. What is already earned stays in the currency it was earned in." })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "edit-notes", children: "Notes" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Textarea,
            {
              id: "edit-notes",
              value: form.notes ?? "",
              onChange: (e) => setForm({ ...form, notes: e.target.value })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-start justify-between gap-x-4", children: [
          /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-1", children: [
            /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "edit-active", children: "Active" }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: "Inactive reps can't get new clients or referrals. Their current clients keep earning until you move them." })
          ] }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Switch,
            {
              id: "edit-active",
              checked: form.is_active,
              onCheckedChange: (checked) => setForm({ ...form, is_active: checked })
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Footer, { children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", disabled: update.isPending, children: "Cancel" }) }),
        /* @__PURE__ */ jsxRuntime.jsx(
          ui.Button,
          {
            size: "small",
            onClick: () => update.mutate(),
            isLoading: update.isPending,
            children: "Save"
          }
        )
      ] })
    ] }) })
  ] });
};
const ReferralSection = ({
  repId,
  referral,
  referredReps
}) => {
  var _a;
  const [open, setOpen] = react.useState(false);
  const [referrerId, setReferrerId] = react.useState("");
  const [rate, setRate] = react.useState("");
  const queryClient = reactQuery.useQueryClient();
  const prompt = ui.usePrompt();
  const { data: reps } = reactQuery.useQuery({
    queryKey: ["sales-reps", "active-options"],
    queryFn: () => sdk.client.fetch("/admin/sales-reps", {
      query: { is_active: "true", limit: 200, order: "name" }
    }),
    enabled: open
  });
  const refresh = () => queryClient.invalidateQueries({ queryKey: ["sales-rep"] });
  const save = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/referral`, {
      method: "POST",
      body: { referrer_sales_rep_id: referrerId, level2_rate: Number(rate) }
    }),
    onSuccess: () => {
      refresh();
      ui.toast.success("Referral saved");
      setOpen(false);
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const end = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/referral`, {
      method: "DELETE"
    }),
    onSuccess: () => {
      refresh();
      ui.toast.success("Referral ended");
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const confirmEnd = async () => {
    const confirmed = await prompt({
      title: "End referral?",
      description: "The referrer stops earning Level 2 commission on orders placed today or later. Earlier days are not affected.",
      confirmText: "End referral",
      cancelText: "Cancel"
    });
    if (confirmed) {
      end.mutate();
    }
  };
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h2", children: "Referral" }),
      /* @__PURE__ */ jsxRuntime.jsxs(
        ui.Button,
        {
          size: "small",
          variant: "secondary",
          onClick: () => {
            setReferrerId((referral == null ? void 0 : referral.referrer_sales_rep_id) ?? "");
            setRate(referral ? String(referral.level2_rate) : "");
            setOpen(true);
          },
          children: [
            /* @__PURE__ */ jsxRuntime.jsx(icons.PencilSquare, {}),
            referral ? "Change" : "Set referrer"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex flex-col gap-y-1 px-6 py-4", children: referral ? /* @__PURE__ */ jsxRuntime.jsxs(jsxRuntime.Fragment, { children: [
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", weight: "plus", children: [
        "Referred by",
        " ",
        /* @__PURE__ */ jsxRuntime.jsx(
          reactRouterDom.Link,
          {
            to: `/sales-reps/${referral.referrer_sales_rep_id}`,
            className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
            children: ((_a = referral.referrer) == null ? void 0 : _a.name) ?? "another rep"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
        "Level 2: ",
        referral.level2_rate,
        "% of this rep's client turnover, since ",
        formatDate(referral.starts_at),
        referral.expires_at ? new Date(referral.expires_at) > /* @__PURE__ */ new Date() ? `, until ${formatDate(referral.expires_at)}` : `. It ended on ${formatDate(referral.expires_at)}, so orders placed since earn nothing` : ", until you end it"
      ] }),
      /* @__PURE__ */ jsxRuntime.jsx("div", { children: /* @__PURE__ */ jsxRuntime.jsx(
        ui.Button,
        {
          size: "small",
          variant: "transparent",
          className: "-ml-3 mt-1",
          isLoading: end.isPending,
          onClick: confirmEnd,
          children: "End referral"
        }
      ) })
    ] }) : /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Not referred by another rep." }) }),
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", children: "Reps they referred" }),
      referredReps.length === 0 ? /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "None" }) : referredReps.map((r) => {
        var _a2;
        return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntime.jsx(
            reactRouterDom.Link,
            {
              to: `/sales-reps/${r.referred_sales_rep_id}`,
              className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
              children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", children: ((_a2 = r.referred) == null ? void 0 : _a2.name) ?? r.referred_sales_rep_id })
            }
          ),
          /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
            r.level2_rate,
            "%"
          ] })
        ] }, r.id);
      })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer, { open, onOpenChange: setOpen, children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Content, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Header, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Title, { children: "Referrer and Level 2 rate" }) }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: "The referrer earns this percentage of the net turnover of this rep's clients, on top of this rep's own commission. It takes effect from the start of today (Budapest time); earlier days are not affected." }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Referred by" }),
          /* @__PURE__ */ jsxRuntime.jsxs(ui.Select, { value: referrerId, onValueChange: setReferrerId, children: [
            /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Value, { placeholder: "Choose a sales rep" }) }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Content, { children: ((reps == null ? void 0 : reps.sales_reps) ?? []).filter((rep) => rep.id !== repId).map((rep) => /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: rep.id, children: rep.name }, rep.id)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "level2-rate", children: "Level 2 rate (%)" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Input,
            {
              id: "level2-rate",
              type: "number",
              min: 0,
              max: 100,
              step: "0.01",
              value: rate,
              onChange: (e) => setRate(e.target.value)
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Footer, { children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", disabled: save.isPending, children: "Cancel" }) }),
        /* @__PURE__ */ jsxRuntime.jsx(
          ui.Button,
          {
            size: "small",
            disabled: !referrerId || rate === "",
            isLoading: save.isPending,
            onClick: () => save.mutate(),
            children: "Save"
          }
        )
      ] })
    ] }) })
  ] });
};
const AdjustmentDrawer = ({
  repId,
  payoutCurrency
}) => {
  const currencies = payoutCurrency ? [payoutCurrency] : CURRENCIES;
  const [open, setOpen] = react.useState(false);
  const [currency, setCurrency] = react.useState(currencies[0]);
  const [amount, setAmount] = react.useState("");
  const [period, setPeriod] = react.useState(currentPeriod());
  const [reason, setReason] = react.useState("");
  const [error, setError] = react.useState(null);
  const queryClient = reactQuery.useQueryClient();
  const { data: status } = reactQuery.useQuery({
    queryKey: ["periods"],
    queryFn: () => sdk.client.fetch("/admin/sales-commission/periods"),
    enabled: open
  });
  const openMonths = recentPeriods().filter(
    (p) => !(status == null ? void 0 : status.approved_through) || p.value > status.approved_through
  );
  const save = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/adjustments`, {
      method: "POST",
      body: {
        currency_code: currency,
        amount: Number(amount),
        period,
        reason: reason.trim()
      }
    }),
    onSuccess: () => {
      for (const key of [
        "sales-rep-balance",
        "sales-rep-statement",
        "commission-report",
        "payment-run"
      ]) {
        queryClient.invalidateQueries({ queryKey: [key] });
      }
      ui.toast.success("Adjustment added");
      setOpen(false);
    },
    onError: (e) => ui.toast.error(errorMessage(e))
  });
  const submit = () => {
    const value = Number(amount);
    if (!amount || Number.isNaN(value) || value === 0) {
      return setError("Enter an amount");
    }
    if (!reason.trim()) {
      return setError("A reason is required");
    }
    setError(null);
    save.mutate();
  };
  return /* @__PURE__ */ jsxRuntime.jsxs(
    ui.Drawer,
    {
      open,
      onOpenChange: (next) => {
        setOpen(next);
        if (next) {
          setCurrency(currencies[0]);
          setAmount("");
          setPeriod(currentPeriod());
          setReason("");
          setError(null);
        }
      },
      children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Trigger, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", children: "Add adjustment" }) }),
        /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Content, { children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Header, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Title, { children: "Add commission adjustment" }) }),
          /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
            /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: "Correct what a rep earned, for example after a partial return. Use a negative amount to reduce it. The reason is shown to the rep. Adjustments can't be edited or deleted; add a reversing one to undo." }),
            /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
                /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Month" }),
                /* @__PURE__ */ jsxRuntime.jsxs(ui.Select, { value: period, onValueChange: setPeriod, children: [
                  /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Value, {}) }),
                  /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Content, { children: openMonths.map((p) => /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: p.value, children: p.label }, p.value)) })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
                /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Currency" }),
                /* @__PURE__ */ jsxRuntime.jsxs(
                  ui.Select,
                  {
                    value: currency,
                    onValueChange: setCurrency,
                    disabled: currencies.length === 1,
                    children: [
                      /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Value, {}) }),
                      /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Content, { children: currencies.map((code) => /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: code, children: code.toUpperCase() }, code)) })
                    ]
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
              /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "adjustment-amount", children: "Amount" }),
              /* @__PURE__ */ jsxRuntime.jsx(
                ui.Input,
                {
                  id: "adjustment-amount",
                  type: "number",
                  step: currencyStep(currency),
                  value: amount,
                  onChange: (e) => {
                    setAmount(e.target.value);
                    setError(null);
                  }
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
              /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "adjustment-reason", children: "Reason" }),
              /* @__PURE__ */ jsxRuntime.jsx(
                ui.Textarea,
                {
                  id: "adjustment-reason",
                  value: reason,
                  onChange: (e) => {
                    setReason(e.target.value);
                    setError(null);
                  }
                }
              )
            ] }),
            error && /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-error", children: error })
          ] }),
          /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Footer, { children: [
            /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", disabled: save.isPending, children: "Cancel" }) }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", onClick: submit, isLoading: save.isPending, children: "Save" })
          ] })
        ] })
      ]
    }
  );
};
const payoutOutcome = ({
  amount,
  payable,
  decimals: decimals2
}) => {
  const scale = 10 ** decimals2;
  const paid = Math.round(amount * scale);
  const owed = Math.round(payable * scale);
  if (!Number.isFinite(paid) || paid <= 0) {
    return { kind: "invalid", difference: 0 };
  }
  return {
    kind: paid === owed ? "full" : paid < owed ? "short" : "over",
    difference: Math.abs(paid - owed) / scale
  };
};
const decimals = (currencyCode) => currencyStep(currencyCode) === "1" ? 0 : 2;
const PayoutDrawer = ({
  repId,
  payoutCurrency
}) => {
  const currencies = payoutCurrency ? [payoutCurrency] : CURRENCIES;
  const [open, setOpen] = react.useState(false);
  const [currency, setCurrency] = react.useState(currencies[0]);
  const [amount, setAmount] = react.useState("");
  const [touched, setTouched] = react.useState(false);
  const [paidAt, setPaidAt] = react.useState(today());
  const [reference, setReference] = react.useState("");
  const [asBonus, setAsBonus] = react.useState(false);
  const [bonusReason, setBonusReason] = react.useState("");
  const [error, setError] = react.useState(null);
  const queryClient = reactQuery.useQueryClient();
  const { data: balance } = reactQuery.useQuery({
    queryKey: ["sales-rep-balance", repId],
    queryFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/balance`),
    enabled: open
  });
  const current = balance == null ? void 0 : balance.balances.find((b) => b.currency_code === currency);
  const payable = (current == null ? void 0 : current.payable) ?? 0;
  const toRecover = (current == null ? void 0 : current.to_recover) ?? 0;
  react.useEffect(() => {
    if (open && !touched) {
      setAmount(payable > 0 ? String(payable) : "");
    }
  }, [open, touched, payable, currency]);
  const parsed = Number(amount);
  const outcome = payoutOutcome({
    amount: parsed,
    payable,
    decimals: decimals(currency)
  });
  const money = (value) => formatMoney(value, currency);
  const save = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/payouts`, {
      method: "POST",
      body: {
        currency_code: currency,
        amount: parsed,
        paid_at: paidAt,
        reference: reference.trim() || null,
        bonus_reason: asBonus ? bonusReason.trim() : null
      }
    }),
    onSuccess: () => {
      for (const key of [
        "sales-rep-balance",
        "sales-rep-statement",
        "commission-report",
        "payment-run",
        "rep-balances"
      ]) {
        queryClient.invalidateQueries({ queryKey: [key] });
      }
      ui.toast.success("Payout recorded");
      setOpen(false);
    },
    onError: (e) => ui.toast.error(errorMessage(e))
  });
  const submit = () => {
    if (outcome.kind === "invalid") {
      return setError("Enter an amount above zero");
    }
    if (asBonus && outcome.kind === "over" && !bonusReason.trim()) {
      return setError("Give a reason for the bonus");
    }
    setError(null);
    save.mutate();
  };
  const reset = () => {
    setCurrency(currencies[0]);
    setAmount("");
    setTouched(false);
    setPaidAt(today());
    setReference("");
    setAsBonus(false);
    setBonusReason("");
    setError(null);
  };
  return /* @__PURE__ */ jsxRuntime.jsxs(
    ui.Drawer,
    {
      open,
      onOpenChange: (next) => {
        setOpen(next);
        if (next) reset();
      },
      children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Trigger, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", children: "Record payout" }) }),
        /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Content, { children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Header, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Title, { children: "Record payout" }) }),
          /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
            /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: "Record a bank transfer you made to the rep. It counts against everything approved so far, whichever month that was earned in." }),
            currencies.length > 1 && /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
              /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Currency" }),
              /* @__PURE__ */ jsxRuntime.jsxs(
                ui.Select,
                {
                  value: currency,
                  onValueChange: (value) => {
                    setCurrency(value);
                    setTouched(false);
                  },
                  children: [
                    /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Value, {}) }),
                    /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Content, { children: currencies.map((code) => /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: code, children: code.toUpperCase() }, code)) })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "bg-ui-bg-subtle border-ui-border-base flex flex-col gap-y-1 rounded-lg border px-4 py-3", children: [
              /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "xsmall", leading: "compact", className: "text-ui-fg-subtle", children: "Payable now" }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "xlarge", leading: "compact", weight: "plus", children: money(payable) }),
              toRecover > 0 && /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "xsmall", leading: "compact", className: "text-ui-tag-orange-text", children: [
                money(toRecover),
                " was paid ahead and is netted first"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
              /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "payout-amount", children: "Amount paid" }),
              /* @__PURE__ */ jsxRuntime.jsx(
                ui.Input,
                {
                  id: "payout-amount",
                  type: "number",
                  min: 0,
                  step: currencyStep(currency),
                  value: amount,
                  onChange: (e) => {
                    setAmount(e.target.value);
                    setTouched(true);
                    setError(null);
                  }
                }
              )
            ] }),
            outcome.kind === "full" && /* @__PURE__ */ jsxRuntime.jsx(ui.Alert, { variant: "success", children: "Pays in full. Nothing is left due." }),
            outcome.kind === "short" && /* @__PURE__ */ jsxRuntime.jsxs(ui.Alert, { variant: "warning", children: [
              "Short by ",
              money(outcome.difference),
              ". The remainder stays due and shows on the next run."
            ] }),
            outcome.kind === "over" && /* @__PURE__ */ jsxRuntime.jsxs(ui.Alert, { variant: "warning", children: [
              payable > 0 ? `Over by ${money(outcome.difference)}.` : "Nothing is payable yet.",
              " ",
              "This is recorded as an advance and recovered from what the rep earns next."
            ] }),
            outcome.kind === "over" && payable > 0 && /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-3", children: [
              /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
                /* @__PURE__ */ jsxRuntime.jsx(
                  ui.Checkbox,
                  {
                    id: "payout-bonus",
                    checked: asBonus,
                    onCheckedChange: (checked) => setAsBonus(checked === true)
                  }
                ),
                /* @__PURE__ */ jsxRuntime.jsxs(ui.Label, { htmlFor: "payout-bonus", children: [
                  "Record the extra ",
                  money(outcome.difference),
                  " as a bonus instead"
                ] })
              ] }),
              asBonus && /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
                /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "payout-bonus-reason", children: "Reason for the bonus" }),
                /* @__PURE__ */ jsxRuntime.jsx(
                  ui.Textarea,
                  {
                    id: "payout-bonus-reason",
                    value: bonusReason,
                    onChange: (e) => setBonusReason(e.target.value)
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
                /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "payout-date", children: "Paid on" }),
                /* @__PURE__ */ jsxRuntime.jsx(
                  ui.Input,
                  {
                    id: "payout-date",
                    type: "date",
                    value: paidAt,
                    onChange: (e) => setPaidAt(e.target.value)
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
                /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "payout-reference", children: "Reference (optional)" }),
                /* @__PURE__ */ jsxRuntime.jsx(
                  ui.Input,
                  {
                    id: "payout-reference",
                    value: reference,
                    onChange: (e) => setReference(e.target.value)
                  }
                )
              ] })
            ] }),
            error && /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-error", children: error })
          ] }),
          /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Footer, { children: [
            /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", disabled: save.isPending, children: "Cancel" }) }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", onClick: submit, isLoading: save.isPending, children: "Record payout" })
          ] })
        ] })
      ]
    }
  );
};
const PeriodSelect = ({
  value,
  onChange
}) => /* @__PURE__ */ jsxRuntime.jsx("div", { className: "w-44", children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Select, { size: "small", value, onValueChange: onChange, children: [
  /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Value, {}) }),
  /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Content, { children: recentPeriods().map((period) => /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: period.value, children: period.label }, period.value)) })
] }) });
const KIND_LABELS = {
  direct: "Commission",
  level2: "Level 2",
  reversal: "Reversal",
  adjustment: "Adjustment",
  payout: "Payout"
};
const Totals = ({ summary }) => {
  const money = (amount) => formatMoney(amount, summary.currency_code);
  const badge = STATUS_BADGES[summary.status];
  const cells = [
    ["Owed at start", money(summary.opening)],
    ["Turnover", money(summary.turnover)],
    ["Direct", money(summary.direct)],
    ["Level 2", money(summary.level2)],
    ["Adjustments", money(summary.adjustments)],
    ["Earned", money(summary.total)],
    ["Paid", money(summary.paid)],
    ["Owed at end", money(summary.closing)]
  ];
  return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-3 px-6 py-4", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", children: summary.currency_code.toUpperCase() }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: badge.color, children: badge.label })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx("div", { className: "grid grid-cols-2 gap-3 md:grid-cols-4", children: cells.map(([label, value]) => /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-1", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "xsmall", leading: "compact", className: "text-ui-fg-subtle", children: label }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", children: value })
    ] }, label)) })
  ] });
};
const StatementSection = ({
  repId,
  payoutCurrency
}) => {
  const [period, setPeriod] = react.useState(currentPeriod());
  const queryClient = reactQuery.useQueryClient();
  const prompt = ui.usePrompt();
  const { data, isLoading } = reactQuery.useQuery({
    queryKey: ["sales-rep-statement", repId, period],
    queryFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/statement`, {
      query: { period }
    })
  });
  const deletePayout = reactQuery.useMutation({
    mutationFn: (payoutId) => sdk.client.fetch(`/admin/sales-commission/payouts/${payoutId}`, {
      method: "DELETE"
    }),
    onSuccess: () => {
      for (const key of [
        "sales-rep-statement",
        "sales-rep-balance",
        "commission-report",
        "payment-run"
      ]) {
        queryClient.invalidateQueries({ queryKey: [key] });
      }
      ui.toast.success("Payout removed");
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const confirmDelete = async (line) => {
    const confirmed = await prompt({
      title: "Remove payout?",
      description: `Removes the ${formatMoney(line.amount, line.currency_code)} payout recorded by mistake. What it paid becomes payable again, and a bonus recorded with it is removed too.`,
      confirmText: "Remove",
      cancelText: "Cancel"
    });
    if (confirmed) {
      deletePayout.mutate(line.source_id);
    }
  };
  const exportCsv = () => downloadFile(
    `/admin/sales-reps/${repId}/statement?period=${period}&format=csv`,
    "text/csv",
    `commission-statement-${period}.csv`
  ).catch((error) => ui.toast.error(errorMessage(error)));
  const carried = ((data == null ? void 0 : data.totals) ?? []).filter((summary) => summary.opening !== 0);
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col items-start justify-between gap-2 px-6 py-4 md:flex-row md:items-center", children: [
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h2", children: "Commission statement" }),
        data && /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: data.approved ? "green" : "orange", children: data.approved ? "Approved" : "Open" })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntime.jsx(PeriodSelect, { value: period, onChange: setPeriod }),
        /* @__PURE__ */ jsxRuntime.jsxs(ui.Button, { size: "small", variant: "secondary", onClick: exportCsv, children: [
          /* @__PURE__ */ jsxRuntime.jsx(icons.ArrowDownTray, {}),
          "CSV"
        ] }),
        /* @__PURE__ */ jsxRuntime.jsx(AdjustmentDrawer, { repId, payoutCurrency }),
        /* @__PURE__ */ jsxRuntime.jsx(PayoutDrawer, { repId, payoutCurrency })
      ] })
    ] }),
    isLoading || !data ? /* @__PURE__ */ jsxRuntime.jsx(Loading, {}) : data.lines.length === 0 && carried.length === 0 ? /* @__PURE__ */ jsxRuntime.jsx("div", { className: "px-6 py-4", children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Nothing recorded for this month." }) }) : /* @__PURE__ */ jsxRuntime.jsxs(jsxRuntime.Fragment, { children: [
      data.totals.map((summary) => /* @__PURE__ */ jsxRuntime.jsx(Totals, { summary }, summary.currency_code)),
      /* @__PURE__ */ jsxRuntime.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Table, { children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Header, { children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Table.Row, { children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Date" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Type" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Order" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Client" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Net value" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Rate" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Amount" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Balance" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Status" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Note" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, {})
        ] }) }),
        /* @__PURE__ */ jsxRuntime.jsxs(ui.Table.Body, { children: [
          carried.map((summary) => /* @__PURE__ */ jsxRuntime.jsxs(ui.Table.Row, { children: [
            /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, {}),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: "Brought forward" }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: "-" }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: "Left over from earlier months" }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: "-" }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: "-" }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: "-" }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: formatMoney(summary.opening, summary.currency_code) }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, {}),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, {}),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, {})
          ] }, `carried-${summary.currency_code}`)),
          data.lines.map((line) => {
            const badge = LINE_BADGES[line.status];
            return /* @__PURE__ */ jsxRuntime.jsxs(ui.Table.Row, { children: [
              /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: formatDate(line.date) }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: KIND_LABELS[line.kind] }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: line.order_display_id ? `#${line.order_display_id}` : "-" }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: line.client_name ?? "-" }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: line.base_amount === null ? "-" : formatMoney(line.base_amount, line.currency_code) }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: line.rate === null ? "-" : `${line.rate}%` }),
              /* @__PURE__ */ jsxRuntime.jsxs(ui.Table.Cell, { className: "text-right", children: [
                formatMoney(line.amount, line.currency_code),
                line.fx_rate && line.order_currency_code && line.order_amount !== null && /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "xsmall", leading: "compact", className: "text-ui-fg-muted", children: [
                  formatMoney(line.order_amount, line.order_currency_code),
                  " ×",
                  " ",
                  line.fx_rate
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: formatMoney(line.balance, line.currency_code) }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: badge.color, children: badge.label }) }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: line.note ?? "" }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: line.kind === "payout" && /* @__PURE__ */ jsxRuntime.jsx(
                ui.IconButton,
                {
                  size: "small",
                  variant: "transparent",
                  disabled: deletePayout.isPending,
                  onClick: () => confirmDelete(line),
                  children: /* @__PURE__ */ jsxRuntime.jsx(icons.Trash, {})
                }
              ) })
            ] }, `${line.kind}-${line.source_id}-${line.date}`);
          })
        ] })
      ] }) })
    ] })
  ] });
};
const SalesRepDetailPage = () => {
  const { id } = reactRouterDom.useParams();
  const { data, isLoading, error } = reactQuery.useQuery({
    queryKey: ["sales-rep", id],
    queryFn: () => sdk.client.fetch(`/admin/sales-reps/${id}`),
    enabled: !!id
  });
  if (isLoading) {
    return /* @__PURE__ */ jsxRuntime.jsx(Loading, {});
  }
  if (error || !data) {
    return /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-error", children: "This sales rep could not be loaded." });
  }
  return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-3 xl:flex-row xl:items-start xl:gap-x-4", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex w-full flex-col gap-y-3", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ProfileSection, { rep: data.sales_rep }, data.sales_rep.id),
      /* @__PURE__ */ jsxRuntime.jsx(BalanceSection, { repId: data.sales_rep.id }),
      /* @__PURE__ */ jsxRuntime.jsx(
        StatementSection,
        {
          repId: data.sales_rep.id,
          payoutCurrency: data.sales_rep.payout_currency_code
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex w-full flex-col gap-y-3 xl:max-w-[400px]", children: [
      /* @__PURE__ */ jsxRuntime.jsx(
        ReferralSection,
        {
          repId: data.sales_rep.id,
          referral: data.referral,
          referredReps: data.referred_reps
        }
      ),
      /* @__PURE__ */ jsxRuntime.jsx(PortalSection, { rep: data.sales_rep, portal: data.portal }),
      /* @__PURE__ */ jsxRuntime.jsx(ClientsSection, { repId: data.sales_rep.id }),
      /* @__PURE__ */ jsxRuntime.jsx(ContractsSection, { repId: data.sales_rep.id }),
      /* @__PURE__ */ jsxRuntime.jsx(DeleteSection, { rep: data.sales_rep })
    ] })
  ] });
};
const FxRatesSection = () => {
  const [open, setOpen] = react.useState(false);
  const [date, setDate] = react.useState(today());
  const [rate, setRate] = react.useState("");
  const [error, setError] = react.useState(null);
  const queryClient = reactQuery.useQueryClient();
  const { data, isLoading } = reactQuery.useQuery({
    queryKey: ["fx-rates"],
    queryFn: () => sdk.client.fetch("/admin/sales-commission/fx-rates")
  });
  const add = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch("/admin/sales-commission/fx-rates", {
      method: "POST",
      body: { rate_date: date, rate: Number(rate) }
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["fx-rates"] });
      ui.toast.success("Rate added");
      setOpen(false);
      setRate("");
    },
    onError: (e) => ui.toast.error(errorMessage(e))
  });
  const submit = () => {
    if (!(Number(rate) > 0)) {
      return setError("Enter the forint per euro");
    }
    setError(null);
    add.mutate();
  };
  const latest = data == null ? void 0 : data.rates[0];
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-1", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h2", children: "Exchange rates" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Commission is converted once, when it is earned, at the rate of that day. Reps paid in one currency see a single balance." })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", onClick: () => setOpen(true), children: "Add a rate" })
    ] }),
    isLoading || !data ? /* @__PURE__ */ jsxRuntime.jsx(Loading, {}) : /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      latest ? /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-wrap items-center gap-x-3 gap-y-1", children: [
        /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", weight: "plus", children: [
          "1 EUR = ",
          latest.rate,
          " HUF"
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
          "on ",
          formatDate(latest.rate_date)
        ] }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: latest.source === "ecb" ? "green" : "orange", children: latest.source === "ecb" ? "ECB" : "Entered by hand" })
      ] }) : /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
        "No rate stored yet.",
        " ",
        data.auto_fetch ? "The first one is fetched from the ECB when a rep paid in a different currency earns commission." : "Automatic fetching is off, so add one."
      ] }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "xsmall", leading: "compact", className: "text-ui-fg-muted", children: data.auto_fetch ? "Fetched from the ECB every working day." : "Automatic fetching is off. Enter each day's rate by hand." })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer, { open, onOpenChange: setOpen, children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Content, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Header, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Title, { children: "Add an exchange rate" }) }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: "Use this for a day the ECB rate is missing. A day that already has a rate can't be changed, and commission already earned keeps the rate it was earned at." }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "fx-date", children: "Day" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Input,
            {
              id: "fx-date",
              type: "date",
              value: date,
              onChange: (e) => setDate(e.target.value)
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "fx-rate", children: "Forint per euro" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Input,
            {
              id: "fx-rate",
              type: "number",
              min: 0,
              step: "0.01",
              value: rate,
              onChange: (e) => {
                setRate(e.target.value);
                setError(null);
              }
            }
          )
        ] }),
        error && /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-error", children: error })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Footer, { children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", disabled: add.isPending, children: "Cancel" }) }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", onClick: submit, isLoading: add.isPending, children: "Save" })
      ] })
    ] }) })
  ] });
};
const rowKey = (row) => `${row.sales_rep_id}:${row.currency_code}`;
const csvCell = (value) => {
  const text = String(value);
  const safe = /^[=+\-@]/.test(text) ? `'${text}` : text;
  return /[",\r\n]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe;
};
const downloadCsv = (fileName, rows) => {
  const csv = "\uFEFF" + rows.map((row) => row.map(csvCell).join(",")).join("\r\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  link.click();
  URL.revokeObjectURL(url);
};
const rowNote = (row, minimums) => {
  const money = (amount) => formatMoney(amount, row.currency_code);
  const notes = [];
  if (row.to_recover > 0) {
    notes.push(
      `Paid ahead ${money(row.to_recover)}. Netted from what they earn next`
    );
  }
  if (row.below_minimum) {
    notes.push(
      `Below the minimum of ${money(minimums[row.currency_code] ?? 0)}. Rolls over to the next run`
    );
  }
  if (row.brought_forward > 0) {
    notes.push(`Includes ${money(row.brought_forward)} from earlier months`);
  }
  if (row.open_earned > 0) {
    notes.push(`${money(row.open_earned)} more waits for its month to be approved`);
  }
  return notes;
};
const PaymentRunPage = () => {
  const queryClient = reactQuery.useQueryClient();
  const prompt = ui.usePrompt();
  const [selected, setSelected] = react.useState({});
  const [amounts, setAmounts] = react.useState({});
  const [open, setOpen] = react.useState(false);
  const [paidAt, setPaidAt] = react.useState(today());
  const [reference, setReference] = react.useState("");
  const { data, isLoading } = reactQuery.useQuery({
    queryKey: ["payment-run"],
    queryFn: () => sdk.client.fetch("/admin/sales-commission/payment-run")
  });
  const signature = JSON.stringify((data == null ? void 0 : data.rows) ?? []);
  react.useEffect(() => {
    if (!data) return;
    setSelected(
      Object.fromEntries(
        data.rows.map((row) => [rowKey(row), row.payable > 0 && !row.below_minimum])
      )
    );
    setAmounts(
      Object.fromEntries(
        data.rows.map((row) => [rowKey(row), row.payable > 0 ? String(row.payable) : ""])
      )
    );
  }, [signature]);
  const refresh = () => {
    for (const key of [
      "payment-run",
      "periods",
      "sales-rep-balance",
      "sales-rep-statement",
      "commission-report",
      "rep-balances"
    ]) {
      queryClient.invalidateQueries({ queryKey: [key] });
    }
  };
  const approve = reactQuery.useMutation({
    mutationFn: (through) => sdk.client.fetch("/admin/sales-commission/periods", {
      method: "POST",
      body: { through }
    }),
    onSuccess: () => {
      refresh();
      ui.toast.success("Months approved");
    },
    onError: (e) => ui.toast.error(errorMessage(e))
  });
  const reopen = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch("/admin/sales-commission/periods/latest", { method: "DELETE" }),
    onSuccess: () => {
      refresh();
      ui.toast.success("Approval undone");
    },
    onError: (e) => ui.toast.error(errorMessage(e))
  });
  const items = react.useMemo(
    () => ((data == null ? void 0 : data.rows) ?? []).filter((row) => selected[rowKey(row)] && Number(amounts[rowKey(row)]) > 0).map((row) => ({
      sales_rep_id: row.sales_rep_id,
      currency_code: row.currency_code,
      amount: Number(amounts[rowKey(row)])
    })),
    [data, selected, amounts]
  );
  const totals = react.useMemo(() => {
    const byCurrency = /* @__PURE__ */ new Map();
    for (const item of items) {
      byCurrency.set(item.currency_code, (byCurrency.get(item.currency_code) ?? 0) + item.amount);
    }
    return [...byCurrency.entries()].sort(([a], [b]) => a.localeCompare(b));
  }, [items]);
  const record = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch("/admin/sales-commission/payment-run", {
      method: "POST",
      body: { items, paid_at: paidAt, reference: reference.trim() || null }
    }),
    onSuccess: () => {
      refresh();
      ui.toast.success("Payouts recorded");
      setOpen(false);
    },
    onError: (e) => ui.toast.error(errorMessage(e))
  });
  const confirmApprove = async (through, count) => {
    const confirmed = await prompt({
      title: `Approve through ${monthLabel(through)}?`,
      description: `What reps earned in ${count === 1 ? "this month" : `these ${count} months`} becomes payable. Statements of an approved month don't change; later refunds and adjustments land in the month they happen. You can undo the latest approval until you record a payout.`,
      confirmText: "Approve",
      cancelText: "Cancel"
    });
    if (confirmed) approve.mutate(through);
  };
  const confirmReopen = async (period) => {
    const confirmed = await prompt({
      title: `Undo the approval of ${monthLabel(period)}?`,
      description: "What was earned in it stops being payable until you approve it again.",
      confirmText: "Undo approval",
      cancelText: "Cancel"
    });
    if (confirmed) reopen.mutate();
  };
  const exportCsv = () => downloadCsv(`payment-run-${today()}.csv`, [
    ["Rep", "Email", "Currency", "Amount"],
    ...((data == null ? void 0 : data.rows) ?? []).filter((row) => selected[rowKey(row)] && Number(amounts[rowKey(row)]) > 0).map((row) => [
      row.sales_rep_name,
      row.sales_rep_email,
      row.currency_code.toUpperCase(),
      Number(amounts[rowKey(row)])
    ])
  ]);
  const lastClosed = data == null ? void 0 : data.closed_unapproved[data.closed_unapproved.length - 1];
  return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-3", children: [
    /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col items-start justify-between gap-2 px-6 py-4 md:flex-row md:items-center", children: [
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-1", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { children: "Payment run" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: "Pay what reps are owed. Only months you have approved are payable; the amounts are filled in from each rep's balance." })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(reactRouterDom.Link, { to: "/sales-reps/report", children: "Monthly report" }) })
      ] }),
      isLoading || !data ? /* @__PURE__ */ jsxRuntime.jsx(Loading, {}) : /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-3 px-6 py-4", children: [
        data.closed_unapproved.length > 0 && lastClosed ? /* @__PURE__ */ jsxRuntime.jsxs(ui.Alert, { variant: "warning", children: [
          data.closed_unapproved.length === 1 ? `${monthLabel(lastClosed)} is over and not approved yet.` : `${data.closed_unapproved.map(monthLabel).join(", ")} are over and not approved yet.`,
          " ",
          "Check the monthly report, then approve it to make what reps earned payable."
        ] }) : /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: data.approved_through ? `All finished months are approved, through ${monthLabel(data.approved_through)}.` : "Nothing to approve yet." }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
          lastClosed && /* @__PURE__ */ jsxRuntime.jsxs(
            ui.Button,
            {
              size: "small",
              isLoading: approve.isPending,
              onClick: () => confirmApprove(lastClosed, data.closed_unapproved.length),
              children: [
                "Approve through ",
                monthLabel(lastClosed)
              ]
            }
          ),
          data.approved_through && /* @__PURE__ */ jsxRuntime.jsxs(
            ui.Button,
            {
              size: "small",
              variant: "secondary",
              isLoading: reopen.isPending,
              onClick: () => confirmReopen(data.approved_through),
              children: [
                "Undo approval of ",
                monthLabel(data.approved_through)
              ]
            }
          )
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h2", children: "Payable now" }),
        (data == null ? void 0 : data.payout_day) && /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
          "Usual payout day: the ",
          data.payout_day,
          "th"
        ] })
      ] }),
      isLoading || !data ? /* @__PURE__ */ jsxRuntime.jsx(Loading, {}) : data.rows.length === 0 ? /* @__PURE__ */ jsxRuntime.jsx("div", { className: "px-6 py-4", children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Nobody is owed anything right now." }) }) : /* @__PURE__ */ jsxRuntime.jsxs(jsxRuntime.Fragment, { children: [
        /* @__PURE__ */ jsxRuntime.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Table, { children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Header, { children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Table.Row, { children: [
            /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, {}),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Rep" }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Currency" }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Payable" }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Pay" }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Note" })
          ] }) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Body, { children: data.rows.map((row) => {
            const key = rowKey(row);
            const payable = row.payable > 0;
            const notes = rowNote(row, data.minimums);
            return /* @__PURE__ */ jsxRuntime.jsxs(ui.Table.Row, { children: [
              /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: payable && /* @__PURE__ */ jsxRuntime.jsx(
                ui.Checkbox,
                {
                  checked: selected[key] ?? false,
                  onCheckedChange: (checked) => setSelected({ ...selected, [key]: checked === true })
                }
              ) }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: /* @__PURE__ */ jsxRuntime.jsx(
                reactRouterDom.Link,
                {
                  to: `/sales-reps/${row.sales_rep_id}`,
                  className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
                  children: row.sales_rep_name
                }
              ) }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: row.currency_code.toUpperCase() }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: formatMoney(row.payable, row.currency_code) }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: payable ? /* @__PURE__ */ jsxRuntime.jsx("div", { className: "ml-auto w-32", children: /* @__PURE__ */ jsxRuntime.jsx(
                ui.Input,
                {
                  size: "small",
                  type: "number",
                  min: 0,
                  step: currencyStep(row.currency_code),
                  "aria-label": `Amount to pay ${row.sales_rep_name} in ${row.currency_code.toUpperCase()}`,
                  value: amounts[key] ?? "",
                  onChange: (e) => setAmounts({ ...amounts, [key]: e.target.value })
                }
              ) }) : "-" }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: notes.map((note) => /* @__PURE__ */ jsxRuntime.jsx(
                ui.Text,
                {
                  size: "small",
                  leading: "compact",
                  className: "text-ui-fg-subtle",
                  children: note
                },
                note
              )) })
            ] }, key);
          }) })
        ] }) }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col items-start justify-between gap-3 px-6 py-4 md:flex-row md:items-center", children: [
          /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Selected" }),
            totals.length === 0 ? /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", children: "nothing" }) : totals.map(([currency, total]) => /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: "blue", children: formatMoney(total, currency) }, currency)),
            /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
              "in ",
              items.length,
              " ",
              items.length === 1 ? "transfer" : "transfers"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
            /* @__PURE__ */ jsxRuntime.jsxs(
              ui.Button,
              {
                size: "small",
                variant: "secondary",
                disabled: items.length === 0,
                onClick: exportCsv,
                children: [
                  /* @__PURE__ */ jsxRuntime.jsx(icons.ArrowDownTray, {}),
                  "Export CSV"
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntime.jsx(
              ui.Button,
              {
                size: "small",
                disabled: items.length === 0,
                onClick: () => {
                  setPaidAt(today());
                  setReference(
                    data.approved_through ? `${data.approved_through} run` : ""
                  );
                  setOpen(true);
                },
                children: "Mark selected as paid"
              }
            )
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx(FxRatesSection, {}),
    /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer, { open, onOpenChange: setOpen, children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Content, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Header, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Title, { children: "Mark as paid" }) }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
        /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: [
          "Records ",
          items.length,
          " ",
          items.length === 1 ? "payout" : "payouts",
          " together, one per rep and currency. Do this after you have made the transfers. A payout that differs from what is payable leaves the rest due, or becomes an advance."
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "run-date", children: "Paid on" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Input,
            {
              id: "run-date",
              type: "date",
              value: paidAt,
              onChange: (e) => setPaidAt(e.target.value)
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "run-reference", children: "Reference (optional)" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Input,
            {
              id: "run-reference",
              value: reference,
              onChange: (e) => setReference(e.target.value)
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Footer, { children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", disabled: record.isPending, children: "Cancel" }) }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", isLoading: record.isPending, onClick: () => record.mutate(), children: "Record payouts" })
      ] })
    ] }) })
  ] });
};
const config$2 = adminSdk.defineRouteConfig({
  label: "Payment run"
});
const CommissionReportPage = () => {
  const [period, setPeriod] = react.useState(currentPeriod());
  const { data, isLoading } = reactQuery.useQuery({
    queryKey: ["commission-report", period],
    queryFn: () => sdk.client.fetch(
      "/admin/sales-commission/report",
      { query: { period } }
    )
  });
  const exportCsv = () => downloadFile(
    `/admin/sales-commission/report?period=${period}&format=csv`,
    "text/csv",
    `commission-report-${period}.csv`
  ).catch((error) => ui.toast.error(errorMessage(error)));
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col items-start justify-between gap-2 px-6 py-4 md:flex-row md:items-center", children: [
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-1", children: [
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { children: "Commission report" }),
          data && /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: data.approved ? "green" : "orange", children: data.approved ? "Approved" : "Open" })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: [
          "What each rep was owed at the start of ",
          monthLabel(period),
          ", what the month earned and paid, and what is owed at the end. Commission counts in the month the order was paid. Totals are per currency."
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
        /* @__PURE__ */ jsxRuntime.jsx(PeriodSelect, { value: period, onChange: setPeriod }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(reactRouterDom.Link, { to: "/sales-reps/payment-run", children: "Payment run" }) }),
        /* @__PURE__ */ jsxRuntime.jsxs(ui.Button, { size: "small", variant: "secondary", onClick: exportCsv, children: [
          /* @__PURE__ */ jsxRuntime.jsx(icons.ArrowDownTray, {}),
          "Export CSV"
        ] })
      ] })
    ] }),
    isLoading || !data ? /* @__PURE__ */ jsxRuntime.jsx(Loading, {}) : data.rows.length === 0 ? /* @__PURE__ */ jsxRuntime.jsx("div", { className: "px-6 py-4", children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "No commission recorded for this month." }) }) : /* @__PURE__ */ jsxRuntime.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Table, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Header, { children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Table.Row, { children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Sales rep" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Currency" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Owed at start" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Direct" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Level 2" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Adjustments" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Earned" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Paid" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Owed at end" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Status" })
      ] }) }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Body, { children: data.rows.map((row) => {
        const money = (amount) => formatMoney(amount, row.currency_code);
        const badge = STATUS_BADGES[row.status];
        return /* @__PURE__ */ jsxRuntime.jsxs(ui.Table.Row, { children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: /* @__PURE__ */ jsxRuntime.jsx(
            reactRouterDom.Link,
            {
              to: `/sales-reps/${row.sales_rep_id}`,
              className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
              children: row.sales_rep_name
            }
          ) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: row.currency_code.toUpperCase() }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: money(row.opening) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: money(row.direct) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: money(row.level2) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: money(row.adjustments) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: money(row.total) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: money(row.paid) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: money(row.closing) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: badge.color, children: badge.label }) })
        ] }, `${row.sales_rep_id}-${row.currency_code}`);
      }) })
    ] }) })
  ] });
};
const config$1 = adminSdk.defineRouteConfig({
  label: "Commission report"
});
const PAGE_SIZE = 20;
const TABS = [
  { value: "applied", label: "Waiting" },
  { value: "approved", label: "Approved" },
  { value: "declined", label: "Declined" },
  { value: "invited", label: "Invited" }
];
const EMPTY = {
  applied: "Nothing is waiting. When someone a rep invited applies, it shows up here and you get an email.",
  approved: "No application has been approved yet.",
  declined: "No application has been declined.",
  invited: "No invitation is waiting for an answer.",
  canceled: "No invitation was withdrawn."
};
const columnHelper = ui.createDataTableColumnHelper();
const columns = [
  columnHelper.display({
    id: "candidate",
    header: "Candidate",
    cell: ({ row }) => /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col py-1", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", children: row.original.name }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: row.original.email })
    ] })
  }),
  columnHelper.display({
    id: "recruiter",
    header: "Recruited by",
    cell: ({ row }) => {
      var _a;
      return ((_a = row.original.recruiter) == null ? void 0 : _a.name) ?? "-";
    }
  }),
  columnHelper.display({
    id: "date",
    header: "Date",
    cell: ({ row }) => {
      const { status, applied_at, decided_at, expires_at, invited_at, expired } = row.original;
      if (status === "applied") return `Applied ${formatDate(applied_at ?? invited_at)}`;
      if (status === "approved" || status === "declined") {
        return `${status === "approved" ? "Approved" : "Declined"} ${formatDate(decided_at ?? invited_at)}`;
      }
      return expired ? `Link ended ${formatDate(expires_at)}` : `Link works until ${formatDate(expires_at)}`;
    }
  }),
  columnHelper.display({
    id: "currency",
    header: "Wants paid in",
    cell: ({ row }) => {
      var _a;
      return ((_a = row.original.requested_currency_code) == null ? void 0 : _a.toUpperCase()) ?? "-";
    }
  }),
  columnHelper.display({
    id: "status",
    header: "Status",
    cell: ({ row }) => {
      const badge = applicationBadge(row.original);
      return /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: badge.color, children: badge.label });
    }
  })
];
const ApplicationsPage = () => {
  const navigate = reactRouterDom.useNavigate();
  const [status, setStatus] = react.useState("applied");
  const [pagination, setPagination] = react.useState({
    pageIndex: 0,
    pageSize: PAGE_SIZE
  });
  const offset = pagination.pageIndex * PAGE_SIZE;
  const { data, isLoading } = reactQuery.useQuery({
    queryKey: ["applications", status, offset],
    queryFn: () => sdk.client.fetch("/admin/sales-commission/applications", {
      query: { status, limit: PAGE_SIZE, offset }
    }),
    placeholderData: reactQuery.keepPreviousData
  });
  const table = ui.useDataTable({
    data: (data == null ? void 0 : data.applications) ?? [],
    columns,
    getRowId: (application) => application.id,
    rowCount: (data == null ? void 0 : data.count) ?? 0,
    isLoading,
    pagination: { state: pagination, onPaginationChange: setPagination },
    // The review page also shows an application after it was decided
    onRowClick: (_, application) => navigate(`/sales-reps/applications/${application.id}`)
  });
  const counts = react.useMemo(() => data == null ? void 0 : data.counts, [data]);
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-1 px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { children: "Applications" }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: "Reps invite people to join. They apply from a personal link, and nothing is created or paid until you approve." })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx("div", { className: "px-6 py-3", children: /* @__PURE__ */ jsxRuntime.jsx(
      ui.Tabs,
      {
        value: status,
        onValueChange: (value) => {
          setStatus(value);
          setPagination({ pageIndex: 0, pageSize: PAGE_SIZE });
        },
        children: /* @__PURE__ */ jsxRuntime.jsx(ui.Tabs.List, { children: TABS.map((tab) => /* @__PURE__ */ jsxRuntime.jsxs(ui.Tabs.Trigger, { value: tab.value, children: [
          tab.label,
          counts ? ` (${counts[tab.value]})` : ""
        ] }, tab.value)) })
      }
    ) }),
    !isLoading && (data == null ? void 0 : data.applications.length) === 0 ? /* @__PURE__ */ jsxRuntime.jsx("div", { className: "px-6 py-6", children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: EMPTY[status] }) }) : /* @__PURE__ */ jsxRuntime.jsxs(ui.DataTable, { instance: table, children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.DataTable.Table, {}),
      /* @__PURE__ */ jsxRuntime.jsx(ui.DataTable.Pagination, {})
    ] })
  ] });
};
const config = adminSdk.defineRouteConfig({
  label: "Applications"
});
const DeclineApplicationDrawer = ({
  applicationId,
  name,
  open,
  onOpenChange
}) => {
  const queryClient = reactQuery.useQueryClient();
  const [reason, setReason] = react.useState("");
  const decline = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-commission/applications/${applicationId}/decline`, {
      method: "POST",
      body: { reason: reason.trim() }
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["applications"] });
      queryClient.invalidateQueries({ queryKey: ["application", applicationId] });
      ui.toast.success("Application declined");
      setReason("");
      onOpenChange(false);
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  return /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer, { open, onOpenChange, children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Content, { children: [
    /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Header, { children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Title, { children: [
      "Decline ",
      name
    ] }) }),
    /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: [
        name,
        " and the rep who invited them are emailed that the application was not approved. They are not told why; your reason stays here for your records."
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "decline-reason", children: "Reason (only you see it)" }),
        /* @__PURE__ */ jsxRuntime.jsx(
          ui.Textarea,
          {
            id: "decline-reason",
            rows: 4,
            maxLength: 500,
            value: reason,
            onChange: (e) => setReason(e.target.value)
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Footer, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", disabled: decline.isPending, children: "Cancel" }) }),
      /* @__PURE__ */ jsxRuntime.jsx(
        ui.Button,
        {
          size: "small",
          variant: "danger",
          disabled: !reason.trim(),
          isLoading: decline.isPending,
          onClick: () => decline.mutate(),
          children: "Decline application"
        }
      )
    ] })
  ] }) });
};
const CONTRACT_TYPES = ["application/pdf", "image/jpeg", "image/png"];
const MAX_CONTRACT_BYTES = 10 * 1024 * 1024;
const DURATIONS = [12, 24, 36];
const Field = ({ label, children }) => /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "grid grid-cols-[10rem_1fr] items-baseline gap-x-4 py-1.5", children: [
  /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: label }),
  /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", children: children || "-" })
] });
const ApplicationPage = () => {
  const { id = "" } = reactRouterDom.useParams();
  const navigate = reactRouterDom.useNavigate();
  const queryClient = reactQuery.useQueryClient();
  const fileInput = react.useRef(null);
  const [rate, setRate] = react.useState("");
  const [months, setMonths] = react.useState("none");
  const [currency, setCurrency] = react.useState("as_earned");
  const [contract, setContract] = react.useState(null);
  const [declining, setDeclining] = react.useState(false);
  const { data, isLoading, error } = reactQuery.useQuery({
    queryKey: ["application", id],
    queryFn: () => sdk.client.fetch(`/admin/sales-commission/applications/${id}`),
    enabled: !!id
  });
  const loaded = data == null ? void 0 : data.application.id;
  react.useEffect(() => {
    if (!data) return;
    setRate(String(data.defaults.level2_rate));
    setMonths(data.defaults.level2_months ? String(data.defaults.level2_months) : "none");
    const asked = data.application.requested_currency_code;
    setCurrency(asked === "eur" || asked === "huf" ? asked : "as_earned");
  }, [loaded]);
  const approve = reactQuery.useMutation({
    mutationFn: async () => sdk.client.fetch(
      `/admin/sales-commission/applications/${id}/approve`,
      {
        method: "POST",
        body: {
          level2_rate: Number(rate),
          level2_months: months === "none" ? null : Number(months),
          payout_currency_code: currency === "as_earned" ? null : currency,
          contract: contract ? {
            file_name: contract.name,
            mime_type: contract.type,
            content_base64: await readAsBase64(contract)
          } : null
        }
      }
    ),
    onSuccess: ({ sales_rep }) => {
      for (const key of ["applications", "application", "sales-reps", "rep-balances"]) {
        queryClient.invalidateQueries({ queryKey: [key] });
      }
      ui.toast.success("Rep created. A welcome email with a link to set a password is on its way");
      navigate(`/sales-reps/${sales_rep.id}`);
    },
    onError: (e) => ui.toast.error(errorMessage(e))
  });
  const onFile = (file) => {
    if (!file) return;
    if (!CONTRACT_TYPES.includes(file.type)) {
      return ui.toast.error("Upload a PDF, JPEG or PNG file");
    }
    if (file.size > MAX_CONTRACT_BYTES) {
      return ui.toast.error("Contracts can be at most 10 MB");
    }
    setContract(file);
  };
  if (isLoading) {
    return /* @__PURE__ */ jsxRuntime.jsx(ui.Container, { className: "p-0", children: /* @__PURE__ */ jsxRuntime.jsx(Loading, {}) });
  }
  if (error || !data) {
    return /* @__PURE__ */ jsxRuntime.jsx(ui.Container, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: error ? errorMessage(error) : "Application not found" }) });
  }
  const { application, recruiter, defaults, blockers } = data;
  const recruiterName = (recruiter == null ? void 0 : recruiter.name) ?? "The recruiter";
  const badge = applicationBadge(application);
  const waiting = application.status === "applied";
  const rateValid = rate !== "" && Number(rate) >= 0 && Number(rate) <= 100;
  const durations = [.../* @__PURE__ */ new Set([...DURATIONS, ...defaults.level2_months ? [defaults.level2_months] : []])].sort(
    (a, b) => a - b
  );
  return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-3", children: [
    /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
      /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex flex-col items-start justify-between gap-2 px-6 py-4 md:flex-row md:items-center", children: /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-1", children: [
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { children: application.name }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: badge.color, children: badge.label })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: /* @__PURE__ */ jsxRuntime.jsx(
          reactRouterDom.Link,
          {
            to: "/sales-reps/applications",
            className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
            children: "Applications"
          }
        ) })
      ] }) }),
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "px-6 py-4", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", className: "mb-2", children: "Application" }),
        /* @__PURE__ */ jsxRuntime.jsx(Field, { label: "Email", children: application.email }),
        /* @__PURE__ */ jsxRuntime.jsx(Field, { label: "Phone", children: application.phone }),
        /* @__PURE__ */ jsxRuntime.jsx(Field, { label: "Company or tax number", children: application.company }),
        /* @__PURE__ */ jsxRuntime.jsx(Field, { label: "Applied", children: application.applied_at ? formatDate(application.applied_at) : "Has not applied yet" }),
        /* @__PURE__ */ jsxRuntime.jsx(Field, { label: "Recruited by", children: application.recruiter ? /* @__PURE__ */ jsxRuntime.jsx(
          reactRouterDom.Link,
          {
            to: `/sales-reps/${application.recruiter.id}`,
            className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
            children: application.recruiter.name
          }
        ) : null }),
        application.note && /* @__PURE__ */ jsxRuntime.jsx(Field, { label: "Note from the recruiter", children: application.note }),
        application.status === "invited" && /* @__PURE__ */ jsxRuntime.jsx(Field, { label: "Link", children: application.expired ? `Ended ${formatDate(application.expires_at)}` : `Works until ${formatDate(application.expires_at)}` })
      ] })
    ] }),
    waiting && /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "px-6 py-4", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h2", children: "Terms" }),
        /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: [
          "Level 2 is what ",
          recruiterName,
          " earns on ",
          application.name,
          "'s clients' net sales, on top of ",
          application.name,
          "'s own commission."
        ] })
      ] }),
      blockers.length > 0 && /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: blockers.map((blocker) => /* @__PURE__ */ jsxRuntime.jsx(ui.Alert, { variant: "error", children: blocker }, blocker)) }),
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "grid grid-cols-1 gap-4 px-6 py-4 md:grid-cols-2", children: [
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsxs(ui.Label, { htmlFor: "level2-rate", children: [
            "Level 2 for ",
            recruiterName,
            " (%)"
          ] }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Input,
            {
              id: "level2-rate",
              type: "number",
              min: 0,
              max: 100,
              step: "0.01",
              value: rate,
              onChange: (e) => setRate(e.target.value)
            }
          ),
          String(defaults.level2_rate) === rate && /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "xsmall", leading: "compact", className: "text-ui-fg-muted", children: "Default from the settings" })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Level 2 lasts" }),
          /* @__PURE__ */ jsxRuntime.jsxs(ui.Select, { value: months, onValueChange: setMonths, children: [
            /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Value, {}) }),
            /* @__PURE__ */ jsxRuntime.jsxs(ui.Select.Content, { children: [
              /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: "none", children: level2Duration(null) }),
              durations.map((n) => /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: String(n), children: level2Duration(n) }, n))
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsxs(ui.Label, { children: [
            "Paid in",
            application.requested_currency_code ? ` (requested: ${application.requested_currency_code.toUpperCase()})` : ""
          ] }),
          /* @__PURE__ */ jsxRuntime.jsxs(ui.Select, { value: currency, onValueChange: setCurrency, children: [
            /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Value, {}) }),
            /* @__PURE__ */ jsxRuntime.jsxs(ui.Select.Content, { children: [
              /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: "as_earned", children: "As earned, in the order's currency" }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: "eur", children: "EUR" }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: "huf", children: "HUF" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Contract (optional)" }),
          /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
            /* @__PURE__ */ jsxRuntime.jsxs(
              ui.Button,
              {
                size: "small",
                variant: "secondary",
                type: "button",
                onClick: () => {
                  var _a;
                  return (_a = fileInput.current) == null ? void 0 : _a.click();
                },
                children: [
                  /* @__PURE__ */ jsxRuntime.jsx(icons.ArrowUpTray, {}),
                  contract ? "Change file" : "Upload the signed PDF"
                ]
              }
            ),
            contract && /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "truncate", children: [
              contract.name,
              " · ",
              formatSize(contract.size)
            ] }),
            /* @__PURE__ */ jsxRuntime.jsx(
              "input",
              {
                ref: fileInput,
                type: "file",
                accept: CONTRACT_TYPES.join(","),
                className: "hidden",
                onChange: (e) => {
                  var _a;
                  onFile((_a = e.target.files) == null ? void 0 : _a[0]);
                  e.target.value = "";
                }
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "xsmall", leading: "compact", className: "text-ui-fg-muted", children: "You can also add it later on the rep's page." })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col items-start justify-between gap-3 px-6 py-4 md:flex-row md:items-center", children: [
        /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", className: "text-ui-fg-subtle md:max-w-md", children: [
          "Approving creates the rep, links ",
          recruiterName,
          " as their recruiter from today, and emails them a link to set a password and sign in to the sales portal."
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Button,
            {
              size: "small",
              variant: "secondary",
              disabled: approve.isPending,
              onClick: () => setDeclining(true),
              children: "Decline…"
            }
          ),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Button,
            {
              size: "small",
              disabled: !rateValid || blockers.length > 0,
              isLoading: approve.isPending,
              onClick: () => approve.mutate(),
              children: "Approve and create rep"
            }
          )
        ] })
      ] })
    ] }),
    application.status === "approved" && /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", weight: "plus", children: [
        "Approved ",
        application.decided_at ? formatDate(application.decided_at) : ""
      ] }),
      application.sales_rep_id && /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", children: /* @__PURE__ */ jsxRuntime.jsx(
        reactRouterDom.Link,
        {
          to: `/sales-reps/${application.sales_rep_id}`,
          className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
          children: "Open the rep"
        }
      ) })
    ] }),
    application.status === "declined" && /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", weight: "plus", children: [
        "Declined ",
        application.decided_at ? formatDate(application.decided_at) : ""
      ] }),
      application.decision_reason && /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
        "Your reason: ",
        application.decision_reason
      ] })
    ] }),
    (application.status === "invited" || application.status === "canceled") && /* @__PURE__ */ jsxRuntime.jsx(ui.Container, { className: "px-6 py-4", children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: application.status === "canceled" ? "The rep withdrew this invitation." : "This person has not applied yet. You will get an email when they do." }) }),
    /* @__PURE__ */ jsxRuntime.jsx(
      DeclineApplicationDrawer,
      {
        applicationId: application.id,
        name: application.name,
        open: declining,
        onOpenChange: setDeclining
      }
    )
  ] });
};
const i18nTranslations0 = {};
const widgetModule = { widgets: [
  {
    Component: CustomerSalesRepWidget,
    zone: ["customer.details.side.after"],
    widgetId: "Widget-cf9f"
  }
] };
const routeModule = {
  routes: [
    {
      Component: SalesRepsPage,
      path: "/sales-reps",
      handle: { label: config$3.label, translationNs: config$3.translationNs }
    },
    {
      Component: SalesRepDetailPage,
      path: "/sales-reps/:id"
    },
    {
      Component: PaymentRunPage,
      path: "/sales-reps/payment-run",
      handle: { label: config$2.label, translationNs: config$2.translationNs }
    },
    {
      Component: CommissionReportPage,
      path: "/sales-reps/report",
      handle: { label: config$1.label, translationNs: config$1.translationNs }
    },
    {
      Component: ApplicationsPage,
      path: "/sales-reps/applications",
      handle: { label: config.label, translationNs: config.translationNs }
    },
    {
      Component: ApplicationPage,
      path: "/sales-reps/applications/:id"
    }
  ]
};
const menuItemModule = {
  menuItems: [
    {
      label: config$3.label,
      icon: config$3.icon,
      path: "/sales-reps",
      nested: void 0,
      rank: void 0,
      translationNs: void 0
    },
    {
      label: config.label,
      icon: void 0,
      path: "/sales-reps/applications",
      nested: void 0,
      rank: void 0,
      translationNs: void 0
    },
    {
      label: config$1.label,
      icon: void 0,
      path: "/sales-reps/report",
      nested: void 0,
      rank: void 0,
      translationNs: void 0
    },
    {
      label: config$2.label,
      icon: void 0,
      path: "/sales-reps/payment-run",
      nested: void 0,
      rank: void 0,
      translationNs: void 0
    }
  ]
};
const formModule = { customFields: {} };
const displayModule = {
  displays: {}
};
const i18nModule = { resources: i18nTranslations0 };
const cellRendererModule = {};
const layoutModule = { layouts: [] };
const plugin = {
  widgetModule,
  routeModule,
  menuItemModule,
  formModule,
  displayModule,
  i18nModule,
  cellRendererModule,
  layoutModule
};
module.exports = plugin;
