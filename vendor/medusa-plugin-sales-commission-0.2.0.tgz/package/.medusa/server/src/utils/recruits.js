"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadPortalRecruits = void 0;
const invite_1 = require("../lib/invite");
const period_1 = require("../lib/period");
const recruits_1 = require("../lib/recruits");
const report_1 = require("../lib/report");
const sales_commission_1 = require("../modules/sales-commission");
const invites_1 = require("./invites");
const period_activity_1 = require("./period-activity");
/** A rep's invites and recruits as the portal lists them, with the invite limits. */
const loadPortalRecruits = async (container, recruiterId) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const now = new Date();
    const settings = (0, invites_1.recruitingSettings)(service);
    const invites = await service.listRepInvites({
        recruiter_sales_rep_id: recruiterId,
    });
    const repIds = invites
        .map((invite) => invite.sales_rep_id)
        .filter((id) => !!id);
    const [reps, referrals, history] = await Promise.all([
        repIds.length
            ? service.listSalesReps({ id: repIds }, { select: ["id", "is_active"] })
            : [],
        repIds.length
            ? service.listRepReferrals({
                referrer_sales_rep_id: recruiterId,
                referred_sales_rep_id: repIds,
                ends_at: null,
            })
            : [],
        repIds.length
            ? (0, period_activity_1.loadRepHistory)(container, recruiterId)
            : { entries: [], adjustments: [], payouts: [] },
    ]);
    return {
        recruits: (0, recruits_1.portalRecruits)({
            recruiterId,
            invites,
            reps,
            referrals,
            lines: (0, report_1.allLines)(history),
            period: (0, period_1.toPeriod)(now, service.getOptions().timezone),
            now,
        }),
        limits: {
            open_invites: invites.filter((invite) => (invite.status === "invited" || invite.status === "applied") &&
                (0, invite_1.inviteState)(invite, now) !== "expired").length,
            max_open_invites: settings.max_open_invites,
            invite_days: settings.invite_days,
        },
    };
};
exports.loadPortalRecruits = loadPortalRecruits;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVjcnVpdHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvdXRpbHMvcmVjcnVpdHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQ0EsMENBQTJDO0FBQzNDLDBDQUF3QztBQUN4Qyw4Q0FBK0Q7QUFDL0QsMENBQXdDO0FBQ3hDLGtFQUFxRTtBQUVyRSx1Q0FBOEM7QUFDOUMsdURBQWtEO0FBU2xELHFGQUFxRjtBQUM5RSxNQUFNLGtCQUFrQixHQUFHLEtBQUssRUFDckMsU0FBMEIsRUFDMUIsV0FBbUIsRUFDNEMsRUFBRTtJQUNqRSxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLEdBQUcsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFBO0lBQ3RCLE1BQU0sUUFBUSxHQUFHLElBQUEsNEJBQWtCLEVBQUMsT0FBTyxDQUFDLENBQUE7SUFFNUMsTUFBTSxPQUFPLEdBQUcsTUFBTSxPQUFPLENBQUMsY0FBYyxDQUFDO1FBQzNDLHNCQUFzQixFQUFFLFdBQVc7S0FDcEMsQ0FBQyxDQUFBO0lBQ0YsTUFBTSxNQUFNLEdBQUcsT0FBTztTQUNuQixHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7U0FDcEMsTUFBTSxDQUFDLENBQUMsRUFBRSxFQUFnQixFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBRXJDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUNuRCxNQUFNLENBQUMsTUFBTTtZQUNYLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxFQUFFLENBQUM7WUFDeEUsQ0FBQyxDQUFDLEVBQUU7UUFDTixNQUFNLENBQUMsTUFBTTtZQUNYLENBQUMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUM7Z0JBQ3ZCLHFCQUFxQixFQUFFLFdBQVc7Z0JBQ2xDLHFCQUFxQixFQUFFLE1BQU07Z0JBQzdCLE9BQU8sRUFBRSxJQUFJO2FBQ2QsQ0FBQztZQUNKLENBQUMsQ0FBQyxFQUFFO1FBQ04sTUFBTSxDQUFDLE1BQU07WUFDWCxDQUFDLENBQUMsSUFBQSxnQ0FBYyxFQUFDLFNBQVMsRUFBRSxXQUFXLENBQUM7WUFDeEMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUU7S0FDbEQsQ0FBQyxDQUFBO0lBRUYsT0FBTztRQUNMLFFBQVEsRUFBRSxJQUFBLHlCQUFjLEVBQUM7WUFDdkIsV0FBVztZQUNYLE9BQU87WUFDUCxJQUFJO1lBQ0osU0FBUztZQUNULEtBQUssRUFBRSxJQUFBLGlCQUFRLEVBQUMsT0FBTyxDQUFDO1lBQ3hCLE1BQU0sRUFBRSxJQUFBLGlCQUFRLEVBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxRQUFRLENBQUM7WUFDcEQsR0FBRztTQUNKLENBQUM7UUFDRixNQUFNLEVBQUU7WUFDTixZQUFZLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FDMUIsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUNULENBQUMsTUFBTSxDQUFDLE1BQU0sS0FBSyxTQUFTLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxTQUFTLENBQUM7Z0JBQzVELElBQUEsb0JBQVcsRUFBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLEtBQUssU0FBUyxDQUN6QyxDQUFDLE1BQU07WUFDUixnQkFBZ0IsRUFBRSxRQUFRLENBQUMsZ0JBQWdCO1lBQzNDLFdBQVcsRUFBRSxRQUFRLENBQUMsV0FBVztTQUNsQztLQUNGLENBQUE7QUFDSCxDQUFDLENBQUE7QUFyRFksUUFBQSxrQkFBa0Isc0JBcUQ5QiJ9