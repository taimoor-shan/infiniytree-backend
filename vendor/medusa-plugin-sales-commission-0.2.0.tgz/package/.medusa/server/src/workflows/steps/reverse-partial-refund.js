"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reversePartialRefundStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const partial_refund_1 = require("../../lib/partial-refund");
const period_1 = require("../../lib/period");
const sales_commission_1 = require("../../modules/sales-commission");
const locks_1 = require("../../utils/locks");
/**
 * Takes back the refunded share of an order's commission, from the entries the
 * order earned, with an adjustment per entry in the current month. Past months
 * never change: a commission that was already paid is netted against the
 * next payout. Running it again for the same refunds adds nothing.
 */
exports.reversePartialRefundStep = (0, workflows_sdk_1.createStep)("reverse-partial-refund", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const created = await (0, locks_1.withLock)(container, (0, locks_1.orderLockKey)(input.order_id), async () => {
        const live = await service.listCommissionEntries({
            order_id: input.order_id,
            voided_at: null,
        });
        if (!live.length) {
            return [];
        }
        const previous = await service.listCommissionAdjustments({
            kind: "partial_refund",
            source_id: live.map((entry) => entry.id),
        });
        const drafts = (0, partial_refund_1.partialRefundAdjustments)({
            entries: live,
            share: input.share,
            previous,
        });
        if (!drafts.length) {
            return [];
        }
        const period = (0, period_1.toPeriod)(new Date(), service.getOptions().timezone);
        return service.createCommissionAdjustments(drafts.map((draft) => ({ ...draft, period, created_by: null })));
    });
    return new workflows_sdk_1.StepResponse(created, created.map((adjustment) => adjustment.id));
}, async (adjustmentIds, { container }) => {
    if (!adjustmentIds?.length) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.deleteCommissionAdjustments(adjustmentIds);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmV2ZXJzZS1wYXJ0aWFsLXJlZnVuZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3Mvc3RlcHMvcmV2ZXJzZS1wYXJ0aWFsLXJlZnVuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxRUFBNEU7QUFDNUUsNkRBQW1FO0FBQ25FLDZDQUEyQztBQUMzQyxxRUFBd0U7QUFFeEUsNkNBQTBEO0FBUTFEOzs7OztHQUtHO0FBQ1UsUUFBQSx3QkFBd0IsR0FBRyxJQUFBLDBCQUFVLEVBQ2hELHdCQUF3QixFQUN4QixLQUFLLEVBQUUsS0FBb0MsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDNUQsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBRUQsTUFBTSxPQUFPLEdBQUcsTUFBTSxJQUFBLGdCQUFRLEVBQUMsU0FBUyxFQUFFLElBQUEsb0JBQVksRUFBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQUUsS0FBSyxJQUFJLEVBQUU7UUFDakYsTUFBTSxJQUFJLEdBQUcsTUFBTSxPQUFPLENBQUMscUJBQXFCLENBQUM7WUFDL0MsUUFBUSxFQUFFLEtBQUssQ0FBQyxRQUFRO1lBQ3hCLFNBQVMsRUFBRSxJQUFJO1NBQ2hCLENBQUMsQ0FBQTtRQUNGLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDakIsT0FBTyxFQUFFLENBQUE7UUFDWCxDQUFDO1FBRUQsTUFBTSxRQUFRLEdBQUcsTUFBTSxPQUFPLENBQUMseUJBQXlCLENBQUM7WUFDdkQsSUFBSSxFQUFFLGdCQUFnQjtZQUN0QixTQUFTLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztTQUN6QyxDQUFDLENBQUE7UUFDRixNQUFNLE1BQU0sR0FBRyxJQUFBLHlDQUF3QixFQUFDO1lBQ3RDLE9BQU8sRUFBRSxJQUFJO1lBQ2IsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLO1lBQ2xCLFFBQVE7U0FDVCxDQUFDLENBQUE7UUFDRixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ25CLE9BQU8sRUFBRSxDQUFBO1FBQ1gsQ0FBQztRQUVELE1BQU0sTUFBTSxHQUFHLElBQUEsaUJBQVEsRUFBQyxJQUFJLElBQUksRUFBRSxFQUFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQTtRQUNsRSxPQUFPLE9BQU8sQ0FBQywyQkFBMkIsQ0FDeEMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsS0FBSyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUNoRSxDQUFBO0lBQ0gsQ0FBQyxDQUFDLENBQUE7SUFFRixPQUFPLElBQUksNEJBQVksQ0FDckIsT0FBTyxFQUNQLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FDM0MsQ0FBQTtBQUNILENBQUMsRUFDRCxLQUFLLEVBQUUsYUFBYSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUNyQyxJQUFJLENBQUMsYUFBYSxFQUFFLE1BQU0sRUFBRSxDQUFDO1FBQzNCLE9BQU07SUFDUixDQUFDO0lBQ0QsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxPQUFPLENBQUMsMkJBQTJCLENBQUMsYUFBYSxDQUFDLENBQUE7QUFDMUQsQ0FBQyxDQUNGLENBQUEifQ==