"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const customer_1 = __importDefault(require("@medusajs/medusa/customer"));
const utils_1 = require("@medusajs/framework/utils");
const sales_commission_1 = __importDefault(require("../modules/sales-commission"));
/**
 * customer.client_assignment: a customer's salesperson history. Read-only,
 * resolved through client_assignment.customer_id (no link table).
 */
exports.default = (0, utils_1.defineLink)({
    linkable: customer_1.default.linkable.customer,
    field: "id",
    isList: true,
}, {
    ...sales_commission_1.default.linkable.clientAssignment.id,
    primaryKey: "customer_id",
}, { readOnly: true });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3VzdG9tZXItY2xpZW50LWFzc2lnbm1lbnRzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL2xpbmtzL2N1c3RvbWVyLWNsaWVudC1hc3NpZ25tZW50cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLHlFQUFzRDtBQUN0RCxxREFBc0Q7QUFDdEQsbUZBQStEO0FBRS9EOzs7R0FHRztBQUNILGtCQUFlLElBQUEsa0JBQVUsRUFDdkI7SUFDRSxRQUFRLEVBQUUsa0JBQWMsQ0FBQyxRQUFRLENBQUMsUUFBUTtJQUMxQyxLQUFLLEVBQUUsSUFBSTtJQUNYLE1BQU0sRUFBRSxJQUFJO0NBQ2IsRUFDRDtJQUNFLEdBQUcsMEJBQXFCLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7SUFDckQsVUFBVSxFQUFFLGFBQWE7Q0FDMUIsRUFDRCxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsQ0FDbkIsQ0FBQSJ9