"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteCommissionPayoutStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const sales_commission_1 = require("../../modules/sales-commission");
/**
 * Soft-deletes a payout recorded by mistake; the row stays in the database.
 * A bonus that was recorded with it goes too, so removing the payout puts
 * the balance back where it was.
 */
exports.deleteCommissionPayoutStep = (0, workflows_sdk_1.createStep)("delete-commission-payout", async ({ id }, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.retrieveCommissionPayout(id);
    const bonuses = await service.listCommissionAdjustments({ kind: "payout_bonus", source_id: id }, { select: ["id"] });
    const bonusIds = bonuses.map((bonus) => bonus.id);
    if (bonusIds.length) {
        await service.softDeleteCommissionAdjustments(bonusIds);
    }
    await service.softDeleteCommissionPayouts(id);
    return new workflows_sdk_1.StepResponse(id, { id, bonusIds });
}, async (removed, { container }) => {
    if (!removed) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.restoreCommissionPayouts(removed.id);
    if (removed.bonusIds.length) {
        await service.restoreCommissionAdjustments(removed.bonusIds);
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVsZXRlLWNvbW1pc3Npb24tcGF5b3V0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9kZWxldGUtY29tbWlzc2lvbi1wYXlvdXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscUVBQTRFO0FBQzVFLHFFQUF3RTtBQUd4RTs7OztHQUlHO0FBQ1UsUUFBQSwwQkFBMEIsR0FBRyxJQUFBLDBCQUFVLEVBQ2xELDBCQUEwQixFQUMxQixLQUFLLEVBQUUsRUFBRSxFQUFFLEVBQWtCLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQzlDLE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sT0FBTyxDQUFDLHdCQUF3QixDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBQzFDLE1BQU0sT0FBTyxHQUFHLE1BQU0sT0FBTyxDQUFDLHlCQUF5QixDQUNyRCxFQUFFLElBQUksRUFBRSxjQUFjLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRSxFQUN2QyxFQUFFLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQ25CLENBQUE7SUFDRCxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUE7SUFFakQsSUFBSSxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDcEIsTUFBTSxPQUFPLENBQUMsK0JBQStCLENBQUMsUUFBUSxDQUFDLENBQUE7SUFDekQsQ0FBQztJQUNELE1BQU0sT0FBTyxDQUFDLDJCQUEyQixDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBRTdDLE9BQU8sSUFBSSw0QkFBWSxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFBO0FBQy9DLENBQUMsRUFDRCxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUMvQixJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDYixPQUFNO0lBQ1IsQ0FBQztJQUNELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sT0FBTyxDQUFDLHdCQUF3QixDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUNsRCxJQUFJLE9BQU8sQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDNUIsTUFBTSxPQUFPLENBQUMsNEJBQTRCLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBQzlELENBQUM7QUFDSCxDQUFDLENBQ0YsQ0FBQSJ9