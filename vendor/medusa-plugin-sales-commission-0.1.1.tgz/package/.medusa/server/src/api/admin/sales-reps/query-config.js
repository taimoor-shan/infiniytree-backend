"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CONTRACT_FIELDS = exports.listSalesRepsQueryConfig = exports.SALES_REP_FIELDS = void 0;
exports.SALES_REP_FIELDS = [
    "id",
    "name",
    "email",
    "phone",
    "notes",
    "is_active",
    "created_at",
    "updated_at",
];
exports.listSalesRepsQueryConfig = {
    defaults: exports.SALES_REP_FIELDS,
    isList: true,
};
/** Everything but the file content */
exports.CONTRACT_FIELDS = [
    "id",
    "file_name",
    "mime_type",
    "size_bytes",
    "uploaded_by",
    "created_at",
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicXVlcnktY29uZmlnLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL2FwaS9hZG1pbi9zYWxlcy1yZXBzL3F1ZXJ5LWNvbmZpZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBYSxRQUFBLGdCQUFnQixHQUFHO0lBQzlCLElBQUk7SUFDSixNQUFNO0lBQ04sT0FBTztJQUNQLE9BQU87SUFDUCxPQUFPO0lBQ1AsV0FBVztJQUNYLFlBQVk7SUFDWixZQUFZO0NBQ2IsQ0FBQTtBQUVZLFFBQUEsd0JBQXdCLEdBQUc7SUFDdEMsUUFBUSxFQUFFLHdCQUFnQjtJQUMxQixNQUFNLEVBQUUsSUFBSTtDQUNiLENBQUE7QUFFRCxzQ0FBc0M7QUFDekIsUUFBQSxlQUFlLEdBQUc7SUFDN0IsSUFBSTtJQUNKLFdBQVc7SUFDWCxXQUFXO0lBQ1gsWUFBWTtJQUNaLGFBQWE7SUFDYixZQUFZO0NBQ2IsQ0FBQSJ9