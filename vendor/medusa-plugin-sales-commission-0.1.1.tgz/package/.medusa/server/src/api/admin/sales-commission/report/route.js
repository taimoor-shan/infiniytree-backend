"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const export_1 = require("../../../../lib/export");
const report_1 = require("../../../../lib/report");
const period_activity_1 = require("../../../../utils/period-activity");
const helpers_1 = require("../helpers");
/** Every rep's totals for a month, per currency. */
async function GET(req, res) {
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { period } = (0, helpers_1.requestedPeriod)(req);
    const [{ data: reps }, activity] = await Promise.all([
        query.graph({
            entity: "sales_rep",
            fields: ["id", "name", "email"],
        }),
        (0, period_activity_1.loadPeriodActivity)(req.scope, { period }),
    ]);
    const rows = (0, report_1.buildReport)({ period, reps, ...activity });
    if ((0, helpers_1.wantsCsv)(req)) {
        return (0, helpers_1.sendCsv)(res, `commission-report-${period}.csv`, (0, export_1.reportCsv)({ period, rows }));
    }
    res.json({ period, rows });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLWNvbW1pc3Npb24vcmVwb3J0L3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBV0Esa0JBeUJDO0FBaENELHFEQUFxRTtBQUNyRSxtREFBa0Q7QUFDbEQsbURBQW9EO0FBQ3BELHVFQUFzRTtBQUN0RSx3Q0FBK0Q7QUFFL0Qsb0RBQW9EO0FBQzdDLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQStCLEVBQy9CLEdBQW1CO0lBRW5CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFBO0lBQ2hFLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFBLHlCQUFlLEVBQUMsR0FBRyxDQUFDLENBQUE7SUFFdkMsTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxFQUFFLFFBQVEsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUNuRCxLQUFLLENBQUMsS0FBSyxDQUFDO1lBQ1YsTUFBTSxFQUFFLFdBQVc7WUFDbkIsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLENBQUM7U0FDaEMsQ0FBQztRQUNGLElBQUEsb0NBQWtCLEVBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxFQUFFLE1BQU0sRUFBRSxDQUFDO0tBQzFDLENBQUMsQ0FBQTtJQUNGLE1BQU0sSUFBSSxHQUFHLElBQUEsb0JBQVcsRUFBQyxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsR0FBRyxRQUFRLEVBQUUsQ0FBQyxDQUFBO0lBRXZELElBQUksSUFBQSxrQkFBUSxFQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDbEIsT0FBTyxJQUFBLGlCQUFPLEVBQ1osR0FBRyxFQUNILHFCQUFxQixNQUFNLE1BQU0sRUFDakMsSUFBQSxrQkFBUyxFQUFDLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxDQUFDLENBQzVCLENBQUE7SUFDSCxDQUFDO0lBRUQsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO0FBQzVCLENBQUMifQ==