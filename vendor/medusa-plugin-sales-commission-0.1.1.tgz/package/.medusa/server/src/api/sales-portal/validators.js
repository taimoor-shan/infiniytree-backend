"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PortalPageParams = exports.PortalPeriodParams = void 0;
const zod_1 = require("@medusajs/framework/zod");
exports.PortalPeriodParams = zod_1.z.object({
    period: zod_1.z
        .string()
        .regex(/^\d{4}-(0[1-9]|1[0-2])$/, "Use a month in the form YYYY-MM")
        .optional(),
});
exports.PortalPageParams = zod_1.z.object({
    limit: zod_1.z.coerce.number().int().min(1).max(100).default(50),
    offset: zod_1.z.coerce.number().int().min(0).default(0),
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdG9ycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9hcGkvc2FsZXMtcG9ydGFsL3ZhbGlkYXRvcnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsaURBQTJDO0FBRTlCLFFBQUEsa0JBQWtCLEdBQUcsT0FBQyxDQUFDLE1BQU0sQ0FBQztJQUN6QyxNQUFNLEVBQUUsT0FBQztTQUNOLE1BQU0sRUFBRTtTQUNSLEtBQUssQ0FBQyx5QkFBeUIsRUFBRSxpQ0FBaUMsQ0FBQztTQUNuRSxRQUFRLEVBQUU7Q0FDZCxDQUFDLENBQUE7QUFFVyxRQUFBLGdCQUFnQixHQUFHLE9BQUMsQ0FBQyxNQUFNLENBQUM7SUFDdkMsS0FBSyxFQUFFLE9BQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO0lBQzFELE1BQU0sRUFBRSxPQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0NBQ2xELENBQUMsQ0FBQSJ9