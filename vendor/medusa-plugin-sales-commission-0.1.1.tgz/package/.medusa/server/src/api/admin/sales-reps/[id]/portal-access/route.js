"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
exports.DELETE = DELETE;
const portal_1 = require("../../../../../lib/portal");
const sales_commission_1 = require("../../../../../modules/sales-commission");
const grant_portal_access_1 = require("../../../../../workflows/grant-portal-access");
const revoke_portal_access_1 = require("../../../../../workflows/revoke-portal-access");
/**
 * Gives the rep a portal login. Returns the links to pass on: the rep sets a
 * first password through the portal's forgot-password page.
 */
async function POST(req, res) {
    const service = req.scope.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const { result } = await (0, grant_portal_access_1.grantPortalAccessWorkflow)(req.scope).run({
        input: { sales_rep_id: req.params.id },
    });
    res.json({
        portal: { status: "active" },
        ...(0, portal_1.portalLinks)(service.getOptions().portal_url, result.email),
    });
}
/** Ends the rep's portal access at once. A rep without access is left as is. */
async function DELETE(req, res) {
    await (0, revoke_portal_access_1.revokePortalAccessWorkflow)(req.scope).run({
        input: { sales_rep_id: req.params.id },
    });
    res.json({ portal: { status: "none" } });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLXJlcHMvW2lkXS9wb3J0YWwtYWNjZXNzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBY0Esb0JBZUM7QUFHRCx3QkFTQztBQXJDRCxzREFBdUQ7QUFDdkQsOEVBQWlGO0FBRWpGLHNGQUF3RjtBQUN4Rix3RkFBMEY7QUFFMUY7OztHQUdHO0FBQ0ksS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBK0IsRUFDL0IsR0FBbUI7SUFFbkIsTUFBTSxPQUFPLEdBQWlDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLElBQUEsK0NBQXlCLEVBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUNoRSxLQUFLLEVBQUUsRUFBRSxZQUFZLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUU7S0FDdkMsQ0FBQyxDQUFBO0lBRUYsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNQLE1BQU0sRUFBRSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUU7UUFDNUIsR0FBRyxJQUFBLG9CQUFXLEVBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDO0tBQzlELENBQUMsQ0FBQTtBQUNKLENBQUM7QUFFRCxnRkFBZ0Y7QUFDekUsS0FBSyxVQUFVLE1BQU0sQ0FDMUIsR0FBK0IsRUFDL0IsR0FBbUI7SUFFbkIsTUFBTSxJQUFBLGlEQUEwQixFQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUM7UUFDOUMsS0FBSyxFQUFFLEVBQUUsWUFBWSxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFO0tBQ3ZDLENBQUMsQ0FBQTtJQUVGLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFBO0FBQzFDLENBQUMifQ==