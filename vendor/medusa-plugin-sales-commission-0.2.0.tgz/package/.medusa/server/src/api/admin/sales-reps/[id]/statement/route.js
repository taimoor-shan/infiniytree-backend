"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const export_1 = require("../../../../../lib/export");
const report_1 = require("../../../../../lib/report");
const statement_1 = require("../../../../../lib/statement");
const period_activity_1 = require("../../../../../utils/period-activity");
const helpers_1 = require("../../../sales-commission/helpers");
/**
 * A rep's month: lines with the running balance carried from earlier months,
 * and the totals with what was owed at the start and the end of the month.
 */
async function GET(req, res) {
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { period, timezone } = (0, helpers_1.requestedPeriod)(req);
    const { data: [salesRep], } = await query.graph({
        entity: "sales_rep",
        fields: ["id", "name", "email", "payout_currency_code"],
        filters: { id: req.params.id },
    });
    if (!salesRep) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, `Sales rep ${req.params.id} was not found`);
    }
    const [history, approvedThrough] = await Promise.all([
        (0, period_activity_1.loadRepHistory)(req.scope, salesRep.id),
        (0, period_activity_1.loadApprovedThrough)(req.scope),
    ]);
    const statement = (0, statement_1.buildStatement)({
        lines: (0, report_1.allLines)(history),
        period,
        approvedThrough,
    });
    if ((0, helpers_1.wantsCsv)(req)) {
        return (0, helpers_1.sendCsv)(res, `commission-statement-${(0, helpers_1.slug)(salesRep.name)}-${period}.csv`, (0, export_1.statementCsv)({ lines: statement.lines, totals: statement.totals, timezone }));
    }
    res.json({ ...statement, sales_rep: salesRep });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLXJlcHMvW2lkXS9zdGF0ZW1lbnQvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUEwQkEsa0JBd0NDO0FBOURELHFEQUdrQztBQUNsQyxzREFBd0Q7QUFDeEQsc0RBQW9EO0FBQ3BELDREQUE2RDtBQUM3RCwwRUFHNkM7QUFDN0MsK0RBSzBDO0FBRTFDOzs7R0FHRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQStCLEVBQy9CLEdBQW1CO0lBRW5CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFBO0lBQ2hFLE1BQU0sRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLEdBQUcsSUFBQSx5QkFBZSxFQUFDLEdBQUcsQ0FBQyxDQUFBO0lBRWpELE1BQU0sRUFDSixJQUFJLEVBQUUsQ0FBQyxRQUFRLENBQUMsR0FDakIsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDcEIsTUFBTSxFQUFFLFdBQVc7UUFDbkIsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsc0JBQXNCLENBQUM7UUFDdkQsT0FBTyxFQUFFLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFO0tBQy9CLENBQUMsQ0FBQTtJQUNGLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNkLE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQzNCLGFBQWEsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLGdCQUFnQixDQUMzQyxDQUFBO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyxPQUFPLEVBQUUsZUFBZSxDQUFDLEdBQUcsTUFBTSxPQUFPLENBQUMsR0FBRyxDQUFDO1FBQ25ELElBQUEsZ0NBQWMsRUFBQyxHQUFHLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxFQUFFLENBQUM7UUFDdEMsSUFBQSxxQ0FBbUIsRUFBQyxHQUFHLENBQUMsS0FBSyxDQUFDO0tBQy9CLENBQUMsQ0FBQTtJQUNGLE1BQU0sU0FBUyxHQUFHLElBQUEsMEJBQWMsRUFBQztRQUMvQixLQUFLLEVBQUUsSUFBQSxpQkFBUSxFQUFDLE9BQU8sQ0FBQztRQUN4QixNQUFNO1FBQ04sZUFBZTtLQUNoQixDQUFDLENBQUE7SUFFRixJQUFJLElBQUEsa0JBQVEsRUFBQyxHQUFHLENBQUMsRUFBRSxDQUFDO1FBQ2xCLE9BQU8sSUFBQSxpQkFBTyxFQUNaLEdBQUcsRUFDSCx3QkFBd0IsSUFBQSxjQUFJLEVBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLE1BQU0sTUFBTSxFQUMzRCxJQUFBLHFCQUFZLEVBQUMsRUFBRSxLQUFLLEVBQUUsU0FBUyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsU0FBUyxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUM3RSxDQUFBO0lBQ0gsQ0FBQztJQUVELEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLFNBQVMsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQTtBQUNqRCxDQUFDIn0=