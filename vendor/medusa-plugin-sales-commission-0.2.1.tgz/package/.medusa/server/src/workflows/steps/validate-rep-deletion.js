"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateRepDeletionStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const rep_deletion_1 = require("../../lib/rep-deletion");
const sales_commission_1 = require("../../modules/sales-commission");
const rep_deletion_2 = require("../../utils/rep-deletion");
/**
 * Stops the deletion of a rep that has money on record, current clients or
 * recruits, or whose recruits wait for a decision. Says everything that is in
 * the way, not just the first thing.
 */
exports.validateRepDeletionStep = (0, workflows_sdk_1.createStep)("validate-rep-deletion", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const [rep] = await service.listSalesReps({ id: input.id }, { take: 1, select: ["id"] });
    if (!rep) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, `Sales rep ${input.id} was not found`);
    }
    const blockers = await (0, rep_deletion_2.loadRepDeletionBlockers)(container, input.id);
    if (blockers.length) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, (0, rep_deletion_1.repDeletionMessage)(blockers), rep_deletion_1.REP_DELETE_BLOCKED);
    }
    return new workflows_sdk_1.StepResponse(null);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdGUtcmVwLWRlbGV0aW9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy92YWxpZGF0ZS1yZXAtZGVsZXRpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQXVEO0FBQ3ZELHFFQUE0RTtBQUM1RSx5REFBK0U7QUFDL0UscUVBQXdFO0FBRXhFLDJEQUFrRTtBQUVsRTs7OztHQUlHO0FBQ1UsUUFBQSx1QkFBdUIsR0FBRyxJQUFBLDBCQUFVLEVBQy9DLHVCQUF1QixFQUN2QixLQUFLLEVBQUUsS0FBcUIsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDN0MsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBRUQsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLGFBQWEsQ0FDdkMsRUFBRSxFQUFFLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRSxFQUNoQixFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FDNUIsQ0FBQTtJQUNELElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNULE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQzNCLGFBQWEsS0FBSyxDQUFDLEVBQUUsZ0JBQWdCLENBQ3RDLENBQUE7SUFDSCxDQUFDO0lBRUQsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFBLHNDQUF1QixFQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUE7SUFDbkUsSUFBSSxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDcEIsTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFDOUIsSUFBQSxpQ0FBa0IsRUFBQyxRQUFRLENBQUMsRUFDNUIsaUNBQWtCLENBQ25CLENBQUE7SUFDSCxDQUFDO0lBRUQsT0FBTyxJQUFJLDRCQUFZLENBQUMsSUFBSSxDQUFDLENBQUE7QUFDL0IsQ0FBQyxDQUNGLENBQUEifQ==