"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.approveCommissionPeriodsWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const approve_commission_periods_1 = require("./steps/approve-commission-periods");
exports.approveCommissionPeriodsWorkflow = (0, workflows_sdk_1.createWorkflow)("approve-commission-periods", function (input) {
    return new workflows_sdk_1.WorkflowResponse((0, approve_commission_periods_1.approveCommissionPeriodsStep)(input));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwcm92ZS1jb21taXNzaW9uLXBlcmlvZHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL2FwcHJvdmUtY29tbWlzc2lvbi1wZXJpb2RzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFFQUcwQztBQUMxQyxtRkFHMkM7QUFFOUIsUUFBQSxnQ0FBZ0MsR0FBRyxJQUFBLDhCQUFjLEVBQzVELDRCQUE0QixFQUM1QixVQUFVLEtBQXdDO0lBQ2hELE9BQU8sSUFBSSxnQ0FBZ0IsQ0FBQyxJQUFBLHlEQUE0QixFQUFDLEtBQUssQ0FBQyxDQUFDLENBQUE7QUFDbEUsQ0FBQyxDQUNGLENBQUEifQ==