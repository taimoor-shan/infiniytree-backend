"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = exports.reconcileCommissions = void 0;
exports.default = reconcileCommissionsJob;
const utils_1 = require("@medusajs/framework/utils");
const orders_for_payments_1 = require("../utils/orders-for-payments");
const record_order_commission_1 = require("../workflows/record-order-commission");
const void_order_commission_1 = require("../workflows/void-order-commission");
const refunds_1 = require("../utils/refunds");
const LOOKBACK_DAYS = 7;
/**
 * Re-runs recording and voiding for payments captured, refunds made and
 * orders canceled since `since`. Both workflows are idempotent, so this only
 * fills in what a lost event (e.g. a restart mid-delivery) left out.
 */
const reconcileCommissions = async (container, { since }) => {
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const logger = container.resolve(utils_1.ContainerRegistrationKeys.LOGGER);
    const [{ data: captured }, { data: refunds }, { data: canceled }] = await Promise.all([
        query.graph({
            entity: "payment",
            fields: ["id"],
            filters: { captured_at: { $gte: since } },
        }),
        query.graph({
            entity: "refund",
            fields: ["payment_id"],
            filters: { created_at: { $gte: since } },
        }),
        query.graph({
            entity: "order",
            fields: ["id"],
            filters: { canceled_at: { $gte: since } },
        }),
    ]);
    let recorded = 0;
    for (const orderId of await (0, orders_for_payments_1.orderIdsForPayments)(container, captured.map((payment) => payment.id))) {
        try {
            const { result } = await (0, record_order_commission_1.recordOrderCommissionWorkflow)(container).run({
                input: { order_id: orderId },
            });
            recorded += result.length ? 1 : 0;
        }
        catch (error) {
            logger.error(`[sales-commission] Reconcile: recording order ${orderId} failed: ${error.message}`);
        }
    }
    let voided = 0;
    let reversed = 0;
    for (const order of canceled) {
        try {
            const { result } = await (0, void_order_commission_1.voidOrderCommissionWorkflow)(container).run({
                input: { order_id: order.id, reason: "order_canceled" },
            });
            voided += result?.length ? 1 : 0;
        }
        catch (error) {
            logger.error(`[sales-commission] Reconcile: voiding order ${order.id} failed: ${error.message}`);
        }
    }
    for (const orderId of await (0, orders_for_payments_1.orderIdsForPayments)(container, refunds.map((refund) => refund.payment_id))) {
        try {
            const result = await (0, refunds_1.applyRefundToCommission)(container, orderId);
            voided += result.voided ? 1 : 0;
            reversed += result.reversed ? 1 : 0;
        }
        catch (error) {
            logger.error(`[sales-commission] Reconcile: refund of order ${orderId} failed: ${error.message}`);
        }
    }
    return { recorded, voided, reversed };
};
exports.reconcileCommissions = reconcileCommissions;
async function reconcileCommissionsJob(container) {
    const logger = container.resolve(utils_1.ContainerRegistrationKeys.LOGGER);
    const since = new Date(Date.now() - LOOKBACK_DAYS * 24 * 60 * 60 * 1000);
    const { recorded, voided, reversed } = await (0, exports.reconcileCommissions)(container, { since });
    logger.info(`[sales-commission] Reconciled the last ${LOOKBACK_DAYS} days: ${recorded} orders recorded, ${voided} voided, ${reversed} part-refunded`);
}
exports.config = {
    name: "reconcile-sales-commissions",
    schedule: "15 2 * * *",
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVjb25jaWxlLWNvbW1pc3Npb25zLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL2pvYnMvcmVjb25jaWxlLWNvbW1pc3Npb25zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQXlGQSwwQ0FXQztBQW5HRCxxREFBcUU7QUFDckUsc0VBQWtFO0FBQ2xFLGtGQUFvRjtBQUNwRiw4RUFBZ0Y7QUFDaEYsOENBQTBEO0FBRTFELE1BQU0sYUFBYSxHQUFHLENBQUMsQ0FBQTtBQUV2Qjs7OztHQUlHO0FBQ0ksTUFBTSxvQkFBb0IsR0FBRyxLQUFLLEVBQ3ZDLFNBQTBCLEVBQzFCLEVBQUUsS0FBSyxFQUFtQixFQUMxQixFQUFFO0lBQ0YsTUFBTSxLQUFLLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxpQ0FBeUIsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUNoRSxNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBRWxFLE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsQ0FBQyxHQUMvRCxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7UUFDaEIsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUNWLE1BQU0sRUFBRSxTQUFTO1lBQ2pCLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQztZQUNkLE9BQU8sRUFBRSxFQUFFLFdBQVcsRUFBRSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRTtTQUMxQyxDQUFDO1FBQ0YsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUNWLE1BQU0sRUFBRSxRQUFRO1lBQ2hCLE1BQU0sRUFBRSxDQUFDLFlBQVksQ0FBQztZQUN0QixPQUFPLEVBQUUsRUFBRSxVQUFVLEVBQUUsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUU7U0FDekMsQ0FBQztRQUNGLEtBQUssQ0FBQyxLQUFLLENBQUM7WUFDVixNQUFNLEVBQUUsT0FBTztZQUNmLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQztZQUNkLE9BQU8sRUFBRSxFQUFFLFdBQVcsRUFBRSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRTtTQUMxQyxDQUFDO0tBQ0gsQ0FBQyxDQUFBO0lBRUosSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFBO0lBQ2hCLEtBQUssTUFBTSxPQUFPLElBQUksTUFBTSxJQUFBLHlDQUFtQixFQUM3QyxTQUFTLEVBQ1QsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUN0QyxFQUFFLENBQUM7UUFDRixJQUFJLENBQUM7WUFDSCxNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsTUFBTSxJQUFBLHVEQUE2QixFQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztnQkFDcEUsS0FBSyxFQUFFLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRTthQUM3QixDQUFDLENBQUE7WUFDRixRQUFRLElBQUksTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7UUFDbkMsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixNQUFNLENBQUMsS0FBSyxDQUNWLGlEQUFpRCxPQUFPLFlBQVksS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUNwRixDQUFBO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFRCxJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUE7SUFDZCxJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUE7SUFDaEIsS0FBSyxNQUFNLEtBQUssSUFBSSxRQUFRLEVBQUUsQ0FBQztRQUM3QixJQUFJLENBQUM7WUFDSCxNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsTUFBTSxJQUFBLG1EQUEyQixFQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztnQkFDbEUsS0FBSyxFQUFFLEVBQUUsUUFBUSxFQUFFLEtBQUssQ0FBQyxFQUFFLEVBQUUsTUFBTSxFQUFFLGdCQUFnQixFQUFFO2FBQ3hELENBQUMsQ0FBQTtZQUNGLE1BQU0sSUFBSSxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUNsQyxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE1BQU0sQ0FBQyxLQUFLLENBQ1YsK0NBQStDLEtBQUssQ0FBQyxFQUFFLFlBQVksS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUNuRixDQUFBO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFDRCxLQUFLLE1BQU0sT0FBTyxJQUFJLE1BQU0sSUFBQSx5Q0FBbUIsRUFDN0MsU0FBUyxFQUNULE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FDM0MsRUFBRSxDQUFDO1FBQ0YsSUFBSSxDQUFDO1lBQ0gsTUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFBLGlDQUF1QixFQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQTtZQUNoRSxNQUFNLElBQUksTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7WUFDL0IsUUFBUSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBQ3JDLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsTUFBTSxDQUFDLEtBQUssQ0FDVixpREFBaUQsT0FBTyxZQUFZLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FDcEYsQ0FBQTtRQUNILENBQUM7SUFDSCxDQUFDO0lBRUQsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLENBQUE7QUFDdkMsQ0FBQyxDQUFBO0FBekVZLFFBQUEsb0JBQW9CLHdCQXlFaEM7QUFFYyxLQUFLLFVBQVUsdUJBQXVCLENBQ25ELFNBQTBCO0lBRTFCLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsTUFBTSxDQUFDLENBQUE7SUFDbEUsTUFBTSxLQUFLLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLGFBQWEsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQTtJQUV4RSxNQUFNLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsR0FBRyxNQUFNLElBQUEsNEJBQW9CLEVBQUMsU0FBUyxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtJQUV2RixNQUFNLENBQUMsSUFBSSxDQUNULDBDQUEwQyxhQUFhLFVBQVUsUUFBUSxxQkFBcUIsTUFBTSxZQUFZLFFBQVEsZ0JBQWdCLENBQ3pJLENBQUE7QUFDSCxDQUFDO0FBRVksUUFBQSxNQUFNLEdBQUc7SUFDcEIsSUFBSSxFQUFFLDZCQUE2QjtJQUNuQyxRQUFRLEVBQUUsWUFBWTtDQUN2QixDQUFBIn0=