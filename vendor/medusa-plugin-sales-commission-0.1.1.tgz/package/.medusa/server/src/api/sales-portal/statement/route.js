"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const portal_view_1 = require("../../../lib/portal-view");
const report_1 = require("../../../lib/report");
const period_activity_1 = require("../../../utils/period-activity");
const helpers_1 = require("../../admin/sales-commission/helpers");
const helpers_2 = require("../helpers");
const middlewares_1 = require("../middlewares");
/**
 * The month as a rep sees it: their orders by client, Level 2 per referred
 * rep, adjustments and payouts, with totals.
 */
async function GET(req, res) {
    const { period } = (0, helpers_1.requestedPeriod)(req);
    const activity = await (0, period_activity_1.loadPeriodActivity)(req.scope, {
        period,
        salesRepId: (0, middlewares_1.portalRep)(req).id,
    });
    const lines = (0, report_1.statementLines)({ period, ...activity });
    res.json({
        period,
        lines: (0, portal_view_1.portalStatementLines)(lines, await (0, helpers_2.referredRepNames)(req.scope, lines)),
        totals: (0, report_1.summarize)(lines),
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLXBvcnRhbC9zdGF0ZW1lbnQvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFZQSxrQkFhQztBQXhCRCwwREFBK0Q7QUFDL0QsZ0RBQStEO0FBQy9ELG9FQUFtRTtBQUNuRSxrRUFBc0U7QUFDdEUsd0NBQTZDO0FBQzdDLGdEQUEwQztBQUUxQzs7O0dBR0c7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxFQUFFLE1BQU0sRUFBRSxHQUFHLElBQUEseUJBQWUsRUFBQyxHQUFHLENBQUMsQ0FBQTtJQUN2QyxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUEsb0NBQWtCLEVBQUMsR0FBRyxDQUFDLEtBQUssRUFBRTtRQUNuRCxNQUFNO1FBQ04sVUFBVSxFQUFFLElBQUEsdUJBQVMsRUFBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO0tBQzlCLENBQUMsQ0FBQTtJQUNGLE1BQU0sS0FBSyxHQUFHLElBQUEsdUJBQWMsRUFBQyxFQUFFLE1BQU0sRUFBRSxHQUFHLFFBQVEsRUFBRSxDQUFDLENBQUE7SUFFckQsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNQLE1BQU07UUFDTixLQUFLLEVBQUUsSUFBQSxrQ0FBb0IsRUFBQyxLQUFLLEVBQUUsTUFBTSxJQUFBLDBCQUFnQixFQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDNUUsTUFBTSxFQUFFLElBQUEsa0JBQVMsRUFBQyxLQUFLLENBQUM7S0FDekIsQ0FBQyxDQUFBO0FBQ0osQ0FBQyJ9