"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCommissionAdjustmentStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const period_1 = require("../../lib/period");
const sales_commission_1 = require("../../modules/sales-commission");
const period_activity_1 = require("../../utils/period-activity");
const payout_rules_1 = require("../../utils/payout-rules");
const invalid = (message) => new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, message);
/**
 * Adjustments are append-only: a mistake is fixed with a reversing one. They
 * go in a month that is still open, so an approved month never changes.
 */
exports.createCommissionAdjustmentStep = (0, workflows_sdk_1.createStep)("create-commission-adjustment", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const rep = await service.retrieveSalesRep(input.sales_rep_id);
    const reason = input.reason.trim();
    if (!reason) {
        throw invalid("An adjustment needs a reason");
    }
    if (!input.amount) {
        throw invalid("An adjustment can't be zero");
    }
    (0, payout_rules_1.assertMoney)(input.amount, input.currency_code, "An adjustment");
    (0, payout_rules_1.assertPayoutCurrency)(rep, input.currency_code);
    if (!(0, period_1.isPeriod)(input.period)) {
        throw invalid(`${input.period} is not a month (YYYY-MM)`);
    }
    const approvedThrough = await (0, period_activity_1.loadApprovedThrough)(container);
    if (approvedThrough && input.period <= approvedThrough) {
        throw invalid(`${input.period} is already approved and can't change. Add the adjustment to an open month`);
    }
    const adjustment = await service.createCommissionAdjustments({
        ...input,
        currency_code: input.currency_code.toLowerCase(),
        reason,
        order_id: input.order_id ?? null,
        created_by: input.created_by ?? null,
    });
    return new workflows_sdk_1.StepResponse(adjustment, adjustment.id);
}, async (adjustmentId, { container }) => {
    if (!adjustmentId) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.deleteCommissionAdjustments(adjustmentId);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLWNvbW1pc3Npb24tYWRqdXN0bWVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3Mvc3RlcHMvY3JlYXRlLWNvbW1pc3Npb24tYWRqdXN0bWVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxREFBdUQ7QUFDdkQscUVBQTRFO0FBQzVFLDZDQUEyQztBQUMzQyxxRUFBd0U7QUFFeEUsaUVBQWlFO0FBQ2pFLDJEQUE0RTtBQVk1RSxNQUFNLE9BQU8sR0FBRyxDQUFDLE9BQWUsRUFBRSxFQUFFLENBQ2xDLElBQUksbUJBQVcsQ0FBQyxtQkFBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsT0FBTyxDQUFDLENBQUE7QUFFMUQ7OztHQUdHO0FBQ1UsUUFBQSw4QkFBOEIsR0FBRyxJQUFBLDBCQUFVLEVBQ3RELDhCQUE4QixFQUM5QixLQUFLLEVBQUUsS0FBMEMsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDbEUsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxHQUFHLEdBQUcsTUFBTSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFBO0lBRTlELE1BQU0sTUFBTSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUE7SUFDbEMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ1osTUFBTSxPQUFPLENBQUMsOEJBQThCLENBQUMsQ0FBQTtJQUMvQyxDQUFDO0lBQ0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNsQixNQUFNLE9BQU8sQ0FBQyw2QkFBNkIsQ0FBQyxDQUFBO0lBQzlDLENBQUM7SUFDRCxJQUFBLDBCQUFXLEVBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsYUFBYSxFQUFFLGVBQWUsQ0FBQyxDQUFBO0lBQy9ELElBQUEsbUNBQW9CLEVBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQTtJQUM5QyxJQUFJLENBQUMsSUFBQSxpQkFBUSxFQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQzVCLE1BQU0sT0FBTyxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sMkJBQTJCLENBQUMsQ0FBQTtJQUMzRCxDQUFDO0lBQ0QsTUFBTSxlQUFlLEdBQUcsTUFBTSxJQUFBLHFDQUFtQixFQUFDLFNBQVMsQ0FBQyxDQUFBO0lBQzVELElBQUksZUFBZSxJQUFJLEtBQUssQ0FBQyxNQUFNLElBQUksZUFBZSxFQUFFLENBQUM7UUFDdkQsTUFBTSxPQUFPLENBQ1gsR0FBRyxLQUFLLENBQUMsTUFBTSw0RUFBNEUsQ0FDNUYsQ0FBQTtJQUNILENBQUM7SUFFRCxNQUFNLFVBQVUsR0FBRyxNQUFNLE9BQU8sQ0FBQywyQkFBMkIsQ0FBQztRQUMzRCxHQUFHLEtBQUs7UUFDUixhQUFhLEVBQUUsS0FBSyxDQUFDLGFBQWEsQ0FBQyxXQUFXLEVBQUU7UUFDaEQsTUFBTTtRQUNOLFFBQVEsRUFBRSxLQUFLLENBQUMsUUFBUSxJQUFJLElBQUk7UUFDaEMsVUFBVSxFQUFFLEtBQUssQ0FBQyxVQUFVLElBQUksSUFBSTtLQUNyQyxDQUFDLENBQUE7SUFFRixPQUFPLElBQUksNEJBQVksQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQ3BELENBQUMsRUFDRCxLQUFLLEVBQUUsWUFBWSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUNwQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDbEIsT0FBTTtJQUNSLENBQUM7SUFDRCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLE9BQU8sQ0FBQywyQkFBMkIsQ0FBQyxZQUFZLENBQUMsQ0FBQTtBQUN6RCxDQUFDLENBQ0YsQ0FBQSJ9