"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addFxRateWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const add_fx_rate_1 = require("./steps/add-fx-rate");
exports.addFxRateWorkflow = (0, workflows_sdk_1.createWorkflow)("add-fx-rate", function (input) {
    return new workflows_sdk_1.WorkflowResponse((0, add_fx_rate_1.addFxRateStep)(input));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWRkLWZ4LXJhdGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL2FkZC1meC1yYXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFFQUcwQztBQUMxQyxxREFBdUU7QUFFMUQsUUFBQSxpQkFBaUIsR0FBRyxJQUFBLDhCQUFjLEVBQzdDLGFBQWEsRUFDYixVQUFVLEtBQXlCO0lBQ2pDLE9BQU8sSUFBSSxnQ0FBZ0IsQ0FBQyxJQUFBLDJCQUFhLEVBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQTtBQUNuRCxDQUFDLENBQ0YsQ0FBQSJ9