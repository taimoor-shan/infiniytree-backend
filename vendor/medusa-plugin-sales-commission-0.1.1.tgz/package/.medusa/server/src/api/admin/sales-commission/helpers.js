"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.slug = exports.sendCsv = exports.wantsCsv = exports.requestedPeriod = void 0;
const period_1 = require("../../../lib/period");
const sales_commission_1 = require("../../../modules/sales-commission");
/** The requested month, or the current one in the plugin's timezone. */
const requestedPeriod = (req) => {
    const service = req.scope.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const { timezone } = service.getOptions();
    const { period } = req.validatedQuery;
    return { period: period ?? (0, period_1.toPeriod)(new Date(), timezone), timezone };
};
exports.requestedPeriod = requestedPeriod;
const wantsCsv = (req) => req.validatedQuery.format === "csv";
exports.wantsCsv = wantsCsv;
const sendCsv = (res, fileName, csv) => {
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
    res.send(csv);
};
exports.sendCsv = sendCsv;
const slug = (text) => text
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
exports.slug = slug;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGVscGVycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcGkvYWRtaW4vc2FsZXMtY29tbWlzc2lvbi9oZWxwZXJzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUNBLGdEQUE4QztBQUM5Qyx3RUFBMkU7QUFJM0Usd0VBQXdFO0FBQ2pFLE1BQU0sZUFBZSxHQUFHLENBQUMsR0FBa0IsRUFBRSxFQUFFO0lBQ3BELE1BQU0sT0FBTyxHQUFpQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLEVBQUUsUUFBUSxFQUFFLEdBQUcsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFBO0lBQ3pDLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsY0FBaUQsQ0FBQTtJQUV4RSxPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sSUFBSSxJQUFBLGlCQUFRLEVBQUMsSUFBSSxJQUFJLEVBQUUsRUFBRSxRQUFRLENBQUMsRUFBRSxRQUFRLEVBQUUsQ0FBQTtBQUN2RSxDQUFDLENBQUE7QUFSWSxRQUFBLGVBQWUsbUJBUTNCO0FBRU0sTUFBTSxRQUFRLEdBQUcsQ0FBQyxHQUFrQixFQUFFLEVBQUUsQ0FDNUMsR0FBRyxDQUFDLGNBQWtELENBQUMsTUFBTSxLQUFLLEtBQUssQ0FBQTtBQUQ3RCxRQUFBLFFBQVEsWUFDcUQ7QUFFbkUsTUFBTSxPQUFPLEdBQUcsQ0FBQyxHQUFtQixFQUFFLFFBQWdCLEVBQUUsR0FBVyxFQUFFLEVBQUU7SUFDNUUsR0FBRyxDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQUUseUJBQXlCLENBQUMsQ0FBQTtJQUN4RCxHQUFHLENBQUMsU0FBUyxDQUFDLHFCQUFxQixFQUFFLHlCQUF5QixRQUFRLEdBQUcsQ0FBQyxDQUFBO0lBQzFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7QUFDZixDQUFDLENBQUE7QUFKWSxRQUFBLE9BQU8sV0FJbkI7QUFFTSxNQUFNLElBQUksR0FBRyxDQUFDLElBQVksRUFBRSxFQUFFLENBQ25DLElBQUk7S0FDRCxTQUFTLENBQUMsTUFBTSxDQUFDO0tBQ2pCLE9BQU8sQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDO0tBQ3JCLFdBQVcsRUFBRTtLQUNiLE9BQU8sQ0FBQyxhQUFhLEVBQUUsR0FBRyxDQUFDO0tBQzNCLE9BQU8sQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUE7QUFOYixRQUFBLElBQUksUUFNUyJ9