"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.orderIdsForPayments = void 0;
const utils_1 = require("@medusajs/framework/utils");
/** The orders paid through the given payments' payment collections. */
const orderIdsForPayments = async (container, paymentIds) => {
    if (!paymentIds.length) {
        return [];
    }
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { data: payments } = await query.graph({
        entity: "payment",
        fields: ["id", "payment_collection_id"],
        filters: { id: paymentIds },
    });
    const collectionIds = [
        ...new Set(payments.map((payment) => payment.payment_collection_id)),
    ];
    if (!collectionIds.length) {
        return [];
    }
    const { data: links } = await query.graph({
        entity: "order_payment_collection",
        fields: ["order_id"],
        filters: { payment_collection_id: collectionIds },
    });
    return [...new Set(links.map((link) => link.order_id))];
};
exports.orderIdsForPayments = orderIdsForPayments;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3JkZXJzLWZvci1wYXltZW50cy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy91dGlscy9vcmRlcnMtZm9yLXBheW1lbnRzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUNBLHFEQUFxRTtBQUVyRSx1RUFBdUU7QUFDaEUsTUFBTSxtQkFBbUIsR0FBRyxLQUFLLEVBQ3RDLFNBQTBCLEVBQzFCLFVBQW9CLEVBQ0QsRUFBRTtJQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3ZCLE9BQU8sRUFBRSxDQUFBO0lBQ1gsQ0FBQztJQUNELE1BQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUE7SUFFaEUsTUFBTSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDM0MsTUFBTSxFQUFFLFNBQVM7UUFDakIsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLHVCQUF1QixDQUFDO1FBQ3ZDLE9BQU8sRUFBRSxFQUFFLEVBQUUsRUFBRSxVQUFVLEVBQUU7S0FDNUIsQ0FBQyxDQUFBO0lBQ0YsTUFBTSxhQUFhLEdBQUc7UUFDcEIsR0FBRyxJQUFJLEdBQUcsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQztLQUNyRSxDQUFBO0lBQ0QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUMxQixPQUFPLEVBQUUsQ0FBQTtJQUNYLENBQUM7SUFFRCxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztRQUN4QyxNQUFNLEVBQUUsMEJBQTBCO1FBQ2xDLE1BQU0sRUFBRSxDQUFDLFVBQVUsQ0FBQztRQUNwQixPQUFPLEVBQUUsRUFBRSxxQkFBcUIsRUFBRSxhQUFhLEVBQUU7S0FDbEQsQ0FBQyxDQUFBO0lBRUYsT0FBTyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQTtBQUN6RCxDQUFDLENBQUE7QUE1QlksUUFBQSxtQkFBbUIsdUJBNEIvQiJ9