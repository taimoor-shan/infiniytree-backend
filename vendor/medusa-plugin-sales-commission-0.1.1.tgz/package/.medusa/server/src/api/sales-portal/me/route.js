"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const middlewares_1 = require("../middlewares");
/** The signed-in rep's profile: name, email and phone, no internal notes. */
async function GET(req, res) {
    res.json({ sales_rep: (0, middlewares_1.portalRep)(req) });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLXBvcnRhbC9tZS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUlBLGtCQUVDO0FBTEQsZ0RBQTBDO0FBRTFDLDZFQUE2RTtBQUN0RSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLFNBQVMsRUFBRSxJQUFBLHVCQUFTLEVBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQ3pDLENBQUMifQ==