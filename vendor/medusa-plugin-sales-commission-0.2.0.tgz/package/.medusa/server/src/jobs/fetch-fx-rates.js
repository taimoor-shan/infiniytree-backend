"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = fetchFxRatesJob;
const utils_1 = require("@medusajs/framework/utils");
const sales_commission_1 = require("../modules/sales-commission");
const fx_1 = require("../utils/fx");
/**
 * Stores the ECB's euro-forint reference rates after it publishes them on
 * working days. The file covers 90 days, so a day missed by an earlier
 * failure is filled in as well.
 */
async function fetchFxRatesJob(container) {
    const logger = container.resolve(utils_1.ContainerRegistrationKeys.LOGGER);
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    if (service.getOptions().fx_auto_fetch === false) {
        return;
    }
    try {
        const added = await (0, fx_1.fetchEcbRates)(container);
        logger.info(`[sales-commission] Exchange rates: ${added} new days from the ECB`);
    }
    catch (error) {
        logger.error(`[sales-commission] Fetching exchange rates failed: ${error.message}`);
    }
}
exports.config = {
    name: "fetch-sales-commission-fx-rates",
    // After the ECB's afternoon publication, on working days
    schedule: "0 17 * * 1-5",
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmV0Y2gtZngtcmF0ZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvam9icy9mZXRjaC1meC1yYXRlcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFXQSxrQ0FpQkM7QUEzQkQscURBQXFFO0FBQ3JFLGtFQUFxRTtBQUVyRSxvQ0FBMkM7QUFFM0M7Ozs7R0FJRztBQUNZLEtBQUssVUFBVSxlQUFlLENBQUMsU0FBMEI7SUFDdEUsTUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxpQ0FBeUIsQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUNsRSxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxJQUFJLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxhQUFhLEtBQUssS0FBSyxFQUFFLENBQUM7UUFDakQsT0FBTTtJQUNSLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxNQUFNLEtBQUssR0FBRyxNQUFNLElBQUEsa0JBQWEsRUFBQyxTQUFTLENBQUMsQ0FBQTtRQUM1QyxNQUFNLENBQUMsSUFBSSxDQUFDLHNDQUFzQyxLQUFLLHdCQUF3QixDQUFDLENBQUE7SUFDbEYsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixNQUFNLENBQUMsS0FBSyxDQUNWLHNEQUF1RCxLQUFlLENBQUMsT0FBTyxFQUFFLENBQ2pGLENBQUE7SUFDSCxDQUFDO0FBQ0gsQ0FBQztBQUVZLFFBQUEsTUFBTSxHQUFHO0lBQ3BCLElBQUksRUFBRSxpQ0FBaUM7SUFDdkMseURBQXlEO0lBQ3pELFFBQVEsRUFBRSxjQUFjO0NBQ3pCLENBQUEifQ==