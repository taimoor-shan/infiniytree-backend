"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.declineRepApplicationWorkflow = void 0;
const core_flows_1 = require("@medusajs/medusa/core-flows");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const events_1 = require("../events");
const mark_application_decided_1 = require("./steps/mark-application-decided");
const validate_rep_application_1 = require("./steps/validate-rep-application");
/**
 * The owner turns an application down. The reason stays with the owner: the
 * candidate and the recruiter are told the outcome, not why.
 */
exports.declineRepApplicationWorkflow = (0, workflows_sdk_1.createWorkflow)("decline-rep-application", function (input) {
    const application = (0, validate_rep_application_1.validateRepApplicationStep)((0, workflows_sdk_1.transform)({ input }, ({ input }) => ({ invite_id: input.invite_id })));
    const invite = (0, mark_application_decided_1.markApplicationDecidedStep)((0, workflows_sdk_1.transform)({ input }, ({ input }) => ({
        invite_id: input.invite_id,
        decision: "declined",
        decided_by: input.actor_id ?? null,
        reason: input.reason,
    })));
    (0, core_flows_1.emitEventStep)({
        eventName: events_1.SalesCommissionEvents.APPLICATION_DECLINED,
        data: (0, workflows_sdk_1.transform)({ application }, ({ application }) => ({
            invite_id: application.invite.id,
            name: application.invite.applicant_name ?? application.invite.name,
            email: application.invite.email,
            recruiter: {
                name: application.recruiter.name,
                email: application.recruiter.email,
            },
            locale: application.invite.locale ?? null,
        })),
    });
    return new workflows_sdk_1.WorkflowResponse(invite);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVjbGluZS1yZXAtYXBwbGljYXRpb24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL2RlY2xpbmUtcmVwLWFwcGxpY2F0aW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLDREQUEyRDtBQUMzRCxxRUFJMEM7QUFDMUMsc0NBQWlEO0FBQ2pELCtFQUE2RTtBQUM3RSwrRUFBNkU7QUFRN0U7OztHQUdHO0FBQ1UsUUFBQSw2QkFBNkIsR0FBRyxJQUFBLDhCQUFjLEVBQ3pELHlCQUF5QixFQUN6QixVQUFVLEtBQXlDO0lBQ2pELE1BQU0sV0FBVyxHQUFHLElBQUEscURBQTBCLEVBQzVDLElBQUEseUJBQVMsRUFBQyxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLFNBQVMsRUFBRSxLQUFLLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUN0RSxDQUFBO0lBRUQsTUFBTSxNQUFNLEdBQUcsSUFBQSxxREFBMEIsRUFDdkMsSUFBQSx5QkFBUyxFQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ25DLFNBQVMsRUFBRSxLQUFLLENBQUMsU0FBUztRQUMxQixRQUFRLEVBQUUsVUFBbUI7UUFDN0IsVUFBVSxFQUFFLEtBQUssQ0FBQyxRQUFRLElBQUksSUFBSTtRQUNsQyxNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU07S0FDckIsQ0FBQyxDQUFDLENBQ0osQ0FBQTtJQUVELElBQUEsMEJBQWEsRUFBQztRQUNaLFNBQVMsRUFBRSw4QkFBcUIsQ0FBQyxvQkFBb0I7UUFDckQsSUFBSSxFQUFFLElBQUEseUJBQVMsRUFBQyxFQUFFLFdBQVcsRUFBRSxFQUFFLENBQUMsRUFBRSxXQUFXLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUNyRCxTQUFTLEVBQUUsV0FBVyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ2hDLElBQUksRUFBRSxXQUFXLENBQUMsTUFBTSxDQUFDLGNBQWMsSUFBSSxXQUFXLENBQUMsTUFBTSxDQUFDLElBQUk7WUFDbEUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxNQUFNLENBQUMsS0FBSztZQUMvQixTQUFTLEVBQUU7Z0JBQ1QsSUFBSSxFQUFFLFdBQVcsQ0FBQyxTQUFTLENBQUMsSUFBSTtnQkFDaEMsS0FBSyxFQUFFLFdBQVcsQ0FBQyxTQUFTLENBQUMsS0FBSzthQUNuQztZQUNELE1BQU0sRUFBRSxXQUFXLENBQUMsTUFBTSxDQUFDLE1BQU0sSUFBSSxJQUFJO1NBQzFDLENBQUMsQ0FBQztLQUNKLENBQUMsQ0FBQTtJQUVGLE9BQU8sSUFBSSxnQ0FBZ0IsQ0FBQyxNQUFNLENBQUMsQ0FBQTtBQUNyQyxDQUFDLENBQ0YsQ0FBQSJ9