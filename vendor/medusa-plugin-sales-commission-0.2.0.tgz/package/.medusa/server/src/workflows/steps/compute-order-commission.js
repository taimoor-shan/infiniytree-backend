"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.computeOrderCommissionStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const commission_1 = require("../../lib/commission");
const sales_commission_1 = require("../../modules/sales-commission");
const client_name_1 = require("../../utils/client-name");
/**
 * The entries a paid order should earn, or none when it is already recorded,
 * canceled, not fully captured, or its customer had no rep when it was placed.
 */
exports.computeOrderCommissionStep = (0, workflows_sdk_1.createStep)("compute-order-commission", async ({ order_id }, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const none = () => new workflows_sdk_1.StepResponse([]);
    const recorded = await service.listCommissionEntries({ order_id }, { take: 1, select: ["id"] });
    if (recorded.length) {
        return none();
    }
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { data: [order], } = await query.graph({
        entity: "order",
        fields: [
            "id",
            "display_id",
            "created_at",
            "canceled_at",
            "status",
            "email",
            "currency_code",
            "customer_id",
            "item_total",
            "item_tax_total",
            "customer.email",
            "customer.company_name",
            "customer.first_name",
            "customer.last_name",
            "payment_collections.payments.id",
            "payment_collections.payments.captured_at",
            "payment_collections.payments.canceled_at",
        ],
        filters: { id: order_id },
    });
    if (!order?.customer_id ||
        order.canceled_at ||
        order.status === "canceled") {
        return none();
    }
    const payments = (order.payment_collections ?? [])
        .flatMap((collection) => collection?.payments ?? [])
        .filter((payment) => !!payment && !payment.canceled_at);
    if (!payments.length || payments.some((payment) => !payment.captured_at)) {
        return none();
    }
    const lastPayment = payments.reduce((latest, payment) => new Date(payment.captured_at) > new Date(latest.captured_at)
        ? payment
        : latest);
    const assignments = await service.listClientAssignments({
        customer_id: order.customer_id,
    });
    const repIds = [...new Set(assignments.map((a) => a.sales_rep_id))];
    const referrals = repIds.length
        ? await service.listRepReferrals({ referred_sales_rep_id: repIds })
        : [];
    return new workflows_sdk_1.StepResponse((0, commission_1.computeCommissionEntries)({
        order: {
            id: order.id,
            display_id: order.display_id,
            created_at: order.created_at,
            currency_code: order.currency_code,
            customer_id: order.customer_id,
            client_name: (0, client_name_1.orderClientName)(order),
            item_total: order.item_total,
            item_tax_total: order.item_tax_total,
        },
        assignments,
        referrals,
        earnedAt: new Date(lastPayment.captured_at),
        timezone: service.getOptions().timezone,
        paymentId: lastPayment.id,
    }));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tcHV0ZS1vcmRlci1jb21taXNzaW9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9jb21wdXRlLW9yZGVyLWNvbW1pc3Npb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQXFFO0FBQ3JFLHFFQUE0RTtBQUM1RSxxREFHNkI7QUFDN0IscUVBQXdFO0FBRXhFLHlEQUF5RDtBQVF6RDs7O0dBR0c7QUFDVSxRQUFBLDBCQUEwQixHQUFHLElBQUEsMEJBQVUsRUFDbEQsMEJBQTBCLEVBQzFCLEtBQUssRUFBRSxFQUFFLFFBQVEsRUFBd0IsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDMUQsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUMsSUFBSSw0QkFBWSxDQUF5QixFQUFFLENBQUMsQ0FBQTtJQUUvRCxNQUFNLFFBQVEsR0FBRyxNQUFNLE9BQU8sQ0FBQyxxQkFBcUIsQ0FDbEQsRUFBRSxRQUFRLEVBQUUsRUFDWixFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FDNUIsQ0FBQTtJQUNELElBQUksUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3BCLE9BQU8sSUFBSSxFQUFFLENBQUE7SUFDZixDQUFDO0lBRUQsTUFBTSxLQUFLLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxpQ0FBeUIsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUNoRSxNQUFNLEVBQ0osSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQ2QsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDcEIsTUFBTSxFQUFFLE9BQU87UUFDZixNQUFNLEVBQUU7WUFDTixJQUFJO1lBQ0osWUFBWTtZQUNaLFlBQVk7WUFDWixhQUFhO1lBQ2IsUUFBUTtZQUNSLE9BQU87WUFDUCxlQUFlO1lBQ2YsYUFBYTtZQUNiLFlBQVk7WUFDWixnQkFBZ0I7WUFDaEIsZ0JBQWdCO1lBQ2hCLHVCQUF1QjtZQUN2QixxQkFBcUI7WUFDckIsb0JBQW9CO1lBQ3BCLGlDQUFpQztZQUNqQywwQ0FBMEM7WUFDMUMsMENBQTBDO1NBQzNDO1FBQ0QsT0FBTyxFQUFFLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRTtLQUMxQixDQUFDLENBQUE7SUFDRixJQUNFLENBQUMsS0FBSyxFQUFFLFdBQVc7UUFDbkIsS0FBSyxDQUFDLFdBQVc7UUFDakIsS0FBSyxDQUFDLE1BQU0sS0FBSyxVQUFVLEVBQzNCLENBQUM7UUFDRCxPQUFPLElBQUksRUFBRSxDQUFBO0lBQ2YsQ0FBQztJQUVELE1BQU0sUUFBUSxHQUFHLENBQUMsS0FBSyxDQUFDLG1CQUFtQixJQUFJLEVBQUUsQ0FBQztTQUMvQyxPQUFPLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLFVBQVUsRUFBRSxRQUFRLElBQUksRUFBRSxDQUFDO1NBQ25ELE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBeUIsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUE7SUFDaEYsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQztRQUN6RSxPQUFPLElBQUksRUFBRSxDQUFBO0lBQ2YsQ0FBQztJQUNELE1BQU0sV0FBVyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLEVBQUUsQ0FDdEQsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVksQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFZLENBQUM7UUFDNUQsQ0FBQyxDQUFDLE9BQU87UUFDVCxDQUFDLENBQUMsTUFBTSxDQUNYLENBQUE7SUFFRCxNQUFNLFdBQVcsR0FBRyxNQUFNLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQztRQUN0RCxXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVc7S0FDL0IsQ0FBQyxDQUFBO0lBQ0YsTUFBTSxNQUFNLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDbkUsTUFBTSxTQUFTLEdBQUcsTUFBTSxDQUFDLE1BQU07UUFDN0IsQ0FBQyxDQUFDLE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUFDLEVBQUUscUJBQXFCLEVBQUUsTUFBTSxFQUFFLENBQUM7UUFDbkUsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtJQUVOLE9BQU8sSUFBSSw0QkFBWSxDQUNyQixJQUFBLHFDQUF3QixFQUFDO1FBQ3ZCLEtBQUssRUFBRTtZQUNMLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFBRTtZQUNaLFVBQVUsRUFBRSxLQUFLLENBQUMsVUFBVztZQUM3QixVQUFVLEVBQUUsS0FBSyxDQUFDLFVBQVc7WUFDN0IsYUFBYSxFQUFFLEtBQUssQ0FBQyxhQUFhO1lBQ2xDLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVztZQUM5QixXQUFXLEVBQUUsSUFBQSw2QkFBZSxFQUFDLEtBQUssQ0FBQztZQUNuQyxVQUFVLEVBQUUsS0FBSyxDQUFDLFVBQW9CO1lBQ3RDLGNBQWMsRUFBRSxLQUFLLENBQUMsY0FBd0I7U0FDL0M7UUFDRCxXQUFXO1FBQ1gsU0FBUztRQUNULFFBQVEsRUFBRSxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBWSxDQUFDO1FBQzVDLFFBQVEsRUFBRSxPQUFPLENBQUMsVUFBVSxFQUFFLENBQUMsUUFBUTtRQUN2QyxTQUFTLEVBQUUsV0FBVyxDQUFDLEVBQUU7S0FDMUIsQ0FBQyxDQUNILENBQUE7QUFDSCxDQUFDLENBQ0YsQ0FBQSJ9