"use strict";
const jsxRuntime = require("react/jsx-runtime");
const adminSdk = require("@medusajs/admin-sdk");
const icons = require("@medusajs/icons");
const ui = require("@medusajs/ui");
const reactQuery = require("@tanstack/react-query");
const react = require("react");
const reactRouterDom = require("react-router-dom");
const Medusa = require("@medusajs/js-sdk");
const _interopDefault = (e) => e && e.__esModule ? e : { default: e };
const Medusa__default = /* @__PURE__ */ _interopDefault(Medusa);
const sdk = new Medusa__default.default({
  baseUrl: "/",
  debug: false,
  auth: {
    type: "session"
  }
});
const TIME_ZONE = "Europe/Budapest";
const ZERO_DECIMAL_CURRENCIES = /* @__PURE__ */ new Set([
  "HUF",
  "JPY",
  "KRW",
  "TWD",
  "VND",
  "CLP",
  "PYG",
  "UGX",
  "RWF",
  "UZS",
  "KES"
]);
const CURRENCIES = ["eur", "huf"];
const formatMoney = (amount, currencyCode) => {
  const currency = currencyCode.toUpperCase();
  const decimals = ZERO_DECIMAL_CURRENCIES.has(currency) ? 0 : 2;
  return new Intl.NumberFormat("en-GB", {
    style: "currency",
    currency,
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals
  }).format(amount);
};
const formatDate = (date) => new Intl.DateTimeFormat("en-GB", {
  timeZone: TIME_ZONE,
  year: "numeric",
  month: "short",
  day: "numeric"
}).format(new Date(date));
const formatSize = (bytes) => bytes < 1024 * 1024 ? `${Math.max(1, Math.round(bytes / 1024))} KB` : `${(bytes / 1024 / 1024).toFixed(1)} MB`;
const today = () => new Intl.DateTimeFormat("en-CA", {
  timeZone: TIME_ZONE,
  year: "numeric",
  month: "2-digit",
  day: "2-digit"
}).format(/* @__PURE__ */ new Date());
const recentPeriods = (count = 24) => {
  const [year, month] = today().split("-").map(Number);
  return Array.from({ length: count }, (_, i) => {
    const date = new Date(Date.UTC(year, month - 1 - i, 1));
    return {
      value: date.toISOString().slice(0, 7),
      label: new Intl.DateTimeFormat("en-GB", {
        timeZone: "UTC",
        month: "long",
        year: "numeric"
      }).format(date)
    };
  });
};
const currentPeriod = () => recentPeriods(1)[0].value;
const STATUS_BADGES = {
  paid: { label: "Paid", color: "green" },
  partial: { label: "Partly paid", color: "orange" },
  unpaid: { label: "Unpaid", color: "red" },
  none: { label: "Nothing due", color: "grey" }
};
const clientName = (customer) => (customer == null ? void 0 : customer.company_name) || [customer == null ? void 0 : customer.first_name, customer == null ? void 0 : customer.last_name].filter(Boolean).join(" ") || (customer == null ? void 0 : customer.email) || "Unknown client";
const errorMessage = (error) => error instanceof Error ? error.message : "Something went wrong";
const Loading = () => /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex justify-center p-6", children: /* @__PURE__ */ jsxRuntime.jsx(icons.Spinner, { className: "text-ui-fg-interactive animate-spin" }) });
const CustomerSalesRepWidget = ({
  data: customer
}) => {
  var _a, _b;
  const [open, setOpen] = react.useState(false);
  const [repId, setRepId] = react.useState("");
  const [rate, setRate] = react.useState("");
  const queryClient = reactQuery.useQueryClient();
  const prompt = ui.usePrompt();
  const queryKey = ["customer-sales-rep", customer.id];
  const { data, isLoading } = reactQuery.useQuery({
    queryKey,
    queryFn: () => sdk.client.fetch(
      `/admin/customers/${customer.id}/sales-rep-assignment`
    )
  });
  const { data: reps } = reactQuery.useQuery({
    queryKey: ["sales-reps", "active-options"],
    queryFn: () => sdk.client.fetch("/admin/sales-reps", {
      query: { is_active: "true", limit: 200, order: "name" }
    }),
    enabled: open
  });
  const refresh = () => {
    queryClient.invalidateQueries({ queryKey });
    queryClient.invalidateQueries({ queryKey: ["sales-rep-clients"] });
  };
  const assign = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/customers/${customer.id}/sales-rep-assignment`, {
      method: "POST",
      body: { sales_rep_id: repId, commission_rate: Number(rate) }
    }),
    onSuccess: () => {
      refresh();
      ui.toast.success("Sales rep saved");
      setOpen(false);
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const end = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/customers/${customer.id}/sales-rep-assignment`, {
      method: "DELETE"
    }),
    onSuccess: () => {
      refresh();
      ui.toast.success("Assignment ended");
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const confirmEnd = async () => {
    const confirmed = await prompt({
      title: "End assignment?",
      description: "Orders placed today or later won't earn commission. Earlier orders keep theirs.",
      confirmText: "End assignment",
      cancelText: "Cancel"
    });
    if (confirmed) {
      end.mutate();
    }
  };
  const current = data == null ? void 0 : data.current;
  const past = (data == null ? void 0 : data.history.filter((a) => a.ends_at !== null)) ?? [];
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h2", children: "Sales rep" }),
      /* @__PURE__ */ jsxRuntime.jsxs(
        ui.Button,
        {
          size: "small",
          variant: "secondary",
          onClick: () => {
            var _a2;
            setRepId(((_a2 = current == null ? void 0 : current.sales_rep) == null ? void 0 : _a2.id) ?? "");
            setRate(current ? String(current.commission_rate) : "");
            setOpen(true);
          },
          children: [
            /* @__PURE__ */ jsxRuntime.jsx(icons.PencilSquare, {}),
            current ? "Change" : "Assign"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex flex-col gap-y-1 px-6 py-4", children: isLoading ? /* @__PURE__ */ jsxRuntime.jsx(Loading, {}) : current ? /* @__PURE__ */ jsxRuntime.jsxs(jsxRuntime.Fragment, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(
        reactRouterDom.Link,
        {
          to: `/sales-reps/${(_a = current.sales_rep) == null ? void 0 : _a.id}`,
          className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
          children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", children: (_b = current.sales_rep) == null ? void 0 : _b.name })
        }
      ),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
        current.commission_rate,
        "% commission since",
        " ",
        formatDate(current.starts_at)
      ] }),
      /* @__PURE__ */ jsxRuntime.jsx("div", { children: /* @__PURE__ */ jsxRuntime.jsx(
        ui.Button,
        {
          size: "small",
          variant: "transparent",
          className: "-ml-3 mt-1",
          isLoading: end.isPending,
          onClick: confirmEnd,
          children: "End assignment"
        }
      ) })
    ] }) : /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "No sales rep assigned. Orders earn no commission." }) }),
    past.length > 0 && /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", children: "History" }),
      past.map((a) => {
        var _a2;
        return /* @__PURE__ */ jsxRuntime.jsxs(
          ui.Text,
          {
            size: "small",
            leading: "compact",
            className: "text-ui-fg-subtle",
            children: [
              (_a2 = a.sales_rep) == null ? void 0 : _a2.name,
              " · ",
              a.commission_rate,
              "% ·",
              " ",
              formatDate(a.starts_at),
              " – ",
              formatDate(a.ends_at)
            ]
          },
          a.id
        );
      })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer, { open, onOpenChange: setOpen, children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Content, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Header, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Title, { children: "Sales rep and commission rate" }) }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: "Takes effect from the start of today (Budapest time), so orders placed earlier today count too. Earlier days keep the rep and rate they were placed with." }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Sales rep" }),
          /* @__PURE__ */ jsxRuntime.jsxs(ui.Select, { value: repId, onValueChange: setRepId, children: [
            /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Value, { placeholder: "Choose a sales rep" }) }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Content, { children: ((reps == null ? void 0 : reps.sales_reps) ?? []).map((rep) => /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: rep.id, children: rep.name }, rep.id)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "commission-rate", children: "Commission rate (%)" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Input,
            {
              id: "commission-rate",
              type: "number",
              min: 0,
              max: 100,
              step: "0.01",
              value: rate,
              onChange: (e) => setRate(e.target.value)
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Footer, { children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", disabled: assign.isPending, children: "Cancel" }) }),
        /* @__PURE__ */ jsxRuntime.jsx(
          ui.Button,
          {
            size: "small",
            disabled: !repId || rate === "",
            isLoading: assign.isPending,
            onClick: () => assign.mutate(),
            children: "Save"
          }
        )
      ] })
    ] }) })
  ] });
};
adminSdk.defineWidgetConfig({
  zone: "customer.details.side.after"
});
const EMPTY = { name: "", email: "", phone: "", notes: "" };
const CreateSalesRepModal = () => {
  const [open, setOpen] = react.useState(false);
  const [form, setForm] = react.useState(EMPTY);
  const [errors, setErrors] = react.useState({});
  const queryClient = reactQuery.useQueryClient();
  const navigate = reactRouterDom.useNavigate();
  const create = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch("/admin/sales-reps", {
      method: "POST",
      body: {
        name: form.name,
        email: form.email,
        phone: form.phone || null,
        notes: form.notes || null
      }
    }),
    onSuccess: ({ sales_rep }) => {
      queryClient.invalidateQueries({ queryKey: ["sales-reps"] });
      ui.toast.success(`${sales_rep.name} was added`);
      setOpen(false);
      setForm(EMPTY);
      navigate(`/sales-reps/${sales_rep.id}`);
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const submit = () => {
    const next = {};
    if (!form.name.trim()) next.name = "Name is required";
    if (!/^\S+@\S+\.\S+$/.test(form.email.trim())) next.email = "Enter a valid email";
    setErrors(next);
    if (!Object.keys(next).length) {
      create.mutate();
    }
  };
  const field = (key) => ({
    value: form[key],
    onChange: (e) => {
      setForm({ ...form, [key]: e.target.value });
      setErrors({ ...errors, [key]: void 0 });
    }
  });
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.FocusModal, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Trigger, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", children: "Create" }) }),
    /* @__PURE__ */ jsxRuntime.jsxs(ui.FocusModal.Content, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Header, { children: /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-end gap-x-2", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", disabled: create.isPending, children: "Cancel" }) }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", onClick: submit, isLoading: create.isPending, children: "Save" })
      ] }) }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Body, { className: "flex flex-1 flex-col items-center overflow-y-auto py-16", children: /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex w-full max-w-lg flex-col gap-y-6", children: [
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-1", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Title, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { children: "Create sales rep" }) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Description, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: "Add a salesperson. You can assign clients and upload their contract afterwards." }) })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "rep-name", children: "Name" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Input, { id: "rep-name", ...field("name") }),
          errors.name && /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-error", children: errors.name })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "rep-email", children: "Email" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Input, { id: "rep-email", type: "email", ...field("email") }),
          errors.email && /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-error", children: errors.email })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "rep-phone", children: "Phone (optional)" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Input, { id: "rep-phone", ...field("phone") })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "rep-notes", children: "Notes (optional)" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Textarea, { id: "rep-notes", ...field("notes") })
        ] })
      ] }) })
    ] })
  ] });
};
const PAGE_SIZE = 20;
const columnHelper = ui.createDataTableColumnHelper();
const columns = [
  columnHelper.accessor("name", { header: "Name" }),
  columnHelper.accessor("email", { header: "Email" }),
  columnHelper.accessor("phone", {
    header: "Phone",
    cell: ({ getValue }) => getValue() || "-"
  }),
  columnHelper.accessor("is_active", {
    header: "Status",
    cell: ({ getValue }) => /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: getValue() ? "green" : "grey", children: getValue() ? "Active" : "Inactive" })
  })
];
const SalesRepsPage = () => {
  const navigate = reactRouterDom.useNavigate();
  const [search, setSearch] = react.useState("");
  const [pagination, setPagination] = react.useState({
    pageIndex: 0,
    pageSize: PAGE_SIZE
  });
  const offset = pagination.pageIndex * PAGE_SIZE;
  const { data, isLoading } = reactQuery.useQuery({
    queryKey: ["sales-reps", offset, search],
    queryFn: () => sdk.client.fetch(
      "/admin/sales-reps",
      {
        query: {
          limit: PAGE_SIZE,
          offset,
          order: "name",
          q: search || void 0
        }
      }
    ),
    placeholderData: reactQuery.keepPreviousData
  });
  const table = ui.useDataTable({
    data: (data == null ? void 0 : data.sales_reps) ?? [],
    columns,
    getRowId: (rep) => rep.id,
    rowCount: (data == null ? void 0 : data.count) ?? 0,
    isLoading,
    search: { state: search, onSearchChange: setSearch },
    pagination: { state: pagination, onPaginationChange: setPagination },
    onRowClick: (_, rep) => navigate(`/sales-reps/${rep.id}`)
  });
  return /* @__PURE__ */ jsxRuntime.jsx(ui.Container, { className: "divide-y p-0", children: /* @__PURE__ */ jsxRuntime.jsxs(ui.DataTable, { instance: table, children: [
    /* @__PURE__ */ jsxRuntime.jsxs(ui.DataTable.Toolbar, { className: "flex flex-col items-start justify-between gap-2 px-6 py-4 md:flex-row md:items-center", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { children: "Sales Reps" }),
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.DataTable.Search, { placeholder: "Search by name or email" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(reactRouterDom.Link, { to: "/sales-reps/report", children: "Monthly report" }) }),
        /* @__PURE__ */ jsxRuntime.jsx(CreateSalesRepModal, {})
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx(ui.DataTable.Table, {}),
    /* @__PURE__ */ jsxRuntime.jsx(ui.DataTable.Pagination, {})
  ] }) });
};
const config$1 = adminSdk.defineRouteConfig({
  label: "Sales Reps",
  icon: icons.Users
});
const PeriodSelect = ({
  value,
  onChange
}) => /* @__PURE__ */ jsxRuntime.jsx("div", { className: "w-44", children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Select, { size: "small", value, onValueChange: onChange, children: [
  /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Value, {}) }),
  /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Content, { children: recentPeriods().map((period) => /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: period.value, children: period.label }, period.value)) })
] }) });
const downloadFile = async (path, accept, fallbackName) => {
  var _a;
  const response = await sdk.client.fetch(path, {
    headers: { accept }
  });
  const blob = await response.blob();
  const disposition = response.headers.get("content-disposition") ?? "";
  const fileName = ((_a = /filename="([^"]+)"/.exec(disposition)) == null ? void 0 : _a[1]) ?? fallbackName;
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
};
const readAsBase64 = (file) => new Promise((resolve, reject) => {
  const reader = new FileReader();
  reader.onload = () => resolve(String(reader.result).split(",")[1] ?? "");
  reader.onerror = () => reject(reader.error);
  reader.readAsDataURL(file);
});
const CommissionReportPage = () => {
  const [period, setPeriod] = react.useState(currentPeriod());
  const { data, isLoading } = reactQuery.useQuery({
    queryKey: ["commission-report", period],
    queryFn: () => sdk.client.fetch(
      "/admin/sales-commission/report",
      { query: { period } }
    )
  });
  const exportCsv = () => downloadFile(
    `/admin/sales-commission/report?period=${period}&format=csv`,
    "text/csv",
    `commission-report-${period}.csv`
  ).catch((error) => ui.toast.error(errorMessage(error)));
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col items-start justify-between gap-2 px-6 py-4 md:flex-row md:items-center", children: [
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-1", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { children: "Commission report" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: "Commission counts in the month the order was paid. Totals are per currency, without conversion." })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
        /* @__PURE__ */ jsxRuntime.jsx(PeriodSelect, { value: period, onChange: setPeriod }),
        /* @__PURE__ */ jsxRuntime.jsxs(ui.Button, { size: "small", variant: "secondary", onClick: exportCsv, children: [
          /* @__PURE__ */ jsxRuntime.jsx(icons.ArrowDownTray, {}),
          "Export CSV"
        ] })
      ] })
    ] }),
    isLoading || !data ? /* @__PURE__ */ jsxRuntime.jsx(Loading, {}) : data.rows.length === 0 ? /* @__PURE__ */ jsxRuntime.jsx("div", { className: "px-6 py-4", children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "No commission recorded for this month." }) }) : /* @__PURE__ */ jsxRuntime.jsxs(ui.Table, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Header, { children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Table.Row, { children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Sales rep" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Currency" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Turnover" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Level 2 turnover" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Direct" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Level 2" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Adjustments" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Total" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Paid" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Status" })
      ] }) }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Body, { children: data.rows.map((row) => {
        const money = (amount) => formatMoney(amount, row.currency_code);
        const badge = STATUS_BADGES[row.status];
        return /* @__PURE__ */ jsxRuntime.jsxs(ui.Table.Row, { children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: /* @__PURE__ */ jsxRuntime.jsx(
            reactRouterDom.Link,
            {
              to: `/sales-reps/${row.sales_rep_id}`,
              className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
              children: row.sales_rep_name
            }
          ) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: row.currency_code.toUpperCase() }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: money(row.turnover) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: money(row.level2_turnover) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: money(row.direct) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: money(row.level2) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: money(row.adjustments) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: money(row.total) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: money(row.paid) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: badge.color, children: badge.label }) })
        ] }, `${row.sales_rep_id}-${row.currency_code}`);
      }) })
    ] })
  ] });
};
const config = adminSdk.defineRouteConfig({
  label: "Commission report"
});
const ClientsSection = ({ repId }) => {
  const { data, isLoading } = reactQuery.useQuery({
    queryKey: ["sales-rep-clients", repId],
    queryFn: () => sdk.client.fetch(
      `/admin/sales-reps/${repId}/clients`
    )
  });
  const current = (data == null ? void 0 : data.clients.filter((a) => a.ends_at === null)) ?? [];
  const pastCount = ((data == null ? void 0 : data.clients.length) ?? 0) - current.length;
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h2", children: "Clients" }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Assign clients from the customer page" })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      isLoading ? /* @__PURE__ */ jsxRuntime.jsx(Loading, {}) : current.length === 0 ? /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "No clients assigned." }) : current.map((assignment) => /* @__PURE__ */ jsxRuntime.jsx(
        reactRouterDom.Link,
        {
          to: `/customers/${assignment.customer_id}`,
          className: "outline-none focus-within:shadow-borders-interactive-with-focus rounded-md [&:hover>div]:bg-ui-bg-component-hover",
          children: /* @__PURE__ */ jsxRuntime.jsx("div", { className: "shadow-elevation-card-rest bg-ui-bg-component rounded-md px-4 py-2 transition-colors", children: /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-1 flex-col", children: [
              /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", children: clientName(assignment.customer) }),
              /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
                assignment.commission_rate,
                "% since",
                " ",
                formatDate(assignment.starts_at)
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntime.jsx(icons.TriangleRightMini, { className: "text-ui-fg-muted rtl:rotate-180" })
          ] }) })
        },
        assignment.id
      )),
      pastCount > 0 && /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
        pastCount,
        " earlier assignment",
        pastCount === 1 ? "" : "s",
        " on record"
      ] })
    ] })
  ] });
};
const ACCEPTED = ["application/pdf", "image/jpeg", "image/png"];
const MAX_BYTES = 10 * 1024 * 1024;
const ContractsSection = ({ repId }) => {
  const input = react.useRef(null);
  const queryClient = reactQuery.useQueryClient();
  const { data, isLoading } = reactQuery.useQuery({
    queryKey: ["sales-rep-contracts", repId],
    queryFn: () => sdk.client.fetch(
      `/admin/sales-reps/${repId}/contracts`
    )
  });
  const upload = reactQuery.useMutation({
    mutationFn: async (file) => sdk.client.fetch(`/admin/sales-reps/${repId}/contracts`, {
      method: "POST",
      body: {
        file_name: file.name,
        mime_type: file.type,
        content_base64: await readAsBase64(file)
      }
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["sales-rep-contracts", repId] });
      ui.toast.success("Contract uploaded");
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const onFile = (file) => {
    if (!file) {
      return;
    }
    if (!ACCEPTED.includes(file.type)) {
      return ui.toast.error("Upload a PDF, JPEG or PNG file");
    }
    if (file.size > MAX_BYTES) {
      return ui.toast.error("Contracts can be at most 10 MB");
    }
    upload.mutate(file);
  };
  const download = (contract) => downloadFile(
    `/admin/sales-reps/${repId}/contracts/${contract.id}/download`,
    contract.mime_type,
    contract.file_name
  ).catch((error) => ui.toast.error(errorMessage(error)));
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h2", children: "Contracts" }),
      /* @__PURE__ */ jsxRuntime.jsxs(
        ui.Button,
        {
          size: "small",
          variant: "secondary",
          isLoading: upload.isPending,
          onClick: () => {
            var _a;
            return (_a = input.current) == null ? void 0 : _a.click();
          },
          children: [
            /* @__PURE__ */ jsxRuntime.jsx(icons.ArrowUpTray, {}),
            "Upload"
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntime.jsx(
        "input",
        {
          ref: input,
          type: "file",
          accept: ACCEPTED.join(","),
          className: "hidden",
          onChange: (e) => {
            var _a;
            onFile((_a = e.target.files) == null ? void 0 : _a[0]);
            e.target.value = "";
          }
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Stored privately; only admins can download them." }),
      isLoading ? /* @__PURE__ */ jsxRuntime.jsx(Loading, {}) : !(data == null ? void 0 : data.contracts.length) ? /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "No contract uploaded yet." }) : data.contracts.map((contract) => /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between gap-x-2", children: [
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex min-w-0 flex-col", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", className: "truncate", children: contract.file_name }),
          /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
            formatDate(contract.created_at),
            " · ",
            formatSize(contract.size_bytes)
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsx(
          ui.IconButton,
          {
            size: "small",
            variant: "transparent",
            onClick: () => download(contract),
            children: /* @__PURE__ */ jsxRuntime.jsx(icons.ArrowDownTray, {})
          }
        )
      ] }, contract.id))
    ] })
  ] });
};
const copy = (text) => navigator.clipboard.writeText(text).then(() => ui.toast.success("Link copied")).catch(() => ui.toast.error("Couldn't copy, select the link instead"));
const PortalSection = ({
  rep,
  portal
}) => {
  const [granted, setGranted] = react.useState(null);
  const queryClient = reactQuery.useQueryClient();
  const prompt = ui.usePrompt();
  const active = portal.status === "active";
  const refresh = () => queryClient.invalidateQueries({ queryKey: ["sales-rep", rep.id] });
  const grant = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${rep.id}/portal-access`, {
      method: "POST",
      body: {}
    }),
    onSuccess: (result) => {
      refresh();
      setGranted(result);
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const revoke = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${rep.id}/portal-access`, {
      method: "DELETE"
    }),
    onSuccess: () => {
      refresh();
      ui.toast.success("Portal access ended");
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const confirmRevoke = async () => {
    const confirmed = await prompt({
      title: "End portal access?",
      description: `${rep.name} is signed out of the sales portal at once. You can give access again later, and they keep their password.`,
      confirmText: "End access",
      cancelText: "Cancel"
    });
    if (confirmed) {
      revoke.mutate();
    }
  };
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h2", children: "Sales portal" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: active ? "green" : "grey", children: active ? "Has access" : "No access" })
      ] }),
      active ? /* @__PURE__ */ jsxRuntime.jsx(
        ui.Button,
        {
          size: "small",
          variant: "secondary",
          isLoading: revoke.isPending,
          onClick: confirmRevoke,
          children: "End access"
        }
      ) : /* @__PURE__ */ jsxRuntime.jsx(
        ui.Button,
        {
          size: "small",
          variant: "secondary",
          disabled: !rep.is_active,
          isLoading: grant.isPending,
          onClick: () => grant.mutate(),
          children: "Give access"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx("div", { className: "px-6 py-4", children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: active ? `${rep.name} can sign in to the sales portal with ${rep.email} to see their clients, paid orders and payouts.` : rep.is_active ? `Gives ${rep.name} a login to see their clients, paid orders and payouts. They set their first password with "Forgot password" on the portal.` : "Reactivate this rep to give them portal access." }) }),
    /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer, { open: !!granted, onOpenChange: (open) => !open && setGranted(null), children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Content, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Header, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Title, { children: "Portal access given" }) }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
        /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: [
          rep.name,
          ' sets a first password with "Forgot password" on the portal: they enter ',
          rep.email,
          " and follow the link in the email that Medusa sends. Pass this link on:"
        ] }),
        (granted == null ? void 0 : granted.forgot_password_url) ? /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Input, { readOnly: true, value: granted.forgot_password_url }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Button,
            {
              size: "small",
              variant: "secondary",
              onClick: () => copy(granted.forgot_password_url),
              children: "Copy"
            }
          )
        ] }) : /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", className: "text-ui-fg-error", children: [
          "The portal URL isn't configured (SALES_PORTAL_URL), so there is no link to copy. Tell ",
          rep.name,
          ` to open the portal's "Forgot password" page.`
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Footer, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", children: "Done" }) }) })
    ] }) })
  ] });
};
const Row = ({ label, value }) => /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "grid grid-cols-2 items-start px-6 py-4", children: [
  /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", children: label }),
  /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: value })
] });
const ProfileSection = ({ rep }) => {
  const [open, setOpen] = react.useState(false);
  const [form, setForm] = react.useState(rep);
  const queryClient = reactQuery.useQueryClient();
  const update = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${rep.id}`, {
      method: "POST",
      body: {
        name: form.name,
        email: form.email,
        phone: form.phone || null,
        notes: form.notes || null,
        is_active: form.is_active
      }
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["sales-rep", rep.id] });
      queryClient.invalidateQueries({ queryKey: ["sales-reps"] });
      ui.toast.success("Sales rep updated");
      setOpen(false);
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { children: rep.name }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: rep.is_active ? "green" : "grey", children: rep.is_active ? "Active" : "Inactive" })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs(
        ui.Button,
        {
          size: "small",
          variant: "secondary",
          onClick: () => {
            setForm(rep);
            setOpen(true);
          },
          children: [
            /* @__PURE__ */ jsxRuntime.jsx(icons.PencilSquare, {}),
            "Edit"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx(Row, { label: "Email", value: rep.email }),
    /* @__PURE__ */ jsxRuntime.jsx(Row, { label: "Phone", value: rep.phone || "-" }),
    /* @__PURE__ */ jsxRuntime.jsx(Row, { label: "Notes", value: rep.notes || "-" }),
    /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer, { open, onOpenChange: setOpen, children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Content, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Header, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Title, { children: "Edit sales rep" }) }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "edit-name", children: "Name" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Input,
            {
              id: "edit-name",
              value: form.name,
              onChange: (e) => setForm({ ...form, name: e.target.value })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "edit-email", children: "Email" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Input,
            {
              id: "edit-email",
              type: "email",
              value: form.email,
              onChange: (e) => setForm({ ...form, email: e.target.value })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "edit-phone", children: "Phone" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Input,
            {
              id: "edit-phone",
              value: form.phone ?? "",
              onChange: (e) => setForm({ ...form, phone: e.target.value })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "edit-notes", children: "Notes" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Textarea,
            {
              id: "edit-notes",
              value: form.notes ?? "",
              onChange: (e) => setForm({ ...form, notes: e.target.value })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-start justify-between gap-x-4", children: [
          /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-1", children: [
            /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "edit-active", children: "Active" }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: "Inactive reps can't get new clients or referrals. Their current clients keep earning until you move them." })
          ] }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Switch,
            {
              id: "edit-active",
              checked: form.is_active,
              onCheckedChange: (checked) => setForm({ ...form, is_active: checked })
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Footer, { children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", disabled: update.isPending, children: "Cancel" }) }),
        /* @__PURE__ */ jsxRuntime.jsx(
          ui.Button,
          {
            size: "small",
            onClick: () => update.mutate(),
            isLoading: update.isPending,
            children: "Save"
          }
        )
      ] })
    ] }) })
  ] });
};
const ReferralSection = ({
  repId,
  referral,
  referredReps
}) => {
  var _a;
  const [open, setOpen] = react.useState(false);
  const [referrerId, setReferrerId] = react.useState("");
  const [rate, setRate] = react.useState("");
  const queryClient = reactQuery.useQueryClient();
  const prompt = ui.usePrompt();
  const { data: reps } = reactQuery.useQuery({
    queryKey: ["sales-reps", "active-options"],
    queryFn: () => sdk.client.fetch("/admin/sales-reps", {
      query: { is_active: "true", limit: 200, order: "name" }
    }),
    enabled: open
  });
  const refresh = () => queryClient.invalidateQueries({ queryKey: ["sales-rep"] });
  const save = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/referral`, {
      method: "POST",
      body: { referrer_sales_rep_id: referrerId, level2_rate: Number(rate) }
    }),
    onSuccess: () => {
      refresh();
      ui.toast.success("Referral saved");
      setOpen(false);
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const end = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/referral`, {
      method: "DELETE"
    }),
    onSuccess: () => {
      refresh();
      ui.toast.success("Referral ended");
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const confirmEnd = async () => {
    const confirmed = await prompt({
      title: "End referral?",
      description: "The referrer stops earning Level 2 commission on orders placed today or later. Earlier days are not affected.",
      confirmText: "End referral",
      cancelText: "Cancel"
    });
    if (confirmed) {
      end.mutate();
    }
  };
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h2", children: "Referral" }),
      /* @__PURE__ */ jsxRuntime.jsxs(
        ui.Button,
        {
          size: "small",
          variant: "secondary",
          onClick: () => {
            setReferrerId((referral == null ? void 0 : referral.referrer_sales_rep_id) ?? "");
            setRate(referral ? String(referral.level2_rate) : "");
            setOpen(true);
          },
          children: [
            /* @__PURE__ */ jsxRuntime.jsx(icons.PencilSquare, {}),
            referral ? "Change" : "Set referrer"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex flex-col gap-y-1 px-6 py-4", children: referral ? /* @__PURE__ */ jsxRuntime.jsxs(jsxRuntime.Fragment, { children: [
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", weight: "plus", children: [
        "Referred by",
        " ",
        /* @__PURE__ */ jsxRuntime.jsx(
          reactRouterDom.Link,
          {
            to: `/sales-reps/${referral.referrer_sales_rep_id}`,
            className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
            children: ((_a = referral.referrer) == null ? void 0 : _a.name) ?? "another rep"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
        "Level 2: ",
        referral.level2_rate,
        "% of this rep's client turnover, since ",
        formatDate(referral.starts_at)
      ] }),
      /* @__PURE__ */ jsxRuntime.jsx("div", { children: /* @__PURE__ */ jsxRuntime.jsx(
        ui.Button,
        {
          size: "small",
          variant: "transparent",
          className: "-ml-3 mt-1",
          isLoading: end.isPending,
          onClick: confirmEnd,
          children: "End referral"
        }
      ) })
    ] }) : /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Not referred by another rep." }) }),
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2 px-6 py-4", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", children: "Reps they referred" }),
      referredReps.length === 0 ? /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "None" }) : referredReps.map((r) => {
        var _a2;
        return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntime.jsx(
            reactRouterDom.Link,
            {
              to: `/sales-reps/${r.referred_sales_rep_id}`,
              className: "text-ui-fg-interactive hover:text-ui-fg-interactive-hover",
              children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", children: ((_a2 = r.referred) == null ? void 0 : _a2.name) ?? r.referred_sales_rep_id })
            }
          ),
          /* @__PURE__ */ jsxRuntime.jsxs(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: [
            r.level2_rate,
            "%"
          ] })
        ] }, r.id);
      })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer, { open, onOpenChange: setOpen, children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Content, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Header, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Title, { children: "Referrer and Level 2 rate" }) }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Body, { className: "flex flex-col gap-y-4 overflow-auto p-4", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: "The referrer earns this percentage of the net turnover of this rep's clients, on top of this rep's own commission. It takes effect from the start of today (Budapest time); earlier days are not affected." }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Referred by" }),
          /* @__PURE__ */ jsxRuntime.jsxs(ui.Select, { value: referrerId, onValueChange: setReferrerId, children: [
            /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Value, { placeholder: "Choose a sales rep" }) }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Content, { children: ((reps == null ? void 0 : reps.sales_reps) ?? []).filter((rep) => rep.id !== repId).map((rep) => /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: rep.id, children: rep.name }, rep.id)) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "level2-rate", children: "Level 2 rate (%)" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            ui.Input,
            {
              id: "level2-rate",
              type: "number",
              min: 0,
              max: 100,
              step: "0.01",
              value: rate,
              onChange: (e) => setRate(e.target.value)
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Drawer.Footer, { children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Drawer.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", disabled: save.isPending, children: "Cancel" }) }),
        /* @__PURE__ */ jsxRuntime.jsx(
          ui.Button,
          {
            size: "small",
            disabled: !referrerId || rate === "",
            isLoading: save.isPending,
            onClick: () => save.mutate(),
            children: "Save"
          }
        )
      ] })
    ] }) })
  ] });
};
const COPY = {
  adjustment: {
    button: "Add adjustment",
    title: "Add commission adjustment",
    description: "Correct a month by hand, for example after a partial return. Use a negative amount to reduce the commission. The reason is shown to the rep in the sales portal. Adjustments can't be edited or deleted; add a reversing one to undo."
  },
  payout: {
    button: "Record payout",
    title: "Record payout",
    description: "Record a bank transfer you made to the rep. The month is marked paid once payouts cover its total."
  }
};
const MoneyEntryModal = ({
  kind,
  repId,
  period
}) => {
  const initial = {
    currency_code: "eur",
    amount: "",
    period,
    note: "",
    paid_at: today()
  };
  const [open, setOpen] = react.useState(false);
  const [form, setForm] = react.useState(initial);
  const [error, setError] = react.useState(null);
  const queryClient = reactQuery.useQueryClient();
  const copy2 = COPY[kind];
  const save = reactQuery.useMutation({
    mutationFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/${kind}s`, {
      method: "POST",
      body: kind === "adjustment" ? {
        currency_code: form.currency_code,
        amount: Number(form.amount),
        period: form.period,
        reason: form.note
      } : {
        currency_code: form.currency_code,
        amount: Number(form.amount),
        period: form.period,
        paid_at: form.paid_at,
        reference: form.note || null
      }
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["sales-rep-statement", repId] });
      queryClient.invalidateQueries({ queryKey: ["commission-report"] });
      ui.toast.success(kind === "adjustment" ? "Adjustment added" : "Payout recorded");
      setOpen(false);
    },
    onError: (e) => ui.toast.error(errorMessage(e))
  });
  const submit = () => {
    const amount = Number(form.amount);
    if (!form.amount || Number.isNaN(amount) || amount === 0) {
      return setError("Enter an amount");
    }
    if (kind === "payout" && amount < 0) {
      return setError("A payout must be more than zero");
    }
    if (kind === "adjustment" && !form.note.trim()) {
      return setError("A reason is required");
    }
    setError(null);
    save.mutate();
  };
  return /* @__PURE__ */ jsxRuntime.jsxs(
    ui.FocusModal,
    {
      open,
      onOpenChange: (next) => {
        setOpen(next);
        if (next) {
          setForm(initial);
          setError(null);
        }
      },
      children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Trigger, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", children: copy2.button }) }),
        /* @__PURE__ */ jsxRuntime.jsxs(ui.FocusModal.Content, { children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Header, { children: /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-end gap-x-2", children: [
            /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", disabled: save.isPending, children: "Cancel" }) }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", onClick: submit, isLoading: save.isPending, children: "Save" })
          ] }) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Body, { className: "flex flex-1 flex-col items-center overflow-y-auto py-16", children: /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex w-full max-w-lg flex-col gap-y-6", children: [
            /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-1", children: [
              /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Title, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { children: copy2.title }) }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Description, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-subtle", children: copy2.description }) })
            ] }),
            /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
                /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Month" }),
                /* @__PURE__ */ jsxRuntime.jsxs(
                  ui.Select,
                  {
                    value: form.period,
                    onValueChange: (value) => setForm({ ...form, period: value }),
                    children: [
                      /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Value, {}) }),
                      /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Content, { children: recentPeriods().map((p) => /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: p.value, children: p.label }, p.value)) })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
                /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { children: "Currency" }),
                /* @__PURE__ */ jsxRuntime.jsxs(
                  ui.Select,
                  {
                    value: form.currency_code,
                    onValueChange: (value) => setForm({ ...form, currency_code: value }),
                    children: [
                      /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Value, {}) }),
                      /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Content, { children: CURRENCIES.map((code) => /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: code, children: code.toUpperCase() }, code)) })
                    ]
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
              /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: `${kind}-amount`, children: "Amount" }),
              /* @__PURE__ */ jsxRuntime.jsx(
                ui.Input,
                {
                  id: `${kind}-amount`,
                  type: "number",
                  step: "0.01",
                  value: form.amount,
                  onChange: (e) => setForm({ ...form, amount: e.target.value })
                }
              )
            ] }),
            kind === "payout" && /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
              /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: "payout-date", children: "Paid on" }),
              /* @__PURE__ */ jsxRuntime.jsx(
                ui.Input,
                {
                  id: "payout-date",
                  type: "date",
                  value: form.paid_at,
                  onChange: (e) => setForm({ ...form, paid_at: e.target.value })
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-2", children: [
              /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: `${kind}-note`, children: kind === "adjustment" ? "Reason" : "Reference or note (optional)" }),
              /* @__PURE__ */ jsxRuntime.jsx(
                ui.Textarea,
                {
                  id: `${kind}-note`,
                  value: form.note,
                  onChange: (e) => setForm({ ...form, note: e.target.value })
                }
              )
            ] }),
            error && /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-error", children: error })
          ] }) })
        ] })
      ]
    }
  );
};
const KIND_LABELS = {
  direct: "Commission",
  level2: "Level 2",
  reversal: "Reversal",
  adjustment: "Adjustment",
  payout: "Payout"
};
const Totals = ({ summary }) => {
  const money = (amount) => formatMoney(amount, summary.currency_code);
  const badge = STATUS_BADGES[summary.status];
  const cells = [
    ["Turnover", money(summary.turnover)],
    ["Direct", money(summary.direct)],
    ["Level 2", money(summary.level2)],
    ["Adjustments", money(summary.adjustments)],
    ["Total", money(summary.total)],
    ["Paid", money(summary.paid)]
  ];
  return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-3 px-6 py-4", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-2", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", children: summary.currency_code.toUpperCase() }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.Badge, { size: "2xsmall", color: badge.color, children: badge.label })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx("div", { className: "grid grid-cols-3 gap-3 md:grid-cols-6", children: cells.map(([label, value]) => /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-1", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "xsmall", leading: "compact", className: "text-ui-fg-subtle", children: label }),
      /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", weight: "plus", children: value })
    ] }, label)) })
  ] });
};
const StatementSection = ({ repId }) => {
  const [period, setPeriod] = react.useState(currentPeriod());
  const queryClient = reactQuery.useQueryClient();
  const prompt = ui.usePrompt();
  const { data, isLoading } = reactQuery.useQuery({
    queryKey: ["sales-rep-statement", repId, period],
    queryFn: () => sdk.client.fetch(`/admin/sales-reps/${repId}/statement`, {
      query: { period }
    })
  });
  const deletePayout = reactQuery.useMutation({
    mutationFn: (payoutId) => sdk.client.fetch(`/admin/sales-commission/payouts/${payoutId}`, {
      method: "DELETE"
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["sales-rep-statement", repId] });
      queryClient.invalidateQueries({ queryKey: ["commission-report"] });
      ui.toast.success("Payout removed");
    },
    onError: (error) => ui.toast.error(errorMessage(error))
  });
  const confirmDelete = async (line) => {
    const confirmed = await prompt({
      title: "Remove payout?",
      description: `Removes the ${formatMoney(line.amount, line.currency_code)} payout recorded by mistake. The month shows as unpaid again if nothing else covers it.`,
      confirmText: "Remove",
      cancelText: "Cancel"
    });
    if (confirmed) {
      deletePayout.mutate(line.source_id);
    }
  };
  const exportCsv = () => downloadFile(
    `/admin/sales-reps/${repId}/statement?period=${period}&format=csv`,
    "text/csv",
    `commission-statement-${period}.csv`
  ).catch((error) => ui.toast.error(errorMessage(error)));
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col items-start justify-between gap-2 px-6 py-4 md:flex-row md:items-center", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h2", children: "Commission statement" }),
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntime.jsx(PeriodSelect, { value: period, onChange: setPeriod }),
        /* @__PURE__ */ jsxRuntime.jsxs(ui.Button, { size: "small", variant: "secondary", onClick: exportCsv, children: [
          /* @__PURE__ */ jsxRuntime.jsx(icons.ArrowDownTray, {}),
          "CSV"
        ] }),
        /* @__PURE__ */ jsxRuntime.jsx(MoneyEntryModal, { kind: "adjustment", repId, period }),
        /* @__PURE__ */ jsxRuntime.jsx(MoneyEntryModal, { kind: "payout", repId, period })
      ] })
    ] }),
    isLoading || !data ? /* @__PURE__ */ jsxRuntime.jsx(Loading, {}) : data.lines.length === 0 ? /* @__PURE__ */ jsxRuntime.jsx("div", { className: "px-6 py-4", children: /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", leading: "compact", className: "text-ui-fg-subtle", children: "Nothing recorded for this month." }) }) : /* @__PURE__ */ jsxRuntime.jsxs(jsxRuntime.Fragment, { children: [
      data.totals.map((summary) => /* @__PURE__ */ jsxRuntime.jsx(Totals, { summary }, summary.currency_code)),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Table, { children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Header, { children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Table.Row, { children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Date" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Type" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Order" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Client" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Net value" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Rate" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { className: "text-right", children: "Amount" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, { children: "Note" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.HeaderCell, {})
        ] }) }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Body, { children: data.lines.map((line) => /* @__PURE__ */ jsxRuntime.jsxs(ui.Table.Row, { children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: formatDate(line.date) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: KIND_LABELS[line.kind] }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: line.order_display_id ? `#${line.order_display_id}` : "-" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: line.client_name ?? "-" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: line.base_amount === null ? "-" : formatMoney(line.base_amount, line.currency_code) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: line.rate === null ? "-" : `${line.rate}%` }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { className: "text-right", children: formatMoney(line.amount, line.currency_code) }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: line.note ?? "" }),
          /* @__PURE__ */ jsxRuntime.jsx(ui.Table.Cell, { children: line.kind === "payout" && /* @__PURE__ */ jsxRuntime.jsx(
            ui.IconButton,
            {
              size: "small",
              variant: "transparent",
              disabled: deletePayout.isPending,
              onClick: () => confirmDelete(line),
              children: /* @__PURE__ */ jsxRuntime.jsx(icons.Trash, {})
            }
          ) })
        ] }, `${line.kind}-${line.source_id}`)) })
      ] })
    ] })
  ] });
};
const SalesRepDetailPage = () => {
  const { id } = reactRouterDom.useParams();
  const { data, isLoading, error } = reactQuery.useQuery({
    queryKey: ["sales-rep", id],
    queryFn: () => sdk.client.fetch(`/admin/sales-reps/${id}`),
    enabled: !!id
  });
  if (isLoading) {
    return /* @__PURE__ */ jsxRuntime.jsx(Loading, {});
  }
  if (error || !data) {
    return /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { size: "small", className: "text-ui-fg-error", children: "This sales rep could not be loaded." });
  }
  return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-y-3 xl:flex-row xl:items-start xl:gap-x-4", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex w-full flex-col gap-y-3", children: [
      /* @__PURE__ */ jsxRuntime.jsx(ProfileSection, { rep: data.sales_rep }, data.sales_rep.id),
      /* @__PURE__ */ jsxRuntime.jsx(StatementSection, { repId: data.sales_rep.id })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex w-full flex-col gap-y-3 xl:max-w-[400px]", children: [
      /* @__PURE__ */ jsxRuntime.jsx(
        ReferralSection,
        {
          repId: data.sales_rep.id,
          referral: data.referral,
          referredReps: data.referred_reps
        }
      ),
      /* @__PURE__ */ jsxRuntime.jsx(PortalSection, { rep: data.sales_rep, portal: data.portal }),
      /* @__PURE__ */ jsxRuntime.jsx(ClientsSection, { repId: data.sales_rep.id }),
      /* @__PURE__ */ jsxRuntime.jsx(ContractsSection, { repId: data.sales_rep.id })
    ] })
  ] });
};
const i18nTranslations0 = {};
const widgetModule = { widgets: [
  {
    Component: CustomerSalesRepWidget,
    zone: ["customer.details.side.after"],
    widgetId: "Widget-cf9f"
  }
] };
const routeModule = {
  routes: [
    {
      Component: SalesRepsPage,
      path: "/sales-reps",
      handle: { label: config$1.label, translationNs: config$1.translationNs }
    },
    {
      Component: CommissionReportPage,
      path: "/sales-reps/report",
      handle: { label: config.label, translationNs: config.translationNs }
    },
    {
      Component: SalesRepDetailPage,
      path: "/sales-reps/:id"
    }
  ]
};
const menuItemModule = {
  menuItems: [
    {
      label: config$1.label,
      icon: config$1.icon,
      path: "/sales-reps",
      nested: void 0,
      rank: void 0,
      translationNs: void 0
    },
    {
      label: config.label,
      icon: void 0,
      path: "/sales-reps/report",
      nested: void 0,
      rank: void 0,
      translationNs: void 0
    }
  ]
};
const formModule = { customFields: {} };
const displayModule = {
  displays: {}
};
const i18nModule = { resources: i18nTranslations0 };
const cellRendererModule = {};
const layoutModule = { layouts: [] };
const plugin = {
  widgetModule,
  routeModule,
  menuItemModule,
  formModule,
  displayModule,
  i18nModule,
  cellRendererModule,
  layoutModule
};
module.exports = plugin;
