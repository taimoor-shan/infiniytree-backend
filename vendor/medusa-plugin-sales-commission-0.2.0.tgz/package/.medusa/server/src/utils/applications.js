"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.approvalBlockers = exports.adminApplicationView = void 0;
const utils_1 = require("@medusajs/framework/utils");
const invite_1 = require("../lib/invite");
const portal_login_1 = require("../lib/portal-login");
const sales_commission_1 = require("../modules/sales-commission");
const iso = (value) => value ? new Date(value).toISOString() : null;
/** An application as the owner sees it. Built field by field: the link's hash stays inside. */
const adminApplicationView = (invite, recruiter) => ({
    id: invite.id,
    status: invite.status,
    /** An invite nobody has answered whose link has run out */
    expired: (0, invite_1.inviteState)(invite, new Date()) === "expired",
    name: invite.applicant_name ?? invite.name,
    email: invite.email,
    phone: invite.applicant_phone,
    company: invite.applicant_company,
    requested_currency_code: invite.requested_currency_code,
    note: invite.note,
    invited_at: iso(invite.created_at),
    expires_at: iso(invite.expires_at),
    applied_at: iso(invite.applied_at),
    terms_accepted_at: iso(invite.terms_accepted_at),
    decided_at: iso(invite.decided_at),
    decision_reason: invite.decision_reason,
    sales_rep_id: invite.sales_rep_id,
    recruiter: recruiter ? { id: recruiter.id, name: recruiter.name } : null,
});
exports.adminApplicationView = adminApplicationView;
/**
 * What would make approving this application fail, in words for the owner, so
 * they are told before they press the button: an inactive recruiter, an email
 * that already belongs to a rep, or a login on the shop that is linked to
 * something else (such as a customer account).
 */
const approvalBlockers = async (container, invite, recruiter) => {
    if (invite.status !== "applied") {
        return [];
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const blockers = [];
    if (!recruiter?.is_active) {
        blockers.push(`${recruiter?.name ?? "The recruiter"} is inactive. Reactivate them first, or decline this application.`);
    }
    const [existingRep] = await service.listSalesReps({ email: invite.email }, { take: 1, select: ["id"] });
    if (existingRep) {
        blockers.push("A sales rep with this email already exists.");
    }
    const [login] = await container
        .resolve(utils_1.Modules.AUTH)
        .listAuthIdentities({ provider_identities: { provider: "emailpass", entity_id: invite.email } }, { take: 1 });
    if (login) {
        const kind = (0, portal_login_1.classifyExistingLogin)(login.app_metadata, "");
        if (kind === "in_use" || kind === "other_rep") {
            blockers.push("This email already has a login on the shop that is linked to another account, such as a customer account, so it can't become a sales portal login. Decline and ask the candidate for a different email.");
        }
    }
    return blockers;
};
exports.approvalBlockers = approvalBlockers;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwbGljYXRpb25zLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3V0aWxzL2FwcGxpY2F0aW9ucy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxxREFBbUQ7QUFDbkQsMENBQXlEO0FBQ3pELHNEQUEyRDtBQUMzRCxrRUFBcUU7QUF1QnJFLE1BQU0sR0FBRyxHQUFHLENBQUMsS0FBMkIsRUFBRSxFQUFFLENBQzFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQTtBQUU5QywrRkFBK0Y7QUFDeEYsTUFBTSxvQkFBb0IsR0FBRyxDQUNsQyxNQUFvQixFQUNwQixTQUFtRCxFQUNuRCxFQUFFLENBQUMsQ0FBQztJQUNKLEVBQUUsRUFBRSxNQUFNLENBQUMsRUFBRTtJQUNiLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtJQUNyQiwyREFBMkQ7SUFDM0QsT0FBTyxFQUFFLElBQUEsb0JBQVcsRUFBQyxNQUFNLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQyxLQUFLLFNBQVM7SUFDdEQsSUFBSSxFQUFFLE1BQU0sQ0FBQyxjQUFjLElBQUksTUFBTSxDQUFDLElBQUk7SUFDMUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0lBQ25CLEtBQUssRUFBRSxNQUFNLENBQUMsZUFBZTtJQUM3QixPQUFPLEVBQUUsTUFBTSxDQUFDLGlCQUFpQjtJQUNqQyx1QkFBdUIsRUFBRSxNQUFNLENBQUMsdUJBQXVCO0lBQ3ZELElBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtJQUNqQixVQUFVLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUU7SUFDbkMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFFO0lBQ25DLFVBQVUsRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQztJQUNsQyxpQkFBaUIsRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDO0lBQ2hELFVBQVUsRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQztJQUNsQyxlQUFlLEVBQUUsTUFBTSxDQUFDLGVBQWU7SUFDdkMsWUFBWSxFQUFFLE1BQU0sQ0FBQyxZQUFZO0lBQ2pDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLFNBQVMsQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFFLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSTtDQUN6RSxDQUFDLENBQUE7QUF0QlcsUUFBQSxvQkFBb0Isd0JBc0IvQjtBQUVGOzs7OztHQUtHO0FBQ0ksTUFBTSxnQkFBZ0IsR0FBRyxLQUFLLEVBQ25DLFNBQTBCLEVBQzFCLE1BQStDLEVBQy9DLFNBQTJELEVBQ3hDLEVBQUU7SUFDckIsSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQ2hDLE9BQU8sRUFBRSxDQUFBO0lBQ1gsQ0FBQztJQUNELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sUUFBUSxHQUFhLEVBQUUsQ0FBQTtJQUU3QixJQUFJLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxDQUFDO1FBQzFCLFFBQVEsQ0FBQyxJQUFJLENBQ1gsR0FBRyxTQUFTLEVBQUUsSUFBSSxJQUFJLGVBQWUsbUVBQW1FLENBQ3pHLENBQUE7SUFDSCxDQUFDO0lBRUQsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLGFBQWEsQ0FDL0MsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUssRUFBRSxFQUN2QixFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FDNUIsQ0FBQTtJQUNELElBQUksV0FBVyxFQUFFLENBQUM7UUFDaEIsUUFBUSxDQUFDLElBQUksQ0FBQyw2Q0FBNkMsQ0FBQyxDQUFBO0lBQzlELENBQUM7SUFFRCxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsTUFBTSxTQUFTO1NBQzVCLE9BQU8sQ0FBQyxlQUFPLENBQUMsSUFBSSxDQUFDO1NBQ3JCLGtCQUFrQixDQUNqQixFQUFFLG1CQUFtQixFQUFFLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsTUFBTSxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQzNFLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUNaLENBQUE7SUFDSCxJQUFJLEtBQUssRUFBRSxDQUFDO1FBQ1YsTUFBTSxJQUFJLEdBQUcsSUFBQSxvQ0FBcUIsRUFBQyxLQUFLLENBQUMsWUFBWSxFQUFFLEVBQUUsQ0FBQyxDQUFBO1FBQzFELElBQUksSUFBSSxLQUFLLFFBQVEsSUFBSSxJQUFJLEtBQUssV0FBVyxFQUFFLENBQUM7WUFDOUMsUUFBUSxDQUFDLElBQUksQ0FDWCx5TUFBeU0sQ0FDMU0sQ0FBQTtRQUNILENBQUM7SUFDSCxDQUFDO0lBRUQsT0FBTyxRQUFRLENBQUE7QUFDakIsQ0FBQyxDQUFBO0FBM0NZLFFBQUEsZ0JBQWdCLG9CQTJDNUIifQ==