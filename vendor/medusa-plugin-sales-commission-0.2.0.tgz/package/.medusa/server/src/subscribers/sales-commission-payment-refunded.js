"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = salesCommissionPaymentRefunded;
const orders_for_payments_1 = require("../utils/orders-for-payments");
const refunds_1 = require("../utils/refunds");
async function salesCommissionPaymentRefunded({ event: { data }, container, }) {
    const logger = container.resolve("logger");
    try {
        for (const orderId of await (0, orders_for_payments_1.orderIdsForPayments)(container, [data.id])) {
            const { voided, reversed } = await (0, refunds_1.applyRefundToCommission)(container, orderId);
            if (voided) {
                logger.info(`[sales-commission] Voided ${voided} commission entries of refunded order ${orderId}`);
            }
            else if (reversed) {
                logger.info(`[sales-commission] Took back the refunded share of ${reversed} commission entries of order ${orderId}`);
            }
        }
    }
    catch (error) {
        logger.error(`[sales-commission] Failed to handle refund of payment ${data.id}: ${error.message}`);
    }
}
exports.config = {
    event: "payment.refunded",
    context: { subscriberId: "sales-commission-payment-refunded" },
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2FsZXMtY29tbWlzc2lvbi1wYXltZW50LXJlZnVuZGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3N1YnNjcmliZXJzL3NhbGVzLWNvbW1pc3Npb24tcGF5bWVudC1yZWZ1bmRlZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFJQSxpREF3QkM7QUEzQkQsc0VBQWtFO0FBQ2xFLDhDQUEwRDtBQUUzQyxLQUFLLFVBQVUsOEJBQThCLENBQUMsRUFDM0QsS0FBSyxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQ2YsU0FBUyxHQUNzQjtJQUMvQixNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBRTFDLElBQUksQ0FBQztRQUNILEtBQUssTUFBTSxPQUFPLElBQUksTUFBTSxJQUFBLHlDQUFtQixFQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFDdEUsTUFBTSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsR0FBRyxNQUFNLElBQUEsaUNBQXVCLEVBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFBO1lBQzlFLElBQUksTUFBTSxFQUFFLENBQUM7Z0JBQ1gsTUFBTSxDQUFDLElBQUksQ0FDVCw2QkFBNkIsTUFBTSx5Q0FBeUMsT0FBTyxFQUFFLENBQ3RGLENBQUE7WUFDSCxDQUFDO2lCQUFNLElBQUksUUFBUSxFQUFFLENBQUM7Z0JBQ3BCLE1BQU0sQ0FBQyxJQUFJLENBQ1Qsc0RBQXNELFFBQVEsZ0NBQWdDLE9BQU8sRUFBRSxDQUN4RyxDQUFBO1lBQ0gsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE1BQU0sQ0FBQyxLQUFLLENBQ1YseURBQXlELElBQUksQ0FBQyxFQUFFLEtBQUssS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUNyRixDQUFBO0lBQ0gsQ0FBQztBQUNILENBQUM7QUFFWSxRQUFBLE1BQU0sR0FBcUI7SUFDdEMsS0FBSyxFQUFFLGtCQUFrQjtJQUN6QixPQUFPLEVBQUUsRUFBRSxZQUFZLEVBQUUsbUNBQW1DLEVBQUU7Q0FDL0QsQ0FBQSJ9