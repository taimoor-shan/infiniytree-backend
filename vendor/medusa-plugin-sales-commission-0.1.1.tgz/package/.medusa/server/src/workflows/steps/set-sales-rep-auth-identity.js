"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setSalesRepAuthIdentityStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const sales_commission_1 = require("../../modules/sales-commission");
/**
 * Records which login belongs to a rep (null to unlink). Every portal request
 * checks it, so unlinking ends access at once, even for a token still valid.
 * Returns the login that was linked before.
 */
exports.setSalesRepAuthIdentityStep = (0, workflows_sdk_1.createStep)("set-sales-rep-auth-identity", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const rep = await service.retrieveSalesRep(input.sales_rep_id);
    await service.updateSalesReps({
        id: rep.id,
        auth_identity_id: input.auth_identity_id,
    });
    const previous = rep.auth_identity_id ?? null;
    return new workflows_sdk_1.StepResponse(previous, { id: rep.id, previous });
}, async (prior, { container }) => {
    if (!prior) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.updateSalesReps({
        id: prior.id,
        auth_identity_id: prior.previous,
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2V0LXNhbGVzLXJlcC1hdXRoLWlkZW50aXR5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9zZXQtc2FsZXMtcmVwLWF1dGgtaWRlbnRpdHkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscUVBQTRFO0FBQzVFLHFFQUF3RTtBQUd4RTs7OztHQUlHO0FBQ1UsUUFBQSwyQkFBMkIsR0FBRyxJQUFBLDBCQUFVLEVBQ25ELDZCQUE2QixFQUM3QixLQUFLLEVBQ0gsS0FBZ0UsRUFDaEUsRUFBRSxTQUFTLEVBQUUsRUFDYixFQUFFO0lBQ0YsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxHQUFHLEdBQUcsTUFBTSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFBO0lBQzlELE1BQU0sT0FBTyxDQUFDLGVBQWUsQ0FBQztRQUM1QixFQUFFLEVBQUUsR0FBRyxDQUFDLEVBQUU7UUFDVixnQkFBZ0IsRUFBRSxLQUFLLENBQUMsZ0JBQWdCO0tBQ3pDLENBQUMsQ0FBQTtJQUVGLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxnQkFBZ0IsSUFBSSxJQUFJLENBQUE7SUFFN0MsT0FBTyxJQUFJLDRCQUFZLENBQUMsUUFBUSxFQUFFLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQyxFQUFFLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQTtBQUM3RCxDQUFDLEVBQ0QsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDN0IsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ1gsT0FBTTtJQUNSLENBQUM7SUFDRCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLE9BQU8sQ0FBQyxlQUFlLENBQUM7UUFDNUIsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFO1FBQ1osZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLFFBQVE7S0FDakMsQ0FBQyxDQUFBO0FBQ0osQ0FBQyxDQUNGLENBQUEifQ==