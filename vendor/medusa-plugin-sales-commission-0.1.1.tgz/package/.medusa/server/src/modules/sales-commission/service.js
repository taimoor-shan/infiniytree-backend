"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const client_assignment_1 = __importDefault(require("./models/client-assignment"));
const commission_adjustment_1 = __importDefault(require("./models/commission-adjustment"));
const commission_entry_1 = __importDefault(require("./models/commission-entry"));
const commission_payout_1 = __importDefault(require("./models/commission-payout"));
const rep_referral_1 = __importDefault(require("./models/rep-referral"));
const sales_rep_1 = __importDefault(require("./models/sales-rep"));
const sales_rep_contract_1 = __importDefault(require("./models/sales-rep-contract"));
class SalesCommissionModuleService extends (0, utils_1.MedusaService)({
    SalesRep: sales_rep_1.default,
    SalesRepContract: sales_rep_contract_1.default,
    ClientAssignment: client_assignment_1.default,
    RepReferral: rep_referral_1.default,
    CommissionEntry: commission_entry_1.default,
    CommissionAdjustment: commission_adjustment_1.default,
    CommissionPayout: commission_payout_1.default,
}) {
    constructor(container, options) {
        super(...arguments);
        this.options_ = {
            ...options,
            timezone: options?.timezone ?? "Europe/Budapest",
        };
    }
    getOptions() {
        return this.options_;
    }
}
exports.default = SalesCommissionModuleService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL3NhbGVzLWNvbW1pc3Npb24vc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLHFEQUF5RDtBQUN6RCxtRkFBeUQ7QUFDekQsMkZBQWlFO0FBQ2pFLGlGQUF1RDtBQUN2RCxtRkFBeUQ7QUFDekQseUVBQStDO0FBQy9DLG1FQUF5QztBQUN6QyxxRkFBMEQ7QUFTMUQsTUFBTSw0QkFBNkIsU0FBUSxJQUFBLHFCQUFhLEVBQUM7SUFDdkQsUUFBUSxFQUFSLG1CQUFRO0lBQ1IsZ0JBQWdCLEVBQWhCLDRCQUFnQjtJQUNoQixnQkFBZ0IsRUFBaEIsMkJBQWdCO0lBQ2hCLFdBQVcsRUFBWCxzQkFBVztJQUNYLGVBQWUsRUFBZiwwQkFBZTtJQUNmLG9CQUFvQixFQUFwQiwrQkFBb0I7SUFDcEIsZ0JBQWdCLEVBQWhCLDJCQUFnQjtDQUNqQixDQUFDO0lBR0EsWUFBWSxTQUFrQyxFQUFFLE9BQWdDO1FBQzlFLEtBQUssQ0FBQyxHQUFHLFNBQVMsQ0FBQyxDQUFBO1FBQ25CLElBQUksQ0FBQyxRQUFRLEdBQUc7WUFDZCxHQUFHLE9BQU87WUFDVixRQUFRLEVBQUUsT0FBTyxFQUFFLFFBQVEsSUFBSSxpQkFBaUI7U0FDakQsQ0FBQTtJQUNILENBQUM7SUFFRCxVQUFVO1FBQ1IsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFBO0lBQ3RCLENBQUM7Q0FDRjtBQUVELGtCQUFlLDRCQUE0QixDQUFBIn0=