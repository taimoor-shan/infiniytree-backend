"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const approve_rep_application_1 = require("../../../../../../workflows/approve-rep-application");
/**
 * Approves an application: creates the rep, links the recruiter on the given
 * Level 2 terms from today, gives the rep a portal login and emails them a
 * link to set a password. All or nothing.
 */
async function POST(req, res) {
    const { level2_months, ...rest } = req.validatedBody;
    const { result } = await (0, approve_rep_application_1.approveRepApplicationWorkflow)(req.scope).run({
        input: {
            ...rest,
            invite_id: req.params.id,
            level2_months: level2_months ?? null,
            actor_id: req.auth_context.actor_id,
        },
    });
    res.json({ sales_rep: result.sales_rep });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLWNvbW1pc3Npb24vYXBwbGljYXRpb25zL1tpZF0vYXBwcm92ZS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVlBLG9CQWdCQztBQXhCRCxpR0FBbUc7QUFHbkc7Ozs7R0FJRztBQUNJLEtBQUssVUFBVSxJQUFJLENBQ3hCLEdBQTRELEVBQzVELEdBQW1CO0lBRW5CLE1BQU0sRUFBRSxhQUFhLEVBQUUsR0FBRyxJQUFJLEVBQUUsR0FBRyxHQUFHLENBQUMsYUFBYSxDQUFBO0lBRXBELE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLElBQUEsdURBQTZCLEVBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUNwRSxLQUFLLEVBQUU7WUFDTCxHQUFHLElBQUk7WUFDUCxTQUFTLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ3hCLGFBQWEsRUFBRSxhQUFhLElBQUksSUFBSTtZQUNwQyxRQUFRLEVBQUUsR0FBRyxDQUFDLFlBQVksQ0FBQyxRQUFRO1NBQ3BDO0tBQ0YsQ0FBQyxDQUFBO0lBRUYsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQTtBQUMzQyxDQUFDIn0=