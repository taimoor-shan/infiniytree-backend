"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const period_1 = require("../../../../../lib/period");
const pending_1 = require("../../../../../lib/pending");
const sales_commission_1 = require("../../../../../modules/sales-commission");
const balances_1 = require("../../../../../utils/balances");
const pending_2 = require("../../../../../utils/pending");
/**
 * What a rep is owed across every month, per currency: what can be paid now,
 * what is earned but not yet payable, what was paid ahead, and what was paid
 * this year. `pending` is what the rep's unpaid orders would earn if paid now.
 */
async function GET(req, res) {
    const service = req.scope.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.retrieveSalesRep(req.params.id);
    const year = (0, period_1.toPeriod)(new Date(), service.getOptions().timezone).slice(0, 4);
    const [{ approved_through, balances, paid_this_year }, pending] = await Promise.all([
        (0, balances_1.loadRepBalances)(req.scope, req.params.id, { year }),
        (0, pending_2.loadPendingLines)(req.scope, { salesRepId: req.params.id }),
    ]);
    res.json({
        approved_through,
        balances,
        paid_this_year,
        pending: (0, pending_1.pendingTotals)(pending),
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLXJlcHMvW2lkXS9iYWxhbmNlL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBZ0JBLGtCQXNCQztBQWxDRCxzREFBb0Q7QUFDcEQsd0RBQTBEO0FBQzFELDhFQUFpRjtBQUVqRiw0REFBK0Q7QUFDL0QsMERBQStEO0FBRS9EOzs7O0dBSUc7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUErQixFQUMvQixHQUFtQjtJQUVuQixNQUFNLE9BQU8sR0FBaUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUU3QyxNQUFNLElBQUksR0FBRyxJQUFBLGlCQUFRLEVBQUMsSUFBSSxJQUFJLEVBQUUsRUFBRSxPQUFPLENBQUMsVUFBVSxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQTtJQUM1RSxNQUFNLENBQUMsRUFBRSxnQkFBZ0IsRUFBRSxRQUFRLEVBQUUsY0FBYyxFQUFFLEVBQUUsT0FBTyxDQUFDLEdBQzdELE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUNoQixJQUFBLDBCQUFlLEVBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxDQUFDO1FBQ25ELElBQUEsMEJBQWdCLEVBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxFQUFFLFVBQVUsRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxDQUFDO0tBQzNELENBQUMsQ0FBQTtJQUVKLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDUCxnQkFBZ0I7UUFDaEIsUUFBUTtRQUNSLGNBQWM7UUFDZCxPQUFPLEVBQUUsSUFBQSx1QkFBYSxFQUFDLE9BQU8sQ0FBQztLQUNoQyxDQUFDLENBQUE7QUFDSixDQUFDIn0=