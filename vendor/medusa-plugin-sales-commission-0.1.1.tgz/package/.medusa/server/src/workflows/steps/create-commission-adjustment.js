"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCommissionAdjustmentStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const money_1 = require("../../lib/money");
const period_1 = require("../../lib/period");
const sales_commission_1 = require("../../modules/sales-commission");
const invalid = (message) => new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, message);
/** Adjustments are append-only: a mistake is fixed with a reversing one. */
exports.createCommissionAdjustmentStep = (0, workflows_sdk_1.createStep)("create-commission-adjustment", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.retrieveSalesRep(input.sales_rep_id);
    const reason = input.reason.trim();
    if (!reason) {
        throw invalid("An adjustment needs a reason");
    }
    if (!input.amount) {
        throw invalid("An adjustment can't be zero");
    }
    if (!(0, money_1.isCurrencyCode)(input.currency_code)) {
        throw invalid(`${input.currency_code} is not a currency code (use EUR or HUF)`);
    }
    if (!(0, money_1.hasValidPrecision)(input.amount, input.currency_code)) {
        throw invalid(`${input.currency_code.toUpperCase()} amounts can have at most ${(0, money_1.currencyDecimals)(input.currency_code)} decimals`);
    }
    if (!(0, period_1.isPeriod)(input.period)) {
        throw invalid(`${input.period} is not a month (YYYY-MM)`);
    }
    const adjustment = await service.createCommissionAdjustments({
        ...input,
        currency_code: input.currency_code.toLowerCase(),
        reason,
        order_id: input.order_id ?? null,
        created_by: input.created_by ?? null,
    });
    return new workflows_sdk_1.StepResponse(adjustment, adjustment.id);
}, async (adjustmentId, { container }) => {
    if (!adjustmentId) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.deleteCommissionAdjustments(adjustmentId);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLWNvbW1pc3Npb24tYWRqdXN0bWVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3Mvc3RlcHMvY3JlYXRlLWNvbW1pc3Npb24tYWRqdXN0bWVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxREFBdUQ7QUFDdkQscUVBQTRFO0FBQzVFLDJDQUFxRjtBQUNyRiw2Q0FBMkM7QUFDM0MscUVBQXdFO0FBYXhFLE1BQU0sT0FBTyxHQUFHLENBQUMsT0FBZSxFQUFFLEVBQUUsQ0FDbEMsSUFBSSxtQkFBVyxDQUFDLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQTtBQUUxRCw0RUFBNEU7QUFDL0QsUUFBQSw4QkFBOEIsR0FBRyxJQUFBLDBCQUFVLEVBQ3RELDhCQUE4QixFQUM5QixLQUFLLEVBQUUsS0FBMEMsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDbEUsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFBO0lBRWxELE1BQU0sTUFBTSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUE7SUFDbEMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ1osTUFBTSxPQUFPLENBQUMsOEJBQThCLENBQUMsQ0FBQTtJQUMvQyxDQUFDO0lBQ0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNsQixNQUFNLE9BQU8sQ0FBQyw2QkFBNkIsQ0FBQyxDQUFBO0lBQzlDLENBQUM7SUFDRCxJQUFJLENBQUMsSUFBQSxzQkFBYyxFQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDO1FBQ3pDLE1BQU0sT0FBTyxDQUFDLEdBQUcsS0FBSyxDQUFDLGFBQWEsMENBQTBDLENBQUMsQ0FBQTtJQUNqRixDQUFDO0lBQ0QsSUFBSSxDQUFDLElBQUEseUJBQWlCLEVBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQztRQUMxRCxNQUFNLE9BQU8sQ0FDWCxHQUFHLEtBQUssQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLDZCQUE2QixJQUFBLHdCQUFnQixFQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUNsSCxDQUFBO0lBQ0gsQ0FBQztJQUNELElBQUksQ0FBQyxJQUFBLGlCQUFRLEVBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFDNUIsTUFBTSxPQUFPLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSwyQkFBMkIsQ0FBQyxDQUFBO0lBQzNELENBQUM7SUFFRCxNQUFNLFVBQVUsR0FBRyxNQUFNLE9BQU8sQ0FBQywyQkFBMkIsQ0FBQztRQUMzRCxHQUFHLEtBQUs7UUFDUixhQUFhLEVBQUUsS0FBSyxDQUFDLGFBQWEsQ0FBQyxXQUFXLEVBQUU7UUFDaEQsTUFBTTtRQUNOLFFBQVEsRUFBRSxLQUFLLENBQUMsUUFBUSxJQUFJLElBQUk7UUFDaEMsVUFBVSxFQUFFLEtBQUssQ0FBQyxVQUFVLElBQUksSUFBSTtLQUNyQyxDQUFDLENBQUE7SUFFRixPQUFPLElBQUksNEJBQVksQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQ3BELENBQUMsRUFDRCxLQUFLLEVBQUUsWUFBWSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUNwQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDbEIsT0FBTTtJQUNSLENBQUM7SUFDRCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLE9BQU8sQ0FBQywyQkFBMkIsQ0FBQyxZQUFZLENBQUMsQ0FBQTtBQUN6RCxDQUFDLENBQ0YsQ0FBQSJ9