"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const client_link_1 = require("../../../lib/client-link");
/**
 * A new client who arrived through a rep's client link, and what became of it.
 * One per client: the first answer stands, so the same account can't be linked
 * twice and a later link can't take it over. Kept for the cases where the
 * client was not linked, so "why wasn't my client credited?" has an answer.
 */
const LinkClaim = utils_1.model
    .define("link_claim", {
    id: utils_1.model.id({ prefix: "slc" }).primaryKey(),
    customer_id: utils_1.model.text(),
    /** The code the client followed, as the storefront sent it */
    code: utils_1.model.text(),
    /** The rep behind the code; null when no rep has it */
    sales_rep_id: utils_1.model.text().nullable(),
    outcome: utils_1.model.enum(client_link_1.CLIENT_LINK_OUTCOMES),
    /** The assignment made, when the client was linked */
    assignment_id: utils_1.model.text().nullable(),
    /** Who the client was when they joined, kept even if the account is deleted */
    client_name: utils_1.model.text(),
    client_email: utils_1.model.text(),
})
    .indexes([
    { on: ["customer_id"], unique: true, where: "deleted_at IS NULL" },
    { on: ["sales_rep_id"] },
]);
exports.default = LinkClaim;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGluay1jbGFpbS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL3NhbGVzLWNvbW1pc3Npb24vbW9kZWxzL2xpbmstY2xhaW0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBaUQ7QUFDakQsMERBQStEO0FBRS9EOzs7OztHQUtHO0FBQ0gsTUFBTSxTQUFTLEdBQUcsYUFBSztLQUNwQixNQUFNLENBQUMsWUFBWSxFQUFFO0lBQ3BCLEVBQUUsRUFBRSxhQUFLLENBQUMsRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsVUFBVSxFQUFFO0lBQzVDLFdBQVcsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBQ3pCLDhEQUE4RDtJQUM5RCxJQUFJLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUNsQix1REFBdUQ7SUFDdkQsWUFBWSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDckMsT0FBTyxFQUFFLGFBQUssQ0FBQyxJQUFJLENBQUMsa0NBQW9CLENBQUM7SUFDekMsc0RBQXNEO0lBQ3RELGFBQWEsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ3RDLCtFQUErRTtJQUMvRSxXQUFXLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUN6QixZQUFZLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtDQUMzQixDQUFDO0tBQ0QsT0FBTyxDQUFDO0lBQ1AsRUFBRSxFQUFFLEVBQUUsQ0FBQyxhQUFhLENBQUMsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxvQkFBb0IsRUFBRTtJQUNsRSxFQUFFLEVBQUUsRUFBRSxDQUFDLGNBQWMsQ0FBQyxFQUFFO0NBQ3pCLENBQUMsQ0FBQTtBQUVKLGtCQUFlLFNBQVMsQ0FBQSJ9