"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const utils_1 = require("@medusajs/framework/utils");
const upload_sales_rep_contract_1 = require("../../../../../workflows/upload-sales-rep-contract");
const query_config_1 = require("../../query-config");
async function GET(req, res) {
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { data: contracts } = await query.graph({
        entity: "sales_rep_contract",
        fields: query_config_1.CONTRACT_FIELDS,
        filters: { sales_rep_id: req.params.id },
        pagination: { order: { created_at: "DESC" } },
    });
    res.json({ contracts });
}
async function POST(req, res) {
    const { result } = await (0, upload_sales_rep_contract_1.uploadSalesRepContractWorkflow)(req.scope).run({
        input: {
            ...req.validatedBody,
            sales_rep_id: req.params.id,
            uploaded_by: req.auth_context.actor_id,
        },
    });
    res.json({ contract: result });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLXJlcHMvW2lkXS9jb250cmFjdHMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFTQSxrQkFjQztBQUVELG9CQWFDO0FBbENELHFEQUFxRTtBQUNyRSxrR0FBbUc7QUFDbkcscURBQW9EO0FBRzdDLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQStCLEVBQy9CLEdBQW1CO0lBRW5CLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFBO0lBRWhFLE1BQU0sRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQzVDLE1BQU0sRUFBRSxvQkFBb0I7UUFDNUIsTUFBTSxFQUFFLDhCQUFlO1FBQ3ZCLE9BQU8sRUFBRSxFQUFFLFlBQVksRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRTtRQUN4QyxVQUFVLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLEVBQUU7S0FDOUMsQ0FBQyxDQUFBO0lBRUYsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUE7QUFDekIsQ0FBQztBQUVNLEtBQUssVUFBVSxJQUFJLENBQ3hCLEdBQWdFLEVBQ2hFLEdBQW1CO0lBRW5CLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLElBQUEsMERBQThCLEVBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUNyRSxLQUFLLEVBQUU7WUFDTCxHQUFHLEdBQUcsQ0FBQyxhQUFhO1lBQ3BCLFlBQVksRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDM0IsV0FBVyxFQUFFLEdBQUcsQ0FBQyxZQUFZLENBQUMsUUFBUTtTQUN2QztLQUNGLENBQUMsQ0FBQTtJQUVGLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQTtBQUNoQyxDQUFDIn0=