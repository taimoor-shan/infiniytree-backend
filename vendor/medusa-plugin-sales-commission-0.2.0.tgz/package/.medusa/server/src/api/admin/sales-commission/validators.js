"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminRecordPaymentRun = exports.AdminApproveCommissionPeriods = exports.AdminAddFxRate = exports.AdminCommissionPeriodParams = exports.AdminCreateCommissionPayout = exports.AdminCreateCommissionAdjustment = void 0;
const zod_1 = require("@medusajs/framework/zod");
const period = zod_1.z
    .string()
    .regex(/^\d{4}-(0[1-9]|1[0-2])$/, "Use a month in the form YYYY-MM");
exports.AdminCreateCommissionAdjustment = zod_1.z.object({
    currency_code: zod_1.z.string().length(3),
    amount: zod_1.z.number(),
    period: zod_1.z.string(),
    reason: zod_1.z.string(),
    order_id: zod_1.z.string().nullish(),
});
exports.AdminCreateCommissionPayout = zod_1.z.object({
    currency_code: zod_1.z.string().length(3),
    amount: zod_1.z.number(),
    /** The month it was paid in; the month of `paid_at` when left out */
    period: zod_1.z.string().nullish(),
    paid_at: zod_1.z.coerce.date(),
    reference: zod_1.z.string().nullish(),
    /** Record what is paid above the payable amount as a bonus, for this reason */
    bonus_reason: zod_1.z.string().nullish(),
});
exports.AdminCommissionPeriodParams = zod_1.z.object({
    period: period.optional(),
    format: zod_1.z.enum(["json", "csv"]).optional(),
});
exports.AdminAddFxRate = zod_1.z.object({
    rate_date: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use a date in the form YYYY-MM-DD"),
    rate: zod_1.z.number().positive(),
});
exports.AdminApproveCommissionPeriods = zod_1.z.object({
    through: period,
});
exports.AdminRecordPaymentRun = zod_1.z.object({
    items: zod_1.z
        .array(zod_1.z.object({
        sales_rep_id: zod_1.z.string().min(1),
        currency_code: zod_1.z.string().length(3),
        amount: zod_1.z.number().positive(),
    }))
        .min(1),
    paid_at: zod_1.z.coerce.date(),
    reference: zod_1.z.string().nullish(),
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdG9ycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcGkvYWRtaW4vc2FsZXMtY29tbWlzc2lvbi92YWxpZGF0b3JzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLGlEQUEyQztBQUUzQyxNQUFNLE1BQU0sR0FBRyxPQUFDO0tBQ2IsTUFBTSxFQUFFO0tBQ1IsS0FBSyxDQUFDLHlCQUF5QixFQUFFLGlDQUFpQyxDQUFDLENBQUE7QUFFekQsUUFBQSwrQkFBK0IsR0FBRyxPQUFDLENBQUMsTUFBTSxDQUFDO0lBQ3RELGFBQWEsRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztJQUNuQyxNQUFNLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRTtJQUNsQixNQUFNLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRTtJQUNsQixNQUFNLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRTtJQUNsQixRQUFRLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLE9BQU8sRUFBRTtDQUMvQixDQUFDLENBQUE7QUFLVyxRQUFBLDJCQUEyQixHQUFHLE9BQUMsQ0FBQyxNQUFNLENBQUM7SUFDbEQsYUFBYSxFQUFFLE9BQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQ25DLE1BQU0sRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFO0lBQ2xCLHFFQUFxRTtJQUNyRSxNQUFNLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLE9BQU8sRUFBRTtJQUM1QixPQUFPLEVBQUUsT0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUU7SUFDeEIsU0FBUyxFQUFFLE9BQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxPQUFPLEVBQUU7SUFDL0IsK0VBQStFO0lBQy9FLFlBQVksRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsT0FBTyxFQUFFO0NBQ25DLENBQUMsQ0FBQTtBQUtXLFFBQUEsMkJBQTJCLEdBQUcsT0FBQyxDQUFDLE1BQU0sQ0FBQztJQUNsRCxNQUFNLEVBQUUsTUFBTSxDQUFDLFFBQVEsRUFBRTtJQUN6QixNQUFNLEVBQUUsT0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRTtDQUMzQyxDQUFDLENBQUE7QUFLVyxRQUFBLGNBQWMsR0FBRyxPQUFDLENBQUMsTUFBTSxDQUFDO0lBQ3JDLFNBQVMsRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsS0FBSyxDQUFDLHFCQUFxQixFQUFFLG1DQUFtQyxDQUFDO0lBQ3ZGLElBQUksRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsUUFBUSxFQUFFO0NBQzVCLENBQUMsQ0FBQTtBQUdXLFFBQUEsNkJBQTZCLEdBQUcsT0FBQyxDQUFDLE1BQU0sQ0FBQztJQUNwRCxPQUFPLEVBQUUsTUFBTTtDQUNoQixDQUFDLENBQUE7QUFLVyxRQUFBLHFCQUFxQixHQUFHLE9BQUMsQ0FBQyxNQUFNLENBQUM7SUFDNUMsS0FBSyxFQUFFLE9BQUM7U0FDTCxLQUFLLENBQ0osT0FBQyxDQUFDLE1BQU0sQ0FBQztRQUNQLFlBQVksRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUMvQixhQUFhLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDbkMsTUFBTSxFQUFFLE9BQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUU7S0FDOUIsQ0FBQyxDQUNIO1NBQ0EsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUNULE9BQU8sRUFBRSxPQUFDLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRTtJQUN4QixTQUFTLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLE9BQU8sRUFBRTtDQUNoQyxDQUFDLENBQUEifQ==