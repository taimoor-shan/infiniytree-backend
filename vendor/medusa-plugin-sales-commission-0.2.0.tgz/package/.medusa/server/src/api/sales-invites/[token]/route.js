"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const invite_1 = require("../../../lib/invite");
const recruiting_errors_1 = require("../../../lib/recruiting-errors");
const sales_commission_1 = require("../../../modules/sales-commission");
/**
 * What a candidate sees on their invite page. Public: the personal link is
 * the credential, a secret nobody can guess, so an unknown, mistyped or
 * withdrawn link all answer the same way.
 */
async function GET(req, res) {
    const service = req.scope.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    res.setHeader("Cache-Control", "no-store");
    const token = req.params.token;
    const [invite] = (0, invite_1.isInviteToken)(token)
        ? await service.listRepInvites({ token_hash: (0, invite_1.hashInviteToken)(token) }, { take: 1 })
        : [];
    if (!invite || invite.status === "canceled") {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, "This invitation link isn't valid", recruiting_errors_1.RECRUITING_ERRORS.LINK_INVALID);
    }
    const recruiter = await service.retrieveSalesRep(invite.recruiter_sales_rep_id);
    res.json({
        invite: {
            state: (0, invite_1.inviteState)(invite, new Date()),
            recruiter_name: recruiter.name,
            name: invite.name,
            email: invite.email,
            expires_at: new Date(invite.expires_at).toISOString(),
            applied_at: invite.applied_at ? new Date(invite.applied_at).toISOString() : null,
        },
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLWludml0ZXMvW3Rva2VuXS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVlBLGtCQThCQztBQXpDRCxxREFBdUQ7QUFDdkQsZ0RBQWlGO0FBQ2pGLHNFQUFrRTtBQUNsRSx3RUFBMkU7QUFHM0U7Ozs7R0FJRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUMvRCxNQUFNLE9BQU8sR0FBaUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsR0FBRyxDQUFDLFNBQVMsQ0FBQyxlQUFlLEVBQUUsVUFBVSxDQUFDLENBQUE7SUFFMUMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUE7SUFDOUIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUEsc0JBQWEsRUFBQyxLQUFLLENBQUM7UUFDbkMsQ0FBQyxDQUFDLE1BQU0sT0FBTyxDQUFDLGNBQWMsQ0FBQyxFQUFFLFVBQVUsRUFBRSxJQUFBLHdCQUFlLEVBQUMsS0FBSyxDQUFDLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQztRQUNuRixDQUFDLENBQUMsRUFBRSxDQUFBO0lBQ04sSUFBSSxDQUFDLE1BQU0sSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLFVBQVUsRUFBRSxDQUFDO1FBQzVDLE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQzNCLGtDQUFrQyxFQUNsQyxxQ0FBaUIsQ0FBQyxZQUFZLENBQy9CLENBQUE7SUFDSCxDQUFDO0lBRUQsTUFBTSxTQUFTLEdBQUcsTUFBTSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLHNCQUFzQixDQUFDLENBQUE7SUFFL0UsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNQLE1BQU0sRUFBRTtZQUNOLEtBQUssRUFBRSxJQUFBLG9CQUFXLEVBQUMsTUFBTSxFQUFFLElBQUksSUFBSSxFQUFFLENBQUM7WUFDdEMsY0FBYyxFQUFFLFNBQVMsQ0FBQyxJQUFJO1lBQzlCLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtZQUNqQixLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7WUFDbkIsVUFBVSxFQUFFLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDckQsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSTtTQUNqRjtLQUNGLENBQUMsQ0FBQTtBQUNKLENBQUMifQ==