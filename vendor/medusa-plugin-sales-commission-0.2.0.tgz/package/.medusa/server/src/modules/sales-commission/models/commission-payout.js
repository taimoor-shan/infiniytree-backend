"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const sales_rep_1 = __importDefault(require("./sales-rep"));
/**
 * A bank transfer to a rep. It counts against everything approved so far,
 * whichever month that was earned in; `period` is the month it was paid in.
 */
const CommissionPayout = utils_1.model
    .define("commission_payout", {
    id: utils_1.model.id({ prefix: "scpay" }).primaryKey(),
    currency_code: utils_1.model.text(),
    amount: utils_1.model.bigNumber(),
    period: utils_1.model.text(),
    paid_at: utils_1.model.dateTime(),
    reference: utils_1.model.text().nullable(),
    /** Set for payouts recorded together in one payment run */
    run_id: utils_1.model.text().nullable(),
    /** What was payable to the rep, in this currency, when the payout was made */
    payable_before: utils_1.model.bigNumber().nullable(),
    created_by: utils_1.model.text().nullable(),
    sales_rep: utils_1.model.belongsTo(() => sales_rep_1.default, { mappedBy: "payouts" }),
})
    .indexes([{ on: ["period"] }]);
exports.default = CommissionPayout;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbWlzc2lvbi1wYXlvdXQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9zYWxlcy1jb21taXNzaW9uL21vZGVscy9jb21taXNzaW9uLXBheW91dC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLHFEQUFpRDtBQUNqRCw0REFBa0M7QUFFbEM7OztHQUdHO0FBQ0gsTUFBTSxnQkFBZ0IsR0FBRyxhQUFLO0tBQzNCLE1BQU0sQ0FBQyxtQkFBbUIsRUFBRTtJQUMzQixFQUFFLEVBQUUsYUFBSyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDLFVBQVUsRUFBRTtJQUM5QyxhQUFhLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUMzQixNQUFNLEVBQUUsYUFBSyxDQUFDLFNBQVMsRUFBRTtJQUN6QixNQUFNLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUNwQixPQUFPLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRTtJQUN6QixTQUFTLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNsQywyREFBMkQ7SUFDM0QsTUFBTSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDL0IsOEVBQThFO0lBQzlFLGNBQWMsRUFBRSxhQUFLLENBQUMsU0FBUyxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQzVDLFVBQVUsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ25DLFNBQVMsRUFBRSxhQUFLLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLG1CQUFRLEVBQUUsRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLENBQUM7Q0FDcEUsQ0FBQztLQUNELE9BQU8sQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUE7QUFFaEMsa0JBQWUsZ0JBQWdCLENBQUEifQ==