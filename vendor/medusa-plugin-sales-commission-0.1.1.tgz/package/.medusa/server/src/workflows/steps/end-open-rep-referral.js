"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.endOpenRepReferralStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const sales_commission_1 = require("../../modules/sales-commission");
exports.endOpenRepReferralStep = (0, workflows_sdk_1.createStep)("end-open-rep-referral", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const [open] = await service.listRepReferrals({ referred_sales_rep_id: input.referred_sales_rep_id, ends_at: null }, { take: 1 });
    if (!open) {
        if (input.required) {
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, `Sales rep ${input.referred_sales_rep_id} has no current referrer`);
        }
        return new workflows_sdk_1.StepResponse(null, null);
    }
    const ended = await service.updateRepReferrals({
        id: open.id,
        ends_at: input.ended_at,
        ended_by: input.ended_by ?? null,
    });
    return new workflows_sdk_1.StepResponse(ended, open.id);
}, async (referralId, { container }) => {
    if (!referralId) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.updateRepReferrals({
        id: referralId,
        ends_at: null,
        ended_by: null,
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW5kLW9wZW4tcmVwLXJlZmVycmFsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9lbmQtb3Blbi1yZXAtcmVmZXJyYWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQXVEO0FBQ3ZELHFFQUE0RTtBQUM1RSxxRUFBd0U7QUFXM0QsUUFBQSxzQkFBc0IsR0FBRyxJQUFBLDBCQUFVLEVBQzlDLHVCQUF1QixFQUN2QixLQUFLLEVBQUUsS0FBa0MsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDMUQsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUMzQyxFQUFFLHFCQUFxQixFQUFFLEtBQUssQ0FBQyxxQkFBcUIsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQ3JFLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUNaLENBQUE7SUFFRCxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDVixJQUFJLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNuQixNQUFNLElBQUksbUJBQVcsQ0FDbkIsbUJBQVcsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUMzQixhQUFhLEtBQUssQ0FBQyxxQkFBcUIsMEJBQTBCLENBQ25FLENBQUE7UUFDSCxDQUFDO1FBQ0QsT0FBTyxJQUFJLDRCQUFZLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFBO0lBQ3JDLENBQUM7SUFFRCxNQUFNLEtBQUssR0FBRyxNQUFNLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQztRQUM3QyxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7UUFDWCxPQUFPLEVBQUUsS0FBSyxDQUFDLFFBQVE7UUFDdkIsUUFBUSxFQUFFLEtBQUssQ0FBQyxRQUFRLElBQUksSUFBSTtLQUNqQyxDQUFDLENBQUE7SUFFRixPQUFPLElBQUksNEJBQVksQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQ3pDLENBQUMsRUFDRCxLQUFLLEVBQUUsVUFBVSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUNsQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDaEIsT0FBTTtJQUNSLENBQUM7SUFDRCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQztRQUMvQixFQUFFLEVBQUUsVUFBVTtRQUNkLE9BQU8sRUFBRSxJQUFJO1FBQ2IsUUFBUSxFQUFFLElBQUk7S0FDZixDQUFDLENBQUE7QUFDSixDQUFDLENBQ0YsQ0FBQSJ9