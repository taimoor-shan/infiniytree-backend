"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const sales_rep_1 = __importDefault(require("./sales-rep"));
/**
 * What one rep earned on one paid order, with the rate and net value
 * snapshotted. Voiding keeps the row and records the month of the void.
 */
const CommissionEntry = utils_1.model
    .define("commission_entry", {
    id: utils_1.model.id({ prefix: "sce" }).primaryKey(),
    type: utils_1.model.enum(["direct", "level2"]),
    order_id: utils_1.model.text(),
    order_display_id: utils_1.model.number(),
    order_created_at: utils_1.model.dateTime(),
    customer_id: utils_1.model.text(),
    client_name: utils_1.model.text(),
    source_sales_rep_id: utils_1.model.text().nullable(),
    client_assignment_id: utils_1.model.text(),
    rep_referral_id: utils_1.model.text().nullable(),
    currency_code: utils_1.model.text(),
    base_amount: utils_1.model.bigNumber(),
    rate: utils_1.model.bigNumber(),
    amount: utils_1.model.bigNumber(),
    payment_id: utils_1.model.text().nullable(),
    earned_at: utils_1.model.dateTime(),
    period: utils_1.model.text(),
    voided_at: utils_1.model.dateTime().nullable(),
    void_period: utils_1.model.text().nullable(),
    void_reason: utils_1.model.text().nullable(),
    sales_rep: utils_1.model.belongsTo(() => sales_rep_1.default, {
        mappedBy: "commission_entries",
    }),
})
    .indexes([
    { on: ["order_id", "type"], unique: true, where: "deleted_at IS NULL" },
    { on: ["period"] },
    { on: ["void_period"] },
    { on: ["customer_id"] },
]);
exports.default = CommissionEntry;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbWlzc2lvbi1lbnRyeS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL3NhbGVzLWNvbW1pc3Npb24vbW9kZWxzL2NvbW1pc3Npb24tZW50cnkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxxREFBaUQ7QUFDakQsNERBQWtDO0FBRWxDOzs7R0FHRztBQUNILE1BQU0sZUFBZSxHQUFHLGFBQUs7S0FDMUIsTUFBTSxDQUFDLGtCQUFrQixFQUFFO0lBQzFCLEVBQUUsRUFBRSxhQUFLLENBQUMsRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsVUFBVSxFQUFFO0lBQzVDLElBQUksRUFBRSxhQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO0lBQ3RDLFFBQVEsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBQ3RCLGdCQUFnQixFQUFFLGFBQUssQ0FBQyxNQUFNLEVBQUU7SUFDaEMsZ0JBQWdCLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRTtJQUNsQyxXQUFXLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUN6QixXQUFXLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtJQUN6QixtQkFBbUIsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQzVDLG9CQUFvQixFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDbEMsZUFBZSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDeEMsYUFBYSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDM0IsV0FBVyxFQUFFLGFBQUssQ0FBQyxTQUFTLEVBQUU7SUFDOUIsSUFBSSxFQUFFLGFBQUssQ0FBQyxTQUFTLEVBQUU7SUFDdkIsTUFBTSxFQUFFLGFBQUssQ0FBQyxTQUFTLEVBQUU7SUFDekIsVUFBVSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDbkMsU0FBUyxFQUFFLGFBQUssQ0FBQyxRQUFRLEVBQUU7SUFDM0IsTUFBTSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDcEIsU0FBUyxFQUFFLGFBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDdEMsV0FBVyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDcEMsV0FBVyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDcEMsU0FBUyxFQUFFLGFBQUssQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsbUJBQVEsRUFBRTtRQUN6QyxRQUFRLEVBQUUsb0JBQW9CO0tBQy9CLENBQUM7Q0FDSCxDQUFDO0tBQ0QsT0FBTyxDQUFDO0lBQ1AsRUFBRSxFQUFFLEVBQUUsQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsb0JBQW9CLEVBQUU7SUFDdkUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRTtJQUNsQixFQUFFLEVBQUUsRUFBRSxDQUFDLGFBQWEsQ0FBQyxFQUFFO0lBQ3ZCLEVBQUUsRUFBRSxFQUFFLENBQUMsYUFBYSxDQUFDLEVBQUU7Q0FDeEIsQ0FBQyxDQUFBO0FBRUosa0JBQWUsZUFBZSxDQUFBIn0=