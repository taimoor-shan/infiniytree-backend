"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.recordOrderCommissionWorkflow = void 0;
const core_flows_1 = require("@medusajs/medusa/core-flows");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const compute_order_commission_1 = require("./steps/compute-order-commission");
const create_commission_entries_1 = require("./steps/create-commission-entries");
/**
 * Records the commission a paid order earns. Safe to run any number of times:
 * an order is recorded once, and a per-order lock keeps the payment event and
 * the reconciliation job from racing.
 */
exports.recordOrderCommissionWorkflow = (0, workflows_sdk_1.createWorkflow)("record-order-commission", function (input) {
    const lockKey = (0, workflows_sdk_1.transform)({ input }, ({ input }) => `sales-commission:order:${input.order_id}`);
    (0, core_flows_1.acquireLockStep)({ key: lockKey, timeout: 30, ttl: 120 });
    const drafts = (0, compute_order_commission_1.computeOrderCommissionStep)(input);
    const entries = (0, create_commission_entries_1.createCommissionEntriesStep)(drafts);
    (0, core_flows_1.releaseLockStep)({ key: lockKey });
    return new workflows_sdk_1.WorkflowResponse(entries);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVjb3JkLW9yZGVyLWNvbW1pc3Npb24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL3JlY29yZC1vcmRlci1jb21taXNzaW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLDREQUdvQztBQUNwQyxxRUFJMEM7QUFDMUMsK0VBQTZFO0FBQzdFLGlGQUErRTtBQUkvRTs7OztHQUlHO0FBQ1UsUUFBQSw2QkFBNkIsR0FBRyxJQUFBLDhCQUFjLEVBQ3pELHlCQUF5QixFQUN6QixVQUFVLEtBQXlDO0lBQ2pELE1BQU0sT0FBTyxHQUFHLElBQUEseUJBQVMsRUFDdkIsRUFBRSxLQUFLLEVBQUUsRUFDVCxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxDQUFDLDBCQUEwQixLQUFLLENBQUMsUUFBUSxFQUFFLENBQzFELENBQUE7SUFDRCxJQUFBLDRCQUFlLEVBQUMsRUFBRSxHQUFHLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUE7SUFFeEQsTUFBTSxNQUFNLEdBQUcsSUFBQSxxREFBMEIsRUFBQyxLQUFLLENBQUMsQ0FBQTtJQUNoRCxNQUFNLE9BQU8sR0FBRyxJQUFBLHVEQUEyQixFQUFDLE1BQU0sQ0FBQyxDQUFBO0lBRW5ELElBQUEsNEJBQWUsRUFBQyxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFBO0lBRWpDLE9BQU8sSUFBSSxnQ0FBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQTtBQUN0QyxDQUFDLENBQ0YsQ0FBQSJ9