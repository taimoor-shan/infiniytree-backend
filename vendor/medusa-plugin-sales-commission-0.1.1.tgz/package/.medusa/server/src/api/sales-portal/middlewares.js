"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ensureActiveSalesRep = exports.portalRep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const sales_commission_1 = require("../../modules/sales-commission");
const portalRep = (req) => req.sales_rep;
exports.portalRep = portalRep;
/**
 * Runs after Medusa's `authenticate("sales_rep")`, which proves who the token
 * belongs to. This checks the rep may use the portal right now: they are
 * active and the login in the token is the one currently linked to them.
 * Ending a rep's access unlinks the login, so it stops working at once even
 * though the token itself is still valid.
 */
const ensureActiveSalesRep = async (req, _res, next) => {
    try {
        const { actor_id, auth_identity_id } = req
            .auth_context;
        const service = req.scope.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
        const [rep] = await service.listSalesReps({ id: actor_id }, { take: 1 });
        if (!rep ||
            !rep.is_active ||
            !rep.auth_identity_id ||
            rep.auth_identity_id !== auth_identity_id) {
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.FORBIDDEN, "You don't have access to the sales portal");
        }
        // Only what the portal may show
        ;
        req.sales_rep = {
            id: rep.id,
            name: rep.name,
            email: rep.email,
            phone: rep.phone ?? null,
        };
        next();
    }
    catch (error) {
        next(error);
    }
};
exports.ensureActiveSalesRep = ensureActiveSalesRep;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWlkZGxld2FyZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLXBvcnRhbC9taWRkbGV3YXJlcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFNQSxxREFBdUQ7QUFDdkQscUVBQXdFO0FBWWpFLE1BQU0sU0FBUyxHQUFHLENBQUMsR0FBa0IsRUFBYSxFQUFFLENBQ3hELEdBQXFCLENBQUMsU0FBUyxDQUFBO0FBRHJCLFFBQUEsU0FBUyxhQUNZO0FBRWxDOzs7Ozs7R0FNRztBQUNJLE1BQU0sb0JBQW9CLEdBQUcsS0FBSyxFQUN2QyxHQUFrQixFQUNsQixJQUFvQixFQUNwQixJQUF3QixFQUN4QixFQUFFO0lBQ0YsSUFBSSxDQUFDO1FBQ0gsTUFBTSxFQUFFLFFBQVEsRUFBRSxnQkFBZ0IsRUFBRSxHQUFJLEdBQWtDO2FBQ3ZFLFlBQVksQ0FBQTtRQUNmLE1BQU0sT0FBTyxHQUFpQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7UUFFRCxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxPQUFPLENBQUMsYUFBYSxDQUFDLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUE7UUFDeEUsSUFDRSxDQUFDLEdBQUc7WUFDSixDQUFDLEdBQUcsQ0FBQyxTQUFTO1lBQ2QsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCO1lBQ3JCLEdBQUcsQ0FBQyxnQkFBZ0IsS0FBSyxnQkFBZ0IsRUFDekMsQ0FBQztZQUNELE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQzNCLDJDQUEyQyxDQUM1QyxDQUFBO1FBQ0gsQ0FBQztRQUVELGdDQUFnQztRQUNoQyxDQUFDO1FBQUMsR0FBcUIsQ0FBQyxTQUFTLEdBQUc7WUFDbEMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxFQUFFO1lBQ1YsSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1lBQ2QsS0FBSyxFQUFFLEdBQUcsQ0FBQyxLQUFLO1lBQ2hCLEtBQUssRUFBRSxHQUFHLENBQUMsS0FBSyxJQUFJLElBQUk7U0FDekIsQ0FBQTtRQUNELElBQUksRUFBRSxDQUFBO0lBQ1IsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixJQUFJLENBQUMsS0FBSyxDQUFDLENBQUE7SUFDYixDQUFDO0FBQ0gsQ0FBQyxDQUFBO0FBcENZLFFBQUEsb0JBQW9CLHdCQW9DaEMifQ==