"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateRepReferralStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const referral_1 = require("../../lib/referral");
const sales_commission_1 = require("../../modules/sales-commission");
const invalid = (message) => new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, message);
exports.validateRepReferralStep = (0, workflows_sdk_1.createStep)("validate-rep-referral", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.retrieveSalesRep(input.referred_sales_rep_id);
    const referrer = await service.retrieveSalesRep(input.referrer_sales_rep_id);
    if (input.level2_rate < 0 || input.level2_rate > 100) {
        throw invalid("Level 2 rate must be between 0 and 100 percent");
    }
    const openReferrals = await service.listRepReferrals({ ends_at: null });
    const error = (0, referral_1.referralError)({
        referrerId: input.referrer_sales_rep_id,
        referredId: input.referred_sales_rep_id,
        openReferrals,
    });
    if (error === "self") {
        throw invalid("A sales rep can't refer themselves");
    }
    if (error === "cycle") {
        throw invalid("This referral would create a referral loop");
    }
    if (!referrer.is_active) {
        throw invalid(`Sales rep ${referrer.name} is inactive and can't earn new Level 2 commission`);
    }
    const current = openReferrals.find((referral) => referral.referred_sales_rep_id === input.referred_sales_rep_id);
    if (current &&
        current.referrer_sales_rep_id === input.referrer_sales_rep_id &&
        utils_1.MathBN.eq(current.level2_rate, input.level2_rate)) {
        throw invalid("This referral is already in place at this rate");
    }
    return new workflows_sdk_1.StepResponse(current ?? null);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdGUtcmVwLXJlZmVycmFsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy92YWxpZGF0ZS1yZXAtcmVmZXJyYWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQStEO0FBQy9ELHFFQUE0RTtBQUM1RSxpREFBa0Q7QUFDbEQscUVBQXdFO0FBU3hFLE1BQU0sT0FBTyxHQUFHLENBQUMsT0FBZSxFQUFFLEVBQUUsQ0FDbEMsSUFBSSxtQkFBVyxDQUFDLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQTtBQUU3QyxRQUFBLHVCQUF1QixHQUFHLElBQUEsMEJBQVUsRUFDL0MsdUJBQXVCLEVBQ3ZCLEtBQUssRUFBRSxLQUFtQyxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUMzRCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsQ0FBQTtJQUMzRCxNQUFNLFFBQVEsR0FBRyxNQUFNLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsQ0FBQTtJQUU1RSxJQUFJLEtBQUssQ0FBQyxXQUFXLEdBQUcsQ0FBQyxJQUFJLEtBQUssQ0FBQyxXQUFXLEdBQUcsR0FBRyxFQUFFLENBQUM7UUFDckQsTUFBTSxPQUFPLENBQUMsZ0RBQWdELENBQUMsQ0FBQTtJQUNqRSxDQUFDO0lBRUQsTUFBTSxhQUFhLEdBQUcsTUFBTSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtJQUN2RSxNQUFNLEtBQUssR0FBRyxJQUFBLHdCQUFhLEVBQUM7UUFDMUIsVUFBVSxFQUFFLEtBQUssQ0FBQyxxQkFBcUI7UUFDdkMsVUFBVSxFQUFFLEtBQUssQ0FBQyxxQkFBcUI7UUFDdkMsYUFBYTtLQUNkLENBQUMsQ0FBQTtJQUNGLElBQUksS0FBSyxLQUFLLE1BQU0sRUFBRSxDQUFDO1FBQ3JCLE1BQU0sT0FBTyxDQUFDLG9DQUFvQyxDQUFDLENBQUE7SUFDckQsQ0FBQztJQUNELElBQUksS0FBSyxLQUFLLE9BQU8sRUFBRSxDQUFDO1FBQ3RCLE1BQU0sT0FBTyxDQUFDLDRDQUE0QyxDQUFDLENBQUE7SUFDN0QsQ0FBQztJQUVELElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDeEIsTUFBTSxPQUFPLENBQ1gsYUFBYSxRQUFRLENBQUMsSUFBSSxvREFBb0QsQ0FDL0UsQ0FBQTtJQUNILENBQUM7SUFFRCxNQUFNLE9BQU8sR0FBRyxhQUFhLENBQUMsSUFBSSxDQUNoQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQ1gsUUFBUSxDQUFDLHFCQUFxQixLQUFLLEtBQUssQ0FBQyxxQkFBcUIsQ0FDakUsQ0FBQTtJQUNELElBQ0UsT0FBTztRQUNQLE9BQU8sQ0FBQyxxQkFBcUIsS0FBSyxLQUFLLENBQUMscUJBQXFCO1FBQzdELGNBQU0sQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVyxDQUFDLEVBQ2pELENBQUM7UUFDRCxNQUFNLE9BQU8sQ0FBQyxnREFBZ0QsQ0FBQyxDQUFBO0lBQ2pFLENBQUM7SUFFRCxPQUFPLElBQUksNEJBQVksQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUE7QUFDMUMsQ0FBQyxDQUNGLENBQUEifQ==