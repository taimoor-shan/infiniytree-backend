"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
exports.DELETE = DELETE;
const utils_1 = require("@medusajs/framework/utils");
const assign_client_1 = require("../../../../../workflows/assign-client");
const end_client_assignment_1 = require("../../../../../workflows/end-client-assignment");
const ASSIGNMENT_FIELDS = [
    "id",
    "customer_id",
    "commission_rate",
    "starts_at",
    "ends_at",
    "created_by",
    "ended_by",
    "source",
    "link_code",
    "created_at",
    "sales_rep.id",
    "sales_rep.name",
    "sales_rep.email",
    "sales_rep.is_active",
];
/** The customer's current salesperson and their full assignment history. */
async function GET(req, res) {
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { data: history } = await query.graph({
        entity: "client_assignment",
        fields: ASSIGNMENT_FIELDS,
        filters: { customer_id: req.params.id },
        pagination: { order: { starts_at: "DESC", created_at: "DESC" } },
    });
    res.json({
        current: history.find((assignment) => assignment.ends_at === null) ?? null,
        history,
    });
}
/** Assign, move to another rep, or change the rate. */
async function POST(req, res) {
    const { result } = await (0, assign_client_1.assignClientWorkflow)(req.scope).run({
        input: {
            ...req.validatedBody,
            customer_id: req.params.id,
            actor_id: req.auth_context.actor_id,
        },
    });
    res.json({ assignment: result });
}
/** End the current assignment; orders placed afterwards earn no commission. */
async function DELETE(req, res) {
    const { result } = await (0, end_client_assignment_1.endClientAssignmentWorkflow)(req.scope).run({
        input: {
            customer_id: req.params.id,
            actor_id: req.auth_context.actor_id,
        },
    });
    res.json({ assignment: result });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2N1c3RvbWVycy9baWRdL3NhbGVzLXJlcC1hc3NpZ25tZW50L3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBMkJBLGtCQWlCQztBQUdELG9CQWFDO0FBR0Qsd0JBWUM7QUF2RUQscURBQXFFO0FBQ3JFLDBFQUE2RTtBQUM3RSwwRkFBNEY7QUFHNUYsTUFBTSxpQkFBaUIsR0FBRztJQUN4QixJQUFJO0lBQ0osYUFBYTtJQUNiLGlCQUFpQjtJQUNqQixXQUFXO0lBQ1gsU0FBUztJQUNULFlBQVk7SUFDWixVQUFVO0lBQ1YsUUFBUTtJQUNSLFdBQVc7SUFDWCxZQUFZO0lBQ1osY0FBYztJQUNkLGdCQUFnQjtJQUNoQixpQkFBaUI7SUFDakIscUJBQXFCO0NBQ3RCLENBQUE7QUFFRCw0RUFBNEU7QUFDckUsS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBK0IsRUFDL0IsR0FBbUI7SUFFbkIsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUE7SUFFaEUsTUFBTSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDMUMsTUFBTSxFQUFFLG1CQUFtQjtRQUMzQixNQUFNLEVBQUUsaUJBQWlCO1FBQ3pCLE9BQU8sRUFBRSxFQUFFLFdBQVcsRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRTtRQUN2QyxVQUFVLEVBQUUsRUFBRSxLQUFLLEVBQUUsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsRUFBRTtLQUNqRSxDQUFDLENBQUE7SUFFRixHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ1AsT0FBTyxFQUFFLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEtBQUssSUFBSSxDQUFDLElBQUksSUFBSTtRQUMxRSxPQUFPO0tBQ1IsQ0FBQyxDQUFBO0FBQ0osQ0FBQztBQUVELHVEQUF1RDtBQUNoRCxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFzRCxFQUN0RCxHQUFtQjtJQUVuQixNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsTUFBTSxJQUFBLG9DQUFvQixFQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUM7UUFDM0QsS0FBSyxFQUFFO1lBQ0wsR0FBRyxHQUFHLENBQUMsYUFBYTtZQUNwQixXQUFXLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQzFCLFFBQVEsRUFBRSxHQUFHLENBQUMsWUFBWSxDQUFDLFFBQVE7U0FDcEM7S0FDRixDQUFDLENBQUE7SUFFRixHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUE7QUFDbEMsQ0FBQztBQUVELCtFQUErRTtBQUN4RSxLQUFLLFVBQVUsTUFBTSxDQUMxQixHQUErQixFQUMvQixHQUFtQjtJQUVuQixNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsTUFBTSxJQUFBLG1EQUEyQixFQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUM7UUFDbEUsS0FBSyxFQUFFO1lBQ0wsV0FBVyxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUMxQixRQUFRLEVBQUUsR0FBRyxDQUFDLFlBQVksQ0FBQyxRQUFRO1NBQ3BDO0tBQ0YsQ0FBQyxDQUFBO0lBRUYsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFBO0FBQ2xDLENBQUMifQ==