"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const approve_commission_periods_1 = require("../../../../workflows/approve-commission-periods");
const period_status_1 = require("../../../../utils/period-status");
/** Which months are approved, and which finished months still wait for it. */
async function GET(req, res) {
    res.json(await (0, period_status_1.loadPeriodStatus)(req.scope));
}
/** Approves every month up to and including `through`, making it payable. */
async function POST(req, res) {
    await (0, approve_commission_periods_1.approveCommissionPeriodsWorkflow)(req.scope).run({
        input: {
            through: req.validatedBody.through,
            approved_by: req.auth_context.actor_id,
        },
    });
    res.json(await (0, period_status_1.loadPeriodStatus)(req.scope));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLWNvbW1pc3Npb24vcGVyaW9kcy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVNBLGtCQUtDO0FBR0Qsb0JBWUM7QUF6QkQsaUdBQW1HO0FBQ25HLG1FQUFrRTtBQUdsRSw4RUFBOEU7QUFDdkUsS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBK0IsRUFDL0IsR0FBbUI7SUFFbkIsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUEsZ0NBQWdCLEVBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUE7QUFDN0MsQ0FBQztBQUVELDZFQUE2RTtBQUN0RSxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFrRSxFQUNsRSxHQUFtQjtJQUVuQixNQUFNLElBQUEsNkRBQWdDLEVBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUNwRCxLQUFLLEVBQUU7WUFDTCxPQUFPLEVBQUUsR0FBRyxDQUFDLGFBQWEsQ0FBQyxPQUFPO1lBQ2xDLFdBQVcsRUFBRSxHQUFHLENBQUMsWUFBWSxDQUFDLFFBQVE7U0FDdkM7S0FDRixDQUFDLENBQUE7SUFFRixHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBQSxnQ0FBZ0IsRUFBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQTtBQUM3QyxDQUFDIn0=