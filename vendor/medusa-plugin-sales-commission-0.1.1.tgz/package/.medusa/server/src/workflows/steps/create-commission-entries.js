"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCommissionEntriesStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const sales_commission_1 = require("../../modules/sales-commission");
exports.createCommissionEntriesStep = (0, workflows_sdk_1.createStep)("create-commission-entries", async (drafts, { container }) => {
    if (!drafts.length) {
        return new workflows_sdk_1.StepResponse([], []);
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const entries = await service.createCommissionEntries(drafts);
    return new workflows_sdk_1.StepResponse(entries, entries.map((entry) => entry.id));
}, async (entryIds, { container }) => {
    if (!entryIds?.length) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.deleteCommissionEntries(entryIds);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLWNvbW1pc3Npb24tZW50cmllcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3Mvc3RlcHMvY3JlYXRlLWNvbW1pc3Npb24tZW50cmllcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxRUFBNEU7QUFFNUUscUVBQXdFO0FBRzNELFFBQUEsMkJBQTJCLEdBQUcsSUFBQSwwQkFBVSxFQUNuRCwyQkFBMkIsRUFDM0IsS0FBSyxFQUFFLE1BQThCLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQ3RELElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDbkIsT0FBTyxJQUFJLDRCQUFZLENBQUMsRUFBRSxFQUFFLEVBQWMsQ0FBQyxDQUFBO0lBQzdDLENBQUM7SUFDRCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLE9BQU8sR0FBRyxNQUFNLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUU3RCxPQUFPLElBQUksNEJBQVksQ0FDckIsT0FBTyxFQUNQLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FDakMsQ0FBQTtBQUNILENBQUMsRUFDRCxLQUFLLEVBQUUsUUFBUSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUNoQyxJQUFJLENBQUMsUUFBUSxFQUFFLE1BQU0sRUFBRSxDQUFDO1FBQ3RCLE9BQU07SUFDUixDQUFDO0lBQ0QsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxPQUFPLENBQUMsdUJBQXVCLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDakQsQ0FBQyxDQUNGLENBQUEifQ==