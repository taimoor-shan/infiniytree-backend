"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = salesCommissionPaymentCaptured;
const orders_for_payments_1 = require("../utils/orders-for-payments");
const record_order_commission_1 = require("../workflows/record-order-commission");
/**
 * A captured payment is "payment received": Make.com captures the bank
 * transfer when Billingo sees it, or an admin clicks Capture.
 */
async function salesCommissionPaymentCaptured({ event: { data }, container, }) {
    const logger = container.resolve("logger");
    try {
        for (const orderId of await (0, orders_for_payments_1.orderIdsForPayments)(container, [data.id])) {
            const { result } = await (0, record_order_commission_1.recordOrderCommissionWorkflow)(container).run({
                input: { order_id: orderId },
            });
            if (result.length) {
                logger.info(`[sales-commission] Recorded ${result.length} commission entries for order ${orderId}`);
            }
        }
    }
    catch (error) {
        logger.error(`[sales-commission] Failed to record commission for payment ${data.id}: ${error.message}`);
    }
}
exports.config = {
    event: "payment.captured",
    context: { subscriberId: "sales-commission-payment-captured" },
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2FsZXMtY29tbWlzc2lvbi1wYXltZW50LWNhcHR1cmVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3N1YnNjcmliZXJzL3NhbGVzLWNvbW1pc3Npb24tcGF5bWVudC1jYXB0dXJlZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFRQSxpREFzQkM7QUE3QkQsc0VBQWtFO0FBQ2xFLGtGQUFvRjtBQUVwRjs7O0dBR0c7QUFDWSxLQUFLLFVBQVUsOEJBQThCLENBQUMsRUFDM0QsS0FBSyxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQ2YsU0FBUyxHQUNzQjtJQUMvQixNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBRTFDLElBQUksQ0FBQztRQUNILEtBQUssTUFBTSxPQUFPLElBQUksTUFBTSxJQUFBLHlDQUFtQixFQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFDdEUsTUFBTSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sSUFBQSx1REFBNkIsRUFBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLENBQUM7Z0JBQ3BFLEtBQUssRUFBRSxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUU7YUFDN0IsQ0FBQyxDQUFBO1lBQ0YsSUFBSSxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ2xCLE1BQU0sQ0FBQyxJQUFJLENBQ1QsK0JBQStCLE1BQU0sQ0FBQyxNQUFNLGlDQUFpQyxPQUFPLEVBQUUsQ0FDdkYsQ0FBQTtZQUNILENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixNQUFNLENBQUMsS0FBSyxDQUNWLDhEQUE4RCxJQUFJLENBQUMsRUFBRSxLQUFLLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FDMUYsQ0FBQTtJQUNILENBQUM7QUFDSCxDQUFDO0FBRVksUUFBQSxNQUFNLEdBQXFCO0lBQ3RDLEtBQUssRUFBRSxrQkFBa0I7SUFDekIsT0FBTyxFQUFFLEVBQUUsWUFBWSxFQUFFLG1DQUFtQyxFQUFFO0NBQy9ELENBQUEifQ==