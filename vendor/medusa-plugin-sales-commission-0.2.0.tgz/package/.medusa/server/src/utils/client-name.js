"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.orderClientName = void 0;
/** Company name, else the person's name, else the email. */
const orderClientName = (order) => order.customer?.company_name?.trim() ||
    [order.customer?.first_name, order.customer?.last_name]
        .filter(Boolean)
        .join(" ")
        .trim() ||
    order.customer?.email ||
    order.email ||
    "";
exports.orderClientName = orderClientName;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xpZW50LW5hbWUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvdXRpbHMvY2xpZW50LW5hbWUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsNERBQTREO0FBQ3JELE1BQU0sZUFBZSxHQUFHLENBQUMsS0FRL0IsRUFBVSxFQUFFLENBQ1gsS0FBSyxDQUFDLFFBQVEsRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFO0lBQ3BDLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxVQUFVLEVBQUUsS0FBSyxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUM7U0FDcEQsTUFBTSxDQUFDLE9BQU8sQ0FBQztTQUNmLElBQUksQ0FBQyxHQUFHLENBQUM7U0FDVCxJQUFJLEVBQUU7SUFDVCxLQUFLLENBQUMsUUFBUSxFQUFFLEtBQUs7SUFDckIsS0FBSyxDQUFDLEtBQUs7SUFDWCxFQUFFLENBQUE7QUFoQlMsUUFBQSxlQUFlLG1CQWdCeEIifQ==