"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createRepInviteWorkflow = exports.inviteSentEvent = void 0;
const core_flows_1 = require("@medusajs/medusa/core-flows");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const events_1 = require("../events");
const create_rep_invite_1 = require("./steps/create-rep-invite");
/** What the candidate's email needs, from a step that made or renewed an invite. */
const inviteSentEvent = (sent) => ({
    invite_id: sent.invite.id,
    email: sent.invite.email,
    name: sent.invite.name,
    token: sent.token,
    expires_at: new Date(sent.invite.expires_at).toISOString(),
    recruiter_name: sent.recruiter_name,
    locale: sent.invite.locale,
});
exports.inviteSentEvent = inviteSentEvent;
/**
 * A rep invites someone to join. The candidate is emailed a personal link;
 * nothing is created for them until they apply and the owner approves. The
 * link token is in the event only, never in the result.
 */
exports.createRepInviteWorkflow = (0, workflows_sdk_1.createWorkflow)("create-rep-invite", function (input) {
    const sent = (0, create_rep_invite_1.createRepInviteStep)(input);
    (0, core_flows_1.emitEventStep)({
        eventName: events_1.SalesCommissionEvents.INVITE_SENT,
        data: (0, workflows_sdk_1.transform)({ sent }, ({ sent }) => (0, exports.inviteSentEvent)(sent)),
    });
    return new workflows_sdk_1.WorkflowResponse((0, workflows_sdk_1.transform)({ sent }, ({ sent }) => sent.invite));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLXJlcC1pbnZpdGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL2NyZWF0ZS1yZXAtaW52aXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLDREQUEyRDtBQUMzRCxxRUFJMEM7QUFDMUMsc0NBQWtFO0FBQ2xFLGlFQUdrQztBQUVsQyxvRkFBb0Y7QUFDN0UsTUFBTSxlQUFlLEdBQUcsQ0FBQyxJQVUvQixFQUFtQixFQUFFLENBQUMsQ0FBQztJQUN0QixTQUFTLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO0lBQ3pCLEtBQUssRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7SUFDeEIsSUFBSSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSTtJQUN0QixLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7SUFDakIsVUFBVSxFQUFFLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsV0FBVyxFQUFFO0lBQzFELGNBQWMsRUFBRSxJQUFJLENBQUMsY0FBYztJQUNuQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNO0NBQzNCLENBQUMsQ0FBQTtBQWxCVyxRQUFBLGVBQWUsbUJBa0IxQjtBQUVGOzs7O0dBSUc7QUFDVSxRQUFBLHVCQUF1QixHQUFHLElBQUEsOEJBQWMsRUFDbkQsbUJBQW1CLEVBQ25CLFVBQVUsS0FBK0I7SUFDdkMsTUFBTSxJQUFJLEdBQUcsSUFBQSx1Q0FBbUIsRUFBQyxLQUFLLENBQUMsQ0FBQTtJQUV2QyxJQUFBLDBCQUFhLEVBQUM7UUFDWixTQUFTLEVBQUUsOEJBQXFCLENBQUMsV0FBVztRQUM1QyxJQUFJLEVBQUUsSUFBQSx5QkFBUyxFQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsQ0FBQyxJQUFBLHVCQUFlLEVBQUMsSUFBSSxDQUFDLENBQUM7S0FDL0QsQ0FBQyxDQUFBO0lBRUYsT0FBTyxJQUFJLGdDQUFnQixDQUFDLElBQUEseUJBQVMsRUFBQyxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUE7QUFDN0UsQ0FBQyxDQUNGLENBQUEifQ==