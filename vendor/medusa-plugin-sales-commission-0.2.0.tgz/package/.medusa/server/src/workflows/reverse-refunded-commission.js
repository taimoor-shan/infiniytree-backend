"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reverseRefundedCommissionWorkflow = void 0;
const core_flows_1 = require("@medusajs/medusa/core-flows");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const refund_1 = require("../lib/refund");
const reverse_partial_refund_1 = require("./steps/reverse-partial-refund");
/**
 * Takes back commission in proportion to what an order has refunded so far.
 * Does nothing for an order that is canceled or refunded in full: those void
 * the commission instead.
 */
exports.reverseRefundedCommissionWorkflow = (0, workflows_sdk_1.createWorkflow)("reverse-refunded-commission", function (input) {
    const { data: orders } = (0, core_flows_1.useQueryGraphStep)({
        entity: "order",
        fields: [
            "id",
            "status",
            "canceled_at",
            "payment_collections.payments.captures.amount",
            "payment_collections.payments.refunds.amount",
        ],
        filters: { id: input.order_id },
    });
    const share = (0, workflows_sdk_1.transform)({ orders }, ({ orders }) => {
        const order = orders[0];
        if (!order || order.canceled_at || order.status === "canceled") {
            return 0;
        }
        const payments = (order.payment_collections ?? []).flatMap((collection) => collection?.payments ?? []);
        return (0, refund_1.isFullyRefunded)(payments) ? 0 : (0, refund_1.refundedShare)(payments);
    });
    const reversed = (0, workflows_sdk_1.when)({ share }, ({ share }) => share > 0).then(() => (0, reverse_partial_refund_1.reversePartialRefundStep)((0, workflows_sdk_1.transform)({ input, share }, ({ input, share }) => ({
        order_id: input.order_id,
        share,
    }))));
    return new workflows_sdk_1.WorkflowResponse(reversed);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmV2ZXJzZS1yZWZ1bmRlZC1jb21taXNzaW9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9yZXZlcnNlLXJlZnVuZGVkLWNvbW1pc3Npb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsNERBQStEO0FBQy9ELHFFQUswQztBQUMxQywwQ0FBOEQ7QUFDOUQsMkVBQXlFO0FBTXpFOzs7O0dBSUc7QUFDVSxRQUFBLGlDQUFpQyxHQUFHLElBQUEsOEJBQWMsRUFDN0QsNkJBQTZCLEVBQzdCLFVBQVUsS0FBNkM7SUFDckQsTUFBTSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFBLDhCQUFpQixFQUFDO1FBQ3pDLE1BQU0sRUFBRSxPQUFPO1FBQ2YsTUFBTSxFQUFFO1lBQ04sSUFBSTtZQUNKLFFBQVE7WUFDUixhQUFhO1lBQ2IsOENBQThDO1lBQzlDLDZDQUE2QztTQUM5QztRQUNELE9BQU8sRUFBRSxFQUFFLEVBQUUsRUFBRSxLQUFLLENBQUMsUUFBUSxFQUFFO0tBQ2hDLENBQUMsQ0FBQTtJQUVGLE1BQU0sS0FBSyxHQUFHLElBQUEseUJBQVMsRUFBQyxFQUFFLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFO1FBQ2pELE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUN2QixJQUFJLENBQUMsS0FBSyxJQUFJLEtBQUssQ0FBQyxXQUFXLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxVQUFVLEVBQUUsQ0FBQztZQUMvRCxPQUFPLENBQUMsQ0FBQTtRQUNWLENBQUM7UUFDRCxNQUFNLFFBQVEsR0FBRyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsSUFBSSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQ3hELENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQyxVQUFVLEVBQUUsUUFBUSxJQUFJLEVBQUUsQ0FDbEMsQ0FBQTtRQUVWLE9BQU8sSUFBQSx3QkFBZSxFQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUEsc0JBQWEsRUFBQyxRQUFRLENBQUMsQ0FBQTtJQUNoRSxDQUFDLENBQUMsQ0FBQTtJQUVGLE1BQU0sUUFBUSxHQUFHLElBQUEsb0JBQUksRUFBQyxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FDbkUsSUFBQSxpREFBd0IsRUFDdEIsSUFBQSx5QkFBUyxFQUFDLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDakQsUUFBUSxFQUFFLEtBQUssQ0FBQyxRQUFRO1FBQ3hCLEtBQUs7S0FDTixDQUFDLENBQUMsQ0FDSixDQUNGLENBQUE7SUFFRCxPQUFPLElBQUksZ0NBQWdCLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDdkMsQ0FBQyxDQUNGLENBQUEifQ==