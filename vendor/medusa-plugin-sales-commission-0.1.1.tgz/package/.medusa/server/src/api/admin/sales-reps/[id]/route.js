"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const utils_1 = require("@medusajs/framework/utils");
const update_sales_rep_1 = require("../../../../workflows/update-sales-rep");
const query_config_1 = require("../query-config");
const REFERRAL_FIELDS = [
    "id",
    "referrer_sales_rep_id",
    "referred_sales_rep_id",
    "level2_rate",
    "starts_at",
    "ends_at",
    "created_by",
];
/**
 * The rep, whether they have portal access (`portal`), who referred them
 * (`referral`, with the Level 2 rate the referrer earns on this rep's clients)
 * and the reps they referred (`referred_reps`).
 */
async function GET(req, res) {
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const id = req.params.id;
    const { data: [salesRepWithLogin], } = await query.graph({
        entity: "sales_rep",
        fields: [...query_config_1.SALES_REP_FIELDS, "auth_identity_id"],
        filters: { id },
    });
    if (!salesRepWithLogin) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, `Sales rep ${id} was not found`);
    }
    // Which login belongs to the rep stays inside the plugin
    const { auth_identity_id, ...salesRep } = salesRepWithLogin;
    const [{ data: upline }, { data: downline }] = await Promise.all([
        query.graph({
            entity: "rep_referral",
            fields: REFERRAL_FIELDS,
            filters: { referred_sales_rep_id: id, ends_at: null },
        }),
        query.graph({
            entity: "rep_referral",
            fields: REFERRAL_FIELDS,
            filters: { referrer_sales_rep_id: id, ends_at: null },
        }),
    ]);
    const relatedIds = [
        ...upline.map((r) => r.referrer_sales_rep_id),
        ...downline.map((r) => r.referred_sales_rep_id),
    ];
    const { data: relatedReps } = relatedIds.length
        ? await query.graph({
            entity: "sales_rep",
            fields: ["id", "name", "email", "is_active"],
            filters: { id: relatedIds },
        })
        : { data: [] };
    const repById = new Map(relatedReps.map((rep) => [rep.id, rep]));
    res.json({
        sales_rep: salesRep,
        portal: { status: auth_identity_id ? "active" : "none" },
        referral: upline[0]
            ? { ...upline[0], referrer: repById.get(upline[0].referrer_sales_rep_id) }
            : null,
        referred_reps: downline.map((referral) => ({
            ...referral,
            referred: repById.get(referral.referred_sales_rep_id),
        })),
    });
}
async function POST(req, res) {
    const { result } = await (0, update_sales_rep_1.updateSalesRepWorkflow)(req.scope).run({
        input: { id: req.params.id, ...req.validatedBody },
    });
    res.json({ sales_rep: result });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLXJlcHMvW2lkXS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQTJCQSxrQkE2REM7QUFFRCxvQkFTQztBQS9GRCxxREFHa0M7QUFDbEMsNkVBQStFO0FBQy9FLGtEQUFrRDtBQUdsRCxNQUFNLGVBQWUsR0FBRztJQUN0QixJQUFJO0lBQ0osdUJBQXVCO0lBQ3ZCLHVCQUF1QjtJQUN2QixhQUFhO0lBQ2IsV0FBVztJQUNYLFNBQVM7SUFDVCxZQUFZO0NBQ2IsQ0FBQTtBQUVEOzs7O0dBSUc7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUErQixFQUMvQixHQUFtQjtJQUVuQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxpQ0FBeUIsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUNoRSxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQTtJQUV4QixNQUFNLEVBQ0osSUFBSSxFQUFFLENBQUMsaUJBQWlCLENBQUMsR0FDMUIsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDcEIsTUFBTSxFQUFFLFdBQVc7UUFDbkIsTUFBTSxFQUFFLENBQUMsR0FBRywrQkFBZ0IsRUFBRSxrQkFBa0IsQ0FBQztRQUNqRCxPQUFPLEVBQUUsRUFBRSxFQUFFLEVBQUU7S0FDaEIsQ0FBQyxDQUFBO0lBRUYsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDdkIsTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFDM0IsYUFBYSxFQUFFLGdCQUFnQixDQUNoQyxDQUFBO0lBQ0gsQ0FBQztJQUNELHlEQUF5RDtJQUN6RCxNQUFNLEVBQUUsZ0JBQWdCLEVBQUUsR0FBRyxRQUFRLEVBQUUsR0FBRyxpQkFBaUIsQ0FBQTtJQUUzRCxNQUFNLENBQUMsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7UUFDL0QsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUNWLE1BQU0sRUFBRSxjQUFjO1lBQ3RCLE1BQU0sRUFBRSxlQUFlO1lBQ3ZCLE9BQU8sRUFBRSxFQUFFLHFCQUFxQixFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFO1NBQ3RELENBQUM7UUFDRixLQUFLLENBQUMsS0FBSyxDQUFDO1lBQ1YsTUFBTSxFQUFFLGNBQWM7WUFDdEIsTUFBTSxFQUFFLGVBQWU7WUFDdkIsT0FBTyxFQUFFLEVBQUUscUJBQXFCLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUU7U0FDdEQsQ0FBQztLQUNILENBQUMsQ0FBQTtJQUVGLE1BQU0sVUFBVSxHQUFHO1FBQ2pCLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDO1FBQzdDLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDO0tBQ2hELENBQUE7SUFDRCxNQUFNLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxHQUFHLFVBQVUsQ0FBQyxNQUFNO1FBQzdDLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7WUFDaEIsTUFBTSxFQUFFLFdBQVc7WUFDbkIsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsV0FBVyxDQUFDO1lBQzVDLE9BQU8sRUFBRSxFQUFFLEVBQUUsRUFBRSxVQUFVLEVBQUU7U0FDNUIsQ0FBQztRQUNKLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsQ0FBQTtJQUNoQixNQUFNLE9BQU8sR0FBRyxJQUFJLEdBQUcsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBRWhFLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDUCxTQUFTLEVBQUUsUUFBUTtRQUNuQixNQUFNLEVBQUUsRUFBRSxNQUFNLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFO1FBQ3hELFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ2pCLENBQUMsQ0FBQyxFQUFFLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFO1lBQzFFLENBQUMsQ0FBQyxJQUFJO1FBQ1IsYUFBYSxFQUFFLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDekMsR0FBRyxRQUFRO1lBQ1gsUUFBUSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLHFCQUFxQixDQUFDO1NBQ3RELENBQUMsQ0FBQztLQUNKLENBQUMsQ0FBQTtBQUNKLENBQUM7QUFFTSxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUF3RCxFQUN4RCxHQUFtQjtJQUVuQixNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsTUFBTSxJQUFBLHlDQUFzQixFQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUM7UUFDN0QsS0FBSyxFQUFFLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLEdBQUcsR0FBRyxDQUFDLGFBQWEsRUFBRTtLQUNuRCxDQUFDLENBQUE7SUFFRixHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUE7QUFDakMsQ0FBQyJ9