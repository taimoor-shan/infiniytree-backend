"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const client_links_1 = require("../../../utils/client-links");
const middlewares_1 = require("../middlewares");
/**
 * The rep's client link: the code to share, whether it is switched on, and how
 * far each client who came through it has got. The code is made the first time
 * a rep asks. `?locale=` tells us the language their portal shows, so the
 * emails about their clients arrive in it.
 */
async function GET(req, res) {
    const locale = typeof req.query.locale === "string" ? req.query.locale : null;
    res.json({
        client_link: await (0, client_links_1.loadPortalClientLink)(req.scope, (0, middlewares_1.portalRep)(req).id, { locale }),
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLXBvcnRhbC9jbGllbnQtbGluay9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVVBLGtCQU1DO0FBZkQsOERBQWtFO0FBQ2xFLGdEQUEwQztBQUUxQzs7Ozs7R0FLRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUMvRCxNQUFNLE1BQU0sR0FBRyxPQUFPLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQTtJQUU3RSxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ1AsV0FBVyxFQUFFLE1BQU0sSUFBQSxtQ0FBb0IsRUFBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUEsdUJBQVMsRUFBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUUsQ0FBQztLQUNsRixDQUFDLENBQUE7QUFDSixDQUFDIn0=