"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const customer_1 = __importDefault(require("@medusajs/medusa/customer"));
const utils_1 = require("@medusajs/framework/utils");
const sales_commission_1 = __importDefault(require("../modules/sales-commission"));
/** client_assignment.customer: the client behind an assignment (read-only). */
exports.default = (0, utils_1.defineLink)({
    linkable: sales_commission_1.default.linkable.clientAssignment,
    field: "customer_id",
}, customer_1.default.linkable.customer, { readOnly: true });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xpZW50LWFzc2lnbm1lbnQtY3VzdG9tZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvbGlua3MvY2xpZW50LWFzc2lnbm1lbnQtY3VzdG9tZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSx5RUFBc0Q7QUFDdEQscURBQXNEO0FBQ3RELG1GQUErRDtBQUUvRCwrRUFBK0U7QUFDL0Usa0JBQWUsSUFBQSxrQkFBVSxFQUN2QjtJQUNFLFFBQVEsRUFBRSwwQkFBcUIsQ0FBQyxRQUFRLENBQUMsZ0JBQWdCO0lBQ3pELEtBQUssRUFBRSxhQUFhO0NBQ3JCLEVBQ0Qsa0JBQWMsQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUNoQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsQ0FDbkIsQ0FBQSJ9