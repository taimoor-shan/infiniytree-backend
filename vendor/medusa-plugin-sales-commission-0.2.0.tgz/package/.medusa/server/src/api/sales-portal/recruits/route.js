"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const create_rep_invite_1 = require("../../../workflows/create-rep-invite");
const recruits_1 = require("../../../utils/recruits");
const middlewares_1 = require("../middlewares");
/**
 * The reps this rep invited, how far along each is, and what Level 2 earns
 * from each. Never the recruits' clients.
 */
async function GET(req, res) {
    res.json(await (0, recruits_1.loadPortalRecruits)(req.scope, (0, middlewares_1.portalRep)(req).id));
}
/**
 * Invites someone by email. They are emailed a personal link to apply; the
 * owner approves before anything starts. The link itself is never returned
 * here: it goes only to the candidate, who is the one to accept the terms.
 */
async function POST(req, res) {
    const recruiter = (0, middlewares_1.portalRep)(req);
    const { result } = await (0, create_rep_invite_1.createRepInviteWorkflow)(req.scope).run({
        input: { ...req.validatedBody, recruiter_sales_rep_id: recruiter.id },
    });
    const { recruits, limits } = await (0, recruits_1.loadPortalRecruits)(req.scope, recruiter.id);
    res.status(201).json({
        recruit: recruits.find((recruit) => recruit.id === result.id),
        limits,
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLXBvcnRhbC9yZWNydWl0cy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVVBLGtCQUVDO0FBT0Qsb0JBZ0JDO0FBbENELDRFQUE4RTtBQUM5RSxzREFBNEQ7QUFDNUQsZ0RBQTBDO0FBRzFDOzs7R0FHRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUMvRCxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBQSw2QkFBa0IsRUFBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUEsdUJBQVMsRUFBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFBO0FBQ2xFLENBQUM7QUFFRDs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBMkMsRUFDM0MsR0FBbUI7SUFFbkIsTUFBTSxTQUFTLEdBQUcsSUFBQSx1QkFBUyxFQUFDLEdBQUcsQ0FBQyxDQUFBO0lBRWhDLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLElBQUEsMkNBQXVCLEVBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUM5RCxLQUFLLEVBQUUsRUFBRSxHQUFHLEdBQUcsQ0FBQyxhQUFhLEVBQUUsc0JBQXNCLEVBQUUsU0FBUyxDQUFDLEVBQUUsRUFBRTtLQUN0RSxDQUFDLENBQUE7SUFFRixNQUFNLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sSUFBQSw2QkFBa0IsRUFBQyxHQUFHLENBQUMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUU5RSxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUNuQixPQUFPLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUUsS0FBSyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQzdELE1BQU07S0FDUCxDQUFDLENBQUE7QUFDSixDQUFDIn0=