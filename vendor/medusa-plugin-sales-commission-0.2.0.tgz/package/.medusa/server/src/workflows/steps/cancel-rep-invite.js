"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cancelRepInviteStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const recruiting_errors_1 = require("../../lib/recruiting-errors");
const sales_commission_1 = require("../../modules/sales-commission");
/**
 * Withdraws an invite nobody has answered, so its link stops working. Only the
 * rep who invited can. Once the candidate has applied it is the owner's call.
 */
exports.cancelRepInviteStep = (0, workflows_sdk_1.createStep)("cancel-rep-invite", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const [invite] = await service.listRepInvites({ id: input.invite_id, recruiter_sales_rep_id: input.recruiter_sales_rep_id }, { take: 1 });
    if (!invite) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, "Invitation not found");
    }
    if (invite.status !== "invited") {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, invite.status === "applied"
            ? "This person has already applied, so the owner decides now"
            : "Only an invitation that hasn't been answered can be canceled", invite.status === "applied" ? recruiting_errors_1.RECRUITING_ERRORS.INVITE_APPLIED : recruiting_errors_1.RECRUITING_ERRORS.INVITE_NOT_PENDING);
    }
    const canceled = await service.updateRepInvites({
        id: invite.id,
        status: "canceled",
        decided_by: input.recruiter_sales_rep_id,
        decided_at: new Date(),
        decision_reason: "Canceled by the recruiter",
    });
    return new workflows_sdk_1.StepResponse(canceled, invite.id);
}, async (inviteId, { container }) => {
    if (!inviteId) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.updateRepInvites({
        id: inviteId,
        status: "invited",
        decided_by: null,
        decided_at: null,
        decision_reason: null,
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FuY2VsLXJlcC1pbnZpdGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL3N0ZXBzL2NhbmNlbC1yZXAtaW52aXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFEQUF1RDtBQUN2RCxxRUFBNEU7QUFDNUUsbUVBQXdFO0FBQ3hFLHFFQUF3RTtBQUd4RTs7O0dBR0c7QUFDVSxRQUFBLG1CQUFtQixHQUFHLElBQUEsMEJBQVUsRUFDM0MsbUJBQW1CLEVBQ25CLEtBQUssRUFDSCxLQUE0RCxFQUM1RCxFQUFFLFNBQVMsRUFBRSxFQUNiLEVBQUU7SUFDRixNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFFRCxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsTUFBTSxPQUFPLENBQUMsY0FBYyxDQUMzQyxFQUFFLEVBQUUsRUFBRSxLQUFLLENBQUMsU0FBUyxFQUFFLHNCQUFzQixFQUFFLEtBQUssQ0FBQyxzQkFBc0IsRUFBRSxFQUM3RSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FDWixDQUFBO0lBQ0QsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ1osTUFBTSxJQUFJLG1CQUFXLENBQUMsbUJBQVcsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLHNCQUFzQixDQUFDLENBQUE7SUFDNUUsQ0FBQztJQUNELElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUNoQyxNQUFNLElBQUksbUJBQVcsQ0FDbkIsbUJBQVcsQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUM5QixNQUFNLENBQUMsTUFBTSxLQUFLLFNBQVM7WUFDekIsQ0FBQyxDQUFDLDJEQUEyRDtZQUM3RCxDQUFDLENBQUMsOERBQThELEVBQ2xFLE1BQU0sQ0FBQyxNQUFNLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxxQ0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMscUNBQUssQ0FBQyxrQkFBa0IsQ0FDOUUsQ0FBQTtJQUNILENBQUM7SUFFRCxNQUFNLFFBQVEsR0FBRyxNQUFNLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQztRQUM5QyxFQUFFLEVBQUUsTUFBTSxDQUFDLEVBQUU7UUFDYixNQUFNLEVBQUUsVUFBVTtRQUNsQixVQUFVLEVBQUUsS0FBSyxDQUFDLHNCQUFzQjtRQUN4QyxVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUU7UUFDdEIsZUFBZSxFQUFFLDJCQUEyQjtLQUM3QyxDQUFDLENBQUE7SUFFRixPQUFPLElBQUksNEJBQVksQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQzlDLENBQUMsRUFDRCxLQUFLLEVBQUUsUUFBUSxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUNoQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDZCxPQUFNO0lBQ1IsQ0FBQztJQUNELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUFDO1FBQzdCLEVBQUUsRUFBRSxRQUFRO1FBQ1osTUFBTSxFQUFFLFNBQVM7UUFDakIsVUFBVSxFQUFFLElBQUk7UUFDaEIsVUFBVSxFQUFFLElBQUk7UUFDaEIsZUFBZSxFQUFFLElBQUk7S0FDdEIsQ0FBQyxDQUFBO0FBQ0osQ0FBQyxDQUNGLENBQUEifQ==