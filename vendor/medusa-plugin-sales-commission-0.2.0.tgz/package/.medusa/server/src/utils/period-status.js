"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadPeriodStatus = exports.firstActivityPeriod = void 0;
const approval_1 = require("../lib/approval");
const period_1 = require("../lib/period");
const sales_commission_1 = require("../modules/sales-commission");
/** The earliest month with any commission, adjustment or payout, or null. */
const firstActivityPeriod = async (service) => {
    const earliest = { select: ["period"], order: { period: "ASC" }, take: 1 };
    const periods = (await Promise.all([
        service.listCommissionEntries({}, earliest),
        service.listCommissionAdjustments({}, earliest),
        service.listCommissionPayouts({}, earliest),
    ]))
        .flat()
        .map((row) => row.period)
        .sort();
    return periods[0] ?? null;
};
exports.firstActivityPeriod = firstActivityPeriod;
const loadPeriodStatus = async (container) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const approvals = (await service.listPeriodApprovals({}, { select: ["period", "approved_at", "approved_by"], order: { period: "ASC" } })).map((row) => ({
        period: row.period,
        approved_at: row.approved_at,
        approved_by: row.approved_by ?? null,
    }));
    const approvedThrough = (0, approval_1.latestApproved)(approvals.map((row) => row.period));
    const currentPeriod = (0, period_1.toPeriod)(new Date(), service.getOptions().timezone);
    const from = approvedThrough
        ? (0, period_1.nextPeriod)(approvedThrough)
        : await (0, exports.firstActivityPeriod)(service);
    return {
        approved_through: approvedThrough,
        approvals,
        current_period: currentPeriod,
        closed_unapproved: from
            ? (0, period_1.periodsBetween)(from, (0, period_1.previousPeriod)(currentPeriod))
            : [],
    };
};
exports.loadPeriodStatus = loadPeriodStatus;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGVyaW9kLXN0YXR1cy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy91dGlscy9wZXJpb2Qtc3RhdHVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUNBLDhDQUFnRDtBQUNoRCwwQ0FBb0Y7QUFDcEYsa0VBQXFFO0FBR3JFLDZFQUE2RTtBQUN0RSxNQUFNLG1CQUFtQixHQUFHLEtBQUssRUFDdEMsT0FBcUMsRUFDYixFQUFFO0lBQzFCLE1BQU0sUUFBUSxHQUFHLEVBQUUsTUFBTSxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQTtJQUMxRSxNQUFNLE9BQU8sR0FBRyxDQUNkLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUNoQixPQUFPLENBQUMscUJBQXFCLENBQUMsRUFBRSxFQUFFLFFBQVEsQ0FBQztRQUMzQyxPQUFPLENBQUMseUJBQXlCLENBQUMsRUFBRSxFQUFFLFFBQVEsQ0FBQztRQUMvQyxPQUFPLENBQUMscUJBQXFCLENBQUMsRUFBRSxFQUFFLFFBQVEsQ0FBQztLQUM1QyxDQUFDLENBQ0g7U0FDRSxJQUFJLEVBQUU7U0FDTixHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxNQUFnQixDQUFDO1NBQ2xDLElBQUksRUFBRSxDQUFBO0lBRVQsT0FBTyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFBO0FBQzNCLENBQUMsQ0FBQTtBQWhCWSxRQUFBLG1CQUFtQix1QkFnQi9CO0FBWU0sTUFBTSxnQkFBZ0IsR0FBRyxLQUFLLEVBQ25DLFNBQTBCLEVBQ0gsRUFBRTtJQUN6QixNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLFNBQVMsR0FBRyxDQUNoQixNQUFNLE9BQU8sQ0FBQyxtQkFBbUIsQ0FDL0IsRUFBRSxFQUNGLEVBQUUsTUFBTSxFQUFFLENBQUMsUUFBUSxFQUFFLGFBQWEsRUFBRSxhQUFhLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FDL0UsQ0FDRixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsTUFBTTtRQUNsQixXQUFXLEVBQUUsR0FBRyxDQUFDLFdBQVc7UUFDNUIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxXQUFXLElBQUksSUFBSTtLQUNyQyxDQUFDLENBQUMsQ0FBQTtJQUNILE1BQU0sZUFBZSxHQUFHLElBQUEseUJBQWMsRUFBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQTtJQUMxRSxNQUFNLGFBQWEsR0FBRyxJQUFBLGlCQUFRLEVBQUMsSUFBSSxJQUFJLEVBQUUsRUFBRSxPQUFPLENBQUMsVUFBVSxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUE7SUFFekUsTUFBTSxJQUFJLEdBQUcsZUFBZTtRQUMxQixDQUFDLENBQUMsSUFBQSxtQkFBVSxFQUFDLGVBQWUsQ0FBQztRQUM3QixDQUFDLENBQUMsTUFBTSxJQUFBLDJCQUFtQixFQUFDLE9BQU8sQ0FBQyxDQUFBO0lBRXRDLE9BQU87UUFDTCxnQkFBZ0IsRUFBRSxlQUFlO1FBQ2pDLFNBQVM7UUFDVCxjQUFjLEVBQUUsYUFBYTtRQUM3QixpQkFBaUIsRUFBRSxJQUFJO1lBQ3JCLENBQUMsQ0FBQyxJQUFBLHVCQUFjLEVBQUMsSUFBSSxFQUFFLElBQUEsdUJBQWMsRUFBQyxhQUFhLENBQUMsQ0FBQztZQUNyRCxDQUFDLENBQUMsRUFBRTtLQUNQLENBQUE7QUFDSCxDQUFDLENBQUE7QUEvQlksUUFBQSxnQkFBZ0Isb0JBK0I1QiJ9