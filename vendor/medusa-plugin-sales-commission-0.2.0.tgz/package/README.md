# medusa-plugin-sales-commission

Sales commission for the Infinytree shop (Medusa v2, pinned to **2.18.0**).

Every B2B client is permanently assigned to a salesperson at a per-client rate. Each paid order earns that salesperson a commission. A salesperson who brought in another salesperson also earns a Level 2 share on top. Salespeople invite recruits themselves and the owner approves each one. The owner approves finished months, pays what is owed in one payment run, and every rep has one running balance that carries over from month to month.

Spec: the approved *Infinytree Sales Commission System — Proposal*, reworked after a review of how affiliate and commission systems run in practice (balance per payee, payment run, locked exchange rates, proportional refunds, invite links).

## Rules

| Topic | Rule |
|---|---|
| Base | Net product value: `item_total − item_tax_total`. No VAT, no shipping, after discounts. Orders with a base of zero or less earn nothing |
| When | Once **all** of the order's payments are captured. Counts in the month of the (latest) capture, in the plugin's `timezone` |
| Who and rate | The assignment in effect when the order was **placed** (`starts_at ≤ order.created_at < ends_at`). The rate is copied onto the entry and never recalculated |
| Assignments | Changing the rep or rate ends the open assignment and starts a new one at the same instant. One open assignment per customer. History is kept. A rep can't be assigned their own customer account (the same email) |
| Effective date | Every change (assigning, moving, changing a rate, ending, setting or ending a referral) takes effect from the **start of that day in Budapest**, so an order placed earlier the same day counts for the new rep or rate. Days before keep what they had |
| Level 2 | The referrer of the credited rep earns `net value × level2 rate` on top, with a rate per rep-to-rep relationship. One level only; self-referral and loops are rejected. A referral can **expire**: orders placed at or after its `expires_at` earn the referrer nothing, orders placed before still do, however late they are paid |
| Currency | An order is in EUR or HUF. A rep has a **payout currency** (EUR, HUF, or none). With one, commission earned in the other currency is converted **once, when it is earned**, at the ECB reference rate of that day (the last published one if it is at most 5 days old, otherwise a rate an admin entered). The rate is stored on the entry, so a reversal takes back exactly what was credited. Without a payout currency each currency has its own balance. Nothing is ever converted afterwards |
| Balance | One running balance per rep and currency across all months: everything earned (reversals and adjustments included) minus everything paid. A month's statement shows what was owed at its start and at its end, so nothing falls out between months |
| Approval | The owner approves finished months ("approve through September"), forward only. The current month can't be approved. An approval can be undone while it is the latest and no payout has been recorded since. What a rep earned in an approved month is **payable**; a month's statement never changes after it |
| Payable | Approved earnings minus everything paid, never below zero. A payout beyond it is an advance (**to recover**), netted from what the rep earns next, or it is recorded as a **bonus** with a reason |
| Payouts | Recorded by hand or in a payment run: date, amount, currency, reference. A month is `paid`, `partial`, `unpaid` or `overpaid`. A short payout leaves the rest due. Each payout keeps what was payable when it was made. A payout recorded by mistake can be removed (soft delete), with its bonus |
| Payment run | One row per rep and currency with what is payable, pre-filled. Amounts below the optional `minimum_payout` roll over to the next run. The run records all payouts together, or none |
| Pending | What the unpaid orders (placed in the last 21 days) of a rep's clients would earn if paid now. Shown to the rep, never part of a balance, and it can still change |
| Voids | Order canceled, or fully refunded without being canceled. A void in the month the commission was earned removes it; a later void shows as a **negative reversal in the month of the void**, so past months never change |
| Partial refunds | The refunded share of what the order captured is taken back from every entry in proportion, direct and Level 2, with an adjustment in the **current month** (a commission already paid is netted against the next payout). Each refund adds only the difference to what earlier ones took, so repeating it changes nothing. If the order is later canceled or refunded in full, the void gives back what the partial refunds took first |
| Adjustments | Signed, non-zero, reason required, record who made them, only in an open month. Append-only: add a reversing one to undo. Partial refunds and bonuses are adjustments with a `kind` |
| Recruiting | A rep with portal access invites someone by email. The candidate applies from a personal link; the owner approves or declines. See [Recruiting](#recruiting) |
| Contracts | PDF, JPEG or PNG up to 10 MB, stored in the database and returned only by an admin-only download route (`file-local` serves "private" uploads from a public folder, so the file module is not used) |

## How a payment reaches the plugin

```
Billingo: payment received
  → Make.com scenario
  → POST /admin/payments/{payment_id}/capture        (secret API key)
  → Medusa emits payment.captured
  → recordOrderCommission workflow → CommissionEntry (direct, + Level 2), converted to the rep's payout currency

order.canceled                       → voidOrderCommission workflow
payment.refunded (in full)           → voidOrderCommission workflow
payment.refunded (a part)            → reverseRefundedCommission workflow (adjustments)
daily at 02:15 → reconcile-commissions job re-runs all of it for the last 7 days
weekdays at 17:00 → fetch-sales-commission-fx-rates job stores the ECB's euro-forint rate
```

Everything is idempotent: an order is recorded once (unique per order and entry type, plus a per-order lock), and a refund adds only the difference to what earlier refunds took, under the same lock, so the event, the job and a manual re-run can't double-count. The job covers events lost to a restart and payments captured without an event (such as Stripe auto-capture, if enabled later). A commission that needs a rate nobody has published yet isn't recorded; the nightly job records it once there is one.

### Make.com scenario

1. In Medusa admin, Settings → Secret API Keys, create a key named `Make.com Billingo`. Send it as `Authorization: Basic {token}` (a Bearer header returns 401).
2. When Billingo reports the payment, look up the order: `GET /admin/orders/{order_id}?fields=id,payment_collections.payments.id,payment_collections.payments.captured_at`.
3. For each payment where `captured_at` is null: `POST /admin/payments/{payment_id}/capture`.
4. To cancel unpaid orders after the 5-day window: `POST /admin/orders/{order_id}/cancel`. This fires `order.canceled` to Make.com and to the plugin.

## Install

The backend installs the plugin from a tarball committed in its own repo (`vendor/medusa-plugin-sales-commission-<version>.tgz`, about 200 kB), so `yarn install` on the server needs no registry and no token.

Register it in `medusa-config.ts`:

```ts
plugins: [
  {
    resolve: "medusa-plugin-sales-commission",
    options: {
      timezone: "Europe/Budapest",              // default; decides which month a payment counts in
      portal_url: process.env.SALES_PORTAL_URL, // where reps sign in, e.g. https://shop.example/sales-portal
    },
  },
],
```

All options are optional:

| Option | Default | What it does |
|---|---|---|
| `timezone` | `Europe/Budapest` | Which month a payment counts in; when a day starts |
| `portal_url` | – | Where reps sign in, without a country code. Password and invite links are built from it |
| `fx_auto_fetch` | `true` | Fetch the ECB's euro-forint rate on working days. `false` leaves rates to be entered by hand |
| `minimum_payout` | none | Smallest amount worth paying, per lowercase currency code, e.g. `{ eur: 50, huf: 20000 }`. Smaller payable amounts roll over to the next payment run |
| `payout_day` | – | The day of the month (1 to 28) the owner usually pays; reps see it as "next run" |
| `invite_days` | `14` | How long an invite link works |
| `max_open_invites` | `20` | How many invitations one rep can have waiting at once |
| `level2_default_rate` | `2` | The Level 2 percent the approval form starts with |
| `level2_default_months` | `24` | The months Level 2 lasts, from approval, that the form starts with; `0` means until the owner ends it |

Create its tables once per database, and again after a release that adds a migration. In production run it from the build, next to where the server starts:

```bash
npx medusa db:migrate           # production: cd .medusa/server && npx medusa db:migrate
```

### Releasing a new version

A version tag does the release. Once your change is committed in the plugin repo:

```bash
npm version patch                       # bumps package.json, commits it and tags v<version>
git push origin master --follow-tags
```

The **Release to backend** workflow (`.github/workflows/release-to-backend.yml`) then runs the unit tests, builds the plugin, packs it into `infiniytree-backend/vendor/` and opens a pull request in the backend that changes only `package.json`, `yarn.lock` and `vendor/`. The pull request says whether the release needs `db:migrate`. Merge it and deploy the backend as usual: pull, `yarn install`, `yarn build`, migrate if the pull request says so, restart. If two release pull requests are open at once, merge the newer one and close the older one: both replace the same tarball.

**One-time setup.** The workflow needs a token that can push to the backend repo, which the workflow's own token can't.

1. GitHub, Settings, Developer settings, Personal access tokens, Fine-grained tokens, Generate new token. Resource owner `taimoor-shan`, repository access *Only select repositories* with `infiniytree-backend`, permissions *Contents* and *Pull requests* both *Read and write*. Pick an expiry and note it: after that date the workflow fails with an authentication error until the token is replaced.
2. Store it as a secret of this repo. Run this in your terminal and paste the token when asked (it isn't shown). It first asks GitHub whether the token is accepted and stores it only if so, so a mistyped, truncated or wrong value can't end up in the secret:

```bash
printf 'Paste the token, then Enter: '; read -rs T; echo; if [ "$(curl -s -o /dev/null -w '%{http_code}' -H "Authorization: Bearer $T" https://api.github.com/repos/taimoor-shan/infiniytree-backend)" = 200 ]; then printf %s "$T" | gh secret set BACKEND_REPO_TOKEN --repo taimoor-shan/medusa-plugin-sales-commission; else echo "GitHub rejected that token, nothing stored"; fi; unset T
```

**Dry run.** Actions, Release to backend, Run workflow (a dry run is the default), or:

```bash
gh workflow run release-to-backend.yml --repo taimoor-shan/medusa-plugin-sales-commission -f dry_run=true
```

It builds and vendors, prints the diff and the pull request text and checks that the token can push, but pushes nothing and opens nothing. Run it after the setup and after any change to the workflow.

If a run stops at **Check the backend token**, GitHub is rejecting the stored token: a wrong value was pasted, or it expired or was revoked. Create a new one and store it again as above, then re-run the failed run (`gh run rerun <run-id> --failed`). A re-run uses the secret as it is at that moment, so the tag doesn't need to change.

**Without GitHub Actions.** The local release still works:

```bash
npm version patch --no-git-tag-version    # a release needs a new version
npm run release:backend                   # builds, packs into ../infiniytree-backend/vendor/ and points the backend at it
```

Then commit `package.json`, `yarn.lock` and `vendor/` in the backend, tag the plugin (`git tag v<version> && git push --tags`) and deploy as above.

### Developing against the backend

Run `npx medusa plugin:develop` here: it rebuilds on change and pushes into the backend through yalc. The backend needs `yalc` as a devDependency and a one-time `npx medusa plugin:add medusa-plugin-sales-commission`. yalc swaps the backend's dependency for `file:.yalc/...` while you work, so before committing in the backend run `npx yalc retreat medusa-plugin-sales-commission`: it puts the vendored tarball back in `package.json`.

After a rebuild the admin can keep showing the old UI, from two caches: Vite's dependency cache in the backend and the browser's copy of it (Vite serves it as immutable). Stop the dev server, delete `node_modules/.vite` in the backend, start it, then hard-reload the admin tab (Cmd/Ctrl+Shift+R).

## Admin API

All routes are under `/admin` and need an admin session or API key.

| Route | Purpose |
|---|---|
| `GET, POST /admin/sales-reps` | List (search `q`, filter `is_active`) and create (with an optional `payout_currency_code`) |
| `GET, POST /admin/sales-reps/:id` | Rep with their referrer (`referral`, with its `expires_at`) and the reps they referred; update, including `is_active` and the payout currency |
| `GET, POST /admin/sales-reps/:id/contracts` | List and upload (JSON, base64) |
| `GET /admin/sales-reps/:id/contracts/:contract_id/download` | Download a contract |
| `POST, DELETE /admin/sales-reps/:id/referral` | Set or replace the referrer and Level 2 rate; end it |
| `POST, DELETE /admin/sales-reps/:id/portal-access` | Give or end portal access |
| `GET /admin/sales-reps/:id/clients` | The rep's clients, current and past |
| `GET, POST, DELETE /admin/customers/:id/sales-rep-assignment` | Current assignment and history; assign, move or change the rate; end |
| `GET, POST /admin/sales-reps/:id/adjustments` | List and add an adjustment (open months only) |
| `GET, POST /admin/sales-reps/:id/payouts` | List and record a payout; `bonus_reason` records an overpayment as a bonus |
| `DELETE /admin/sales-commission/payouts/:id` | Remove a payout recorded by mistake |
| `GET /admin/sales-reps/:id/balance` | What the rep is owed per currency: earned, paid, payable, earned but not yet payable, to recover, paid this year, pending |
| `GET /admin/sales-reps/:id/statement?period=YYYY-MM[&format=csv]` | A rep's month: lines with the running balance, what was owed at its start and end |
| `GET /admin/sales-commission/report?period=YYYY-MM[&format=csv]` | Every rep's month per currency |
| `GET /admin/sales-commission/balances` | Every rep's balance per currency |
| `GET, POST /admin/sales-commission/periods` | Which months are approved and which are waiting; approve every month up to `through` |
| `DELETE /admin/sales-commission/periods/latest` | Undo the latest approval (not once a payout was recorded after it) |
| `GET, POST /admin/sales-commission/payment-run` | Who is owed what now, per rep and currency; record several payouts at once |
| `GET, POST /admin/sales-commission/fx-rates` | The latest euro-forint rates; add one for a day that has none |
| `GET /admin/sales-commission/applications?status=` | Applications waiting for the owner (or `approved`, `declined`, `invited`, `canceled`, `all`), with counts per status |
| `GET /admin/sales-commission/applications/:id` | One application, the terms the approval form starts with, and anything that would stop an approval |
| `POST /admin/sales-commission/applications/:id/approve` | Approve: creates the rep, links the recruiter, gives portal access, emails a link to set a password. All or nothing |
| `POST /admin/sales-commission/applications/:id/decline` | Decline, with a reason only the owner sees |

`period` defaults to the current month. CSV is RFC 4180 with CRLF line endings and a UTF-8 BOM so Excel shows accents correctly. Numbers use a dot as the decimal separator, so in Hungarian Excel use Data → From Text and pick "." as the decimal separator. Text starting with `= + - @` is prefixed with `'` so a client name can't run as a formula.

The module's data is also reachable through the query graph: `customer.client_assignment` (read-only link, no link table).

## Admin UI

- **Sales Reps** (sidebar): list with what each rep is owed, create, and a detail page with profile, balance (pending, payable now, not yet payable, paid this year, to recover), monthly statement (running balance, adjustments, payouts, CSV), referral with its end date, clients and contracts.
- **Payment run** (under Sales Reps): approve finished months, see who is owed what, pay one or all in one go (amounts pre-filled, CSV for the bank), plus the euro-forint rates.
- **Applications** (under Sales Reps): what recruits have applied, and a review screen to approve with the Level 2 terms and the payout currency, upload the signed contract, or decline.
- **Commission report** (under Sales Reps): all reps for a month, with CSV export.
- **Sales rep widget** on the customer page: assign, change or end, with history.

The admin UI is in English; the backend's admin has no translations configured.

## Recruiting

```
rep invites by email ──▶ candidate opens their personal link ──▶ applies ──▶ owner reviews
                                                                              │
                              approve: rep created, recruiter linked, portal access, welcome email
                              decline: candidate and recruiter told, without the reason
```

- **Invite.** A rep with portal access sends one from the portal (`POST /sales-portal/recruits`). An invite is not a rep: nothing is paid and nobody gets access until the owner approves. One email has one open invite at a time, the first one wins; an invite whose link ran out no longer blocks it. Resending gives a new link and ends the old one (not within a minute of the last send); the rep can also withdraw an invite nobody has answered. Each rep can have at most `max_open_invites` waiting.
- **The link** carries 256 random bits. Only its hash is stored, and the plugin never returns it: it travels in the `sales-commission.invite.sent` event to the candidate's email, so the recruiter can't apply in the candidate's name. It works for `invite_days`, once. The page behind it is public (`GET /sales-invites/:token`, `POST /sales-invites/:token/apply`); an unknown, mistyped or withdrawn link all answer the same 404. The email in the application is the invite's and can't be changed.
- **Approve** (`POST /admin/sales-commission/applications/:id/approve`) is one workflow: create the rep, link the recruiter as referrer from today at the Level 2 rate and duration the owner chose (the form starts from `level2_default_rate` and `level2_default_months`), give the rep a portal login, optionally keep the signed contract, mark the application approved and create a **welcome link** to set a first password. If any step fails, all of it is undone and the application stays waiting. An inactive recruiter, an email that already belongs to a rep, or a login linked to a customer account stop it with a plain message (the detail route lists them beforehand).
- **The welcome link** is a Medusa reset-password token for the new rep: the same page and route set the password and consume it once, but it is good for 7 days instead of 15 minutes, since the rep may open the email days later. After that, "Forgot password" gives a new one.
- **Recruiters see** each recruit's name, how far along they are, and the Level 2 they earn from them (this month and in total, with the rate and when it ends). Never the recruit's clients, phone, company or the owner's reason for declining.

### Events

The plugin emits these so the shop can send the emails; the backend subscribers render them (`src/subscribers/sales-*.ts`). Those with a `token` carry a secret link token, so the backend renders the email itself and keeps the token out of the notification log, and nothing should log the event.

| Event | Sent when | Data |
|---|---|---|
| `sales-commission.invite.sent` | An invite is sent or sent again | `invite_id`, `email`, `name`, `token`, `expires_at`, `recruiter_name`, `locale` |
| `sales-commission.application.received` | A candidate applies | `invite_id`, `applicant_name`, `email`, `phone`, `company`, `requested_currency_code`, `recruiter_name`, `locale` |
| `sales-commission.application.approved` | The owner approves | `invite_id`, `sales_rep_id`, `name`, `email`, `token`, `recruiter {name, email}`, `level2_rate`, `level2_until`, `locale` |
| `sales-commission.application.declined` | The owner declines | `invite_id`, `name`, `email`, `recruiter {name, email}`, `locale` (the reason is not in it) |

`locale` is the language the recruiter's portal was in ("en", "de-AT", "de-DE", "hu-HU"), so everything about one invitation reaches the people in that language. The errors of the invite and application flow carry a stable `code` (see `src/lib/recruiting-errors.ts`) that the storefront turns into a sentence in the visitor's language.

## Sales portal

Reps sign in with Medusa's own auth as the `sales_rep` actor type. The plugin adds no login or register routes of its own; the only public routes are the candidate's invite page above.

**Giving access.** Admin → Sales Reps → rep → Sales portal → Give access. This creates the rep's login with the auth module and links it to them. The admin passes on the portal's forgot-password link; the rep enters their email, follows Medusa's reset email, sets a password and signs in with `POST /auth/sales_rep/emailpass`. Reset links last 15 minutes (fixed in Medusa) and are only issued when the rep asks for one. A rep who joined through an application gets a welcome email instead (see [Recruiting](#recruiting)).

- An email whose login is linked to a customer account (or to any other account) is **refused**. A login linked to nothing is taken over: that is what Medusa leaves behind when a customer is deleted (it keeps the login and only unlinks the customer), or a registration that was never finished. Its old password is replaced with a random one first, because Medusa's public register routes accept unverified emails and whoever set that password must not get into the rep's portal; the rep sets their own with forgot-password. A login that belongs to an admin user is reused, and a rep keeps their own login after access is ended and granted again.
- **Ending access** unlinks the login. Every portal request checks that link, so a token that is still valid stops working at once. A deactivated rep is turned away too.
- The password-reset email is sent by the backend's existing `auth.password_reset` subscriber, which links reps to `/sales-portal/reset-password`.

**Where reps sign in.** The plugin ships no screens for reps. The Infinytree storefront serves them at `/<country>/sales-portal` (sign-in form and overview on the same page, plus `forgot-password`, `reset-password`, client, payout and recruit pages, and the candidate's `join/<token>` page), calling the API below from its server. `portal_url` is that address *without* a country code, which the storefront's proxy adds. The Portal access drawer and the reset email are built from it: `<portal_url>/forgot-password?email=…`, `<portal_url>/reset-password?token=…`, and `<portal_url>/login` (which the storefront sends on to the portal's own page); the invite email links to `<portal_url>/join/<token>?lang=<locale>`.

**API.** The portal routes need `Authorization: Bearer <token>` from a rep who currently has access. They are meant to be called from the storefront's server, so no CORS headers are added. Only the recruit routes change anything.

| Route | Returns |
|---|---|
| `GET /sales-portal/me` | name, email, phone (no internal notes) |
| `GET /sales-portal/balance` | per currency: earned, paid, payable, earned but not yet payable, paid ahead, paid this year; what unpaid orders would earn (`pending`); the day the owner usually pays next (`next_run`) |
| `GET /sales-portal/summary?period=YYYY-MM` | the month's totals per currency |
| `GET /sales-portal/statement?period=YYYY-MM` | the month's lines (each with status and running balance, and the conversion when the order was in another currency), totals with what was owed at the start and end, and `pending` lines for unpaid orders |
| `GET /sales-portal/clients?period=YYYY-MM` | the rep's clients by company name, rate, since when, and the month's turnover and commission per currency |
| `GET /sales-portal/clients/:customer_id/orders` | a client's paid orders: number, date, net value, currency, rate, commission, status (paged) |
| `GET /sales-portal/statements` | every month with activity, newest first, with totals (paged) |
| `GET /sales-portal/payouts` | date, month, amount, currency, reference |
| `GET, POST /sales-portal/recruits` | the rep's invitations and recruits with their status and Level 2; send an invitation |
| `POST /sales-portal/recruits/:id/resend`, `DELETE /sales-portal/recruits/:id` | send an unanswered invitation again with a new link; withdraw it |

What a rep never gets: addresses, emails of clients, order contents, internal ids or admin notes. Responses are built field by field from named values, never by passing a database row through. A direct commission shows the order number and client; Level 2 is summed per referred rep and shows neither their clients nor their orders. A client that isn't (or wasn't) the rep's own returns the same 404 as one that doesn't exist. Adjustment reasons and payout references are shown to the rep; the reason of a partial refund names the order only on the rep's own commission.

## Development

```bash
npm run test:unit                                   # pure rules: money, months, commission, balances, payment runs, refunds, invites, report, CSV
DB_HOST=localhost DB_USERNAME=<pg user> npm run test:integration:modules   # models and DB constraints

npx medusa plugin:db:generate                       # after changing models (needs DB_* in .env)
```

End-to-end behaviour (API, workflows, subscribers, jobs) is covered by the backend's `integration-tests/http/sales-commission-*.spec.ts`, which exercise the plugin through the real app and pay orders with `markPaymentCollectionAsPaid`, the same capture path Make.com uses. The backend loads its own `.env` when tests run, so `integration-tests/setup.js` blanks the keys of live services (the Make.com webhook, Resend, SendGrid) before the app starts; keep it that way, or a test that cancels an order posts to the real scenario.

Layout: `src/modules/sales-commission` (data models, service, migrations), `src/lib` (pure functions), `src/workflows`, `src/subscribers`, `src/jobs`, `src/api/admin`, `src/api/sales-portal`, `src/api/sales-invites`, `src/links`, `src/admin`, `src/events.ts` (the event names and payloads).
