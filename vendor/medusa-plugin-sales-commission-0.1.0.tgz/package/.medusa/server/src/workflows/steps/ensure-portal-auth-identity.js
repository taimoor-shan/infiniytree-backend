"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ensurePortalAuthIdentityStep = void 0;
const crypto_1 = require("crypto");
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const PROVIDER = "emailpass";
/**
 * The login (Medusa auth identity) for a rep's email, created through the auth
 * module's own `register` with a random password nobody sees: the rep sets
 * their first password with Medusa's forgot-password flow, which proves they
 * own the mailbox.
 *
 * An existing login is only reused when it belongs to an admin user or was
 * already linked to this rep. Anyone can register a login for any email
 * through Medusa's public register routes without proving they own it, so any
 * other existing login could have been set up by someone else.
 */
exports.ensurePortalAuthIdentityStep = (0, workflows_sdk_1.createStep)("ensure-portal-auth-identity", async ({ email, sales_rep_id }, { container }) => {
    const auth = container.resolve(utils_1.Modules.AUTH);
    const [existing] = await auth.listAuthIdentities({ provider_identities: { provider: PROVIDER, entity_id: email } }, { take: 1 });
    if (existing) {
        const linkedRepId = existing.app_metadata?.sales_rep_id;
        if (linkedRepId && linkedRepId !== sales_rep_id) {
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, `The login for ${email} already belongs to another sales rep`);
        }
        if (!linkedRepId && !existing.app_metadata?.user_id) {
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, `${email} already has a login on the shop (a customer account or an earlier registration), so it can't be linked automatically. Use a different email for the rep`);
        }
        return new workflows_sdk_1.StepResponse({ auth_identity_id: existing.id, already_linked: !!linkedRepId }, { id: existing.id, created: false });
    }
    const { success, authIdentity, error } = await auth.register(PROVIDER, {
        url: "",
        headers: {},
        query: {},
        protocol: "",
        body: { email, password: (0, crypto_1.randomBytes)(32).toString("base64url") },
    });
    if (!success || !authIdentity) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, error ?? `Could not create a login for ${email}`);
    }
    return new workflows_sdk_1.StepResponse({ auth_identity_id: authIdentity.id, already_linked: false }, { id: authIdentity.id, created: true });
}, async (prior, { container }) => {
    if (!prior?.created) {
        return;
    }
    await container.resolve(utils_1.Modules.AUTH).deleteAuthIdentities([prior.id]);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW5zdXJlLXBvcnRhbC1hdXRoLWlkZW50aXR5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9lbnN1cmUtcG9ydGFsLWF1dGgtaWRlbnRpdHkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsbUNBQW9DO0FBQ3BDLHFEQUFnRTtBQUNoRSxxRUFBNEU7QUFFNUUsTUFBTSxRQUFRLEdBQUcsV0FBVyxDQUFBO0FBRTVCOzs7Ozs7Ozs7O0dBVUc7QUFDVSxRQUFBLDRCQUE0QixHQUFHLElBQUEsMEJBQVUsRUFDcEQsNkJBQTZCLEVBQzdCLEtBQUssRUFDSCxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQTJDLEVBQ2hFLEVBQUUsU0FBUyxFQUFFLEVBQ2IsRUFBRTtJQUNGLE1BQU0sSUFBSSxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLElBQUksQ0FBQyxDQUFBO0lBRTVDLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxNQUFNLElBQUksQ0FBQyxrQkFBa0IsQ0FDOUMsRUFBRSxtQkFBbUIsRUFBRSxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQ2pFLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUNaLENBQUE7SUFDRCxJQUFJLFFBQVEsRUFBRSxDQUFDO1FBQ2IsTUFBTSxXQUFXLEdBQUcsUUFBUSxDQUFDLFlBQVksRUFBRSxZQUFZLENBQUE7UUFDdkQsSUFBSSxXQUFXLElBQUksV0FBVyxLQUFLLFlBQVksRUFBRSxDQUFDO1lBQ2hELE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQzlCLGlCQUFpQixLQUFLLHVDQUF1QyxDQUM5RCxDQUFBO1FBQ0gsQ0FBQztRQUNELElBQUksQ0FBQyxXQUFXLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxFQUFFLE9BQU8sRUFBRSxDQUFDO1lBQ3BELE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQzlCLEdBQUcsS0FBSywwSkFBMEosQ0FDbkssQ0FBQTtRQUNILENBQUM7UUFFRCxPQUFPLElBQUksNEJBQVksQ0FDckIsRUFBRSxnQkFBZ0IsRUFBRSxRQUFRLENBQUMsRUFBRSxFQUFFLGNBQWMsRUFBRSxDQUFDLENBQUMsV0FBVyxFQUFFLEVBQ2hFLEVBQUUsRUFBRSxFQUFFLFFBQVEsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxDQUNwQyxDQUFBO0lBQ0gsQ0FBQztJQUVELE1BQU0sRUFBRSxPQUFPLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7UUFDckUsR0FBRyxFQUFFLEVBQUU7UUFDUCxPQUFPLEVBQUUsRUFBRTtRQUNYLEtBQUssRUFBRSxFQUFFO1FBQ1QsUUFBUSxFQUFFLEVBQUU7UUFDWixJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLElBQUEsb0JBQVcsRUFBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLEVBQUU7S0FDakUsQ0FBQyxDQUFBO0lBQ0YsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQzlCLE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQzlCLEtBQUssSUFBSSxnQ0FBZ0MsS0FBSyxFQUFFLENBQ2pELENBQUE7SUFDSCxDQUFDO0lBRUQsT0FBTyxJQUFJLDRCQUFZLENBQ3JCLEVBQUUsZ0JBQWdCLEVBQUUsWUFBWSxDQUFDLEVBQUUsRUFBRSxjQUFjLEVBQUUsS0FBSyxFQUFFLEVBQzVELEVBQUUsRUFBRSxFQUFFLFlBQVksQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxDQUN2QyxDQUFBO0FBQ0gsQ0FBQyxFQUNELEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQzdCLElBQUksQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLENBQUM7UUFDcEIsT0FBTTtJQUNSLENBQUM7SUFDRCxNQUFNLFNBQVMsQ0FBQyxPQUFPLENBQUMsZUFBTyxDQUFDLElBQUksQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUE7QUFDeEUsQ0FBQyxDQUNGLENBQUEifQ==