"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplyToInvite = void 0;
const zod_1 = require("@medusajs/framework/zod");
/** The currencies a rep can ask to be paid in */
const payoutCurrency = zod_1.z
    .string()
    .transform((code) => code.toLowerCase())
    .pipe(zod_1.z.enum(["eur", "huf"]));
/** What a candidate fills in on their invite page. The email is the invite's, never theirs to change. */
exports.ApplyToInvite = zod_1.z.object({
    name: zod_1.z.string().trim().min(2).max(120),
    phone: zod_1.z.string().trim().max(40).nullish(),
    company: zod_1.z.string().trim().max(160).nullish(),
    requested_currency_code: payoutCurrency.nullish(),
    accept_terms: zod_1.z.literal(true, { error: "You need to accept the terms to apply" }),
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdG9ycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9hcGkvc2FsZXMtaW52aXRlcy92YWxpZGF0b3JzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLGlEQUEyQztBQUUzQyxpREFBaUQ7QUFDakQsTUFBTSxjQUFjLEdBQUcsT0FBQztLQUNyQixNQUFNLEVBQUU7S0FDUixTQUFTLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztLQUN2QyxJQUFJLENBQUMsT0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFFL0IseUdBQXlHO0FBQzVGLFFBQUEsYUFBYSxHQUFHLE9BQUMsQ0FBQyxNQUFNLENBQUM7SUFDcEMsSUFBSSxFQUFFLE9BQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUN2QyxLQUFLLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLEVBQUU7SUFDMUMsT0FBTyxFQUFFLE9BQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFO0lBQzdDLHVCQUF1QixFQUFFLGNBQWMsQ0FBQyxPQUFPLEVBQUU7SUFDakQsWUFBWSxFQUFFLE9BQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLHVDQUF1QyxFQUFFLENBQUM7Q0FDbEYsQ0FBQyxDQUFBIn0=