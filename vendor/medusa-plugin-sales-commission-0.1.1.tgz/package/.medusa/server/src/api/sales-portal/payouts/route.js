"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const helpers_1 = require("../helpers");
const middlewares_1 = require("../middlewares");
/** The rep's payout history: date, amount, currency, reference. */
async function GET(req, res) {
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { data: payouts } = await query.graph({
        entity: "commission_payout",
        fields: ["period", "paid_at", "amount", "currency_code", "reference"],
        filters: { sales_rep_id: (0, middlewares_1.portalRep)(req).id },
        pagination: { order: { paid_at: "DESC" } },
    });
    res.json({
        payouts: payouts.map((payout) => ({
            paid_at: payout.paid_at,
            period: payout.period,
            amount: (0, helpers_1.toNumber)(payout.amount),
            currency_code: payout.currency_code,
            reference: payout.reference ?? null,
        })),
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLXBvcnRhbC9wYXlvdXRzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBTUEsa0JBbUJDO0FBeEJELHFEQUFxRTtBQUNyRSx3Q0FBcUM7QUFDckMsZ0RBQTBDO0FBRTFDLG1FQUFtRTtBQUM1RCxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUE7SUFFaEUsTUFBTSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDMUMsTUFBTSxFQUFFLG1CQUFtQjtRQUMzQixNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxlQUFlLEVBQUUsV0FBVyxDQUFDO1FBQ3JFLE9BQU8sRUFBRSxFQUFFLFlBQVksRUFBRSxJQUFBLHVCQUFTLEVBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxFQUFFO1FBQzVDLFVBQVUsRUFBRSxFQUFFLEtBQUssRUFBRSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtLQUMzQyxDQUFDLENBQUE7SUFFRixHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ1AsT0FBTyxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDaEMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO1lBQ3ZCLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtZQUNyQixNQUFNLEVBQUUsSUFBQSxrQkFBUSxFQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7WUFDL0IsYUFBYSxFQUFFLE1BQU0sQ0FBQyxhQUFhO1lBQ25DLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUyxJQUFJLElBQUk7U0FDcEMsQ0FBQyxDQUFDO0tBQ0osQ0FBQyxDQUFBO0FBQ0osQ0FBQyJ9