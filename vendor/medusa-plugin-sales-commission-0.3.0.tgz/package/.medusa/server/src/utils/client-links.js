"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadAdminClientLink = exports.loadPortalClientLink = exports.claimClientLink = exports.ensureClientLinkCode = exports.makeClientLinkCode = exports.CLIENT_LINK_METADATA_KEY = void 0;
const utils_1 = require("@medusajs/framework/utils");
const events_1 = require("../events");
const client_link_1 = require("../lib/client-link");
const sales_commission_1 = require("../modules/sales-commission");
const assign_client_1 = require("../workflows/assign-client");
const client_name_1 = require("./client-name");
const invites_1 = require("./invites");
const locks_1 = require("./locks");
/** The key in a customer's metadata where the storefront puts the code the client followed */
exports.CLIENT_LINK_METADATA_KEY = "sales_rep_ref";
const rateOf = (value) => value === null || value === undefined
    ? null
    : utils_1.MathBN.convert(value).toNumber();
const unique = (values) => [...new Set(values)];
/** Gives the rep a new code, replacing any they had: the old link stops working. */
const makeClientLinkCode = async (service, repId) => {
    let failure;
    // A code another rep already has fails the unique index: try another
    for (let attempt = 0; attempt < 5; attempt++) {
        const code = (0, client_link_1.newClientLinkCode)();
        try {
            await service.updateSalesReps({ id: repId, client_link_code: code });
            return code;
        }
        catch (error) {
            failure = error;
        }
    }
    throw failure;
};
exports.makeClientLinkCode = makeClientLinkCode;
/** The rep's code, made the first time it is needed. */
const ensureClientLinkCode = async (service, rep) => rep.client_link_code ?? (await (0, exports.makeClientLinkCode)(service, rep.id));
exports.ensureClientLinkCode = ensureClientLinkCode;
/** Whether the person is a client already: an order, or a rep, under any account with their email. */
const isExistingClient = async (container, service, customer) => {
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const emails = unique([customer.email, customer.email.trim().toLowerCase()]);
    const { data: sameEmail } = await query.graph({
        entity: "customer",
        fields: ["id"],
        filters: { email: emails },
    });
    const customerIds = unique([customer.id, ...sameEmail.map((row) => row.id)]);
    const [assignment] = await service.listClientAssignments({ customer_id: customerIds }, { take: 1, select: ["id"] });
    if (assignment) {
        return true;
    }
    const [{ data: byAccount }, { data: byEmail }] = await Promise.all([
        query.graph({
            entity: "order",
            fields: ["id"],
            filters: { customer_id: customerIds },
            pagination: { take: 1 },
        }),
        query.graph({
            entity: "order",
            fields: ["id"],
            filters: { email: emails },
            pagination: { take: 1 },
        }),
    ]);
    return byAccount.length > 0 || byEmail.length > 0;
};
/**
 * Applies the client link a new customer followed, once. The storefront puts
 * the code in the customer's metadata when the account is created, so this
 * works from data alone: the `customer.created` subscriber calls it, and so
 * does the nightly job for any whose event was lost.
 *
 * Whoever answered first stands. A client is linked to one rep, forever, unless
 * the owner moves them; a later link can't take them over, and existing
 * customers can't be claimed at all (see `decideClientLink`).
 */
const claimClientLink = async (container, customerId) => (0, locks_1.withLock)(container, (0, locks_1.customerLockKey)(customerId), async () => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const [earlier] = await service.listLinkClaims({ customer_id: customerId }, { take: 1 });
    if (earlier) {
        return { status: "handled", claim: earlier };
    }
    const { data: [customer], } = await query.graph({
        entity: "customer",
        fields: [
            "id",
            "email",
            "has_account",
            "metadata",
            "company_name",
            "first_name",
            "last_name",
        ],
        filters: { id: customerId },
    });
    if (!customer) {
        return { status: "no_customer" };
    }
    // Only a client who made an account is linked: a guest checkout is no sign-up
    if (!customer.has_account) {
        return { status: "no_account" };
    }
    const code = (0, client_link_1.normalizeClientLinkCode)(customer.metadata?.[exports.CLIENT_LINK_METADATA_KEY]);
    if (!code || !customer.email) {
        return { status: "no_code" };
    }
    const [rep] = await service.listSalesReps({ client_link_code: code }, { take: 1 });
    // A crash between making the assignment and writing the claim leaves an
    // assignment this link made: finish the claim instead of deciding afresh,
    // when the customer would now look like an existing client
    const [made] = rep
        ? await service.listClientAssignments({ customer_id: customer.id, source: "link", link_code: code }, { take: 1 })
        : [];
    const decision = made
        ? { outcome: "credited", rate: rateOf(made.commission_rate) }
        : (0, client_link_1.decideClientLink)({
            rep: rep
                ? {
                    email: rep.email,
                    is_active: rep.is_active,
                    default_client_rate: rateOf(rep.default_client_rate),
                }
                : null,
            customerEmail: customer.email,
            existingClient: rep
                ? await isExistingClient(container, service, {
                    id: customer.id,
                    email: customer.email,
                })
                : false,
        });
    let assignmentId = made?.id ?? null;
    if (decision.outcome === "credited" && !made) {
        const { result } = await (0, assign_client_1.assignClientWorkflow)(container).run({
            input: {
                customer_id: customer.id,
                sales_rep_id: rep.id,
                commission_rate: decision.rate,
                source: "link",
                link_code: code,
                actor_id: null,
            },
        });
        assignmentId = result.id;
    }
    const clientName = (0, client_name_1.customerClientName)(customer);
    const claim = (await service.createLinkClaims({
        customer_id: customer.id,
        code,
        sales_rep_id: rep?.id ?? null,
        outcome: decision.outcome,
        assignment_id: assignmentId,
        client_name: clientName,
        client_email: customer.email,
    }));
    const eventBus = container.resolve(utils_1.Modules.EVENT_BUS);
    if (decision.outcome === "credited") {
        const data = {
            claim_id: claim.id,
            customer_id: customer.id,
            client_name: clientName,
            client_email: customer.email,
            sales_rep_id: rep.id,
            rep_name: rep.name,
            rep_email: rep.email,
            rate: decision.rate,
            locale: (0, invites_1.normalizeLocale)(rep.locale),
        };
        await eventBus.emit({ name: events_1.SalesCommissionEvents.CLIENT_JOINED, data });
    }
    else if (rep && (0, client_link_1.needsOwnerAttention)(decision.outcome)) {
        const data = {
            claim_id: claim.id,
            customer_id: customer.id,
            client_name: clientName,
            client_email: customer.email,
            sales_rep_id: rep.id,
            rep_name: rep.name,
            outcome: decision.outcome,
        };
        await eventBus.emit({ name: events_1.SalesCommissionEvents.CLIENT_NOT_LINKED, data });
    }
    return { status: "claimed", outcome: decision.outcome, claim };
});
exports.claimClientLink = claimClientLink;
/**
 * What a rep sees on their "bring clients" page: the code, whether it is on,
 * and how far each client who came through it has got. Only clients still
 * theirs: one the owner moved to someone else drops out.
 */
const loadPortalClientLink = async (container, repId, { locale } = {}) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const rep = await service.retrieveSalesRep(repId);
    // The emails about their clients come in the language their portal shows
    const language = (0, invites_1.normalizeLocale)(locale);
    if (language && language !== rep.locale) {
        await service.updateSalesReps({ id: rep.id, locale: language });
    }
    const code = await (0, exports.ensureClientLinkCode)(service, rep);
    const rate = rateOf(rep.default_client_rate);
    const { data: assignments } = await query.graph({
        entity: "client_assignment",
        fields: [
            "id",
            "customer_id",
            "starts_at",
            "customer.email",
            "customer.company_name",
            "customer.first_name",
            "customer.last_name",
        ],
        filters: { sales_rep_id: rep.id, source: "link", ends_at: null },
        pagination: { order: { starts_at: "DESC" } },
    });
    const customerIds = assignments.map((assignment) => assignment.customer_id);
    const [{ data: orders }, entries] = customerIds.length
        ? await Promise.all([
            query.graph({
                entity: "order",
                fields: ["id", "customer_id", "created_at", "canceled_at"],
                filters: { customer_id: customerIds },
            }),
            service.listCommissionEntries({ sales_rep_id: rep.id, customer_id: customerIds, voided_at: null }, { select: ["customer_id"] }),
        ])
        : [{ data: [] }, []];
    const referred = assignments.map((assignment) => {
        const joined = new Date(assignment.starts_at);
        return {
            id: assignment.id,
            name: (0, client_name_1.customerClientName)(assignment.customer ?? {}) || "Client",
            joined_at: joined.toISOString(),
            status: (0, client_link_1.referredClientStatus)({
                orders: orders.filter((order) => order.customer_id === assignment.customer_id &&
                    !order.canceled_at &&
                    new Date(order.created_at) >= joined).length,
                commissionEntries: entries.filter((entry) => entry.customer_id === assignment.customer_id).length,
            }),
        };
    });
    return {
        code,
        active: rate !== null,
        reason: rate === null ? "no_rate" : null,
        rate,
        referred,
        summary: {
            registered: referred.filter((client) => client.status === "registered").length,
            ordered: referred.filter((client) => client.status === "ordered").length,
            paid: referred.filter((client) => client.status === "paid").length,
        },
    };
};
exports.loadPortalClientLink = loadPortalClientLink;
/**
 * The owner's view of a rep's client link: whether it works, and who came
 * through it. A rep from before client links has no code yet; the first look
 * makes it, as the rep's own portal page does.
 */
const loadAdminClientLink = async (container, repId) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const rep = await service.retrieveSalesRep(repId);
    const code = await (0, exports.ensureClientLinkCode)(service, rep);
    const rate = rateOf(rep.default_client_rate);
    const claims = await service.listLinkClaims({ sales_rep_id: rep.id }, { order: { created_at: "DESC" }, take: 25 });
    return {
        code,
        link: (0, client_link_1.clientLinkUrl)(service.getOptions().storefront_url, code),
        active: rep.is_active && rate !== null,
        reason: !rep.is_active ? "rep_inactive" : rate === null ? "no_rate" : null,
        rate,
        claims: claims.map((claim) => ({
            id: claim.id,
            created_at: new Date(claim.created_at).toISOString(),
            outcome: claim.outcome,
            client_name: claim.client_name,
            client_email: claim.client_email,
        })),
    };
};
exports.loadAdminClientLink = loadAdminClientLink;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xpZW50LWxpbmtzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3V0aWxzL2NsaWVudC1saW5rcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxxREFJa0M7QUFDbEMsc0NBSWtCO0FBQ2xCLG9EQVMyQjtBQUMzQixrRUFBcUU7QUFFckUsOERBQWlFO0FBQ2pFLCtDQUFrRDtBQUNsRCx1Q0FBMkM7QUFDM0MsbUNBQW1EO0FBRW5ELDhGQUE4RjtBQUNqRixRQUFBLHdCQUF3QixHQUFHLGVBQWUsQ0FBQTtBQUV2RCxNQUFNLE1BQU0sR0FBRyxDQUFDLEtBQWMsRUFBaUIsRUFBRSxDQUMvQyxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssS0FBSyxTQUFTO0lBQ25DLENBQUMsQ0FBQyxJQUFJO0lBQ04sQ0FBQyxDQUFDLGNBQU0sQ0FBQyxPQUFPLENBQUMsS0FBZSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUE7QUFFaEQsTUFBTSxNQUFNLEdBQUcsQ0FBSSxNQUFXLEVBQUUsRUFBRSxDQUFDLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFBO0FBRXZELG9GQUFvRjtBQUM3RSxNQUFNLGtCQUFrQixHQUFHLEtBQUssRUFDckMsT0FBcUMsRUFDckMsS0FBYSxFQUNJLEVBQUU7SUFDbkIsSUFBSSxPQUFnQixDQUFBO0lBQ3BCLHFFQUFxRTtJQUNyRSxLQUFLLElBQUksT0FBTyxHQUFHLENBQUMsRUFBRSxPQUFPLEdBQUcsQ0FBQyxFQUFFLE9BQU8sRUFBRSxFQUFFLENBQUM7UUFDN0MsTUFBTSxJQUFJLEdBQUcsSUFBQSwrQkFBaUIsR0FBRSxDQUFBO1FBQ2hDLElBQUksQ0FBQztZQUNILE1BQU0sT0FBTyxDQUFDLGVBQWUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtZQUNwRSxPQUFPLElBQUksQ0FBQTtRQUNiLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTyxHQUFHLEtBQUssQ0FBQTtRQUNqQixDQUFDO0lBQ0gsQ0FBQztJQUNELE1BQU0sT0FBTyxDQUFBO0FBQ2YsQ0FBQyxDQUFBO0FBaEJZLFFBQUEsa0JBQWtCLHNCQWdCOUI7QUFFRCx3REFBd0Q7QUFDakQsTUFBTSxvQkFBb0IsR0FBRyxLQUFLLEVBQ3ZDLE9BQXFDLEVBQ3JDLEdBQXFELEVBQ3BDLEVBQUUsQ0FDbkIsR0FBRyxDQUFDLGdCQUFnQixJQUFJLENBQUMsTUFBTSxJQUFBLDBCQUFrQixFQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQTtBQUp4RCxRQUFBLG9CQUFvQix3QkFJb0M7QUFFckUsc0dBQXNHO0FBQ3RHLE1BQU0sZ0JBQWdCLEdBQUcsS0FBSyxFQUM1QixTQUEwQixFQUMxQixPQUFxQyxFQUNyQyxRQUF1QyxFQUNyQixFQUFFO0lBQ3BCLE1BQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUE7SUFDaEUsTUFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQTtJQUU1RSxNQUFNLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztRQUM1QyxNQUFNLEVBQUUsVUFBVTtRQUNsQixNQUFNLEVBQUUsQ0FBQyxJQUFJLENBQUM7UUFDZCxPQUFPLEVBQUUsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFO0tBQzNCLENBQUMsQ0FBQTtJQUNGLE1BQU0sV0FBVyxHQUFHLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBRTVFLE1BQU0sQ0FBQyxVQUFVLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxxQkFBcUIsQ0FDdEQsRUFBRSxXQUFXLEVBQUUsV0FBVyxFQUFFLEVBQzVCLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUM1QixDQUFBO0lBQ0QsSUFBSSxVQUFVLEVBQUUsQ0FBQztRQUNmLE9BQU8sSUFBSSxDQUFBO0lBQ2IsQ0FBQztJQUVELE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUNqRSxLQUFLLENBQUMsS0FBSyxDQUFDO1lBQ1YsTUFBTSxFQUFFLE9BQU87WUFDZixNQUFNLEVBQUUsQ0FBQyxJQUFJLENBQUM7WUFDZCxPQUFPLEVBQUUsRUFBRSxXQUFXLEVBQUUsV0FBVyxFQUFFO1lBQ3JDLFVBQVUsRUFBRSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUU7U0FDeEIsQ0FBQztRQUNGLEtBQUssQ0FBQyxLQUFLLENBQUM7WUFDVixNQUFNLEVBQUUsT0FBTztZQUNmLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQztZQUNkLE9BQU8sRUFBRSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUU7WUFDMUIsVUFBVSxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRTtTQUN4QixDQUFDO0tBQ0gsQ0FBQyxDQUFBO0lBRUYsT0FBTyxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQTtBQUNuRCxDQUFDLENBQUE7QUFpQkQ7Ozs7Ozs7OztHQVNHO0FBQ0ksTUFBTSxlQUFlLEdBQUcsS0FBSyxFQUNsQyxTQUEwQixFQUMxQixVQUFrQixFQUNJLEVBQUUsQ0FDeEIsSUFBQSxnQkFBUSxFQUFDLFNBQVMsRUFBRSxJQUFBLHVCQUFlLEVBQUMsVUFBVSxDQUFDLEVBQUUsS0FBSyxJQUFJLEVBQUU7SUFDMUQsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxLQUFLLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxpQ0FBeUIsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUVoRSxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsTUFBTSxPQUFPLENBQUMsY0FBYyxDQUM1QyxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUUsRUFDM0IsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQ1osQ0FBQTtJQUNELElBQUksT0FBTyxFQUFFLENBQUM7UUFDWixPQUFPLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsT0FBdUIsRUFBRSxDQUFBO0lBQzlELENBQUM7SUFFRCxNQUFNLEVBQ0osSUFBSSxFQUFFLENBQUMsUUFBUSxDQUFDLEdBQ2pCLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQ3BCLE1BQU0sRUFBRSxVQUFVO1FBQ2xCLE1BQU0sRUFBRTtZQUNOLElBQUk7WUFDSixPQUFPO1lBQ1AsYUFBYTtZQUNiLFVBQVU7WUFDVixjQUFjO1lBQ2QsWUFBWTtZQUNaLFdBQVc7U0FDWjtRQUNELE9BQU8sRUFBRSxFQUFFLEVBQUUsRUFBRSxVQUFVLEVBQUU7S0FDNUIsQ0FBQyxDQUFBO0lBQ0YsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2QsT0FBTyxFQUFFLE1BQU0sRUFBRSxhQUFhLEVBQUUsQ0FBQTtJQUNsQyxDQUFDO0lBQ0QsOEVBQThFO0lBQzlFLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDMUIsT0FBTyxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsQ0FBQTtJQUNqQyxDQUFDO0lBQ0QsTUFBTSxJQUFJLEdBQUcsSUFBQSxxQ0FBdUIsRUFBQyxRQUFRLENBQUMsUUFBUSxFQUFFLENBQUMsZ0NBQXdCLENBQUMsQ0FBQyxDQUFBO0lBQ25GLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDN0IsT0FBTyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsQ0FBQTtJQUM5QixDQUFDO0lBRUQsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLGFBQWEsQ0FDdkMsRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsRUFDMUIsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQ1osQ0FBQTtJQUVELHdFQUF3RTtJQUN4RSwwRUFBMEU7SUFDMUUsMkRBQTJEO0lBQzNELE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxHQUFHO1FBQ2hCLENBQUMsQ0FBQyxNQUFNLE9BQU8sQ0FBQyxxQkFBcUIsQ0FDakMsRUFBRSxXQUFXLEVBQUUsUUFBUSxDQUFDLEVBQUUsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsRUFDN0QsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQ1o7UUFDSCxDQUFDLENBQUMsRUFBRSxDQUFBO0lBRU4sTUFBTSxRQUFRLEdBQUcsSUFBSTtRQUNuQixDQUFDLENBQUMsRUFBRSxPQUFPLEVBQUUsVUFBK0IsRUFBRSxJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsRUFBRTtRQUNsRixDQUFDLENBQUMsSUFBQSw4QkFBZ0IsRUFBQztZQUNmLEdBQUcsRUFBRSxHQUFHO2dCQUNOLENBQUMsQ0FBQztvQkFDRSxLQUFLLEVBQUUsR0FBRyxDQUFDLEtBQUs7b0JBQ2hCLFNBQVMsRUFBRSxHQUFHLENBQUMsU0FBUztvQkFDeEIsbUJBQW1CLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQztpQkFDckQ7Z0JBQ0gsQ0FBQyxDQUFDLElBQUk7WUFDUixhQUFhLEVBQUUsUUFBUSxDQUFDLEtBQUs7WUFDN0IsY0FBYyxFQUFFLEdBQUc7Z0JBQ2pCLENBQUMsQ0FBQyxNQUFNLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUU7b0JBQ3pDLEVBQUUsRUFBRSxRQUFRLENBQUMsRUFBRTtvQkFDZixLQUFLLEVBQUUsUUFBUSxDQUFDLEtBQUs7aUJBQ3RCLENBQUM7Z0JBQ0osQ0FBQyxDQUFDLEtBQUs7U0FDVixDQUFDLENBQUE7SUFFTixJQUFJLFlBQVksR0FBa0IsSUFBSSxFQUFFLEVBQUUsSUFBSSxJQUFJLENBQUE7SUFDbEQsSUFBSSxRQUFRLENBQUMsT0FBTyxLQUFLLFVBQVUsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQzdDLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLElBQUEsb0NBQW9CLEVBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDO1lBQzNELEtBQUssRUFBRTtnQkFDTCxXQUFXLEVBQUUsUUFBUSxDQUFDLEVBQUU7Z0JBQ3hCLFlBQVksRUFBRSxHQUFJLENBQUMsRUFBRTtnQkFDckIsZUFBZSxFQUFFLFFBQVEsQ0FBQyxJQUFLO2dCQUMvQixNQUFNLEVBQUUsTUFBTTtnQkFDZCxTQUFTLEVBQUUsSUFBSTtnQkFDZixRQUFRLEVBQUUsSUFBSTthQUNmO1NBQ0YsQ0FBQyxDQUFBO1FBQ0YsWUFBWSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUE7SUFDMUIsQ0FBQztJQUVELE1BQU0sVUFBVSxHQUFHLElBQUEsZ0NBQWtCLEVBQUMsUUFBUSxDQUFDLENBQUE7SUFDL0MsTUFBTSxLQUFLLEdBQUcsQ0FBQyxNQUFNLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQztRQUM1QyxXQUFXLEVBQUUsUUFBUSxDQUFDLEVBQUU7UUFDeEIsSUFBSTtRQUNKLFlBQVksRUFBRSxHQUFHLEVBQUUsRUFBRSxJQUFJLElBQUk7UUFDN0IsT0FBTyxFQUFFLFFBQVEsQ0FBQyxPQUFPO1FBQ3pCLGFBQWEsRUFBRSxZQUFZO1FBQzNCLFdBQVcsRUFBRSxVQUFVO1FBQ3ZCLFlBQVksRUFBRSxRQUFRLENBQUMsS0FBSztLQUM3QixDQUFDLENBQWlCLENBQUE7SUFFbkIsTUFBTSxRQUFRLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsU0FBUyxDQUFDLENBQUE7SUFDckQsSUFBSSxRQUFRLENBQUMsT0FBTyxLQUFLLFVBQVUsRUFBRSxDQUFDO1FBQ3BDLE1BQU0sSUFBSSxHQUFzQjtZQUM5QixRQUFRLEVBQUUsS0FBSyxDQUFDLEVBQUU7WUFDbEIsV0FBVyxFQUFFLFFBQVEsQ0FBQyxFQUFFO1lBQ3hCLFdBQVcsRUFBRSxVQUFVO1lBQ3ZCLFlBQVksRUFBRSxRQUFRLENBQUMsS0FBSztZQUM1QixZQUFZLEVBQUUsR0FBSSxDQUFDLEVBQUU7WUFDckIsUUFBUSxFQUFFLEdBQUksQ0FBQyxJQUFJO1lBQ25CLFNBQVMsRUFBRSxHQUFJLENBQUMsS0FBSztZQUNyQixJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUs7WUFDcEIsTUFBTSxFQUFFLElBQUEseUJBQWUsRUFBQyxHQUFJLENBQUMsTUFBTSxDQUFDO1NBQ3JDLENBQUE7UUFDRCxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLEVBQUUsOEJBQXFCLENBQUMsYUFBYSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUE7SUFDMUUsQ0FBQztTQUFNLElBQUksR0FBRyxJQUFJLElBQUEsaUNBQW1CLEVBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7UUFDeEQsTUFBTSxJQUFJLEdBQXlCO1lBQ2pDLFFBQVEsRUFBRSxLQUFLLENBQUMsRUFBRTtZQUNsQixXQUFXLEVBQUUsUUFBUSxDQUFDLEVBQUU7WUFDeEIsV0FBVyxFQUFFLFVBQVU7WUFDdkIsWUFBWSxFQUFFLFFBQVEsQ0FBQyxLQUFLO1lBQzVCLFlBQVksRUFBRSxHQUFHLENBQUMsRUFBRTtZQUNwQixRQUFRLEVBQUUsR0FBRyxDQUFDLElBQUk7WUFDbEIsT0FBTyxFQUFFLFFBQVEsQ0FBQyxPQUEwQztTQUM3RCxDQUFBO1FBQ0QsTUFBTSxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxFQUFFLDhCQUFxQixDQUFDLGlCQUFpQixFQUFFLElBQUksRUFBRSxDQUFDLENBQUE7SUFDOUUsQ0FBQztJQUVELE9BQU8sRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsT0FBTyxFQUFFLEtBQUssRUFBRSxDQUFBO0FBQ2hFLENBQUMsQ0FBQyxDQUFBO0FBcklTLFFBQUEsZUFBZSxtQkFxSXhCO0FBaUJKOzs7O0dBSUc7QUFDSSxNQUFNLG9CQUFvQixHQUFHLEtBQUssRUFDdkMsU0FBMEIsRUFDMUIsS0FBYSxFQUNiLEVBQUUsTUFBTSxLQUFpQyxFQUFFLEVBQ2hCLEVBQUU7SUFDN0IsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxLQUFLLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxpQ0FBeUIsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUVoRSxNQUFNLEdBQUcsR0FBRyxNQUFNLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUVqRCx5RUFBeUU7SUFDekUsTUFBTSxRQUFRLEdBQUcsSUFBQSx5QkFBZSxFQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQ3hDLElBQUksUUFBUSxJQUFJLFFBQVEsS0FBSyxHQUFHLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDeEMsTUFBTSxPQUFPLENBQUMsZUFBZSxDQUFDLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQyxFQUFFLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUE7SUFDakUsQ0FBQztJQUNELE1BQU0sSUFBSSxHQUFHLE1BQU0sSUFBQSw0QkFBb0IsRUFBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUE7SUFDckQsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFBO0lBRTVDLE1BQU0sRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQzlDLE1BQU0sRUFBRSxtQkFBbUI7UUFDM0IsTUFBTSxFQUFFO1lBQ04sSUFBSTtZQUNKLGFBQWE7WUFDYixXQUFXO1lBQ1gsZ0JBQWdCO1lBQ2hCLHVCQUF1QjtZQUN2QixxQkFBcUI7WUFDckIsb0JBQW9CO1NBQ3JCO1FBQ0QsT0FBTyxFQUFFLEVBQUUsWUFBWSxFQUFFLEdBQUcsQ0FBQyxFQUFFLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFO1FBQ2hFLFVBQVUsRUFBRSxFQUFFLEtBQUssRUFBRSxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsRUFBRTtLQUM3QyxDQUFDLENBQUE7SUFFRixNQUFNLFdBQVcsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUE7SUFDM0UsTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFLE9BQU8sQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNO1FBQ3BELENBQUMsQ0FBQyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7WUFDaEIsS0FBSyxDQUFDLEtBQUssQ0FBQztnQkFDVixNQUFNLEVBQUUsT0FBTztnQkFDZixNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsYUFBYSxFQUFFLFlBQVksRUFBRSxhQUFhLENBQUM7Z0JBQzFELE9BQU8sRUFBRSxFQUFFLFdBQVcsRUFBRSxXQUFXLEVBQUU7YUFDdEMsQ0FBQztZQUNGLE9BQU8sQ0FBQyxxQkFBcUIsQ0FDM0IsRUFBRSxZQUFZLEVBQUUsR0FBRyxDQUFDLEVBQUUsRUFBRSxXQUFXLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsRUFDbkUsRUFBRSxNQUFNLEVBQUUsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUM1QjtTQUNGLENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFXLEVBQUUsRUFBRSxFQUErQixDQUFDLENBQUE7SUFFNUQsTUFBTSxRQUFRLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFVBQVUsRUFBRSxFQUFFO1FBQzlDLE1BQU0sTUFBTSxHQUFHLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQTtRQUU3QyxPQUFPO1lBQ0wsRUFBRSxFQUFFLFVBQVUsQ0FBQyxFQUFFO1lBQ2pCLElBQUksRUFBRSxJQUFBLGdDQUFrQixFQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksRUFBRSxDQUFDLElBQUksUUFBUTtZQUMvRCxTQUFTLEVBQUUsTUFBTSxDQUFDLFdBQVcsRUFBRTtZQUMvQixNQUFNLEVBQUUsSUFBQSxrQ0FBb0IsRUFBQztnQkFDM0IsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQ25CLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FDUixLQUFLLENBQUMsV0FBVyxLQUFLLFVBQVUsQ0FBQyxXQUFXO29CQUM1QyxDQUFDLEtBQUssQ0FBQyxXQUFXO29CQUNsQixJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLElBQUksTUFBTSxDQUN2QyxDQUFDLE1BQU07Z0JBQ1IsaUJBQWlCLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FDL0IsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLEtBQUssQ0FBQyxXQUFXLEtBQUssVUFBVSxDQUFDLFdBQVcsQ0FDeEQsQ0FBQyxNQUFNO2FBQ1QsQ0FBQztTQUNILENBQUE7SUFDSCxDQUFDLENBQUMsQ0FBQTtJQUVGLE9BQU87UUFDTCxJQUFJO1FBQ0osTUFBTSxFQUFFLElBQUksS0FBSyxJQUFJO1FBQ3JCLE1BQU0sRUFBRSxJQUFJLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUk7UUFDeEMsSUFBSTtRQUNKLFFBQVE7UUFDUixPQUFPLEVBQUU7WUFDUCxVQUFVLEVBQUUsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sS0FBSyxZQUFZLENBQUMsQ0FBQyxNQUFNO1lBQzlFLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxLQUFLLFNBQVMsQ0FBQyxDQUFDLE1BQU07WUFDeEUsSUFBSSxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEtBQUssTUFBTSxDQUFDLENBQUMsTUFBTTtTQUNuRTtLQUNGLENBQUE7QUFDSCxDQUFDLENBQUE7QUFuRlksUUFBQSxvQkFBb0Isd0JBbUZoQztBQWtCRDs7OztHQUlHO0FBQ0ksTUFBTSxtQkFBbUIsR0FBRyxLQUFLLEVBQ3RDLFNBQTBCLEVBQzFCLEtBQWEsRUFDYSxFQUFFO0lBQzVCLE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUNELE1BQU0sR0FBRyxHQUFHLE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFBO0lBQ2pELE1BQU0sSUFBSSxHQUFHLE1BQU0sSUFBQSw0QkFBb0IsRUFBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUE7SUFDckQsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFBO0lBRTVDLE1BQU0sTUFBTSxHQUFHLE1BQU0sT0FBTyxDQUFDLGNBQWMsQ0FDekMsRUFBRSxZQUFZLEVBQUUsR0FBRyxDQUFDLEVBQUUsRUFBRSxFQUN4QixFQUFFLEtBQUssRUFBRSxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQzVDLENBQUE7SUFFRCxPQUFPO1FBQ0wsSUFBSTtRQUNKLElBQUksRUFBRSxJQUFBLDJCQUFhLEVBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUM7UUFDOUQsTUFBTSxFQUFFLEdBQUcsQ0FBQyxTQUFTLElBQUksSUFBSSxLQUFLLElBQUk7UUFDdEMsTUFBTSxFQUFFLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUk7UUFDMUUsSUFBSTtRQUNKLE1BQU0sRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQzdCLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFBRTtZQUNaLFVBQVUsRUFBRSxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQ3BELE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBNEI7WUFDM0MsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXO1lBQzlCLFlBQVksRUFBRSxLQUFLLENBQUMsWUFBWTtTQUNqQyxDQUFDLENBQUM7S0FDSixDQUFBO0FBQ0gsQ0FBQyxDQUFBO0FBOUJZLFFBQUEsbUJBQW1CLHVCQThCL0IifQ==