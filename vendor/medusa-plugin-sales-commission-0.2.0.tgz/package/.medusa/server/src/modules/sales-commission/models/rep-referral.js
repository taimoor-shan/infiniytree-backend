"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
/**
 * "Referrer brought in referred" over [starts_at, ends_at), with the Level 2
 * rate the referrer earns on the referred rep's clients.
 */
const RepReferral = utils_1.model
    .define("rep_referral", {
    id: utils_1.model.id({ prefix: "srr" }).primaryKey(),
    referrer_sales_rep_id: utils_1.model.text(),
    referred_sales_rep_id: utils_1.model.text(),
    level2_rate: utils_1.model.bigNumber(),
    starts_at: utils_1.model.dateTime(),
    ends_at: utils_1.model.dateTime().nullable(),
    /** Level 2 stops earning at this time without anyone ending the referral */
    expires_at: utils_1.model.dateTime().nullable(),
    created_by: utils_1.model.text().nullable(),
    ended_by: utils_1.model.text().nullable(),
})
    .indexes([
    {
        on: ["referred_sales_rep_id"],
        unique: true,
        where: "ends_at IS NULL AND deleted_at IS NULL",
    },
    { on: ["referrer_sales_rep_id"] },
]);
exports.default = RepReferral;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVwLXJlZmVycmFsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL21vZHVsZXMvc2FsZXMtY29tbWlzc2lvbi9tb2RlbHMvcmVwLXJlZmVycmFsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEscURBQWlEO0FBRWpEOzs7R0FHRztBQUNILE1BQU0sV0FBVyxHQUFHLGFBQUs7S0FDdEIsTUFBTSxDQUFDLGNBQWMsRUFBRTtJQUN0QixFQUFFLEVBQUUsYUFBSyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLFVBQVUsRUFBRTtJQUM1QyxxQkFBcUIsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBQ25DLHFCQUFxQixFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDbkMsV0FBVyxFQUFFLGFBQUssQ0FBQyxTQUFTLEVBQUU7SUFDOUIsU0FBUyxFQUFFLGFBQUssQ0FBQyxRQUFRLEVBQUU7SUFDM0IsT0FBTyxFQUFFLGFBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDcEMsNEVBQTRFO0lBQzVFLFVBQVUsRUFBRSxhQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ3ZDLFVBQVUsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ25DLFFBQVEsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0NBQ2xDLENBQUM7S0FDRCxPQUFPLENBQUM7SUFDUDtRQUNFLEVBQUUsRUFBRSxDQUFDLHVCQUF1QixDQUFDO1FBQzdCLE1BQU0sRUFBRSxJQUFJO1FBQ1osS0FBSyxFQUFFLHdDQUF3QztLQUNoRDtJQUNELEVBQUUsRUFBRSxFQUFFLENBQUMsdUJBQXVCLENBQUMsRUFBRTtDQUNsQyxDQUFDLENBQUE7QUFFSixrQkFBZSxXQUFXLENBQUEifQ==