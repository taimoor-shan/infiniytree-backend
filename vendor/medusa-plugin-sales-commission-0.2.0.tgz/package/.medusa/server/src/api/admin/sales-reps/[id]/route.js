"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const utils_1 = require("@medusajs/framework/utils");
const update_sales_rep_1 = require("../../../../workflows/update-sales-rep");
const query_config_1 = require("../query-config");
const REFERRAL_FIELDS = [
    "id",
    "referrer_sales_rep_id",
    "referred_sales_rep_id",
    "level2_rate",
    "starts_at",
    "ends_at",
    "expires_at",
    "created_by",
];
/**
 * The rep, whether they have portal access (`portal`), who referred them
 * (`referral`, with the Level 2 rate the referrer earns on this rep's clients)
 * and the reps they referred (`referred_reps`).
 */
async function GET(req, res) {
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const id = req.params.id;
    const { data: [salesRepWithLogin], } = await query.graph({
        entity: "sales_rep",
        fields: [...query_config_1.SALES_REP_FIELDS, "auth_identity_id"],
        filters: { id },
    });
    if (!salesRepWithLogin) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, `Sales rep ${id} was not found`);
    }
    // Which login belongs to the rep stays inside the plugin
    const { auth_identity_id, ...salesRep } = salesRepWithLogin;
    const [{ data: upline }, { data: downline }] = await Promise.all([
        query.graph({
            entity: "rep_referral",
            fields: REFERRAL_FIELDS,
            filters: { referred_sales_rep_id: id, ends_at: null },
        }),
        query.graph({
            entity: "rep_referral",
            fields: REFERRAL_FIELDS,
            filters: { referrer_sales_rep_id: id, ends_at: null },
        }),
    ]);
    const relatedIds = [
        ...upline.map((r) => r.referrer_sales_rep_id),
        ...downline.map((r) => r.referred_sales_rep_id),
    ];
    const { data: relatedReps } = relatedIds.length
        ? await query.graph({
            entity: "sales_rep",
            fields: ["id", "name", "email", "is_active"],
            filters: { id: relatedIds },
        })
        : { data: [] };
    const repById = new Map(relatedReps.map((rep) => [rep.id, rep]));
    res.json({
        sales_rep: salesRep,
        portal: { status: auth_identity_id ? "active" : "none" },
        referral: upline[0]
            ? { ...upline[0], referrer: repById.get(upline[0].referrer_sales_rep_id) }
            : null,
        referred_reps: downline.map((referral) => ({
            ...referral,
            referred: repById.get(referral.referred_sales_rep_id),
        })),
    });
}
async function POST(req, res) {
    const { result } = await (0, update_sales_rep_1.updateSalesRepWorkflow)(req.scope).run({
        input: { id: req.params.id, ...req.validatedBody },
    });
    res.json({ sales_rep: result });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLXJlcHMvW2lkXS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQTRCQSxrQkE2REM7QUFFRCxvQkFTQztBQWhHRCxxREFHa0M7QUFDbEMsNkVBQStFO0FBQy9FLGtEQUFrRDtBQUdsRCxNQUFNLGVBQWUsR0FBRztJQUN0QixJQUFJO0lBQ0osdUJBQXVCO0lBQ3ZCLHVCQUF1QjtJQUN2QixhQUFhO0lBQ2IsV0FBVztJQUNYLFNBQVM7SUFDVCxZQUFZO0lBQ1osWUFBWTtDQUNiLENBQUE7QUFFRDs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBK0IsRUFDL0IsR0FBbUI7SUFFbkIsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUE7SUFDaEUsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUE7SUFFeEIsTUFBTSxFQUNKLElBQUksRUFBRSxDQUFDLGlCQUFpQixDQUFDLEdBQzFCLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQ3BCLE1BQU0sRUFBRSxXQUFXO1FBQ25CLE1BQU0sRUFBRSxDQUFDLEdBQUcsK0JBQWdCLEVBQUUsa0JBQWtCLENBQUM7UUFDakQsT0FBTyxFQUFFLEVBQUUsRUFBRSxFQUFFO0tBQ2hCLENBQUMsQ0FBQTtJQUVGLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ3ZCLE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQzNCLGFBQWEsRUFBRSxnQkFBZ0IsQ0FDaEMsQ0FBQTtJQUNILENBQUM7SUFDRCx5REFBeUQ7SUFDekQsTUFBTSxFQUFFLGdCQUFnQixFQUFFLEdBQUcsUUFBUSxFQUFFLEdBQUcsaUJBQWlCLENBQUE7SUFFM0QsTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxDQUFDLEdBQUcsTUFBTSxPQUFPLENBQUMsR0FBRyxDQUFDO1FBQy9ELEtBQUssQ0FBQyxLQUFLLENBQUM7WUFDVixNQUFNLEVBQUUsY0FBYztZQUN0QixNQUFNLEVBQUUsZUFBZTtZQUN2QixPQUFPLEVBQUUsRUFBRSxxQkFBcUIsRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRTtTQUN0RCxDQUFDO1FBQ0YsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUNWLE1BQU0sRUFBRSxjQUFjO1lBQ3RCLE1BQU0sRUFBRSxlQUFlO1lBQ3ZCLE9BQU8sRUFBRSxFQUFFLHFCQUFxQixFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFO1NBQ3RELENBQUM7S0FDSCxDQUFDLENBQUE7SUFFRixNQUFNLFVBQVUsR0FBRztRQUNqQixHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQztRQUM3QyxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQztLQUNoRCxDQUFBO0lBQ0QsTUFBTSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsR0FBRyxVQUFVLENBQUMsTUFBTTtRQUM3QyxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO1lBQ2hCLE1BQU0sRUFBRSxXQUFXO1lBQ25CLE1BQU0sRUFBRSxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLFdBQVcsQ0FBQztZQUM1QyxPQUFPLEVBQUUsRUFBRSxFQUFFLEVBQUUsVUFBVSxFQUFFO1NBQzVCLENBQUM7UUFDSixDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUE7SUFDaEIsTUFBTSxPQUFPLEdBQUcsSUFBSSxHQUFHLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUVoRSxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ1AsU0FBUyxFQUFFLFFBQVE7UUFDbkIsTUFBTSxFQUFFLEVBQUUsTUFBTSxFQUFFLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRTtRQUN4RCxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQztZQUNqQixDQUFDLENBQUMsRUFBRSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsRUFBRTtZQUMxRSxDQUFDLENBQUMsSUFBSTtRQUNSLGFBQWEsRUFBRSxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQ3pDLEdBQUcsUUFBUTtZQUNYLFFBQVEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQztTQUN0RCxDQUFDLENBQUM7S0FDSixDQUFDLENBQUE7QUFDSixDQUFDO0FBRU0sS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBd0QsRUFDeEQsR0FBbUI7SUFFbkIsTUFBTSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sSUFBQSx5Q0FBc0IsRUFBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDO1FBQzdELEtBQUssRUFBRSxFQUFFLEVBQUUsRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxHQUFHLEdBQUcsQ0FBQyxhQUFhLEVBQUU7S0FDbkQsQ0FBQyxDQUFBO0lBRUYsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFBO0FBQ2pDLENBQUMifQ==