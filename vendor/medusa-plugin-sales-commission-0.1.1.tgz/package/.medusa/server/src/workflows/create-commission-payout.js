"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCommissionPayoutWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const create_commission_payout_1 = require("./steps/create-commission-payout");
exports.createCommissionPayoutWorkflow = (0, workflows_sdk_1.createWorkflow)("create-commission-payout", function (input) {
    const payout = (0, create_commission_payout_1.createCommissionPayoutStep)(input);
    return new workflows_sdk_1.WorkflowResponse(payout);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLWNvbW1pc3Npb24tcGF5b3V0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9jcmVhdGUtY29tbWlzc2lvbi1wYXlvdXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscUVBRzBDO0FBQzFDLCtFQUd5QztBQUU1QixRQUFBLDhCQUE4QixHQUFHLElBQUEsOEJBQWMsRUFDMUQsMEJBQTBCLEVBQzFCLFVBQVUsS0FBc0M7SUFDOUMsTUFBTSxNQUFNLEdBQUcsSUFBQSxxREFBMEIsRUFBQyxLQUFLLENBQUMsQ0FBQTtJQUVoRCxPQUFPLElBQUksZ0NBQWdCLENBQUMsTUFBTSxDQUFDLENBQUE7QUFDckMsQ0FBQyxDQUNGLENBQUEifQ==