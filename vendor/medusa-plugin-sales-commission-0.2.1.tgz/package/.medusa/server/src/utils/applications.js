"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.approvalBlockers = exports.adminApplicationView = void 0;
const utils_1 = require("@medusajs/framework/utils");
const invite_1 = require("../lib/invite");
const portal_login_1 = require("../lib/portal-login");
const sales_commission_1 = require("../modules/sales-commission");
const portal_login_2 = require("./portal-login");
const iso = (value) => value ? new Date(value).toISOString() : null;
/** An application as the owner sees it. Built field by field: the link's hash stays inside. */
const adminApplicationView = (invite, recruiter) => ({
    id: invite.id,
    status: invite.status,
    /** An invite nobody has answered whose link has run out */
    expired: (0, invite_1.inviteState)(invite, new Date()) === "expired",
    name: invite.applicant_name ?? invite.name,
    email: invite.email,
    phone: invite.applicant_phone,
    company: invite.applicant_company,
    requested_currency_code: invite.requested_currency_code,
    note: invite.note,
    invited_at: iso(invite.created_at),
    expires_at: iso(invite.expires_at),
    applied_at: iso(invite.applied_at),
    terms_accepted_at: iso(invite.terms_accepted_at),
    decided_at: iso(invite.decided_at),
    decision_reason: invite.decision_reason,
    sales_rep_id: invite.sales_rep_id,
    recruiter: recruiter ? { id: recruiter.id, name: recruiter.name } : null,
});
exports.adminApplicationView = adminApplicationView;
/**
 * What would make approving this application fail, in words for the owner, so
 * they are told before they press the button: an inactive recruiter, an email
 * that already belongs to a rep, or a login on the shop that is linked to
 * something else (such as a customer account).
 */
const approvalBlockers = async (container, invite, recruiter) => {
    if (invite.status !== "applied") {
        return [];
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const blockers = [];
    if (!recruiter?.is_active) {
        blockers.push(`${recruiter?.name ?? "The recruiter"} is inactive. Reactivate them first, or decline this application.`);
    }
    const [existingRep] = await service.listSalesReps({ email: invite.email }, { take: 1, select: ["id"] });
    if (existingRep) {
        blockers.push("A sales rep with this email already exists.");
    }
    const [login] = await container
        .resolve(utils_1.Modules.AUTH)
        .listAuthIdentities({ provider_identities: { provider: "emailpass", entity_id: invite.email } }, { take: 1 });
    if (login) {
        const kind = (0, portal_login_1.classifyExistingLogin)(login.app_metadata, "", await (0, portal_login_2.linkedRepExists)(service, login.app_metadata, ""));
        if (kind === "in_use" || kind === "other_rep") {
            blockers.push("This email already has a login on the shop that is linked to another account, such as a customer account, so it can't become a sales portal login. Decline and ask the candidate for a different email.");
        }
    }
    return blockers;
};
exports.approvalBlockers = approvalBlockers;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwbGljYXRpb25zLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3V0aWxzL2FwcGxpY2F0aW9ucy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxxREFBbUQ7QUFDbkQsMENBQXlEO0FBQ3pELHNEQUEyRDtBQUMzRCxrRUFBcUU7QUFFckUsaURBQWdEO0FBc0JoRCxNQUFNLEdBQUcsR0FBRyxDQUFDLEtBQTJCLEVBQUUsRUFBRSxDQUMxQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUE7QUFFOUMsK0ZBQStGO0FBQ3hGLE1BQU0sb0JBQW9CLEdBQUcsQ0FDbEMsTUFBb0IsRUFDcEIsU0FBbUQsRUFDbkQsRUFBRSxDQUFDLENBQUM7SUFDSixFQUFFLEVBQUUsTUFBTSxDQUFDLEVBQUU7SUFDYixNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07SUFDckIsMkRBQTJEO0lBQzNELE9BQU8sRUFBRSxJQUFBLG9CQUFXLEVBQUMsTUFBTSxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsS0FBSyxTQUFTO0lBQ3RELElBQUksRUFBRSxNQUFNLENBQUMsY0FBYyxJQUFJLE1BQU0sQ0FBQyxJQUFJO0lBQzFDLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSztJQUNuQixLQUFLLEVBQUUsTUFBTSxDQUFDLGVBQWU7SUFDN0IsT0FBTyxFQUFFLE1BQU0sQ0FBQyxpQkFBaUI7SUFDakMsdUJBQXVCLEVBQUUsTUFBTSxDQUFDLHVCQUF1QjtJQUN2RCxJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7SUFDakIsVUFBVSxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFFO0lBQ25DLFVBQVUsRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBRTtJQUNuQyxVQUFVLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7SUFDbEMsaUJBQWlCLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQztJQUNoRCxVQUFVLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7SUFDbEMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxlQUFlO0lBQ3ZDLFlBQVksRUFBRSxNQUFNLENBQUMsWUFBWTtJQUNqQyxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxTQUFTLENBQUMsRUFBRSxFQUFFLElBQUksRUFBRSxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUk7Q0FDekUsQ0FBQyxDQUFBO0FBdEJXLFFBQUEsb0JBQW9CLHdCQXNCL0I7QUFFRjs7Ozs7R0FLRztBQUNJLE1BQU0sZ0JBQWdCLEdBQUcsS0FBSyxFQUNuQyxTQUEwQixFQUMxQixNQUErQyxFQUMvQyxTQUEyRCxFQUN4QyxFQUFFO0lBQ3JCLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUNoQyxPQUFPLEVBQUUsQ0FBQTtJQUNYLENBQUM7SUFDRCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLFFBQVEsR0FBYSxFQUFFLENBQUE7SUFFN0IsSUFBSSxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsQ0FBQztRQUMxQixRQUFRLENBQUMsSUFBSSxDQUNYLEdBQUcsU0FBUyxFQUFFLElBQUksSUFBSSxlQUFlLG1FQUFtRSxDQUN6RyxDQUFBO0lBQ0gsQ0FBQztJQUVELE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxhQUFhLENBQy9DLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLLEVBQUUsRUFDdkIsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQzVCLENBQUE7SUFDRCxJQUFJLFdBQVcsRUFBRSxDQUFDO1FBQ2hCLFFBQVEsQ0FBQyxJQUFJLENBQUMsNkNBQTZDLENBQUMsQ0FBQTtJQUM5RCxDQUFDO0lBRUQsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLE1BQU0sU0FBUztTQUM1QixPQUFPLENBQUMsZUFBTyxDQUFDLElBQUksQ0FBQztTQUNyQixrQkFBa0IsQ0FDakIsRUFBRSxtQkFBbUIsRUFBRSxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLE1BQU0sQ0FBQyxLQUFLLEVBQUUsRUFBRSxFQUMzRSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FDWixDQUFBO0lBQ0gsSUFBSSxLQUFLLEVBQUUsQ0FBQztRQUNWLE1BQU0sSUFBSSxHQUFHLElBQUEsb0NBQXFCLEVBQ2hDLEtBQUssQ0FBQyxZQUFZLEVBQ2xCLEVBQUUsRUFDRixNQUFNLElBQUEsOEJBQWUsRUFBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLFlBQVksRUFBRSxFQUFFLENBQUMsQ0FDdkQsQ0FBQTtRQUNELElBQUksSUFBSSxLQUFLLFFBQVEsSUFBSSxJQUFJLEtBQUssV0FBVyxFQUFFLENBQUM7WUFDOUMsUUFBUSxDQUFDLElBQUksQ0FDWCx5TUFBeU0sQ0FDMU0sQ0FBQTtRQUNILENBQUM7SUFDSCxDQUFDO0lBRUQsT0FBTyxRQUFRLENBQUE7QUFDakIsQ0FBQyxDQUFBO0FBL0NZLFFBQUEsZ0JBQWdCLG9CQStDNUIifQ==