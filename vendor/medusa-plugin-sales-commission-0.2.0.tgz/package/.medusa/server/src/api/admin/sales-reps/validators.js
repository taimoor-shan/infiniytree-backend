"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminSetRepReferral = exports.AdminUploadSalesRepContract = exports.AdminUpdateSalesRep = exports.AdminCreateSalesRep = exports.AdminGetSalesRepsParams = void 0;
const zod_1 = require("@medusajs/framework/zod");
const validators_1 = require("@medusajs/medusa/api/utils/validators");
exports.AdminGetSalesRepsParams = (0, validators_1.createFindParams)({
    limit: 50,
    offset: 0,
}).extend({
    q: zod_1.z.string().optional(),
    is_active: zod_1.z
        .enum(["true", "false"])
        .transform((value) => value === "true")
        .optional(),
});
const email = zod_1.z.string().trim().pipe(zod_1.z.email());
/** The currencies a rep can be paid in */
const payoutCurrency = zod_1.z
    .string()
    .transform((code) => code.toLowerCase())
    .pipe(zod_1.z.enum(["eur", "huf"]));
exports.AdminCreateSalesRep = zod_1.z.object({
    name: zod_1.z.string().trim().min(1),
    email,
    phone: zod_1.z.string().trim().nullish(),
    notes: zod_1.z.string().nullish(),
    payout_currency_code: payoutCurrency.nullish(),
});
exports.AdminUpdateSalesRep = zod_1.z.object({
    name: zod_1.z.string().trim().min(1).optional(),
    email: email.optional(),
    phone: zod_1.z.string().trim().nullish(),
    notes: zod_1.z.string().nullish(),
    is_active: zod_1.z.boolean().optional(),
    payout_currency_code: payoutCurrency.nullish(),
});
exports.AdminUploadSalesRepContract = zod_1.z.object({
    file_name: zod_1.z.string().trim().min(1).max(255),
    mime_type: zod_1.z.string(),
    content_base64: zod_1.z.string(),
});
exports.AdminSetRepReferral = zod_1.z.object({
    referrer_sales_rep_id: zod_1.z.string().min(1),
    level2_rate: zod_1.z.number().min(0).max(100),
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdG9ycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcGkvYWRtaW4vc2FsZXMtcmVwcy92YWxpZGF0b3JzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLGlEQUEyQztBQUMzQyxzRUFBd0U7QUFFM0QsUUFBQSx1QkFBdUIsR0FBRyxJQUFBLDZCQUFnQixFQUFDO0lBQ3RELEtBQUssRUFBRSxFQUFFO0lBQ1QsTUFBTSxFQUFFLENBQUM7Q0FDVixDQUFDLENBQUMsTUFBTSxDQUFDO0lBQ1IsQ0FBQyxFQUFFLE9BQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDeEIsU0FBUyxFQUFFLE9BQUM7U0FDVCxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7U0FDdkIsU0FBUyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxLQUFLLEtBQUssTUFBTSxDQUFDO1NBQ3RDLFFBQVEsRUFBRTtDQUNkLENBQUMsQ0FBQTtBQUdGLE1BQU0sS0FBSyxHQUFHLE9BQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsT0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUE7QUFFL0MsMENBQTBDO0FBQzFDLE1BQU0sY0FBYyxHQUFHLE9BQUM7S0FDckIsTUFBTSxFQUFFO0tBQ1IsU0FBUyxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7S0FDdkMsSUFBSSxDQUFDLE9BQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFBO0FBRWxCLFFBQUEsbUJBQW1CLEdBQUcsT0FBQyxDQUFDLE1BQU0sQ0FBQztJQUMxQyxJQUFJLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDOUIsS0FBSztJQUNMLEtBQUssRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFO0lBQ2xDLEtBQUssRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsT0FBTyxFQUFFO0lBQzNCLG9CQUFvQixFQUFFLGNBQWMsQ0FBQyxPQUFPLEVBQUU7Q0FDL0MsQ0FBQyxDQUFBO0FBR1csUUFBQSxtQkFBbUIsR0FBRyxPQUFDLENBQUMsTUFBTSxDQUFDO0lBQzFDLElBQUksRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRTtJQUN6QyxLQUFLLEVBQUUsS0FBSyxDQUFDLFFBQVEsRUFBRTtJQUN2QixLQUFLLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRTtJQUNsQyxLQUFLLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLE9BQU8sRUFBRTtJQUMzQixTQUFTLEVBQUUsT0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNqQyxvQkFBb0IsRUFBRSxjQUFjLENBQUMsT0FBTyxFQUFFO0NBQy9DLENBQUMsQ0FBQTtBQUdXLFFBQUEsMkJBQTJCLEdBQUcsT0FBQyxDQUFDLE1BQU0sQ0FBQztJQUNsRCxTQUFTLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0lBQzVDLFNBQVMsRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFO0lBQ3JCLGNBQWMsRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFO0NBQzNCLENBQUMsQ0FBQTtBQUtXLFFBQUEsbUJBQW1CLEdBQUcsT0FBQyxDQUFDLE1BQU0sQ0FBQztJQUMxQyxxQkFBcUIsRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUN4QyxXQUFXLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0NBQ3hDLENBQUMsQ0FBQSJ9