"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateRepApplicationStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const sales_commission_1 = require("../../modules/sales-commission");
const sales_rep_email_1 = require("./sales-rep-email");
const invalid = (message) => new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, message);
const WHY_NOT = {
    invited: "hasn't been submitted yet",
    approved: "was already approved",
    declined: "was already declined",
    canceled: "was canceled by the recruiter",
};
/**
 * Loads an application the owner is about to decide on. Only an application
 * the candidate has submitted can be decided, and once.
 */
exports.validateRepApplicationStep = (0, workflows_sdk_1.createStep)("validate-rep-application", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const invite = await service.retrieveRepInvite(input.invite_id);
    if (invite.status !== "applied") {
        throw invalid(`This application ${WHY_NOT[invite.status] ?? "can't be decided"}`);
    }
    const recruiter = await service.retrieveSalesRep(invite.recruiter_sales_rep_id);
    if (input.for_approval) {
        if (!recruiter.is_active) {
            throw invalid(`${recruiter.name} is inactive. Reactivate them first, or decline this application`);
        }
        await (0, sales_rep_email_1.assertEmailAvailable)(service, invite.email);
    }
    return new workflows_sdk_1.StepResponse({
        invite,
        recruiter: { id: recruiter.id, name: recruiter.name, email: recruiter.email },
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdGUtcmVwLWFwcGxpY2F0aW9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy92YWxpZGF0ZS1yZXAtYXBwbGljYXRpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQXVEO0FBQ3ZELHFFQUE0RTtBQUM1RSxxRUFBd0U7QUFFeEUsdURBQXdEO0FBUXhELE1BQU0sT0FBTyxHQUFHLENBQUMsT0FBZSxFQUFFLEVBQUUsQ0FDbEMsSUFBSSxtQkFBVyxDQUFDLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQTtBQUUxRCxNQUFNLE9BQU8sR0FBMkI7SUFDdEMsT0FBTyxFQUFFLDJCQUEyQjtJQUNwQyxRQUFRLEVBQUUsc0JBQXNCO0lBQ2hDLFFBQVEsRUFBRSxzQkFBc0I7SUFDaEMsUUFBUSxFQUFFLCtCQUErQjtDQUMxQyxDQUFBO0FBRUQ7OztHQUdHO0FBQ1UsUUFBQSwwQkFBMEIsR0FBRyxJQUFBLDBCQUFVLEVBQ2xELDBCQUEwQixFQUMxQixLQUFLLEVBQUUsS0FBc0MsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDOUQsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBRUQsTUFBTSxNQUFNLEdBQUcsTUFBTSxPQUFPLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFBO0lBQy9ELElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUNoQyxNQUFNLE9BQU8sQ0FBQyxvQkFBb0IsT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxrQkFBa0IsRUFBRSxDQUFDLENBQUE7SUFDbkYsQ0FBQztJQUVELE1BQU0sU0FBUyxHQUFHLE1BQU0sT0FBTyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFBO0lBQy9FLElBQUksS0FBSyxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDekIsTUFBTSxPQUFPLENBQ1gsR0FBRyxTQUFTLENBQUMsSUFBSSxrRUFBa0UsQ0FDcEYsQ0FBQTtRQUNILENBQUM7UUFDRCxNQUFNLElBQUEsc0NBQW9CLEVBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUNuRCxDQUFDO0lBRUQsT0FBTyxJQUFJLDRCQUFZLENBQUM7UUFDdEIsTUFBTTtRQUNOLFNBQVMsRUFBRSxFQUFFLEVBQUUsRUFBRSxTQUFTLENBQUMsRUFBRSxFQUFFLElBQUksRUFBRSxTQUFTLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxTQUFTLENBQUMsS0FBSyxFQUFFO0tBQzlFLENBQUMsQ0FBQTtBQUNKLENBQUMsQ0FDRixDQUFBIn0=