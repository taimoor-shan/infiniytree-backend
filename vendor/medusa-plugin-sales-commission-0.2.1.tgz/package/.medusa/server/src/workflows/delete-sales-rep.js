"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteSalesRepWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const delete_rep_records_1 = require("./steps/delete-rep-records");
const soft_delete_sales_rep_1 = require("./steps/soft-delete-sales-rep");
const validate_rep_deletion_1 = require("./steps/validate-rep-deletion");
const revoke_portal_access_1 = require("./revoke-portal-access");
/**
 * Deletes a rep who has no money on record and nothing still running: ends
 * their portal login, withdraws the invitations they sent, removes what
 * belongs to them, then the rep. Refused with every reason that is in the way
 * otherwise; such a rep is deactivated instead. Each step is undone if a later
 * one fails.
 */
exports.deleteSalesRepWorkflow = (0, workflows_sdk_1.createWorkflow)("delete-sales-rep", function (input) {
    (0, validate_rep_deletion_1.validateRepDeletionStep)({ id: input.id });
    revoke_portal_access_1.revokePortalAccessWorkflow.runAsStep({
        input: { sales_rep_id: input.id },
    });
    const removed = (0, delete_rep_records_1.deleteRepRecordsStep)({
        id: input.id,
        deleted_by: input.deleted_by,
    });
    (0, soft_delete_sales_rep_1.softDeleteSalesRepStep)({ id: input.id });
    return new workflows_sdk_1.WorkflowResponse(removed);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVsZXRlLXNhbGVzLXJlcC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3MvZGVsZXRlLXNhbGVzLXJlcC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxRUFHMEM7QUFDMUMsbUVBQWlFO0FBQ2pFLHlFQUFzRTtBQUN0RSx5RUFBdUU7QUFDdkUsaUVBQW1FO0FBT25FOzs7Ozs7R0FNRztBQUNVLFFBQUEsc0JBQXNCLEdBQUcsSUFBQSw4QkFBYyxFQUNsRCxrQkFBa0IsRUFDbEIsVUFBVSxLQUFrQztJQUMxQyxJQUFBLCtDQUF1QixFQUFDLEVBQUUsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFBO0lBQ3pDLGlEQUEwQixDQUFDLFNBQVMsQ0FBQztRQUNuQyxLQUFLLEVBQUUsRUFBRSxZQUFZLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRTtLQUNsQyxDQUFDLENBQUE7SUFDRixNQUFNLE9BQU8sR0FBRyxJQUFBLHlDQUFvQixFQUFDO1FBQ25DLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFBRTtRQUNaLFVBQVUsRUFBRSxLQUFLLENBQUMsVUFBVTtLQUM3QixDQUFDLENBQUE7SUFDRixJQUFBLDhDQUFzQixFQUFDLEVBQUUsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFBO0lBRXhDLE9BQU8sSUFBSSxnQ0FBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQTtBQUN0QyxDQUFDLENBQ0YsQ0FBQSJ9