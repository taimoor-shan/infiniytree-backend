"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createSalesRepStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const sales_commission_1 = require("../../modules/sales-commission");
const sales_rep_email_1 = require("./sales-rep-email");
exports.createSalesRepStep = (0, workflows_sdk_1.createStep)("create-sales-rep", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const email = (0, sales_rep_email_1.normalizeEmail)(input.email);
    await (0, sales_rep_email_1.assertEmailAvailable)(service, email);
    const salesRep = await service.createSalesReps({
        ...input,
        name: input.name.trim(),
        email,
    });
    return new workflows_sdk_1.StepResponse(salesRep, salesRep.id);
}, async (salesRepId, { container }) => {
    if (!salesRepId) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.deleteSalesReps(salesRepId);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLXNhbGVzLXJlcC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3Mvc3RlcHMvY3JlYXRlLXNhbGVzLXJlcC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxRUFBNEU7QUFDNUUscUVBQXdFO0FBRXhFLHVEQUF3RTtBQVMzRCxRQUFBLGtCQUFrQixHQUFHLElBQUEsMEJBQVUsRUFDMUMsa0JBQWtCLEVBQ2xCLEtBQUssRUFBRSxLQUE4QixFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUN0RCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLEtBQUssR0FBRyxJQUFBLGdDQUFjLEVBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFBO0lBQ3pDLE1BQU0sSUFBQSxzQ0FBb0IsRUFBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUE7SUFFMUMsTUFBTSxRQUFRLEdBQUcsTUFBTSxPQUFPLENBQUMsZUFBZSxDQUFDO1FBQzdDLEdBQUcsS0FBSztRQUNSLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRTtRQUN2QixLQUFLO0tBQ04sQ0FBQyxDQUFBO0lBRUYsT0FBTyxJQUFJLDRCQUFZLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQTtBQUNoRCxDQUFDLEVBQ0QsS0FBSyxFQUFFLFVBQVUsRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDbEMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2hCLE9BQU07SUFDUixDQUFDO0lBQ0QsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxPQUFPLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQyxDQUFBO0FBQzNDLENBQUMsQ0FDRixDQUFBIn0=