"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const submit_rep_application_1 = require("../../../../workflows/submit-rep-application");
/**
 * A candidate applies through their invite link. Public, like the page. The
 * application is only a request: the owner approves it before anything is
 * created or paid.
 */
async function POST(req, res) {
    res.setHeader("Cache-Control", "no-store");
    const { result } = await (0, submit_rep_application_1.submitRepApplicationWorkflow)(req.scope).run({
        input: { ...req.validatedBody, token: req.params.token },
    });
    res.status(201).json({ application: result });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLWludml0ZXMvW3Rva2VuXS9hcHBseS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVNBLG9CQVdDO0FBbkJELHlGQUEyRjtBQUczRjs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBcUMsRUFDckMsR0FBbUI7SUFFbkIsR0FBRyxDQUFDLFNBQVMsQ0FBQyxlQUFlLEVBQUUsVUFBVSxDQUFDLENBQUE7SUFFMUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sSUFBQSxxREFBNEIsRUFBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDO1FBQ25FLEtBQUssRUFBRSxFQUFFLEdBQUcsR0FBRyxDQUFDLGFBQWEsRUFBRSxLQUFLLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7S0FDekQsQ0FBQyxDQUFBO0lBRUYsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxXQUFXLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQTtBQUMvQyxDQUFDIn0=