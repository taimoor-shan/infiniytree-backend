"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setRepReferralWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const create_rep_referral_1 = require("./steps/create-rep-referral");
const end_open_rep_referral_1 = require("./steps/end-open-rep-referral");
const resolve_effective_from_1 = require("./steps/resolve-effective-from");
const validate_rep_referral_1 = require("./steps/validate-rep-referral");
/**
 * Sets who referred a rep and the Level 2 rate that referrer earns on the
 * rep's clients, from the start of today (Budapest). A change ends the open
 * referral when the new one starts.
 */
exports.setRepReferralWorkflow = (0, workflows_sdk_1.createWorkflow)("set-rep-referral", function (input) {
    (0, validate_rep_referral_1.validateRepReferralStep)(input);
    const now = (0, resolve_effective_from_1.resolveEffectiveFromStep)();
    (0, end_open_rep_referral_1.endOpenRepReferralStep)((0, workflows_sdk_1.transform)({ input, now }, ({ input, now }) => ({
        referred_sales_rep_id: input.referred_sales_rep_id,
        ended_at: now,
        ended_by: input.actor_id ?? null,
    })));
    const referral = (0, create_rep_referral_1.createRepReferralStep)((0, workflows_sdk_1.transform)({ input, now }, ({ input, now }) => ({
        referrer_sales_rep_id: input.referrer_sales_rep_id,
        referred_sales_rep_id: input.referred_sales_rep_id,
        level2_rate: input.level2_rate,
        starts_at: now,
        created_by: input.actor_id ?? null,
    })));
    return new workflows_sdk_1.WorkflowResponse(referral);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2V0LXJlcC1yZWZlcnJhbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3Mvc2V0LXJlcC1yZWZlcnJhbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxRUFJMEM7QUFDMUMscUVBQW1FO0FBQ25FLHlFQUFzRTtBQUN0RSwyRUFBeUU7QUFDekUseUVBQXVFO0FBU3ZFOzs7O0dBSUc7QUFDVSxRQUFBLHNCQUFzQixHQUFHLElBQUEsOEJBQWMsRUFDbEQsa0JBQWtCLEVBQ2xCLFVBQVUsS0FBa0M7SUFDMUMsSUFBQSwrQ0FBdUIsRUFBQyxLQUFLLENBQUMsQ0FBQTtJQUU5QixNQUFNLEdBQUcsR0FBRyxJQUFBLGlEQUF3QixHQUFFLENBQUE7SUFFdEMsSUFBQSw4Q0FBc0IsRUFDcEIsSUFBQSx5QkFBUyxFQUFDLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDN0MscUJBQXFCLEVBQUUsS0FBSyxDQUFDLHFCQUFxQjtRQUNsRCxRQUFRLEVBQUUsR0FBRztRQUNiLFFBQVEsRUFBRSxLQUFLLENBQUMsUUFBUSxJQUFJLElBQUk7S0FDakMsQ0FBQyxDQUFDLENBQ0osQ0FBQTtJQUVELE1BQU0sUUFBUSxHQUFHLElBQUEsMkNBQXFCLEVBQ3BDLElBQUEseUJBQVMsRUFBQyxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQzdDLHFCQUFxQixFQUFFLEtBQUssQ0FBQyxxQkFBcUI7UUFDbEQscUJBQXFCLEVBQUUsS0FBSyxDQUFDLHFCQUFxQjtRQUNsRCxXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVc7UUFDOUIsU0FBUyxFQUFFLEdBQUc7UUFDZCxVQUFVLEVBQUUsS0FBSyxDQUFDLFFBQVEsSUFBSSxJQUFJO0tBQ25DLENBQUMsQ0FBQyxDQUNKLENBQUE7SUFFRCxPQUFPLElBQUksZ0NBQWdCLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDdkMsQ0FBQyxDQUNGLENBQUEifQ==