"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.endRepReferralWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const end_open_rep_referral_1 = require("./steps/end-open-rep-referral");
const resolve_effective_from_1 = require("./steps/resolve-effective-from");
exports.endRepReferralWorkflow = (0, workflows_sdk_1.createWorkflow)("end-rep-referral", function (input) {
    const endedAt = (0, resolve_effective_from_1.resolveEffectiveFromStep)();
    const referral = (0, end_open_rep_referral_1.endOpenRepReferralStep)((0, workflows_sdk_1.transform)({ input, endedAt }, ({ input, endedAt }) => ({
        referred_sales_rep_id: input.referred_sales_rep_id,
        ended_at: endedAt,
        ended_by: input.actor_id ?? null,
        required: true,
    })));
    return new workflows_sdk_1.WorkflowResponse(referral);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW5kLXJlcC1yZWZlcnJhbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3MvZW5kLXJlcC1yZWZlcnJhbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxRUFJMEM7QUFDMUMseUVBQXNFO0FBQ3RFLDJFQUF5RTtBQU81RCxRQUFBLHNCQUFzQixHQUFHLElBQUEsOEJBQWMsRUFDbEQsa0JBQWtCLEVBQ2xCLFVBQVUsS0FBa0M7SUFDMUMsTUFBTSxPQUFPLEdBQUcsSUFBQSxpREFBd0IsR0FBRSxDQUFBO0lBRTFDLE1BQU0sUUFBUSxHQUFHLElBQUEsOENBQXNCLEVBQ3JDLElBQUEseUJBQVMsRUFBQyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ3JELHFCQUFxQixFQUFFLEtBQUssQ0FBQyxxQkFBcUI7UUFDbEQsUUFBUSxFQUFFLE9BQU87UUFDakIsUUFBUSxFQUFFLEtBQUssQ0FBQyxRQUFRLElBQUksSUFBSTtRQUNoQyxRQUFRLEVBQUUsSUFBSTtLQUNmLENBQUMsQ0FBQyxDQUNKLENBQUE7SUFFRCxPQUFPLElBQUksZ0NBQWdCLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDdkMsQ0FBQyxDQUNGLENBQUEifQ==