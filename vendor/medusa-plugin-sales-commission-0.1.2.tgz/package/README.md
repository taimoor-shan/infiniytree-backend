# medusa-plugin-sales-commission

Sales commission for the Infinytree shop (Medusa v2, pinned to **2.18.0**).

Every B2B client is permanently assigned to a salesperson at a per-client rate. Each paid order earns that salesperson a commission. A salesperson who brought in another salesperson also earns a Level 2 share on top. Admins manage assignments, adjustments and payouts and export a monthly report.

Spec: the approved *Infinytree Sales Commission System — Proposal*.

## Rules

| Topic | Rule |
|---|---|
| Base | Net product value: `item_total − item_tax_total`. No VAT, no shipping, after discounts. Orders with a base of zero or less earn nothing |
| When | Once **all** of the order's payments are captured. Counts in the month of the (latest) capture, in the plugin's `timezone` |
| Who and rate | The assignment in effect when the order was **placed** (`starts_at ≤ order.created_at < ends_at`). The rate is copied onto the entry and never recalculated |
| Assignments | Changing the rep or rate ends the open assignment and starts a new one at the same instant. One open assignment per customer. History is kept |
| Effective date | Every change (assigning, moving, changing a rate, ending, setting or ending a referral) takes effect from the **start of that day in Budapest**, so an order placed earlier the same day counts for the new rep or rate. Days before keep what they had |
| Level 2 | The referrer of the credited rep earns `net value × level2 rate` on top, with a rate per rep-to-rep relationship. One level only; self-referral and loops are rejected |
| Currency | The order's currency (EUR or HUF). Rounded per entry (HUF to whole forint). Totals are per currency, never converted |
| Voids | Order canceled, or fully refunded without being canceled. Partial refunds and returns are corrected with an adjustment. A void in the month the commission was earned removes it; a later void shows as a **negative reversal in the month of the void**, so past months never change |
| Adjustments | Signed, non-zero, reason required, record who made them. Append-only: add a reversing one to undo |
| Payouts | Recorded manually: month, date, amount, currency, reference or note. A month is `paid`, `partial` or `unpaid`. A payout recorded by mistake can be removed (soft delete) |
| Contracts | PDF, JPEG or PNG up to 10 MB, stored in the database and returned only by an admin-only download route (`file-local` serves "private" uploads from a public folder, so the file module is not used) |

## How a payment reaches the plugin

```
Billingo: payment received
  → Make.com scenario
  → POST /admin/payments/{payment_id}/capture        (secret API key)
  → Medusa emits payment.captured
  → recordOrderCommission workflow → CommissionEntry (direct, + Level 2)

order.canceled | payment.refunded (full) → voidOrderCommission workflow
daily at 02:15 → reconcile-commissions job re-runs both for the last 7 days
```

Everything is idempotent: an order is recorded once (unique per order and entry type, plus a per-order lock), so the event, the job and a manual re-run can't double-count. The job covers events lost to a restart and payments captured without an event (such as Stripe auto-capture, if enabled later).

### Make.com scenario

1. In Medusa admin, Settings → Secret API Keys, create a key named `Make.com Billingo`. Send it as `Authorization: Basic {token}` (a Bearer header returns 401).
2. When Billingo reports the payment, look up the order: `GET /admin/orders/{order_id}?fields=id,payment_collections.payments.id,payment_collections.payments.captured_at`.
3. For each payment where `captured_at` is null: `POST /admin/payments/{payment_id}/capture`.
4. To cancel unpaid orders after the 5-day window: `POST /admin/orders/{order_id}/cancel`. This fires `order.canceled` to Make.com and to the plugin.

## Install

The backend installs the plugin from a tarball committed in its own repo (`vendor/medusa-plugin-sales-commission-<version>.tgz`, about 90 kB), so `yarn install` on the server needs no registry and no token.

Register it in `medusa-config.ts`:

```ts
plugins: [
  {
    resolve: "medusa-plugin-sales-commission",
    options: {
      timezone: "Europe/Budapest",          // default; decides which month a payment counts in
      portal_url: process.env.SALES_PORTAL_URL, // where reps sign in, e.g. https://shop.example/sales-portal
    },
  },
],
```

Create its tables once per database, and again after a release that adds a migration. In production run it from the build, next to where the server starts:

```bash
npx medusa db:migrate           # production: cd .medusa/server && npx medusa db:migrate
```

### Releasing a new version

A version tag does the release. Once your change is committed in the plugin repo:

```bash
npm version patch                       # bumps package.json, commits it and tags v<version>
git push origin master --follow-tags
```

The **Release to backend** workflow (`.github/workflows/release-to-backend.yml`) then runs the unit tests, builds the plugin, packs it into `infiniytree-backend/vendor/` and opens a pull request in the backend that changes only `package.json`, `yarn.lock` and `vendor/`. The pull request says whether the release needs `db:migrate`. Merge it and deploy the backend as usual: pull, `yarn install`, `yarn build`, migrate if the pull request says so, restart. If two release pull requests are open at once, merge the newer one and close the older one: both replace the same tarball.

**One-time setup.** The workflow needs a token that can push to the backend repo, which the workflow's own token can't.

1. GitHub, Settings, Developer settings, Personal access tokens, Fine-grained tokens, Generate new token. Resource owner `taimoor-shan`, repository access *Only select repositories* with `infiniytree-backend`, permissions *Contents* and *Pull requests* both *Read and write*. Pick an expiry and note it: after that date the workflow fails with an authentication error until the token is replaced.
2. Store it as a secret of this repo. The command asks for the value and prints nothing:

```bash
gh secret set BACKEND_REPO_TOKEN --repo taimoor-shan/medusa-plugin-sales-commission
```

**Dry run.** Actions, Release to backend, Run workflow (a dry run is the default), or:

```bash
gh workflow run release-to-backend.yml --repo taimoor-shan/medusa-plugin-sales-commission -f dry_run=true
```

It builds and vendors, prints the diff and the pull request text and checks that the token can push, but pushes nothing and opens nothing. Run it after the setup and after any change to the workflow.

**Without GitHub Actions.** The local release still works:

```bash
npm version patch --no-git-tag-version    # a release needs a new version
npm run release:backend                   # builds, packs into ../infiniytree-backend/vendor/ and points the backend at it
```

Then commit `package.json`, `yarn.lock` and `vendor/` in the backend, tag the plugin (`git tag v<version> && git push --tags`) and deploy as above.

### Developing against the backend

Run `npx medusa plugin:develop` here: it rebuilds on change and pushes into the backend through yalc. The backend needs `yalc` as a devDependency and a one-time `npx medusa plugin:add medusa-plugin-sales-commission`. yalc swaps the backend's dependency for `file:.yalc/...` while you work, so before committing in the backend run `npx yalc retreat medusa-plugin-sales-commission`: it puts the vendored tarball back in `package.json`.

After a rebuild the admin can keep showing the old UI, from two caches: Vite's dependency cache in the backend and the browser's copy of it (Vite serves it as immutable). Stop the dev server, delete `node_modules/.vite` in the backend, start it, then hard-reload the admin tab (Cmd/Ctrl+Shift+R).

## Admin API

All routes are under `/admin` and need an admin session or API key.

| Route | Purpose |
|---|---|
| `GET, POST /admin/sales-reps` | List (search `q`, filter `is_active`) and create |
| `GET, POST /admin/sales-reps/:id` | Rep with their referrer (`referral`) and the reps they referred; update, including `is_active` |
| `GET, POST /admin/sales-reps/:id/contracts` | List and upload (JSON, base64) |
| `GET /admin/sales-reps/:id/contracts/:contract_id/download` | Download a contract |
| `POST, DELETE /admin/sales-reps/:id/referral` | Set or replace the referrer and Level 2 rate; end it |
| `GET /admin/sales-reps/:id/clients` | The rep's clients, current and past |
| `GET, POST, DELETE /admin/customers/:id/sales-rep-assignment` | Current assignment and history; assign, move or change the rate; end |
| `GET, POST /admin/sales-reps/:id/adjustments` | List and add an adjustment |
| `GET, POST /admin/sales-reps/:id/payouts` | List and record a payout |
| `DELETE /admin/sales-commission/payouts/:id` | Remove a payout recorded by mistake |
| `GET /admin/sales-reps/:id/statement?period=YYYY-MM[&format=csv]` | A rep's month |
| `GET /admin/sales-commission/report?period=YYYY-MM[&format=csv]` | Every rep's month per currency |

`period` defaults to the current month. CSV is RFC 4180 with CRLF line endings and a UTF-8 BOM so Excel shows accents correctly. Numbers use a dot as the decimal separator, so in Hungarian Excel use Data → From Text and pick "." as the decimal separator. Text starting with `= + - @` is prefixed with `'` so a client name can't run as a formula.

The module's data is also reachable through the query graph: `customer.client_assignment` (read-only link, no link table).

## Admin UI

- **Sales Reps** (sidebar): list, create, and a detail page with profile, monthly statement (totals, paid status, adjustments, payouts, CSV), referral, clients and contracts.
- **Commission report** (under Sales Reps): all reps for a month, with CSV export.
- **Sales rep widget** on the customer page: assign, change or end, with history.

The admin UI is in English; the backend's admin has no translations configured.

## Sales portal

Reps sign in with Medusa's own auth as the `sales_rep` actor type. The plugin adds no login, register or invite routes of its own.

**Giving access.** Admin → Sales Reps → rep → Sales portal → Give access. This creates the rep's login with the auth module and links it to them. The admin passes on the portal's forgot-password link; the rep enters their email, follows Medusa's reset email, sets a password and signs in with `POST /auth/sales_rep/emailpass`. Reset links last 15 minutes (fixed in Medusa) and are only issued when the rep asks for one.

- An email whose login is linked to a customer account (or to any other account) is **refused**. A login linked to nothing is taken over: that is what Medusa leaves behind when a customer is deleted (it keeps the login and only unlinks the customer), or a registration that was never finished. Its old password is replaced with a random one first, because Medusa's public register routes accept unverified emails and whoever set that password must not get into the rep's portal; the rep sets their own with forgot-password. A login that belongs to an admin user is reused, and a rep keeps their own login after access is ended and granted again.
- **Ending access** unlinks the login. Every portal request checks that link, so a token that is still valid stops working at once. A deactivated rep is turned away too.
- The password-reset email is sent by the backend's existing `auth.password_reset` subscriber, which links reps to `/sales-portal/reset-password`.

**Where reps sign in.** The plugin ships no screens for reps. The Infinytree storefront serves them at `/<country>/sales-portal` (sign-in form and overview on the same page, plus `forgot-password`, `reset-password` and client and payout pages), calling the API below from its server. `portal_url` is that address *without* a country code, which the storefront's proxy adds. The Portal access drawer and the reset email are built from it: `<portal_url>/forgot-password?email=…`, `<portal_url>/reset-password?token=…`, and `<portal_url>/login` (which the storefront sends on to the portal's own page).

**API.** All routes are read-only and need `Authorization: Bearer <token>` from a rep who currently has access. They are meant to be called from the storefront's server, so no CORS headers are added.

| Route | Returns |
|---|---|
| `GET /sales-portal/me` | name, email, phone (no internal notes) |
| `GET /sales-portal/summary?period=YYYY-MM` | the month's totals per currency |
| `GET /sales-portal/statement?period=YYYY-MM` | the month's lines and totals |
| `GET /sales-portal/clients?period=YYYY-MM` | the rep's clients by company name, rate, since when, and the month's turnover and commission per currency |
| `GET /sales-portal/clients/:customer_id/orders` | a client's paid orders: number, date, net value, currency, rate, commission, status (paged) |
| `GET /sales-portal/statements` | every month with activity, newest first, with totals (paged) |
| `GET /sales-portal/payouts` | date, month, amount, currency, reference |

What a rep never gets: addresses, emails, order contents, internal ids or admin notes. Responses are built field by field from named values, never by passing a database row through. A direct commission shows the order number and client; Level 2 is summed per referred rep and shows neither their clients nor their orders. A client that isn't (or wasn't) the rep's own returns the same 404 as one that doesn't exist. Adjustment reasons and payout references are shown to the rep.

## Development

```bash
npm run test:unit                                   # pure rules: money, months, commission, voids, report, CSV
DB_HOST=localhost DB_USERNAME=<pg user> npm run test:integration:modules   # models and DB constraints

npx medusa plugin:db:generate                       # after changing models (needs DB_* in .env)
```

End-to-end behaviour (API, workflows, subscribers, job) is covered by the backend's `integration-tests/http/sales-commission-*.spec.ts`, which exercise the plugin through the real app and pay orders with `markPaymentCollectionAsPaid`, the same capture path Make.com uses.

Layout: `src/modules/sales-commission` (data models, service, migration), `src/lib` (pure functions), `src/workflows`, `src/subscribers`, `src/jobs`, `src/api/admin`, `src/links`, `src/admin`.
