"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminSetRepReferral = exports.AdminUploadSalesRepContract = exports.AdminUpdateSalesRep = exports.AdminCreateSalesRep = exports.AdminGetSalesRepsParams = void 0;
const zod_1 = require("@medusajs/framework/zod");
const validators_1 = require("@medusajs/medusa/api/utils/validators");
exports.AdminGetSalesRepsParams = (0, validators_1.createFindParams)({
    limit: 50,
    offset: 0,
}).extend({
    q: zod_1.z.string().optional(),
    is_active: zod_1.z
        .enum(["true", "false"])
        .transform((value) => value === "true")
        .optional(),
});
const email = zod_1.z.string().trim().pipe(zod_1.z.email());
/** The currencies a rep can be paid in */
const payoutCurrency = zod_1.z
    .string()
    .transform((code) => code.toLowerCase())
    .pipe(zod_1.z.enum(["eur", "huf"]));
/** Percent a client who joins through the rep's link is credited at; null switches the link off */
const clientRate = zod_1.z.number().min(0).max(100);
exports.AdminCreateSalesRep = zod_1.z.object({
    name: zod_1.z.string().trim().min(1),
    email,
    phone: zod_1.z.string().trim().nullish(),
    notes: zod_1.z.string().nullish(),
    payout_currency_code: payoutCurrency.nullish(),
    default_client_rate: clientRate.nullish(),
});
exports.AdminUpdateSalesRep = zod_1.z.object({
    name: zod_1.z.string().trim().min(1).optional(),
    email: email.optional(),
    phone: zod_1.z.string().trim().nullish(),
    notes: zod_1.z.string().nullish(),
    is_active: zod_1.z.boolean().optional(),
    payout_currency_code: payoutCurrency.nullish(),
    default_client_rate: clientRate.nullish(),
});
exports.AdminUploadSalesRepContract = zod_1.z.object({
    file_name: zod_1.z.string().trim().min(1).max(255),
    mime_type: zod_1.z.string(),
    content_base64: zod_1.z.string(),
});
exports.AdminSetRepReferral = zod_1.z.object({
    referrer_sales_rep_id: zod_1.z.string().min(1),
    level2_rate: zod_1.z.number().min(0).max(100),
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdG9ycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcGkvYWRtaW4vc2FsZXMtcmVwcy92YWxpZGF0b3JzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLGlEQUEyQztBQUMzQyxzRUFBd0U7QUFFM0QsUUFBQSx1QkFBdUIsR0FBRyxJQUFBLDZCQUFnQixFQUFDO0lBQ3RELEtBQUssRUFBRSxFQUFFO0lBQ1QsTUFBTSxFQUFFLENBQUM7Q0FDVixDQUFDLENBQUMsTUFBTSxDQUFDO0lBQ1IsQ0FBQyxFQUFFLE9BQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDeEIsU0FBUyxFQUFFLE9BQUM7U0FDVCxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7U0FDdkIsU0FBUyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxLQUFLLEtBQUssTUFBTSxDQUFDO1NBQ3RDLFFBQVEsRUFBRTtDQUNkLENBQUMsQ0FBQTtBQUdGLE1BQU0sS0FBSyxHQUFHLE9BQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsT0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUE7QUFFL0MsMENBQTBDO0FBQzFDLE1BQU0sY0FBYyxHQUFHLE9BQUM7S0FDckIsTUFBTSxFQUFFO0tBQ1IsU0FBUyxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7S0FDdkMsSUFBSSxDQUFDLE9BQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFBO0FBRS9CLG1HQUFtRztBQUNuRyxNQUFNLFVBQVUsR0FBRyxPQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQTtBQUVoQyxRQUFBLG1CQUFtQixHQUFHLE9BQUMsQ0FBQyxNQUFNLENBQUM7SUFDMUMsSUFBSSxFQUFFLE9BQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQzlCLEtBQUs7SUFDTCxLQUFLLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRTtJQUNsQyxLQUFLLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLE9BQU8sRUFBRTtJQUMzQixvQkFBb0IsRUFBRSxjQUFjLENBQUMsT0FBTyxFQUFFO0lBQzlDLG1CQUFtQixFQUFFLFVBQVUsQ0FBQyxPQUFPLEVBQUU7Q0FDMUMsQ0FBQyxDQUFBO0FBR1csUUFBQSxtQkFBbUIsR0FBRyxPQUFDLENBQUMsTUFBTSxDQUFDO0lBQzFDLElBQUksRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRTtJQUN6QyxLQUFLLEVBQUUsS0FBSyxDQUFDLFFBQVEsRUFBRTtJQUN2QixLQUFLLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRTtJQUNsQyxLQUFLLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLE9BQU8sRUFBRTtJQUMzQixTQUFTLEVBQUUsT0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNqQyxvQkFBb0IsRUFBRSxjQUFjLENBQUMsT0FBTyxFQUFFO0lBQzlDLG1CQUFtQixFQUFFLFVBQVUsQ0FBQyxPQUFPLEVBQUU7Q0FDMUMsQ0FBQyxDQUFBO0FBR1csUUFBQSwyQkFBMkIsR0FBRyxPQUFDLENBQUMsTUFBTSxDQUFDO0lBQ2xELFNBQVMsRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDNUMsU0FBUyxFQUFFLE9BQUMsQ0FBQyxNQUFNLEVBQUU7SUFDckIsY0FBYyxFQUFFLE9BQUMsQ0FBQyxNQUFNLEVBQUU7Q0FDM0IsQ0FBQyxDQUFBO0FBS1csUUFBQSxtQkFBbUIsR0FBRyxPQUFDLENBQUMsTUFBTSxDQUFDO0lBQzFDLHFCQUFxQixFQUFFLE9BQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQ3hDLFdBQVcsRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7Q0FDeEMsQ0FBQyxDQUFBIn0=