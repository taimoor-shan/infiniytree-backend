"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.approveCommissionPeriodsStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const approval_1 = require("../../lib/approval");
const period_1 = require("../../lib/period");
const sales_commission_1 = require("../../modules/sales-commission");
const period_status_1 = require("../../utils/period-status");
const invalid = (message) => new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, message);
/**
 * Approves the months after the last approved one, up to `through`. From then
 * on what they earned is payable.
 */
exports.approveCommissionPeriodsStep = (0, workflows_sdk_1.createStep)("approve-commission-periods", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    if (!(0, period_1.isPeriod)(input.through)) {
        throw invalid(`${input.through} is not a month (YYYY-MM)`);
    }
    const approvals = await service.listPeriodApprovals({}, { select: ["period"] });
    const approvedThrough = (0, approval_1.latestApproved)(approvals.map((row) => row.period));
    const error = (0, approval_1.approvalError)({
        through: input.through,
        approvedThrough,
        currentPeriod: (0, period_1.toPeriod)(new Date(), service.getOptions().timezone),
    });
    if (error === "not_ended") {
        throw invalid(`${input.through} hasn't ended yet. A month can be approved once it is over`);
    }
    if (error === "already_approved") {
        throw invalid(`${input.through} is already approved`);
    }
    const months = (0, approval_1.monthsToApprove)({
        through: input.through,
        approvedThrough,
        firstActivity: await (0, period_status_1.firstActivityPeriod)(service),
    });
    const now = new Date();
    const created = await service.createPeriodApprovals(months.map((period) => ({
        period,
        approved_by: input.approved_by ?? null,
        approved_at: now,
    })));
    return new workflows_sdk_1.StepResponse(created, created.map((row) => row.id));
}, async (ids, { container }) => {
    if (!ids?.length) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.deletePeriodApprovals(ids);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwcm92ZS1jb21taXNzaW9uLXBlcmlvZHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL3N0ZXBzL2FwcHJvdmUtY29tbWlzc2lvbi1wZXJpb2RzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFEQUF1RDtBQUN2RCxxRUFBNEU7QUFDNUUsaURBSTJCO0FBQzNCLDZDQUFxRDtBQUNyRCxxRUFBd0U7QUFFeEUsNkRBQStEO0FBUS9ELE1BQU0sT0FBTyxHQUFHLENBQUMsT0FBZSxFQUFFLEVBQUUsQ0FDbEMsSUFBSSxtQkFBVyxDQUFDLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQTtBQUUxRDs7O0dBR0c7QUFDVSxRQUFBLDRCQUE0QixHQUFHLElBQUEsMEJBQVUsRUFDcEQsNEJBQTRCLEVBQzVCLEtBQUssRUFBRSxLQUF3QyxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUNoRSxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxJQUFJLENBQUMsSUFBQSxpQkFBUSxFQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1FBQzdCLE1BQU0sT0FBTyxDQUFDLEdBQUcsS0FBSyxDQUFDLE9BQU8sMkJBQTJCLENBQUMsQ0FBQTtJQUM1RCxDQUFDO0lBRUQsTUFBTSxTQUFTLEdBQUcsTUFBTSxPQUFPLENBQUMsbUJBQW1CLENBQUMsRUFBRSxFQUFFLEVBQUUsTUFBTSxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBQy9FLE1BQU0sZUFBZSxHQUFHLElBQUEseUJBQWMsRUFBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQTtJQUMxRSxNQUFNLEtBQUssR0FBRyxJQUFBLHdCQUFhLEVBQUM7UUFDMUIsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO1FBQ3RCLGVBQWU7UUFDZixhQUFhLEVBQUUsSUFBQSxpQkFBUSxFQUFDLElBQUksSUFBSSxFQUFFLEVBQUUsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFDLFFBQVEsQ0FBQztLQUNuRSxDQUFDLENBQUE7SUFDRixJQUFJLEtBQUssS0FBSyxXQUFXLEVBQUUsQ0FBQztRQUMxQixNQUFNLE9BQU8sQ0FDWCxHQUFHLEtBQUssQ0FBQyxPQUFPLDREQUE0RCxDQUM3RSxDQUFBO0lBQ0gsQ0FBQztJQUNELElBQUksS0FBSyxLQUFLLGtCQUFrQixFQUFFLENBQUM7UUFDakMsTUFBTSxPQUFPLENBQUMsR0FBRyxLQUFLLENBQUMsT0FBTyxzQkFBc0IsQ0FBQyxDQUFBO0lBQ3ZELENBQUM7SUFFRCxNQUFNLE1BQU0sR0FBRyxJQUFBLDBCQUFlLEVBQUM7UUFDN0IsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO1FBQ3RCLGVBQWU7UUFDZixhQUFhLEVBQUUsTUFBTSxJQUFBLG1DQUFtQixFQUFDLE9BQU8sQ0FBQztLQUNsRCxDQUFDLENBQUE7SUFDRixNQUFNLEdBQUcsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFBO0lBQ3RCLE1BQU0sT0FBTyxHQUFHLE1BQU0sT0FBTyxDQUFDLHFCQUFxQixDQUNqRCxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ3RCLE1BQU07UUFDTixXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVcsSUFBSSxJQUFJO1FBQ3RDLFdBQVcsRUFBRSxHQUFHO0tBQ2pCLENBQUMsQ0FBQyxDQUNKLENBQUE7SUFFRCxPQUFPLElBQUksNEJBQVksQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUE7QUFDaEUsQ0FBQyxFQUNELEtBQUssRUFBRSxHQUFHLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQzNCLElBQUksQ0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLENBQUM7UUFDakIsT0FBTTtJQUNSLENBQUM7SUFDRCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLENBQUMsQ0FBQTtBQUMxQyxDQUFDLENBQ0YsQ0FBQSJ9