"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const portal_view_1 = require("../../../lib/portal-view");
const report_1 = require("../../../lib/report");
const period_activity_1 = require("../../../utils/period-activity");
const helpers_1 = require("../../admin/sales-commission/helpers");
const helpers_2 = require("../helpers");
const middlewares_1 = require("../middlewares");
/** The rep's clients by company name, with the month's turnover and commission. */
async function GET(req, res) {
    const rep = (0, middlewares_1.portalRep)(req);
    const { period } = (0, helpers_1.requestedPeriod)(req);
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const [{ data: assignments }, activity] = await Promise.all([
        query.graph({
            entity: "client_assignment",
            fields: [
                "customer_id",
                "commission_rate",
                "starts_at",
                "customer.company_name",
                "customer.first_name",
                "customer.last_name",
            ],
            filters: { sales_rep_id: rep.id, ends_at: null },
        }),
        (0, period_activity_1.loadPeriodActivity)(req.scope, { period, salesRepId: rep.id }),
    ]);
    res.json({
        period,
        clients: (0, portal_view_1.portalClients)({
            assignments: assignments.map((assignment) => ({
                customer_id: assignment.customer_id,
                client_name: (0, helpers_2.clientDisplayName)(assignment.customer),
                commission_rate: (0, helpers_2.toNumber)(assignment.commission_rate),
                starts_at: new Date(assignment.starts_at),
            })),
            lines: (0, report_1.statementLines)({ period, ...activity }),
        }),
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLXBvcnRhbC9jbGllbnRzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBVUEsa0JBaUNDO0FBMUNELHFEQUFxRTtBQUNyRSwwREFBd0Q7QUFDeEQsZ0RBQW9EO0FBQ3BELG9FQUFtRTtBQUNuRSxrRUFBc0U7QUFDdEUsd0NBQXdEO0FBQ3hELGdEQUEwQztBQUUxQyxtRkFBbUY7QUFDNUUsS0FBSyxVQUFVLEdBQUcsQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQy9ELE1BQU0sR0FBRyxHQUFHLElBQUEsdUJBQVMsRUFBQyxHQUFHLENBQUMsQ0FBQTtJQUMxQixNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsSUFBQSx5QkFBZSxFQUFDLEdBQUcsQ0FBQyxDQUFBO0lBQ3ZDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFBO0lBRWhFLE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsRUFBRSxRQUFRLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7UUFDMUQsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUNWLE1BQU0sRUFBRSxtQkFBbUI7WUFDM0IsTUFBTSxFQUFFO2dCQUNOLGFBQWE7Z0JBQ2IsaUJBQWlCO2dCQUNqQixXQUFXO2dCQUNYLHVCQUF1QjtnQkFDdkIscUJBQXFCO2dCQUNyQixvQkFBb0I7YUFDckI7WUFDRCxPQUFPLEVBQUUsRUFBRSxZQUFZLEVBQUUsR0FBRyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFO1NBQ2pELENBQUM7UUFDRixJQUFBLG9DQUFrQixFQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLEdBQUcsQ0FBQyxFQUFFLEVBQUUsQ0FBQztLQUM5RCxDQUFDLENBQUE7SUFFRixHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ1AsTUFBTTtRQUNOLE9BQU8sRUFBRSxJQUFBLDJCQUFhLEVBQUM7WUFDckIsV0FBVyxFQUFFLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQzVDLFdBQVcsRUFBRSxVQUFVLENBQUMsV0FBVztnQkFDbkMsV0FBVyxFQUFFLElBQUEsMkJBQWlCLEVBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQztnQkFDbkQsZUFBZSxFQUFFLElBQUEsa0JBQVEsRUFBQyxVQUFVLENBQUMsZUFBZSxDQUFDO2dCQUNyRCxTQUFTLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQzthQUMxQyxDQUFDLENBQUM7WUFDSCxLQUFLLEVBQUUsSUFBQSx1QkFBYyxFQUFDLEVBQUUsTUFBTSxFQUFFLEdBQUcsUUFBUSxFQUFFLENBQUM7U0FDL0MsQ0FBQztLQUNILENBQUMsQ0FBQTtBQUNKLENBQUMifQ==