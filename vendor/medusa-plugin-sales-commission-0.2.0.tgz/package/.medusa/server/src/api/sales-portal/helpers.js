"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.referredRepNames = exports.clientDisplayName = exports.toNumber = void 0;
const utils_1 = require("@medusajs/framework/utils");
const toNumber = (value) => utils_1.MathBN.convert(value).toNumber();
exports.toNumber = toNumber;
/** A customer's name for a rep: the company, else the person's name. */
const clientDisplayName = (customer) => customer?.company_name?.trim() ||
    [customer?.first_name, customer?.last_name].filter(Boolean).join(" ").trim() ||
    "Client";
exports.clientDisplayName = clientDisplayName;
/** Names of the reps behind a statement's Level 2 lines. */
const referredRepNames = async (container, lines) => {
    const repIds = [
        ...new Set(lines
            .map((line) => line.source_sales_rep_id)
            .filter((id) => !!id)),
    ];
    if (!repIds.length) {
        return new Map();
    }
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { data: reps } = await query.graph({
        entity: "sales_rep",
        fields: ["id", "name"],
        filters: { id: repIds },
    });
    return new Map(reps.map((rep) => [rep.id, rep.name]));
};
exports.referredRepNames = referredRepNames;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGVscGVycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9hcGkvc2FsZXMtcG9ydGFsL2hlbHBlcnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQ0EscURBQTZFO0FBR3RFLE1BQU0sUUFBUSxHQUFHLENBQUMsS0FBYyxFQUFVLEVBQUUsQ0FDakQsY0FBTSxDQUFDLE9BQU8sQ0FBQyxLQUFlLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQTtBQUQvQixRQUFBLFFBQVEsWUFDdUI7QUFFNUMsd0VBQXdFO0FBQ2pFLE1BQU0saUJBQWlCLEdBQUcsQ0FBQyxRQUlqQyxFQUFVLEVBQUUsQ0FDWCxRQUFRLEVBQUUsWUFBWSxFQUFFLElBQUksRUFBRTtJQUM5QixDQUFDLFFBQVEsRUFBRSxVQUFVLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFO0lBQzVFLFFBQVEsQ0FBQTtBQVBHLFFBQUEsaUJBQWlCLHFCQU9wQjtBQUVWLDREQUE0RDtBQUNyRCxNQUFNLGdCQUFnQixHQUFHLEtBQUssRUFDbkMsU0FBMEIsRUFDMUIsS0FBK0MsRUFDakIsRUFBRTtJQUNoQyxNQUFNLE1BQU0sR0FBRztRQUNiLEdBQUcsSUFBSSxHQUFHLENBQ1IsS0FBSzthQUNGLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDO2FBQ3ZDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsRUFBZ0IsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FDdEM7S0FDRixDQUFBO0lBQ0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNuQixPQUFPLElBQUksR0FBRyxFQUFFLENBQUE7SUFDbEIsQ0FBQztJQUVELE1BQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUE7SUFDaEUsTUFBTSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDdkMsTUFBTSxFQUFFLFdBQVc7UUFDbkIsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQztRQUN0QixPQUFPLEVBQUUsRUFBRSxFQUFFLEVBQUUsTUFBTSxFQUFFO0tBQ3hCLENBQUMsQ0FBQTtJQUVGLE9BQU8sSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDdkQsQ0FBQyxDQUFBO0FBdkJZLFFBQUEsZ0JBQWdCLG9CQXVCNUIifQ==