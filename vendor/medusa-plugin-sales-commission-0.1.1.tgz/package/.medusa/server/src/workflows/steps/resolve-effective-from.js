"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveEffectiveFromStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const period_1 = require("../../lib/period");
const sales_commission_1 = require("../../modules/sales-commission");
/**
 * When a change to an assignment or referral takes effect: the start of
 * today in the plugin's timezone. Orders placed earlier today still count
 * for the new rep or rate; everything before today keeps the old one.
 */
exports.resolveEffectiveFromStep = (0, workflows_sdk_1.createStep)("resolve-effective-from", async (_, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    return new workflows_sdk_1.StepResponse((0, period_1.startOfLocalDay)(new Date(), service.getOptions().timezone));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVzb2x2ZS1lZmZlY3RpdmUtZnJvbS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3Mvc3RlcHMvcmVzb2x2ZS1lZmZlY3RpdmUtZnJvbS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxRUFBNEU7QUFDNUUsNkNBQWtEO0FBQ2xELHFFQUF3RTtBQUd4RTs7OztHQUlHO0FBQ1UsUUFBQSx3QkFBd0IsR0FBRyxJQUFBLDBCQUFVLEVBQ2hELHdCQUF3QixFQUN4QixLQUFLLEVBQUUsQ0FBTyxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUMvQixNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFFRCxPQUFPLElBQUksNEJBQVksQ0FDckIsSUFBQSx3QkFBZSxFQUFDLElBQUksSUFBSSxFQUFFLEVBQUUsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUMzRCxDQUFBO0FBQ0gsQ0FBQyxDQUNGLENBQUEifQ==