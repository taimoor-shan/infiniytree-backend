"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const report_1 = require("../../../lib/report");
const period_activity_1 = require("../../../utils/period-activity");
const helpers_1 = require("../../admin/sales-commission/helpers");
const middlewares_1 = require("../middlewares");
/** The month's totals per currency: direct, Level 2, adjustments, total, paid. */
async function GET(req, res) {
    const { period } = (0, helpers_1.requestedPeriod)(req);
    const activity = await (0, period_activity_1.loadPeriodActivity)(req.scope, {
        period,
        salesRepId: (0, middlewares_1.portalRep)(req).id,
    });
    res.json({ period, totals: (0, report_1.summarize)((0, report_1.statementLines)({ period, ...activity })) });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLXBvcnRhbC9zdW1tYXJ5L3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBT0Esa0JBUUM7QUFkRCxnREFBK0Q7QUFDL0Qsb0VBQW1FO0FBQ25FLGtFQUFzRTtBQUN0RSxnREFBMEM7QUFFMUMsa0ZBQWtGO0FBQzNFLEtBQUssVUFBVSxHQUFHLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUMvRCxNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsSUFBQSx5QkFBZSxFQUFDLEdBQUcsQ0FBQyxDQUFBO0lBQ3ZDLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBQSxvQ0FBa0IsRUFBQyxHQUFHLENBQUMsS0FBSyxFQUFFO1FBQ25ELE1BQU07UUFDTixVQUFVLEVBQUUsSUFBQSx1QkFBUyxFQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7S0FDOUIsQ0FBQyxDQUFBO0lBRUYsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsSUFBQSxrQkFBUyxFQUFDLElBQUEsdUJBQWMsRUFBQyxFQUFFLE1BQU0sRUFBRSxHQUFHLFFBQVEsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUE7QUFDbEYsQ0FBQyJ9