"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ensurePortalAuthIdentityStep = void 0;
const crypto_1 = require("crypto");
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const portal_login_1 = require("../../lib/portal-login");
const PROVIDER = "emailpass";
/** A password nobody sees: the rep sets their own with forgot-password */
const unknownPassword = () => (0, crypto_1.randomBytes)(32).toString("base64url");
/**
 * The login (Medusa auth identity) for a rep's email, created through the auth
 * module's own `register` with a random password nobody sees: the rep sets
 * their first password with Medusa's forgot-password flow, which proves they
 * own the mailbox.
 *
 * An existing login is reused when it belongs to an admin user or was already
 * linked to this rep. One that is linked to nothing, such as what Medusa
 * leaves behind when it deletes a customer or a registration that was never
 * finished, is taken over, but only after its password is replaced by one
 * nobody knows. Anyone can register a login for any email through Medusa's
 * public register routes without proving they own it, so whoever set the old
 * password must not get into the rep's portal. A login linked to a customer
 * account, or to anything else, is refused.
 */
exports.ensurePortalAuthIdentityStep = (0, workflows_sdk_1.createStep)("ensure-portal-auth-identity", async ({ email, sales_rep_id }, { container }) => {
    const auth = container.resolve(utils_1.Modules.AUTH);
    const [existing] = await auth.listAuthIdentities({ provider_identities: { provider: PROVIDER, entity_id: email } }, { take: 1 });
    if (existing) {
        const kind = (0, portal_login_1.classifyExistingLogin)(existing.app_metadata, sales_rep_id);
        if (kind === "other_rep") {
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, `The login for ${email} already belongs to another sales rep`);
        }
        if (kind === "in_use") {
            throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, `${email} already has a login linked to another account on the shop (such as a customer account), so it can't be linked automatically. Use a different email for the rep`);
        }
        if (kind === "unclaimed") {
            // Not undone if a later step fails: the login has no owner either way
            const reset = await auth.updateProvider(PROVIDER, {
                entity_id: email,
                password: unknownPassword(),
            });
            if (!reset.success) {
                throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, reset.error ?? `Could not reset the old password for ${email}`);
            }
        }
        return new workflows_sdk_1.StepResponse({ auth_identity_id: existing.id, already_linked: kind === "linked" }, { id: existing.id, created: false });
    }
    const { success, authIdentity, error } = await auth.register(PROVIDER, {
        url: "",
        headers: {},
        query: {},
        protocol: "",
        body: { email, password: unknownPassword() },
    });
    if (!success || !authIdentity) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, error ?? `Could not create a login for ${email}`);
    }
    return new workflows_sdk_1.StepResponse({ auth_identity_id: authIdentity.id, already_linked: false }, { id: authIdentity.id, created: true });
}, async (prior, { container }) => {
    if (!prior?.created) {
        return;
    }
    await container.resolve(utils_1.Modules.AUTH).deleteAuthIdentities([prior.id]);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW5zdXJlLXBvcnRhbC1hdXRoLWlkZW50aXR5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy9lbnN1cmUtcG9ydGFsLWF1dGgtaWRlbnRpdHkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsbUNBQW9DO0FBQ3BDLHFEQUFnRTtBQUNoRSxxRUFBNEU7QUFDNUUseURBQThEO0FBRTlELE1BQU0sUUFBUSxHQUFHLFdBQVcsQ0FBQTtBQUU1QiwwRUFBMEU7QUFDMUUsTUFBTSxlQUFlLEdBQUcsR0FBRyxFQUFFLENBQUMsSUFBQSxvQkFBVyxFQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQTtBQUVuRTs7Ozs7Ozs7Ozs7Ozs7R0FjRztBQUNVLFFBQUEsNEJBQTRCLEdBQUcsSUFBQSwwQkFBVSxFQUNwRCw2QkFBNkIsRUFDN0IsS0FBSyxFQUNILEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBMkMsRUFDaEUsRUFBRSxTQUFTLEVBQUUsRUFDYixFQUFFO0lBQ0YsTUFBTSxJQUFJLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsSUFBSSxDQUFDLENBQUE7SUFFNUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUM5QyxFQUFFLG1CQUFtQixFQUFFLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFDakUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQ1osQ0FBQTtJQUNELElBQUksUUFBUSxFQUFFLENBQUM7UUFDYixNQUFNLElBQUksR0FBRyxJQUFBLG9DQUFxQixFQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsWUFBWSxDQUFDLENBQUE7UUFDdkUsSUFBSSxJQUFJLEtBQUssV0FBVyxFQUFFLENBQUM7WUFDekIsTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFDOUIsaUJBQWlCLEtBQUssdUNBQXVDLENBQzlELENBQUE7UUFDSCxDQUFDO1FBQ0QsSUFBSSxJQUFJLEtBQUssUUFBUSxFQUFFLENBQUM7WUFDdEIsTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFDOUIsR0FBRyxLQUFLLGlLQUFpSyxDQUMxSyxDQUFBO1FBQ0gsQ0FBQztRQUNELElBQUksSUFBSSxLQUFLLFdBQVcsRUFBRSxDQUFDO1lBQ3pCLHNFQUFzRTtZQUN0RSxNQUFNLEtBQUssR0FBRyxNQUFNLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFO2dCQUNoRCxTQUFTLEVBQUUsS0FBSztnQkFDaEIsUUFBUSxFQUFFLGVBQWUsRUFBRTthQUM1QixDQUFDLENBQUE7WUFDRixJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUNuQixNQUFNLElBQUksbUJBQVcsQ0FDbkIsbUJBQVcsQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUM5QixLQUFLLENBQUMsS0FBSyxJQUFJLHdDQUF3QyxLQUFLLEVBQUUsQ0FDL0QsQ0FBQTtZQUNILENBQUM7UUFDSCxDQUFDO1FBRUQsT0FBTyxJQUFJLDRCQUFZLENBQ3JCLEVBQUUsZ0JBQWdCLEVBQUUsUUFBUSxDQUFDLEVBQUUsRUFBRSxjQUFjLEVBQUUsSUFBSSxLQUFLLFFBQVEsRUFBRSxFQUNwRSxFQUFFLEVBQUUsRUFBRSxRQUFRLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FDcEMsQ0FBQTtJQUNILENBQUM7SUFFRCxNQUFNLEVBQUUsT0FBTyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO1FBQ3JFLEdBQUcsRUFBRSxFQUFFO1FBQ1AsT0FBTyxFQUFFLEVBQUU7UUFDWCxLQUFLLEVBQUUsRUFBRTtRQUNULFFBQVEsRUFBRSxFQUFFO1FBQ1osSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxlQUFlLEVBQUUsRUFBRTtLQUM3QyxDQUFDLENBQUE7SUFDRixJQUFJLENBQUMsT0FBTyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDOUIsTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksRUFDOUIsS0FBSyxJQUFJLGdDQUFnQyxLQUFLLEVBQUUsQ0FDakQsQ0FBQTtJQUNILENBQUM7SUFFRCxPQUFPLElBQUksNEJBQVksQ0FDckIsRUFBRSxnQkFBZ0IsRUFBRSxZQUFZLENBQUMsRUFBRSxFQUFFLGNBQWMsRUFBRSxLQUFLLEVBQUUsRUFDNUQsRUFBRSxFQUFFLEVBQUUsWUFBWSxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLENBQ3ZDLENBQUE7QUFDSCxDQUFDLEVBQ0QsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDN0IsSUFBSSxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsQ0FBQztRQUNwQixPQUFNO0lBQ1IsQ0FBQztJQUNELE1BQU0sU0FBUyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQTtBQUN4RSxDQUFDLENBQ0YsQ0FBQSJ9