"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DELETE = DELETE;
const delete_commission_payout_1 = require("../../../../../workflows/delete-commission-payout");
/** Removes a payout recorded by mistake (soft delete). */
async function DELETE(req, res) {
    await (0, delete_commission_payout_1.deleteCommissionPayoutWorkflow)(req.scope).run({
        input: { id: req.params.id },
    });
    res.json({ id: req.params.id, object: "commission_payout", deleted: true });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NhbGVzLWNvbW1pc3Npb24vcGF5b3V0cy9baWRdL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBT0Esd0JBU0M7QUFaRCxnR0FBa0c7QUFFbEcsMERBQTBEO0FBQ25ELEtBQUssVUFBVSxNQUFNLENBQzFCLEdBQStCLEVBQy9CLEdBQW1CO0lBRW5CLE1BQU0sSUFBQSx5REFBOEIsRUFBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDO1FBQ2xELEtBQUssRUFBRSxFQUFFLEVBQUUsRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRTtLQUM3QixDQUFDLENBQUE7SUFFRixHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE1BQU0sRUFBRSxtQkFBbUIsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtBQUM3RSxDQUFDIn0=