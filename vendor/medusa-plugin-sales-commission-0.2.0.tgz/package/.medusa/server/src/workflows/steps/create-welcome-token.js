"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createWelcomeTokenStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const PROVIDER = "emailpass";
const WELCOME_TOKEN_DAYS = 7;
/**
 * A link token a new rep uses to set their first password. It is a Medusa
 * reset-password token, used by the same page and consumed once by the same
 * route, but good for a week instead of 15 minutes, because the rep may open
 * the welcome email days after the owner approved. A rep whose link has run
 * out asks for a new one with forgot-password.
 */
exports.createWelcomeTokenStep = (0, workflows_sdk_1.createStep)("create-welcome-token", async ({ email }, { container }) => {
    const auth = container.resolve(utils_1.Modules.AUTH);
    const { http } = container.resolve(utils_1.ContainerRegistrationKeys.CONFIG_MODULE).projectConfig;
    const ttl_seconds = WELCOME_TOKEN_DAYS * 24 * 60 * 60;
    const { jti, expires_at } = await auth.createPasswordResetToken({
        provider: PROVIDER,
        entity_id: email,
        ttl_seconds,
    });
    if (!http.jwtSecret) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.UNEXPECTED_STATE, "The JWT secret isn't configured");
    }
    const token = (0, utils_1.generateJwtToken)({
        entity_id: email,
        provider: PROVIDER,
        actor_type: "sales_rep",
        purpose: "reset",
    }, {
        secret: http.jwtSecret,
        expiresIn: `${ttl_seconds}s`,
        jwtOptions: { ...http.jwtOptions, jwtid: jti },
    });
    return new workflows_sdk_1.StepResponse({ token, expires_at: new Date(expires_at).toISOString() }, { jti, email });
}, async (prior, { container }) => {
    if (!prior) {
        return;
    }
    try {
        await container.resolve(utils_1.Modules.AUTH).consumePasswordResetToken({
            jti: prior.jti,
            provider: PROVIDER,
            entity_id: prior.email,
        });
    }
    catch {
        // Already consumed: nothing left to undo
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLXdlbGNvbWUtdG9rZW4uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL3N0ZXBzL2NyZWF0ZS13ZWxjb21lLXRva2VuLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFEQUtrQztBQUNsQyxxRUFBNEU7QUFFNUUsTUFBTSxRQUFRLEdBQUcsV0FBVyxDQUFBO0FBQzVCLE1BQU0sa0JBQWtCLEdBQUcsQ0FBQyxDQUFBO0FBRTVCOzs7Ozs7R0FNRztBQUNVLFFBQUEsc0JBQXNCLEdBQUcsSUFBQSwwQkFBVSxFQUM5QyxzQkFBc0IsRUFDdEIsS0FBSyxFQUFFLEVBQUUsS0FBSyxFQUFxQixFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUNwRCxNQUFNLElBQUksR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGVBQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQTtJQUM1QyxNQUFNLEVBQUUsSUFBSSxFQUFFLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FDaEMsaUNBQXlCLENBQUMsYUFBYSxDQUN4QyxDQUFDLGFBQWEsQ0FBQTtJQUVmLE1BQU0sV0FBVyxHQUFHLGtCQUFrQixHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFBO0lBQ3JELE1BQU0sRUFBRSxHQUFHLEVBQUUsVUFBVSxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsd0JBQXdCLENBQUM7UUFDOUQsUUFBUSxFQUFFLFFBQVE7UUFDbEIsU0FBUyxFQUFFLEtBQUs7UUFDaEIsV0FBVztLQUNaLENBQUMsQ0FBQTtJQUNGLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDcEIsTUFBTSxJQUFJLG1CQUFXLENBQ25CLG1CQUFXLENBQUMsS0FBSyxDQUFDLGdCQUFnQixFQUNsQyxpQ0FBaUMsQ0FDbEMsQ0FBQTtJQUNILENBQUM7SUFFRCxNQUFNLEtBQUssR0FBRyxJQUFBLHdCQUFnQixFQUM1QjtRQUNFLFNBQVMsRUFBRSxLQUFLO1FBQ2hCLFFBQVEsRUFBRSxRQUFRO1FBQ2xCLFVBQVUsRUFBRSxXQUFXO1FBQ3ZCLE9BQU8sRUFBRSxPQUFPO0tBQ2pCLEVBQ0Q7UUFDRSxNQUFNLEVBQUUsSUFBSSxDQUFDLFNBQVM7UUFDdEIsU0FBUyxFQUFFLEdBQUcsV0FBVyxHQUFHO1FBQzVCLFVBQVUsRUFBRSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFO0tBQy9DLENBQ0YsQ0FBQTtJQUVELE9BQU8sSUFBSSw0QkFBWSxDQUNyQixFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsV0FBVyxFQUFFLEVBQUUsRUFDekQsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLENBQ2YsQ0FBQTtBQUNILENBQUMsRUFDRCxLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUM3QixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDWCxPQUFNO0lBQ1IsQ0FBQztJQUNELElBQUksQ0FBQztRQUNILE1BQU0sU0FBUyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsSUFBSSxDQUFDLENBQUMseUJBQXlCLENBQUM7WUFDOUQsR0FBRyxFQUFFLEtBQUssQ0FBQyxHQUFHO1lBQ2QsUUFBUSxFQUFFLFFBQVE7WUFDbEIsU0FBUyxFQUFFLEtBQUssQ0FBQyxLQUFLO1NBQ3ZCLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFBQyxNQUFNLENBQUM7UUFDUCx5Q0FBeUM7SUFDM0MsQ0FBQztBQUNILENBQUMsQ0FDRixDQUFBIn0=