"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = exports.reconcileClientLinks = void 0;
exports.default = reconcileClientLinksJob;
const utils_1 = require("@medusajs/framework/utils");
const client_link_1 = require("../lib/client-link");
const client_links_1 = require("../utils/client-links");
const LOOKBACK_DAYS = 3;
/**
 * Applies the client link of every account created since `since` that carries
 * one and has no answer yet. Applying is idempotent, so this only fills in
 * what a lost `customer.created` event left out.
 */
const reconcileClientLinks = async (container, { since }) => {
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const logger = container.resolve(utils_1.ContainerRegistrationKeys.LOGGER);
    const { data: customers } = await query.graph({
        entity: "customer",
        fields: ["id", "metadata"],
        filters: { created_at: { $gte: since }, has_account: true },
    });
    let claimed = 0;
    for (const customer of customers) {
        if (!(0, client_link_1.normalizeClientLinkCode)(customer.metadata?.[client_links_1.CLIENT_LINK_METADATA_KEY])) {
            continue;
        }
        try {
            const result = await (0, client_links_1.claimClientLink)(container, customer.id);
            claimed += result.status === "claimed" ? 1 : 0;
        }
        catch (error) {
            logger.error(`[sales-commission] Reconcile: client link of customer ${customer.id} failed: ${error.message}`);
        }
    }
    return { claimed };
};
exports.reconcileClientLinks = reconcileClientLinks;
async function reconcileClientLinksJob(container) {
    const logger = container.resolve(utils_1.ContainerRegistrationKeys.LOGGER);
    const since = new Date(Date.now() - LOOKBACK_DAYS * 24 * 60 * 60 * 1000);
    const { claimed } = await (0, exports.reconcileClientLinks)(container, { since });
    if (claimed) {
        logger.info(`[sales-commission] Reconciled client links of the last ${LOOKBACK_DAYS} days: ${claimed} applied`);
    }
}
exports.config = {
    name: "reconcile-sales-client-links",
    schedule: "30 2 * * *",
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVjb25jaWxlLWNsaWVudC1saW5rcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9qb2JzL3JlY29uY2lsZS1jbGllbnQtbGlua3MudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBMkNBLDBDQWFDO0FBdkRELHFEQUFxRTtBQUNyRSxvREFBNEQ7QUFDNUQsd0RBQWlGO0FBRWpGLE1BQU0sYUFBYSxHQUFHLENBQUMsQ0FBQTtBQUV2Qjs7OztHQUlHO0FBQ0ksTUFBTSxvQkFBb0IsR0FBRyxLQUFLLEVBQ3ZDLFNBQTBCLEVBQzFCLEVBQUUsS0FBSyxFQUFtQixFQUMxQixFQUFFO0lBQ0YsTUFBTSxLQUFLLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxpQ0FBeUIsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUNoRSxNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBRWxFLE1BQU0sRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQzVDLE1BQU0sRUFBRSxVQUFVO1FBQ2xCLE1BQU0sRUFBRSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUM7UUFDMUIsT0FBTyxFQUFFLEVBQUUsVUFBVSxFQUFFLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUU7S0FDNUQsQ0FBQyxDQUFBO0lBRUYsSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFBO0lBQ2YsS0FBSyxNQUFNLFFBQVEsSUFBSSxTQUFTLEVBQUUsQ0FBQztRQUNqQyxJQUFJLENBQUMsSUFBQSxxQ0FBdUIsRUFBQyxRQUFRLENBQUMsUUFBUSxFQUFFLENBQUMsdUNBQXdCLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFDNUUsU0FBUTtRQUNWLENBQUM7UUFDRCxJQUFJLENBQUM7WUFDSCxNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUEsOEJBQWUsRUFBQyxTQUFTLEVBQUUsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFBO1lBQzVELE9BQU8sSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7UUFDaEQsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixNQUFNLENBQUMsS0FBSyxDQUNWLHlEQUF5RCxRQUFRLENBQUMsRUFBRSxZQUFZLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FDaEcsQ0FBQTtRQUNILENBQUM7SUFDSCxDQUFDO0lBRUQsT0FBTyxFQUFFLE9BQU8sRUFBRSxDQUFBO0FBQ3BCLENBQUMsQ0FBQTtBQTdCWSxRQUFBLG9CQUFvQix3QkE2QmhDO0FBRWMsS0FBSyxVQUFVLHVCQUF1QixDQUNuRCxTQUEwQjtJQUUxQixNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQ2xFLE1BQU0sS0FBSyxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxhQUFhLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUE7SUFFeEUsTUFBTSxFQUFFLE9BQU8sRUFBRSxHQUFHLE1BQU0sSUFBQSw0QkFBb0IsRUFBQyxTQUFTLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO0lBRXBFLElBQUksT0FBTyxFQUFFLENBQUM7UUFDWixNQUFNLENBQUMsSUFBSSxDQUNULDBEQUEwRCxhQUFhLFVBQVUsT0FBTyxVQUFVLENBQ25HLENBQUE7SUFDSCxDQUFDO0FBQ0gsQ0FBQztBQUVZLFFBQUEsTUFBTSxHQUFHO0lBQ3BCLElBQUksRUFBRSw4QkFBOEI7SUFDcEMsUUFBUSxFQUFFLFlBQVk7Q0FDdkIsQ0FBQSJ9