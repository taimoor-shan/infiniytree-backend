"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = exports.reconcileCommissions = void 0;
exports.default = reconcileCommissionsJob;
const utils_1 = require("@medusajs/framework/utils");
const orders_for_payments_1 = require("../utils/orders-for-payments");
const record_order_commission_1 = require("../workflows/record-order-commission");
const void_order_commission_1 = require("../workflows/void-order-commission");
const LOOKBACK_DAYS = 7;
/**
 * Re-runs recording and voiding for payments captured, refunds made and
 * orders canceled since `since`. Both workflows are idempotent, so this only
 * fills in what a lost event (e.g. a restart mid-delivery) left out.
 */
const reconcileCommissions = async (container, { since }) => {
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const logger = container.resolve(utils_1.ContainerRegistrationKeys.LOGGER);
    const [{ data: captured }, { data: refunds }, { data: canceled }] = await Promise.all([
        query.graph({
            entity: "payment",
            fields: ["id"],
            filters: { captured_at: { $gte: since } },
        }),
        query.graph({
            entity: "refund",
            fields: ["payment_id"],
            filters: { created_at: { $gte: since } },
        }),
        query.graph({
            entity: "order",
            fields: ["id"],
            filters: { canceled_at: { $gte: since } },
        }),
    ]);
    let recorded = 0;
    for (const orderId of await (0, orders_for_payments_1.orderIdsForPayments)(container, captured.map((payment) => payment.id))) {
        try {
            const { result } = await (0, record_order_commission_1.recordOrderCommissionWorkflow)(container).run({
                input: { order_id: orderId },
            });
            recorded += result.length ? 1 : 0;
        }
        catch (error) {
            logger.error(`[sales-commission] Reconcile: recording order ${orderId} failed: ${error.message}`);
        }
    }
    let voided = 0;
    const voidOrder = async (orderId, reason) => {
        try {
            const { result } = await (0, void_order_commission_1.voidOrderCommissionWorkflow)(container).run({
                input: { order_id: orderId, reason },
            });
            voided += result?.length ? 1 : 0;
        }
        catch (error) {
            logger.error(`[sales-commission] Reconcile: voiding order ${orderId} failed: ${error.message}`);
        }
    };
    for (const order of canceled) {
        await voidOrder(order.id, "order_canceled");
    }
    for (const orderId of await (0, orders_for_payments_1.orderIdsForPayments)(container, refunds.map((refund) => refund.payment_id))) {
        await voidOrder(orderId, "order_refunded");
    }
    return { recorded, voided };
};
exports.reconcileCommissions = reconcileCommissions;
async function reconcileCommissionsJob(container) {
    const logger = container.resolve(utils_1.ContainerRegistrationKeys.LOGGER);
    const since = new Date(Date.now() - LOOKBACK_DAYS * 24 * 60 * 60 * 1000);
    const { recorded, voided } = await (0, exports.reconcileCommissions)(container, { since });
    logger.info(`[sales-commission] Reconciled the last ${LOOKBACK_DAYS} days: ${recorded} orders recorded, ${voided} voided`);
}
exports.config = {
    name: "reconcile-sales-commissions",
    schedule: "15 2 * * *",
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVjb25jaWxlLWNvbW1pc3Npb25zLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL2pvYnMvcmVjb25jaWxlLWNvbW1pc3Npb25zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQW1GQSwwQ0FXQztBQTdGRCxxREFBcUU7QUFDckUsc0VBQWtFO0FBQ2xFLGtGQUFvRjtBQUNwRiw4RUFBZ0Y7QUFHaEYsTUFBTSxhQUFhLEdBQUcsQ0FBQyxDQUFBO0FBRXZCOzs7O0dBSUc7QUFDSSxNQUFNLG9CQUFvQixHQUFHLEtBQUssRUFDdkMsU0FBMEIsRUFDMUIsRUFBRSxLQUFLLEVBQW1CLEVBQzFCLEVBQUU7SUFDRixNQUFNLEtBQUssR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFBO0lBQ2hFLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsTUFBTSxDQUFDLENBQUE7SUFFbEUsTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxDQUFDLEdBQy9ELE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUNoQixLQUFLLENBQUMsS0FBSyxDQUFDO1lBQ1YsTUFBTSxFQUFFLFNBQVM7WUFDakIsTUFBTSxFQUFFLENBQUMsSUFBSSxDQUFDO1lBQ2QsT0FBTyxFQUFFLEVBQUUsV0FBVyxFQUFFLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFO1NBQzFDLENBQUM7UUFDRixLQUFLLENBQUMsS0FBSyxDQUFDO1lBQ1YsTUFBTSxFQUFFLFFBQVE7WUFDaEIsTUFBTSxFQUFFLENBQUMsWUFBWSxDQUFDO1lBQ3RCLE9BQU8sRUFBRSxFQUFFLFVBQVUsRUFBRSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRTtTQUN6QyxDQUFDO1FBQ0YsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUNWLE1BQU0sRUFBRSxPQUFPO1lBQ2YsTUFBTSxFQUFFLENBQUMsSUFBSSxDQUFDO1lBQ2QsT0FBTyxFQUFFLEVBQUUsV0FBVyxFQUFFLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFO1NBQzFDLENBQUM7S0FDSCxDQUFDLENBQUE7SUFFSixJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUE7SUFDaEIsS0FBSyxNQUFNLE9BQU8sSUFBSSxNQUFNLElBQUEseUNBQW1CLEVBQzdDLFNBQVMsRUFDVCxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQ3RDLEVBQUUsQ0FBQztRQUNGLElBQUksQ0FBQztZQUNILE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLElBQUEsdURBQTZCLEVBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDO2dCQUNwRSxLQUFLLEVBQUUsRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFO2FBQzdCLENBQUMsQ0FBQTtZQUNGLFFBQVEsSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUNuQyxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE1BQU0sQ0FBQyxLQUFLLENBQ1YsaURBQWlELE9BQU8sWUFBWSxLQUFLLENBQUMsT0FBTyxFQUFFLENBQ3BGLENBQUE7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVELElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQTtJQUNkLE1BQU0sU0FBUyxHQUFHLEtBQUssRUFBRSxPQUFlLEVBQUUsTUFBa0IsRUFBRSxFQUFFO1FBQzlELElBQUksQ0FBQztZQUNILE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLElBQUEsbURBQTJCLEVBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDO2dCQUNsRSxLQUFLLEVBQUUsRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRTthQUNyQyxDQUFDLENBQUE7WUFDRixNQUFNLElBQUksTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7UUFDbEMsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixNQUFNLENBQUMsS0FBSyxDQUNWLCtDQUErQyxPQUFPLFlBQVksS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUNsRixDQUFBO1FBQ0gsQ0FBQztJQUNILENBQUMsQ0FBQTtJQUNELEtBQUssTUFBTSxLQUFLLElBQUksUUFBUSxFQUFFLENBQUM7UUFDN0IsTUFBTSxTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUUsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFBO0lBQzdDLENBQUM7SUFDRCxLQUFLLE1BQU0sT0FBTyxJQUFJLE1BQU0sSUFBQSx5Q0FBbUIsRUFDN0MsU0FBUyxFQUNULE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FDM0MsRUFBRSxDQUFDO1FBQ0YsTUFBTSxTQUFTLENBQUMsT0FBTyxFQUFFLGdCQUFnQixDQUFDLENBQUE7SUFDNUMsQ0FBQztJQUVELE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLENBQUE7QUFDN0IsQ0FBQyxDQUFBO0FBbkVZLFFBQUEsb0JBQW9CLHdCQW1FaEM7QUFFYyxLQUFLLFVBQVUsdUJBQXVCLENBQ25ELFNBQTBCO0lBRTFCLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsTUFBTSxDQUFDLENBQUE7SUFDbEUsTUFBTSxLQUFLLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLGFBQWEsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQTtJQUV4RSxNQUFNLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sSUFBQSw0QkFBb0IsRUFBQyxTQUFTLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFBO0lBRTdFLE1BQU0sQ0FBQyxJQUFJLENBQ1QsMENBQTBDLGFBQWEsVUFBVSxRQUFRLHFCQUFxQixNQUFNLFNBQVMsQ0FDOUcsQ0FBQTtBQUNILENBQUM7QUFFWSxRQUFBLE1BQU0sR0FBRztJQUNwQixJQUFJLEVBQUUsNkJBQTZCO0lBQ25DLFFBQVEsRUFBRSxZQUFZO0NBQ3ZCLENBQUEifQ==