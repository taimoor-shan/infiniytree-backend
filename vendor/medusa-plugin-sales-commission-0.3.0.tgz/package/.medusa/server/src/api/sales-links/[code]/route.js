"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const client_link_1 = require("../../../lib/client-link");
const sales_commission_1 = require("../../../modules/sales-commission");
/**
 * Whose link this is, for the storefront to say "you're joining through Peter
 * Nagy" next to the sign-up form. Public, and shows only the rep's name, which
 * the rep shares by sharing the link. A code nobody has, or a rep who can't
 * take clients, answers the same way, so nothing is learned by guessing.
 */
async function GET(req, res) {
    const service = req.scope.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    res.setHeader("Cache-Control", "no-store");
    const code = (0, client_link_1.normalizeClientLinkCode)(req.params.code);
    const [rep] = code
        ? await service.listSalesReps({ client_link_code: code }, { take: 1 })
        : [];
    if (!rep || !rep.is_active) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, "This link isn't valid", "link_invalid");
    }
    res.json({ link: { rep_name: rep.name } });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3NhbGVzLWxpbmtzL1tjb2RlXS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVlBLGtCQW9CQztBQS9CRCxxREFBdUQ7QUFDdkQsMERBQWtFO0FBQ2xFLHdFQUEyRTtBQUczRTs7Ozs7R0FLRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUMvRCxNQUFNLE9BQU8sR0FBaUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsR0FBRyxDQUFDLFNBQVMsQ0FBQyxlQUFlLEVBQUUsVUFBVSxDQUFDLENBQUE7SUFFMUMsTUFBTSxJQUFJLEdBQUcsSUFBQSxxQ0FBdUIsRUFBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFBO0lBQ3JELE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJO1FBQ2hCLENBQUMsQ0FBQyxNQUFNLE9BQU8sQ0FBQyxhQUFhLENBQUMsRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQztRQUN0RSxDQUFDLENBQUMsRUFBRSxDQUFBO0lBRU4sSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUMzQixNQUFNLElBQUksbUJBQVcsQ0FDbkIsbUJBQVcsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUMzQix1QkFBdUIsRUFDdkIsY0FBYyxDQUNmLENBQUE7SUFDSCxDQUFDO0lBRUQsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFLFFBQVEsRUFBRSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFBO0FBQzVDLENBQUMifQ==