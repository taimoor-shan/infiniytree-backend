"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.voidOrderCommissionStep = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const partial_refund_1 = require("../../lib/partial-refund");
const period_1 = require("../../lib/period");
const sales_commission_1 = require("../../modules/sales-commission");
const locks_1 = require("../../utils/locks");
/**
 * Marks the order's live entries void. They stay on record; the report
 * reverses them in the month of the void if that is a later month. The void
 * takes back each entry in full, so what partial refunds took back earlier is
 * given back with offsetting adjustments, and nothing is taken twice.
 */
exports.voidOrderCommissionStep = (0, workflows_sdk_1.createStep)("void-order-commission", async (input, { container }) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const done = await (0, locks_1.withLock)(container, (0, locks_1.orderLockKey)(input.order_id), async () => {
        const live = await service.listCommissionEntries({
            order_id: input.order_id,
            voided_at: null,
        });
        if (!live.length) {
            return null;
        }
        const voidPeriod = (0, period_1.toPeriod)(input.voided_at, service.getOptions().timezone);
        const voided = await service.updateCommissionEntries(live.map((entry) => ({
            id: entry.id,
            voided_at: input.voided_at,
            void_period: voidPeriod,
            void_reason: input.reason,
        })));
        const offsets = (0, partial_refund_1.partialRefundOffsets)({
            entries: live,
            previous: await service.listCommissionAdjustments({
                kind: "partial_refund",
                source_id: live.map((entry) => entry.id),
            }),
            why: input.reason,
        });
        const adjustments = offsets.length
            ? await service.createCommissionAdjustments(offsets.map((offset) => ({
                ...offset,
                period: voidPeriod,
                created_by: null,
            })))
            : [];
        return {
            voided,
            entryIds: live.map((entry) => entry.id),
            adjustmentIds: adjustments.map((adjustment) => adjustment.id),
        };
    });
    if (!done) {
        return new workflows_sdk_1.StepResponse([], { entryIds: [], adjustmentIds: [] });
    }
    return new workflows_sdk_1.StepResponse(done.voided, {
        entryIds: done.entryIds,
        adjustmentIds: done.adjustmentIds,
    });
}, async (undo, { container }) => {
    if (!undo?.entryIds.length) {
        return;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    await service.updateCommissionEntries(undo.entryIds.map((id) => ({
        id,
        voided_at: null,
        void_period: null,
        void_reason: null,
    })));
    if (undo.adjustmentIds.length) {
        await service.deleteCommissionAdjustments(undo.adjustmentIds);
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidm9pZC1vcmRlci1jb21taXNzaW9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3dvcmtmbG93cy9zdGVwcy92b2lkLW9yZGVyLWNvbW1pc3Npb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscUVBQTRFO0FBQzVFLDZEQUErRDtBQUMvRCw2Q0FBMkM7QUFDM0MscUVBQXdFO0FBRXhFLDZDQUEwRDtBQVUxRDs7Ozs7R0FLRztBQUNVLFFBQUEsdUJBQXVCLEdBQUcsSUFBQSwwQkFBVSxFQUMvQyx1QkFBdUIsRUFDdkIsS0FBSyxFQUFFLEtBQW1DLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQzNELE1BQU0sT0FBTyxHQUFpQyxTQUFTLENBQUMsT0FBTyxDQUM3RCwwQ0FBdUIsQ0FDeEIsQ0FBQTtJQUVELE1BQU0sSUFBSSxHQUFHLE1BQU0sSUFBQSxnQkFBUSxFQUFDLFNBQVMsRUFBRSxJQUFBLG9CQUFZLEVBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEtBQUssSUFBSSxFQUFFO1FBQzlFLE1BQU0sSUFBSSxHQUFHLE1BQU0sT0FBTyxDQUFDLHFCQUFxQixDQUFDO1lBQy9DLFFBQVEsRUFBRSxLQUFLLENBQUMsUUFBUTtZQUN4QixTQUFTLEVBQUUsSUFBSTtTQUNoQixDQUFDLENBQUE7UUFDRixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2pCLE9BQU8sSUFBSSxDQUFBO1FBQ2IsQ0FBQztRQUVELE1BQU0sVUFBVSxHQUFHLElBQUEsaUJBQVEsRUFBQyxLQUFLLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQTtRQUMzRSxNQUFNLE1BQU0sR0FBRyxNQUFNLE9BQU8sQ0FBQyx1QkFBdUIsQ0FDbEQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztZQUNuQixFQUFFLEVBQUUsS0FBSyxDQUFDLEVBQUU7WUFDWixTQUFTLEVBQUUsS0FBSyxDQUFDLFNBQVM7WUFDMUIsV0FBVyxFQUFFLFVBQVU7WUFDdkIsV0FBVyxFQUFFLEtBQUssQ0FBQyxNQUFNO1NBQzFCLENBQUMsQ0FBQyxDQUNKLENBQUE7UUFFRCxNQUFNLE9BQU8sR0FBRyxJQUFBLHFDQUFvQixFQUFDO1lBQ25DLE9BQU8sRUFBRSxJQUFJO1lBQ2IsUUFBUSxFQUFFLE1BQU0sT0FBTyxDQUFDLHlCQUF5QixDQUFDO2dCQUNoRCxJQUFJLEVBQUUsZ0JBQWdCO2dCQUN0QixTQUFTLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQzthQUN6QyxDQUFDO1lBQ0YsR0FBRyxFQUFFLEtBQUssQ0FBQyxNQUFNO1NBQ2xCLENBQUMsQ0FBQTtRQUNGLE1BQU0sV0FBVyxHQUFHLE9BQU8sQ0FBQyxNQUFNO1lBQ2hDLENBQUMsQ0FBQyxNQUFNLE9BQU8sQ0FBQywyQkFBMkIsQ0FDdkMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDdkIsR0FBRyxNQUFNO2dCQUNULE1BQU0sRUFBRSxVQUFVO2dCQUNsQixVQUFVLEVBQUUsSUFBSTthQUNqQixDQUFDLENBQUMsQ0FDSjtZQUNILENBQUMsQ0FBQyxFQUFFLENBQUE7UUFFTixPQUFPO1lBQ0wsTUFBTTtZQUNOLFFBQVEsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ3ZDLGFBQWEsRUFBRSxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDO1NBQzlELENBQUE7SUFDSCxDQUFDLENBQUMsQ0FBQTtJQUNGLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNWLE9BQU8sSUFBSSw0QkFBWSxDQUFDLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFjLEVBQUUsYUFBYSxFQUFFLEVBQWMsRUFBRSxDQUFDLENBQUE7SUFDMUYsQ0FBQztJQUVELE9BQU8sSUFBSSw0QkFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7UUFDbkMsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO1FBQ3ZCLGFBQWEsRUFBRSxJQUFJLENBQUMsYUFBYTtLQUNsQyxDQUFDLENBQUE7QUFDSixDQUFDLEVBQ0QsS0FBSyxFQUFFLElBQUksRUFBRSxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUU7SUFDNUIsSUFBSSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDM0IsT0FBTTtJQUNSLENBQUM7SUFDRCxNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLE9BQU8sQ0FBQyx1QkFBdUIsQ0FDbkMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDekIsRUFBRTtRQUNGLFNBQVMsRUFBRSxJQUFJO1FBQ2YsV0FBVyxFQUFFLElBQUk7UUFDakIsV0FBVyxFQUFFLElBQUk7S0FDbEIsQ0FBQyxDQUFDLENBQ0osQ0FBQTtJQUNELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUM5QixNQUFNLE9BQU8sQ0FBQywyQkFBMkIsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUE7SUFDL0QsQ0FBQztBQUNILENBQUMsQ0FDRixDQUFBIn0=