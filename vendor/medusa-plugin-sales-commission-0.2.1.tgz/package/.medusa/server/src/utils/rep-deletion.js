"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadRepDeletionBlockers = exports.loadRepDeletionFacts = void 0;
const rep_deletion_1 = require("../lib/rep-deletion");
const sales_commission_1 = require("../modules/sales-commission");
const pending_1 = require("./pending");
/** The count from a `listAndCount…` call, whatever the rows' type */
const countOf = async (rows) => (await rows)[1];
/**
 * What a rep has on record, as far as deleting them is concerned. Counts only:
 * one row is enough to know, so nothing is read in full.
 */
const loadRepDeletionFacts = async (container, repId, now = new Date()) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const [earned, earnedFromClients, adjustments, payouts, clients, referrals, applications, pending,] = await Promise.all([
        countOf(service.listAndCountCommissionEntries({ sales_rep_id: repId }, { take: 1 })),
        countOf(service.listAndCountCommissionEntries({ source_sales_rep_id: repId }, { take: 1 })),
        countOf(service.listAndCountCommissionAdjustments({ sales_rep_id: repId }, { take: 1 })),
        countOf(service.listAndCountCommissionPayouts({ sales_rep_id: repId }, { take: 1 })),
        service.listClientAssignments({ sales_rep_id: repId }),
        service.listRepReferrals({ referrer_sales_rep_id: repId }),
        countOf(service.listAndCountRepInvites({ recruiter_sales_rep_id: repId, status: "applied" }, { take: 1 })),
        (0, pending_1.loadPendingLines)(container, { salesRepId: repId }),
    ]);
    // Still in force: not ended, and not run out. Ended ones are history
    const running = (row) => (!row.ends_at || new Date(row.ends_at) > now) &&
        (!row.expires_at || new Date(row.expires_at) > now);
    return {
        commission_entries: earned + earnedFromClients,
        adjustments,
        payouts,
        clients: clients.filter(running).length,
        recruits: referrals.filter(running).length,
        applications,
        unpaid_orders: new Set(pending.map((line) => line.order_id)).size,
    };
};
exports.loadRepDeletionFacts = loadRepDeletionFacts;
const loadRepDeletionBlockers = async (container, repId) => (0, rep_deletion_1.repDeletionBlockers)(await (0, exports.loadRepDeletionFacts)(container, repId));
exports.loadRepDeletionBlockers = loadRepDeletionBlockers;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVwLWRlbGV0aW9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3V0aWxzL3JlcC1kZWxldGlvbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxzREFBMkU7QUFDM0Usa0VBQXFFO0FBRXJFLHVDQUE0QztBQUU1QyxxRUFBcUU7QUFDckUsTUFBTSxPQUFPLEdBQUcsS0FBSyxFQUFFLElBQXNCLEVBQW1CLEVBQUUsQ0FDL0QsQ0FBQyxNQUFNLElBQUksQ0FBeUIsQ0FBQyxDQUFDLENBQUMsQ0FBQTtBQUUxQzs7O0dBR0c7QUFDSSxNQUFNLG9CQUFvQixHQUFHLEtBQUssRUFDdkMsU0FBMEIsRUFDMUIsS0FBYSxFQUNiLEdBQUcsR0FBRyxJQUFJLElBQUksRUFBRSxFQUNXLEVBQUU7SUFDN0IsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBRUQsTUFBTSxDQUNKLE1BQU0sRUFDTixpQkFBaUIsRUFDakIsV0FBVyxFQUNYLE9BQU8sRUFDUCxPQUFPLEVBQ1AsU0FBUyxFQUNULFlBQVksRUFDWixPQUFPLEVBQ1IsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7UUFDcEIsT0FBTyxDQUFDLE9BQU8sQ0FBQyw2QkFBNkIsQ0FBQyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3BGLE9BQU8sQ0FDTCxPQUFPLENBQUMsNkJBQTZCLENBQUMsRUFBRSxtQkFBbUIsRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUNuRjtRQUNELE9BQU8sQ0FDTCxPQUFPLENBQUMsaUNBQWlDLENBQUMsRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FDaEY7UUFDRCxPQUFPLENBQUMsT0FBTyxDQUFDLDZCQUE2QixDQUFDLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDcEYsT0FBTyxDQUFDLHFCQUFxQixDQUFDLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBRSxDQUFDO1FBQ3RELE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLHFCQUFxQixFQUFFLEtBQUssRUFBRSxDQUFDO1FBQzFELE9BQU8sQ0FDTCxPQUFPLENBQUMsc0JBQXNCLENBQzVCLEVBQUUsc0JBQXNCLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFDcEQsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQ1osQ0FDRjtRQUNELElBQUEsMEJBQWdCLEVBQUMsU0FBUyxFQUFFLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxDQUFDO0tBQ25ELENBQUMsQ0FBQTtJQUVGLHFFQUFxRTtJQUNyRSxNQUFNLE9BQU8sR0FBRyxDQUFDLEdBR2hCLEVBQUUsRUFBRSxDQUNILENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxJQUFJLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxHQUFHLENBQUM7UUFDN0MsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLElBQUksSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFBO0lBRXJELE9BQU87UUFDTCxrQkFBa0IsRUFBRSxNQUFNLEdBQUcsaUJBQWlCO1FBQzlDLFdBQVc7UUFDWCxPQUFPO1FBQ1AsT0FBTyxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTTtRQUN2QyxRQUFRLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNO1FBQzFDLFlBQVk7UUFDWixhQUFhLEVBQUUsSUFBSSxHQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSTtLQUNsRSxDQUFBO0FBQ0gsQ0FBQyxDQUFBO0FBdkRZLFFBQUEsb0JBQW9CLHdCQXVEaEM7QUFFTSxNQUFNLHVCQUF1QixHQUFHLEtBQUssRUFDMUMsU0FBMEIsRUFDMUIsS0FBYSxFQUNiLEVBQUUsQ0FBQyxJQUFBLGtDQUFtQixFQUFDLE1BQU0sSUFBQSw0QkFBb0IsRUFBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQTtBQUh6RCxRQUFBLHVCQUF1QiwyQkFHa0MifQ==