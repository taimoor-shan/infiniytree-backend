"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.linkedRepExists = void 0;
/**
 * Whether the rep a login is linked to still exists. A login keeps the link to
 * a rep that was deleted, and that link must not keep the email from the next
 * rep who uses it. True when the login isn't linked to another rep at all.
 */
const linkedRepExists = async (service, appMetadata, salesRepId) => {
    const linked = appMetadata?.sales_rep_id;
    if (typeof linked !== "string" || !linked || linked === salesRepId) {
        return true;
    }
    const [rep] = await service.listSalesReps({ id: linked }, { take: 1, select: ["id"] });
    return !!rep;
};
exports.linkedRepExists = linkedRepExists;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9ydGFsLWxvZ2luLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3V0aWxzL3BvcnRhbC1sb2dpbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFFQTs7OztHQUlHO0FBQ0ksTUFBTSxlQUFlLEdBQUcsS0FBSyxFQUNsQyxPQUFxQyxFQUNyQyxXQUF1RCxFQUN2RCxVQUFrQixFQUNBLEVBQUU7SUFDcEIsTUFBTSxNQUFNLEdBQUcsV0FBVyxFQUFFLFlBQVksQ0FBQTtJQUN4QyxJQUFJLE9BQU8sTUFBTSxLQUFLLFFBQVEsSUFBSSxDQUFDLE1BQU0sSUFBSSxNQUFNLEtBQUssVUFBVSxFQUFFLENBQUM7UUFDbkUsT0FBTyxJQUFJLENBQUE7SUFDYixDQUFDO0lBRUQsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLGFBQWEsQ0FDdkMsRUFBRSxFQUFFLEVBQUUsTUFBTSxFQUFFLEVBQ2QsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQzVCLENBQUE7SUFFRCxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUE7QUFDZCxDQUFDLENBQUE7QUFoQlksUUFBQSxlQUFlLG1CQWdCM0IifQ==