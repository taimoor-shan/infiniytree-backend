"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveFxRate = exports.fetchEcbRates = exports.ECB_90_DAYS_URL = exports.ECB_DAILY_URL = void 0;
const utils_1 = require("@medusajs/framework/utils");
const fx_1 = require("../lib/fx");
const period_1 = require("../lib/period");
const sales_commission_1 = require("../modules/sales-commission");
exports.ECB_DAILY_URL = "https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml";
exports.ECB_90_DAYS_URL = "https://www.ecb.europa.eu/stats/eurofxref/eurofxref-hist-90d.xml";
const pair = { base_currency_code: fx_1.FX_BASE, quote_currency_code: fx_1.FX_QUOTE };
/**
 * Downloads an ECB rate file and stores the days we don't have yet; days we
 * have are left alone, including rates entered by hand. Returns how many days
 * were added.
 */
const fetchEcbRates = async (container, url = exports.ECB_90_DAYS_URL) => {
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const response = await fetch(url, { signal: AbortSignal.timeout(15_000) });
    if (!response.ok) {
        throw new Error(`The ECB answered ${response.status}`);
    }
    const days = (0, fx_1.parseEcbRates)(await response.text());
    if (!days.length) {
        throw new Error("The ECB file had no HUF rates");
    }
    const known = await service.listFxRates({ ...pair, rate_date: days.map((day) => day.rate_date) }, { select: ["rate_date"] });
    const have = new Set(known.map((row) => row.rate_date));
    const fresh = days.filter((day) => !have.has(day.rate_date));
    if (fresh.length) {
        await service.createFxRates(fresh.map((day) => ({ ...pair, ...day, source: "ecb" })));
    }
    return fresh.length;
};
exports.fetchEcbRates = fetchEcbRates;
/**
 * The rate to convert `from` into `to` for the day `at` falls on, in the
 * plugin's time zone: the stored rate of that day, else the last one before
 * it. When none is recent enough, the missing days are fetched from the ECB
 * (unless `fx_auto_fetch` is off). Nothing is guessed: with no rate this
 * throws, and the caller retries later.
 */
const resolveFxRate = async (container, { from, to, at }) => {
    if (from.toLowerCase() === to.toLowerCase()) {
        return null;
    }
    const service = container.resolve(sales_commission_1.SALES_COMMISSION_MODULE);
    const logger = container.resolve(utils_1.ContainerRegistrationKeys.LOGGER);
    const { timezone, fx_auto_fetch } = service.getOptions();
    const date = (0, period_1.toLocalDate)(at, timezone);
    const load = async () => (0, fx_1.rateInForce)(await service.listFxRates({ ...pair, rate_date: { $lte: date } }, { order: { rate_date: "DESC" }, take: 10 }), date);
    let row = await load();
    if (!row && fx_auto_fetch !== false) {
        try {
            await (0, exports.fetchEcbRates)(container);
        }
        catch (error) {
            logger.warn(`[sales-commission] Could not fetch exchange rates: ${error.message}`);
        }
        row = await load();
    }
    if (!row) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, `There is no EUR/HUF exchange rate for ${date}. Add one by hand, or try again once the ECB has published`);
    }
    return {
        rate: (0, fx_1.crossRate)({ from, to, eurRate: row.rate }),
        rate_date: row.rate_date,
        source: row.source,
    };
};
exports.resolveFxRate = resolveFxRate;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZnguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvdXRpbHMvZngudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQ0EscURBQWtGO0FBQ2xGLGtDQU1rQjtBQUNsQiwwQ0FBMkM7QUFDM0Msa0VBQXFFO0FBR3hELFFBQUEsYUFBYSxHQUN4QiwrREFBK0QsQ0FBQTtBQUNwRCxRQUFBLGVBQWUsR0FDMUIsa0VBQWtFLENBQUE7QUFFcEUsTUFBTSxJQUFJLEdBQUcsRUFBRSxrQkFBa0IsRUFBRSxZQUFPLEVBQUUsbUJBQW1CLEVBQUUsYUFBUSxFQUFFLENBQUE7QUFFM0U7Ozs7R0FJRztBQUNJLE1BQU0sYUFBYSxHQUFHLEtBQUssRUFDaEMsU0FBMEIsRUFDMUIsR0FBRyxHQUFHLHVCQUFlLEVBQ0osRUFBRTtJQUNuQixNQUFNLE9BQU8sR0FBaUMsU0FBUyxDQUFDLE9BQU8sQ0FDN0QsMENBQXVCLENBQ3hCLENBQUE7SUFDRCxNQUFNLFFBQVEsR0FBRyxNQUFNLEtBQUssQ0FBQyxHQUFHLEVBQUUsRUFBRSxNQUFNLEVBQUUsV0FBVyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUE7SUFDMUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQztRQUNqQixNQUFNLElBQUksS0FBSyxDQUFDLG9CQUFvQixRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQTtJQUN4RCxDQUFDO0lBQ0QsTUFBTSxJQUFJLEdBQUcsSUFBQSxrQkFBYSxFQUFDLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUE7SUFDakQsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNqQixNQUFNLElBQUksS0FBSyxDQUFDLCtCQUErQixDQUFDLENBQUE7SUFDbEQsQ0FBQztJQUVELE1BQU0sS0FBSyxHQUFHLE1BQU0sT0FBTyxDQUFDLFdBQVcsQ0FDckMsRUFBRSxHQUFHLElBQUksRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxFQUFFLEVBQ3hELEVBQUUsTUFBTSxFQUFFLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FDMUIsQ0FBQTtJQUNELE1BQU0sSUFBSSxHQUFHLElBQUksR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFBO0lBQ3ZELE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQTtJQUM1RCxJQUFJLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNqQixNQUFNLE9BQU8sQ0FBQyxhQUFhLENBQ3pCLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLElBQUksRUFBRSxHQUFHLEdBQUcsRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUN6RCxDQUFBO0lBQ0gsQ0FBQztJQUVELE9BQU8sS0FBSyxDQUFDLE1BQU0sQ0FBQTtBQUNyQixDQUFDLENBQUE7QUE3QlksUUFBQSxhQUFhLGlCQTZCekI7QUFTRDs7Ozs7O0dBTUc7QUFDSSxNQUFNLGFBQWEsR0FBRyxLQUFLLEVBQ2hDLFNBQTBCLEVBQzFCLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQTBDLEVBQ3hCLEVBQUU7SUFDbEMsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFLEtBQUssRUFBRSxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQUM7UUFDNUMsT0FBTyxJQUFJLENBQUE7SUFDYixDQUFDO0lBQ0QsTUFBTSxPQUFPLEdBQWlDLFNBQVMsQ0FBQyxPQUFPLENBQzdELDBDQUF1QixDQUN4QixDQUFBO0lBQ0QsTUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxpQ0FBeUIsQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUNsRSxNQUFNLEVBQUUsUUFBUSxFQUFFLGFBQWEsRUFBRSxHQUFHLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQTtJQUN4RCxNQUFNLElBQUksR0FBRyxJQUFBLG9CQUFXLEVBQUMsRUFBRSxFQUFFLFFBQVEsQ0FBQyxDQUFBO0lBRXRDLE1BQU0sSUFBSSxHQUFHLEtBQUssSUFBSSxFQUFFLENBQ3RCLElBQUEsZ0JBQVcsRUFDVCxNQUFNLE9BQU8sQ0FBQyxXQUFXLENBQ3ZCLEVBQUUsR0FBRyxJQUFJLEVBQUUsU0FBUyxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQ3RDLEVBQUUsS0FBSyxFQUFFLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsQ0FDM0MsRUFDRCxJQUFJLENBQ0wsQ0FBQTtJQUVILElBQUksR0FBRyxHQUFHLE1BQU0sSUFBSSxFQUFFLENBQUE7SUFDdEIsSUFBSSxDQUFDLEdBQUcsSUFBSSxhQUFhLEtBQUssS0FBSyxFQUFFLENBQUM7UUFDcEMsSUFBSSxDQUFDO1lBQ0gsTUFBTSxJQUFBLHFCQUFhLEVBQUMsU0FBUyxDQUFDLENBQUE7UUFDaEMsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixNQUFNLENBQUMsSUFBSSxDQUNULHNEQUF1RCxLQUFlLENBQUMsT0FBTyxFQUFFLENBQ2pGLENBQUE7UUFDSCxDQUFDO1FBQ0QsR0FBRyxHQUFHLE1BQU0sSUFBSSxFQUFFLENBQUE7SUFDcEIsQ0FBQztJQUNELElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNULE1BQU0sSUFBSSxtQkFBVyxDQUNuQixtQkFBVyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQzNCLHlDQUF5QyxJQUFJLDREQUE0RCxDQUMxRyxDQUFBO0lBQ0gsQ0FBQztJQUVELE9BQU87UUFDTCxJQUFJLEVBQUUsSUFBQSxjQUFTLEVBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDaEQsU0FBUyxFQUFFLEdBQUcsQ0FBQyxTQUFTO1FBQ3hCLE1BQU0sRUFBRSxHQUFHLENBQUMsTUFBTTtLQUNuQixDQUFBO0FBQ0gsQ0FBQyxDQUFBO0FBOUNZLFFBQUEsYUFBYSxpQkE4Q3pCIn0=