"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCommissionAdjustmentWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const create_commission_adjustment_1 = require("./steps/create-commission-adjustment");
exports.createCommissionAdjustmentWorkflow = (0, workflows_sdk_1.createWorkflow)("create-commission-adjustment", function (input) {
    const adjustment = (0, create_commission_adjustment_1.createCommissionAdjustmentStep)(input);
    return new workflows_sdk_1.WorkflowResponse(adjustment);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLWNvbW1pc3Npb24tYWRqdXN0bWVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3MvY3JlYXRlLWNvbW1pc3Npb24tYWRqdXN0bWVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxRUFHMEM7QUFDMUMsdUZBRzZDO0FBRWhDLFFBQUEsa0NBQWtDLEdBQUcsSUFBQSw4QkFBYyxFQUM5RCw4QkFBOEIsRUFDOUIsVUFBVSxLQUEwQztJQUNsRCxNQUFNLFVBQVUsR0FBRyxJQUFBLDZEQUE4QixFQUFDLEtBQUssQ0FBQyxDQUFBO0lBRXhELE9BQU8sSUFBSSxnQ0FBZ0IsQ0FBQyxVQUFVLENBQUMsQ0FBQTtBQUN6QyxDQUFDLENBQ0YsQ0FBQSJ9