"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.linkPortalAuthIdentityStep = void 0;
const utils_1 = require("@medusajs/framework/utils");
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
/**
 * Links a login (Medusa auth identity) to a rep as the `sales_rep` actor, which
 * is what makes a sign-in with it carry the rep's id.
 *
 * Medusa's own step for this refuses a login that has the key already, even
 * with a null value, and a login can never lose the key: updates merge the app
 * metadata. The login of a rep who was deleted keeps pointing at them, so the
 * next rep to use the email would be refused. Writing the key directly links
 * the new rep. Only called for a login that is not linked to a rep who still
 * exists: `ensurePortalAuthIdentityStep` decides that.
 */
exports.linkPortalAuthIdentityStep = (0, workflows_sdk_1.createStep)("link-portal-auth-identity", async (input, { container }) => {
    const auth = container.resolve(utils_1.Modules.AUTH);
    const identity = await auth.retrieveAuthIdentity(input.auth_identity_id);
    const previous = identity.app_metadata?.sales_rep_id ?? null;
    await auth.updateAuthIdentities({
        id: identity.id,
        app_metadata: { sales_rep_id: input.sales_rep_id },
    });
    return new workflows_sdk_1.StepResponse(null, { id: identity.id, previous });
}, async (prior, { container }) => {
    if (!prior) {
        return;
    }
    // The key can't be removed, only set back
    await container.resolve(utils_1.Modules.AUTH).updateAuthIdentities({
        id: prior.id,
        app_metadata: { sales_rep_id: prior.previous },
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGluay1wb3J0YWwtYXV0aC1pZGVudGl0eS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy93b3JrZmxvd3Mvc3RlcHMvbGluay1wb3J0YWwtYXV0aC1pZGVudGl0eS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxREFBbUQ7QUFDbkQscUVBQTRFO0FBRTVFOzs7Ozs7Ozs7O0dBVUc7QUFDVSxRQUFBLDBCQUEwQixHQUFHLElBQUEsMEJBQVUsRUFDbEQsMkJBQTJCLEVBQzNCLEtBQUssRUFDSCxLQUF5RCxFQUN6RCxFQUFFLFNBQVMsRUFBRSxFQUNiLEVBQUU7SUFDRixNQUFNLElBQUksR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGVBQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQTtJQUM1QyxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQTtJQUN4RSxNQUFNLFFBQVEsR0FBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFlBQThCLElBQUksSUFBSSxDQUFBO0lBRS9FLE1BQU0sSUFBSSxDQUFDLG9CQUFvQixDQUFDO1FBQzlCLEVBQUUsRUFBRSxRQUFRLENBQUMsRUFBRTtRQUNmLFlBQVksRUFBRSxFQUFFLFlBQVksRUFBRSxLQUFLLENBQUMsWUFBWSxFQUFFO0tBQ25ELENBQUMsQ0FBQTtJQUVGLE9BQU8sSUFBSSw0QkFBWSxDQUFDLElBQUksRUFBRSxFQUFFLEVBQUUsRUFBRSxRQUFRLENBQUMsRUFBRSxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUE7QUFDOUQsQ0FBQyxFQUNELEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFO0lBQzdCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNYLE9BQU07SUFDUixDQUFDO0lBQ0QsMENBQTBDO0lBQzFDLE1BQU0sU0FBUyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsb0JBQW9CLENBQUM7UUFDekQsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFO1FBQ1osWUFBWSxFQUFFLEVBQUUsWUFBWSxFQUFFLEtBQUssQ0FBQyxRQUFRLEVBQUU7S0FDL0MsQ0FBQyxDQUFBO0FBQ0osQ0FBQyxDQUNGLENBQUEifQ==